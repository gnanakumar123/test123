package com.anthem.marketplace.dataconsolidation.model;

import java.io.Serializable;
import java.util.Date;

public class PolicyHolderDetails implements Serializable {

	private String firstName;
	private String lastName;
	private String uwLevel;
	private Date dateOfBirth;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUwLevel() {
		return uwLevel;
	}
	public void setUwLevel(String uwLevel) {
		this.uwLevel = uwLevel;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
}
