package com.anthem.marketplace.dataconsolidation.utils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/*
 * This class reads ingest and transform related parameters from properties file and returns them.  
 */

public class GetSysProperties {
	static final  Logger logger = LoggerFactory.getLogger(InvokeType.class);
	private static HashMap<String,String> propList = new HashMap<String,String>();
	private static GetSysProperties instance;

	private GetSysProperties() throws IOException, NoSuchMethodException, ClassNotFoundException,
			InvocationTargetException, IllegalAccessException {

		propList = readProp("eas.properties");


	}



	public HashMap<String,String> getPropertyContext() {
		return propList;
	}
	

	public static synchronized GetSysProperties getInstance() { // type needs to
																// be passed...
		if (null == instance) {
			try {
				instance = new GetSysProperties();

			} catch (Exception e) {
				logger.error("Error{}", e);
			}
			
		}
		return instance;
	}
	
	
	private HashMap<String,String> readProp(String configpath) throws IOException, NoSuchMethodException,
			ClassNotFoundException, InvocationTargetException, IllegalAccessException {
		HashMap<String,String> strList = new HashMap<String,String>();
		Properties prop = new Properties();
		prop.load(InvokeType.class.getResourceAsStream("/"+configpath));
		Enumeration<?> propertyNames = prop.propertyNames();
		while (propertyNames.hasMoreElements()) {
			String key = (String) propertyNames.nextElement();
			String tempPropertyValue = prop.getProperty(key);
				strList.put(key,tempPropertyValue);
				
		}

		return strList;
	}	
	
}