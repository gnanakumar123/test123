package kafka.sparkstreaming.mongo;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;

public class KafkaSparkStreamingMongo {

	public static void main(String[] args) throws InterruptedException {

		SparkSession sparkSession = SparkSession.builder().master("local").appName("KafkaSparkMongo")
				.config("spark.mongodb.output.uri", "mongodb://127.0.0.1/test.agent_lookup").getOrCreate();

		JavaSparkContext javaSparkContext = new JavaSparkContext(sparkSession.sparkContext());
		JavaStreamingContext streamingContext = new JavaStreamingContext(javaSparkContext, Durations.seconds(1));

		Map<String, Object> kafkaParams = new HashMap<>();
		kafkaParams.put("bootstrap.servers", "localhost:9092");
		kafkaParams.put("key.deserializer", StringDeserializer.class);
		kafkaParams.put("value.deserializer", StringDeserializer.class);
		kafkaParams.put("group.id", "use_a_separate_group_id_for_each_stream");
		kafkaParams.put("auto.offset.reset", "latest");
		kafkaParams.put("enable.auto.commit", false);
		Collection<String> topics = Arrays.asList("test");

		JavaInputDStream<ConsumerRecord<String, String>> stream = KafkaUtils.createDirectStream(streamingContext,
				LocationStrategies.PreferConsistent(),
				ConsumerStrategies.<String, String>Subscribe(topics, kafkaParams));

		/* Get the text and put into JavaDstream */
		JavaDStream<String> message = stream.map(entry -> entry.value());
		/* foreachRDD is the "output" function */
		message.foreachRDD(rdd -> {
			System.out.println("Number of messages:" + rdd.count());
			rdd.foreach(val -> System.out.println(val));
		}

		);
		
		

		streamingContext.start();
		try {
			streamingContext.awaitTermination();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
