/**
 * 
 */
package com.sparkTutorial.sparkSql;


import java.util.Arrays;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

/**
 * @author 238209
 *
 */
public class CreateDatasetsExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Logger.getLogger("org").setLevel(Level.ERROR);
		SparkSession session = SparkSession.builder().appName("createDs").master("local[*]").getOrCreate();

		// Create primitive Dataset
		Encoder<Integer> integerEncoders = Encoders.INT();

		Dataset<Integer> primitiveDs = session.createDataset(Arrays.asList(1,2,3), integerEncoders);
		primitiveDs.show();

		// Create DataFrame from RDD
		JavaRDD<Person> peopleRDD = session.read()
				.textFile("in/people.txt")
				.javaRDD()
				.map(line -> {
					String[] parts = line.split(",");
					Person person = new Person();
					person.setName(parts[0]);
					person.setAge(Integer.parseInt(parts[1].trim()));
					return person;
				});
		
		// Apply a schema to an RDD of JavaBeans to get a DataFrame
		Dataset<Row> peopleDF = session.createDataFrame(peopleRDD, Person.class);
		
		peopleDF.printSchema();
		
		// or by field name
		Dataset<String> teenagerNamesByFieldDF = peopleDF.map(
		    (MapFunction<Row, String>) row -> "Name: " + row.getAs("name"),
		    Encoders.STRING());
		teenagerNamesByFieldDF.show();
	}

}
