package com.map.examples;

import java.io.Serializable;
import java.util.Arrays;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.VoidFunction;

public class RDD_MapExample implements Serializable {

	public static void main(String[] args) {

		SparkConf conf = new SparkConf().setAppName("MapPartitionsWithIndexEx").setMaster("local[*]");
		JavaSparkContext sc = new JavaSparkContext(conf);

		JavaRDD<String> rawInputRdd = sc
				.textFile("D:\\anthem\\sparkjobs\\com.spark.mongo.example\\src\\main\\resources\\group.txt");

		// MAP Example - returns an String Array
		JavaRDD<String[]> mapResult = rawInputRdd.map(

				new Function<String, String[]>() {
					
					

					@Override
					public String[] call(String s) throws Exception {
						
						System.out.println("map - call() method is invoked");
						
						return s.split(";");
					}
				});

		System.out.println("Printing MAP results");

		// Print MAP results
		mapResult.foreach(new VoidFunction<String[]>() {

			@Override
			public void call(String[] strings) throws Exception {
				//for (String tmp : strings) {
					System.out.println(Arrays.toString(strings));
				//}
			}
		});

	}

}
