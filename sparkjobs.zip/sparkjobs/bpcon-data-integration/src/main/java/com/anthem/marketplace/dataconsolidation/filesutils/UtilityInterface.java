package com.anthem.marketplace.dataconsolidation.filesutils;

import java.util.List;

import org.apache.spark.sql.Row;
import org.bson.BSONObject;
import org.bson.Document;

import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;

import scala.Tuple2;

/*
 * This interface declares methods common for each file type
 * @author : MongoDB Team
 * @version : 1.0
 * @Date : April 2016
 */
public interface UtilityInterface {
	public  String createGuid(String sourceCollection, String delimeted, Row readFileContent, String guidvalue,
			String type);
	public  boolean createFlag(String delimeted, String sourceCollection, Row readFileContent, String type);
	public  Document appendRaw(ProcessInput processInput, String sourcePath, String guid,boolean flag, Row readFileContent);
	public Document ingestTDMProcess(String sourceDb, String sourceCollection,
			Tuple2<Object, BSONObject> bsonFilter, String targetDb, String targetCollection,
			String appendedCollection);
	public  Document ingestUDMProcess(String sourceDb, String sourceCollection,
			Tuple2<Object, BSONObject> bsonFilter, String targetDb,
			String targetCollection, String targetDetailCollection);
	public void ingestRDMprocess(ProcessInput processInput,String sourcePath,  String guidvalue,String strType);
	
	public Document ingestSDSProcess(String sourceDb, String[] sourceColl,
			Tuple2<Object, BSONObject> bsonFilter, String targetDb,
			String targetCollection,String sourceDbTDM);
	
	public Document ingestSDSProcess(String sourceDb, String[] sourceColl,
			Tuple2<Object, BSONObject> bsonFilter, String targetDb,
			String targetCollection,String sourceDbTDM, ProcessInput processInput);
	
	
	public  List<Document> ingestSDSProcess(String sourceDb, String sourceCollection,
			Tuple2<Object, BSONObject> bsonFilter, ProcessFieldNames procFieldNames, String targetDb,
			String targetCollection, String targetDetailCollection,String sourceDbTDM);

	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection);
	
}
