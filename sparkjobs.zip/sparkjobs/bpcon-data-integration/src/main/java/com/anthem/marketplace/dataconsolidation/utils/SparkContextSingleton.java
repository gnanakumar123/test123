package com.anthem.marketplace.dataconsolidation.utils;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;

/*
 * This class creats singleton class for JavaSparkContext  
 */

public class SparkContextSingleton {

	private JavaSparkContext scIngest;

		   //create an object of SingleObject
		   private static SparkContextSingleton instance;

		   //make the constructor private so that this class cannot be
		   //instantiated
		   private SparkContextSingleton(){
			   SparkConf conf;
			   String SparkConfFlag =GetSysProperties.getInstance().getPropertyContext().get(IConstants.SPARK_CONF_FLAG);
			   String cacheDBName =GetSysProperties.getInstance().getPropertyContext().get(IConstants.CACHE_DB_NAME);
			   String cacheCollectionName =GetSysProperties.getInstance().getPropertyContext().get(IConstants.CACHE_COLLECTION_NAME);
			   if(SparkConfFlag.equals("false"))
				   conf = new SparkConf().setAppName(GetSysProperties.getInstance().getPropertyContext().get(IConstants.APP_NAME)).setMaster(GetSysProperties.getInstance().getPropertyContext().get(IConstants.SPARK_MASTER));//"spark://VA10TLVWBS316.wellpoint.com:7077");
			   else{

				 conf = new SparkConf().setAppName(GetSysProperties.getInstance().getPropertyContext().get(IConstants.APP_NAME))
				             .setMaster(GetSysProperties.getInstance().getPropertyContext().get(IConstants.SPARK_MASTER))
				             .set("spark.executor.memory", GetSysProperties.getInstance().getPropertyContext().get(IConstants.EXECUTOR_MEMORY))
				             .set("spark.driver.memory", GetSysProperties.getInstance().getPropertyContext().get(IConstants.DRIVER_MEMORY))
				         	 .set("spark.mongodb.output.uri",Utility.getConfAddress(cacheDBName, cacheCollectionName , IConstants.TDM_DB))
				             .setJars(new String[]{GetSysProperties.getInstance().getPropertyContext().get(IConstants.JAR_NAME)});
				
				   
			   }

			 
			   scIngest = new JavaSparkContext(conf);
		   }

		   //Get the only object available
		   public JavaSparkContext getSparkContext(){
		      return scIngest;
		   }

		   //Get the only object available
		   public static synchronized SparkContextSingleton getInstance(){
			   if(null==instance)
			   {
				   instance = new SparkContextSingleton();
			   }
		      return instance;
		   }

}
