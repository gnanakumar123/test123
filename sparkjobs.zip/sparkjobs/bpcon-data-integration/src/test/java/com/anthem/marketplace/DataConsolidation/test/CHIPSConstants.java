package com.anthem.marketplace.DataConsolidation.test;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.bson.BSONObject;
import org.bson.Document;

import com.anthem.marketplace.dataconsolidation.model.AgencyInfo;
import com.anthem.marketplace.dataconsolidation.model.AgentInfo;
import com.anthem.marketplace.dataconsolidation.model.Contract;
import com.anthem.marketplace.dataconsolidation.model.DependentDetails;
import com.anthem.marketplace.dataconsolidation.model.PolicyHolderData;
import com.anthem.marketplace.dataconsolidation.model.PolicyHolderDetails;
import com.anthem.marketplace.dataconsolidation.model.SpouseDetails;
import com.anthem.marketplace.dataconsolidation.model.VARenewal;
import com.mongodb.BasicDBList;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCursor;
import com.mongodb.util.JSON;

public class CHIPSConstants {

	@SuppressWarnings("deprecation")
	public static VARenewal createVARenewals() throws ParseException
	{
		VARenewal vaRenewal = new VARenewal();
		//Adding AgencyInfo
		AgencyInfo agencyInfo = new AgencyInfo();
		agencyInfo.setAgencyAddressLine1("2413 CAROLINA AVENUE");
		agencyInfo.setAgencyAddressLine2("");
		agencyInfo.setAgencyCity("ROANOKE");
		agencyInfo.setAgencyName("SCOTT A MICHIE INC");
		agencyInfo.setAgencyNumber("AAC524");
		agencyInfo.setAgencyState("VA");
		agencyInfo.setAgencyZip("24014");
		
		//Adding AgentInfo
		AgentInfo agentInfo = new AgentInfo();
		agentInfo.setAgentNumber("0001");
		agentInfo.setFirstName("SCOTT");
		agentInfo.setLastName("MICHIE");
		agentInfo.setMiddleName("A");
		
		//Adding contract
		Contract contract = new Contract();
		contract.setHcid("236M64949");
		contract.setContractId("851075981");
		contract.setDeductible(5000.0);
		contract.setEffectiveDate(convertDate("2018-07-31"));
		contract.setNewRate(942.0);
		contract.setOldRate(863.0);
		contract.setProduct("KEYCARE HEALTHSMART");
		
		//Adding PolicyHolderData
		PolicyHolderData policyHolderData = new PolicyHolderData();
		policyHolderData.setAddressLine1("600 RADFORD ST");
		policyHolderData.setAddressLine2("");
		policyHolderData.setAddressLine3("");
		policyHolderData.setCity("CHRISTIANSBURG");
		policyHolderData.setPhoneNumber("(540) 381-2367");
		policyHolderData.setState("VA");
		policyHolderData.setZip("24073");
		
		//Adding PolicyHolderDetails
		PolicyHolderDetails policyHolderDetails = new PolicyHolderDetails();
		policyHolderDetails.setFirstName("BRYAN A");
		policyHolderDetails.setLastName("RICE");
		policyHolderDetails.setUwLevel("2");
		policyHolderDetails.setDateOfBirth(convertDate("1964-09-10"));
		
		//Adding spouse Details
		SpouseDetails spouseDetails = new SpouseDetails();
		spouseDetails.setSpouseFirstName("BENITA M");
		spouseDetails.setSpouseLastName("RICE");
		spouseDetails.setSpouseUwLevel("1");
		spouseDetails.setSpouseDateOfBirth(convertDate("1970-09-08"));
		
		//Adding Dependent Details
		DependentDetails dependentDetails = new DependentDetails();
		dependentDetails.setDependentFirstName("STEPHANIE R");
		dependentDetails.setDependentLastName("RICE");
		dependentDetails.setDependentUwLevel("1");
		dependentDetails.setDependentDateOfBirth(convertDate("1998-09-30"));
		
		List<DependentDetails> dependentDetailsList = new ArrayList<DependentDetails>(); 
		dependentDetailsList.add(dependentDetails);
		
		vaRenewal.setAgencyInfo(agencyInfo);
		vaRenewal.setAgentInfo(agentInfo);
		vaRenewal.setContract(contract);
		vaRenewal.setPolicyHolderData(policyHolderData);
		vaRenewal.setPolicyHolderDetails(policyHolderDetails);
		vaRenewal.setSpouseDetails(spouseDetails);
		vaRenewal.setDependentDetails(dependentDetailsList);
		
		return vaRenewal;
		
	}
	
	private static Date convertDate(String value) throws ParseException {
		
		if (value != null) {

			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date formattedDate = (Date) formatter.parse(value);
			return formattedDate;
		}
		else
			return null;
	}
	
	public static BSONObject clientBSONObject() {
		String clientTdm ="{\r\n" + 
				"    \"_id\" : ObjectId(\"5baa1f9930ddf10f20129c8f\"),\r\n" + 
				"    \"GUID\" : \"236M649492018-07-31INDSUBSCR\",\r\n" + 
				"    \"ID\" : \"236M64949\",\r\n" + 
				"    \"renewalDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"    \"effectiveDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"    \"type\" : \"IND\",\r\n" + 
				"    \"relationship\" : \"SUBSCR\",\r\n" + 
				"    \"firstName\" : \"BRYAN A\",\r\n" + 
				"    \"lastName\" : \"RICE\",\r\n" + 
				"    \"dateofBirth\" : ISODate(\"1964-09-10T04:00:00.000Z\"),\r\n" + 
				"    \"renewals\" : {\r\n" + 
				"        \"renewalPeriod\" : 2018\r\n" + 
				"    },\r\n" + 
				"    \"contacts\" : [ \r\n" + 
				"        {\r\n" + 
				"            \"addressType\" : \"default\",\r\n" + 
				"            \"addressLine1\" : \"600 RADFORD ST\",\r\n" + 
				"            \"cityName\" : \"CHRISTIANSBURG\",\r\n" + 
				"            \"stateCode\" : \"VA\",\r\n" + 
				"            \"postalCode\" : \"24073\"\r\n" + 
				"        }\r\n" + 
				"    ],\r\n" + 
				"    \"agents\" : [ \r\n" + 
				"        {\r\n" + 
				"            \"taxIDType\" : \"Writing\",\r\n" + 
				"            \"product\" : \"MED\",\r\n" + 
				"            \"name\" : \"SCOTT A MICHIE INC\",\r\n" + 
				"            \"taxID\" : \"LLGLNQRMNZ\",\r\n" + 
				"            \"agentID\" : \"LLGLNQRMNZ\"\r\n" + 
				"        }\r\n" + 
				"    ],\r\n" + 
				"    \"Dependents\" : [ \r\n" + 
				"        {\r\n" + 
				"            \"spouseFirstName\" : \"BENITA M\",\r\n" + 
				"            \"spouseLastName\" : \"RICE\",\r\n" + 
				"            \"spouseUwLevel\" : \"1\",\r\n" + 
				"            \"spouseDateOfBirth\" : ISODate(\"1970-09-08T04:00:00.000Z\")\r\n" + 
				"        }, \r\n" + 
				"        {\r\n" + 
				"            \"dependentFirstName\" : \"STEPHANIE R\",\r\n" + 
				"            \"dependentLastName\" : \"RICE\",\r\n" + 
				"            \"dependentUwLevel\" : \"1\",\r\n" + 
				"            \"dependentDateOfBirth\" : ISODate(\"1998-09-30T04:00:00.000Z\")\r\n" + 
				"        }\r\n" + 
				"    ],\r\n" + 
				"    \"dependentsCovered\" : \"Yes\",\r\n" + 
				"    \"start-date\" : \"2018-09-25 17:14:25.32\",\r\n" + 
				"    \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n" + 
				"    \"source-path\" : \"D:/Renewals/feedfile/VA/PHC.TST.BRXML.MPH7507.CATUP.D180810.XML\",\r\n" + 
				"    \"source\" : \"CHIPS\",\r\n" + 
				"    \"Version\" : \"V1\",\r\n" + 
				"    \"status\" : \"processed\",\r\n" + 
				"    \"Data_Quality_Check\" : \"passed\"\r\n" + 
				"}";
		Document doc = (Document) Document.parse(clientTdm);
		BSONObject bsonObject = (BSONObject) JSON.parse(doc.toJson());
		return bsonObject;
	}
	
	public static Document tdmRenewalDoc() {
		String json ="{\r\n" + 
				"    \"_id\" : ObjectId(\"5bac766930ddf121d4660b84\"),\r\n" + 
				"    \"GUID\" : \"236M649492018-07-31INDSUBSCR\",\r\n" + 
				"    \"ID\" : \"236M64949\",\r\n" + 
				"    \"renewalDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"    \"effectiveDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"    \"monthlyPremium\" : 942.0,\r\n" + 
				"    \"currentMonthlyPremium\" : 863.0,\r\n" + 
				"    \"type\" : \"IND\",\r\n" + 
				"    \"relationship\" : \"SUBSCR\",\r\n" + 
				"    \"Benefits\" : [ \r\n" + 
				"        {\r\n" + 
				"            \"effectiveDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"            \"renewalDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"            \"currentMonthlyPremium\" : 863.0,\r\n" + 
				"            \"currentTotalPremium\" : 863.0,\r\n" + 
				"            \"currentContractPlanName\" : \"KEYCARE HEALTHSMART\",\r\n" + 
				"            \"renewalMonthlyPremium\" : 942.0,\r\n" + 
				"            \"renewalTotalPremium\" : 942.0,\r\n" + 
				"            \"renewalContractPlanName\" : \"KEYCARE HEALTHSMART\",\r\n" + 
				"            \"product\" : \"MED\",\r\n" + 
				"            \"currentContractPlanCode\" : \"84012\",\r\n" + 
				"            \"renewalContractCode\" : \"84012\",\r\n" + 
				"            \"renewalProducts\" : [ \r\n" + 
				"                {\r\n" + 
				"                    \"renewalContractCode\" : \"84012\",\r\n" + 
				"                    \"renewalContractPlanName\" : \"KEYCARE HEALTHSMART\"\r\n" + 
				"                }\r\n" + 
				"            ]\r\n" + 
				"        }\r\n" + 
				"    ],\r\n" + 
				"    \"start-date\" : \"2018-09-27 11:49:21.228\",\r\n" + 
				"    \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n" + 
				"    \"source-path\" : \"D:/Renewals/feedfile/VA/PHC.TST.BRXML.MPH7507.CATUP.D180810.XML\",\r\n" + 
				"    \"source\" : \"CHIPS\",\r\n" + 
				"    \"Version\" : \"V1\",\r\n" + 
				"    \"status\" : \"processed\",\r\n" + 
				"    \"Data_Quality_Check\" : \"passed\"\r\n" + 
				"}";
		Document doc = Document.parse(json);
		return doc;
	}
	
	public static Document sdsRenewalSummaryDocument() {
		String json = "{\r\n" + 
				"    \"_id\" : ObjectId(\"5bac766a30ddf121d4660b91\"),\r\n" + 
				"    \"ID\" : \"236M64949\",\r\n" + 
				"    \"renewalDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"    \"type\" : \"IND\",\r\n" + 
				"    \"effectiveDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"    \"firstName\" : \"BRYAN A\",\r\n" + 
				"    \"lastName\" : \"RICE\",\r\n" + 
				"    \"dateofBirth\" : ISODate(\"1964-09-10T04:00:00.000Z\"),\r\n" + 
				"    \"agents\" : [ \r\n" + 
				"        {\r\n" + 
				"            \"taxIDType\" : \"Writing\",\r\n" + 
				"            \"product\" : \"MED\",\r\n" + 
				"            \"name\" : \"SCOTT A MICHIE INC\\\\\",\r\n" + 
				"            \"taxID\" : \"LLGLNQRMNZ\",\r\n" + 
				"            \"agentID\" : \"LLGLNQRMNZ\"\r\n" + 
				"        }\r\n" + 
				"    ],\r\n" + 
				"    \"contacts\" : [ \r\n" + 
				"        {\r\n" + 
				"            \"addressType\" : \"default\",\r\n" + 
				"            \"addressLine1\" : \"600 RADFORD ST\",\r\n" + 
				"            \"cityName\" : \"CHRISTIANSBURG\",\r\n" + 
				"            \"stateCode\" : \"VA\",\r\n" + 
				"            \"postalCode\" : \"24073\"\r\n" + 
				"        }\r\n" + 
				"    ],\r\n" + 
				"    \"start-date\" : \"2018-09-27 11:49:21.26\",\r\n" + 
				"    \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n" + 
				"    \"source-path\" : \"D:/Renewals/feedfile/VA/PHC.TST.BRXML.MPH7507.CATUP.D180810.XML\",\r\n" + 
				"    \"source\" : \"CHIPS\",\r\n" + 
				"    \"Version\" : \"V1\",\r\n" + 
				"    \"status\" : \"un-processed\",\r\n" + 
				"    \"Data_Quality_Check\" : \"passed\",\r\n" + 
				"    \"currentMonthlyPremium\" : 863.0,\r\n" + 
				"    \"monthlyPremium\" : 942.0,\r\n" + 
				"    \"Delta\" : 9.15411355735805,\r\n" + 
				"    \"Difference\" : 79.0,\r\n" + 
				"    \"renewalSummary\" : [ \r\n" + 
				"        {\r\n" + 
				"            \"productType\" : \"MED\",\r\n" + 
				"            \"renewalDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"            \"currentContractPlanCode\" : \"84012\",\r\n" + 
				"            \"currentContractPlanName\" : \"KEYCARE HEALTHSMART\",\r\n" + 
				"            \"renewalProducts\" : [ \r\n" + 
				"                {\r\n" + 
				"                    \"renewalContractPlanName\" : \"KEYCARE HEALTHSMART\",\r\n" + 
				"                    \"contractPlanCode\" : \"84012\",\r\n" + 
				"                    \"productType\" : \"MED\"\r\n" + 
				"                }\r\n" + 
				"            ],\r\n" + 
				"            \"contractPlanCode\" : \"84012\"\r\n" + 
				"        }\r\n" + 
				"    ],\r\n" + 
				"    \"groupName\" : \"BRYAN A RICE\"\r\n" + 
				"}";
		Document doc = Document.parse(json);
		return doc;
	}
	
	public static Document sdsRenewalDetailDocument() {
		String json = "{\r\n" + 
				"    \"_id\" : ObjectId(\"5bac766a30ddf121d4660b90\"),\r\n" + 
				"    \"ID\" : \"236M64949\",\r\n" + 
				"    \"type\" : \"IND\",\r\n" + 
				"    \"relationship\" : \"SUBSCR\",\r\n" + 
				"    \"renewalDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"    \"firstName\" : \"BRYAN A\",\r\n" + 
				"    \"lastName\" : \"RICE\",\r\n" + 
				"    \"dateofBirth\" : ISODate(\"1964-09-10T04:00:00.000Z\"),\r\n" + 
				"    \"contacts\" : [ \r\n" + 
				"        {\r\n" + 
				"            \"addressType\" : \"default\",\r\n" + 
				"            \"addressLine1\" : \"600 RADFORD ST\",\r\n" + 
				"            \"cityName\" : \"CHRISTIANSBURG\",\r\n" + 
				"            \"stateCode\" : \"VA\",\r\n" + 
				"            \"postalCode\" : \"24073\"\r\n" + 
				"        }\r\n" + 
				"    ],\r\n" + 
				"    \"agents\" : [ \r\n" + 
				"        {\r\n" + 
				"            \"taxIDType\" : \"Writing\",\r\n" + 
				"            \"product\" : \"MED\",\r\n" + 
				"            \"name\" : \"SCOTT A MICHIE INC\\\\\",\r\n" + 
				"            \"taxID\" : \"LLGLNQRMNZ\",\r\n" + 
				"            \"agentID\" : \"LLGLNQRMNZ\"\r\n" + 
				"        }\r\n" + 
				"    ],\r\n" + 
				"    \"exchangeIndicator\" : \"No\",\r\n" + 
				"    \"ratingArea\" : \"\",\r\n" + 
				"    \"start-date\" : \"2018-09-27 11:49:21.26\",\r\n" + 
				"    \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n" + 
				"    \"source-path\" : \"D:/Renewals/feedfile/VA/PHC.TST.BRXML.MPH7507.CATUP.D180810.XML\",\r\n" + 
				"    \"source\" : \"CHIPS\",\r\n" + 
				"    \"Version\" : \"V1\",\r\n" + 
				"    \"status\" : \"un-processed\",\r\n" + 
				"    \"Data_Quality_Check\" : \"passed\",\r\n" + 
				"    \"groupName\" : \"BRYAN A RICE\",\r\n" + 
				"    \"Benefits\" : [ \r\n" + 
				"        {\r\n" + 
				"            \"currentContractPlanCode\" : \"84012\",\r\n" + 
				"            \"currentContractPlanName\" : \"KEYCARE HEALTHSMART\",\r\n" + 
				"            \"currentTotalPremium\" : 863.0,\r\n" + 
				"            \"productType\" : \"MED\",\r\n" + 
				"            \"currentMonthlyPremium\" : 863.0,\r\n" + 
				"            \"currentSubsidy\" : \"No\",\r\n" + 
				"            \"currentPremiumwithoutSubsidy\" : null,\r\n" + 
				"            \"benefitType\" : \"currentProducts\"\r\n" + 
				"        }, \r\n" + 
				"        {\r\n" + 
				"            \"benefitType\" : \"renewalProducts\",\r\n" + 
				"            \"premium\" : [ \r\n" + 
				"                {\r\n" + 
				"                    \"currentMonthlyPremium\" : 863.0,\r\n" + 
				"                    \"monthlyPremium\" : 942.0,\r\n" + 
				"                    \"renewalSubsidy\" : \"No\",\r\n" + 
				"                    \"renewalPremiumwithoutSubsidy\" : null\r\n" + 
				"                }\r\n" + 
				"            ],\r\n" + 
				"            \"currentContractPlanCode\" : \"84012\",\r\n" + 
				"            \"currentContractPlanName\" : \"KEYCARE HEALTHSMART\",\r\n" + 
				"            \"contractPlanCode\" : \"84012\",\r\n" + 
				"            \"renewalContractPlanName\" : \"KEYCARE HEALTHSMART\",\r\n" + 
				"            \"productType\" : \"MED\",\r\n" + 
				"            \"monthlyPremium\" : 942.0,\r\n" + 
				"            \"renewalSubsidy\" : \"No\"\r\n" + 
				"        }\r\n" + 
				"    ],\r\n" + 
				"    \"dependentsCovered\" : \"Yes\"\r\n" + 
				"}";
		Document doc = Document.parse(json);
		return doc;
	}
	
	public static Document lookUpNameNotNullDoc() {
		String json = "{\r\n" + 
				"    \"_id\" : ObjectId(\"59fcf9c0d9e4a2c5a9953060\"),\r\n" + 
				"    \"agentTaxId\" : \"227276758\",\r\n" + 
				"    \"starBrokerTin\" : \"227276758S\",\r\n" + 
				"    \"encryptedTaxId\" : \"LLGLNQRMNZ\",\r\n" + 
				"    \"firstName\" : \"SCOTT\",\r\n" + 
				"    \"middleName\" : \"A\",\r\n" + 
				"    \"lastName\" : \"MICHIE\",\r\n" + 
				"    \"agencyName\" : \"NULL\",\r\n" + 
				"    \"agentId\" : \"AC5240004\",\r\n" + 
				"    \"legacyAgentCode\" : \"AAC5240004\"\r\n" + 
				"}";
		Document doc = Document.parse(json);
		return doc;
	}
	public static Document lookUpDoc() {
		String json = "{\r\n" + 
				"    \"_id\" : ObjectId(\"59fcf9c0d9e4a2c5a9953060\"),\r\n" + 
				"    \"agentTaxId\" : \"227276758\",\r\n" + 
				"    \"starBrokerTin\" : \"227276758S\",\r\n" + 
				"    \"encryptedTaxId\" : \"LLGLNQRMNZ\",\r\n" + 
				"    \"firstName\" : \"SCOTT\",\r\n" + 
				"    \"middleName\" : \"A\",\r\n" + 
				"    \"lastName\" : \"MICHIE\",\r\n" + 
				"    \"agencyName\" : \"NULL\",\r\n" + 
				"    \"agentId\" : \"AC5240001\",\r\n" + 
				"    \"legacyAgentCode\" : \"AAC5240001\"\r\n" + 
				"}";
		Document doc = Document.parse(json);
		return doc;
	}
	public static Document lookUpAgencyNameDoc() {
		String json = "{\r\n" + 
				"    \"_id\" : ObjectId(\"59fcf9c0d9e4a2c5a9953060\"),\r\n" + 
				"    \"agentTaxId\" : \"227276758\",\r\n" + 
				"    \"starBrokerTin\" : \"227276758S\",\r\n" + 
				"    \"encryptedTaxId\" : \"LLGLNQRMNZ\",\r\n" + 
				"    \"firstName\" : \"SCOTT\",\r\n" + 
				"    \"middleName\" : \"A\",\r\n" + 
				"    \"lastName\" : \"MICHIE\",\r\n" + 
				"    \"agencyName\" : \"SCOTT A MICHIE\",\r\n" + 
				"    \"agentId\" : \"AC5240002\",\r\n" + 
				"    \"legacyAgentCode\" : \"AAC5240002\"\r\n" + 
				"}";
		Document doc = Document.parse(json);
		return doc;
	}
	
	public static Document lookUpForAgentNamePopulate() {
		String json = "{\r\n" + 
				"    \"_id\" : ObjectId(\"59fcf9c0d9e4a2c5a9953060\"),\r\n" + 
				"    \"agentTaxId\" : \"227276758\",\r\n" + 
				"    \"starBrokerTin\" : \"227276758S\",\r\n" + 
				"    \"encryptedTaxId\" : \"LLGLNQRMNZ\",\r\n" + 
				"    \"firstName\" : \"NULL\",\r\n" + 
				"    \"middleName\" : \"NULL\",\r\n" + 
				"    \"lastName\" : \"NULL\",\r\n" + 
				"    \"agencyName\" : \"NULL\",\r\n" + 
				"    \"agentId\" : \"AC5240003\",\r\n" + 
				"    \"legacyAgentCode\" : \"AAC5240003\"\r\n" + 
				"}";
		Document doc = Document.parse(json);
		return doc;
	}
	
	public static Document metaDoc() {
		String json = "{\r\n" + 
				"    \"_id\" : ObjectId(\"5ba2690f30ddf124acf867ec\"),\r\n" + 
				"    \"GUID\" : \"236M649492018-07-31INDSUBSCR\",\r\n" + 
				"    \"ID\" : \"236M64949\",\r\n" + 
				"    \"renewalDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"    \"effectiveDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"    \"monthlyPremium\" : 942.0,\r\n" + 
				"    \"currentMonthlyPremium\" : 863.0,\r\n" + 
				"    \"type\" : \"IND\",\r\n" + 
				"    \"relationship\" : \"SUBSCR\",\r\n" + 
				"}";
		
		Document doc = Document.parse(json);
		return doc;
	}
	
	public static Document contractDoc() {
		String json = "{\r\n" + 
				"        \"hcid\" : \"236M64949\",\r\n" + 
				"        \"contractId\" : \"851075981\",\r\n" + 
				"        \"product\" : \"KEYCARE HEALTHSMART\",\r\n" + 
				"        \"deductible\" : 5000.0,\r\n" + 
				"        \"effectiveDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"        \"newRate\" : 942.0,\r\n" + 
				"        \"oldRate\" : 863.0\r\n" + 
				"    }";
		Document doc = Document.parse(json);
		return doc;
		
	}
	
	public static Document contractMockDoc() {
		String json = "{\r\n" + 
				"        \"hcid\" : \"236M64949\",\r\n" + 
				"        \"contractId\" : \"851075981\",\r\n" + 
				"        \"product\" : \"KEYCARE HEALTHSMART\",\r\n" + 
				"        \"deductible\" : 5000.0,\r\n" + 
				"        \"effectiveDate\" : \"2018-07-31\",\r\n" + 
				"        \"newRate\" : 942.0,\r\n" + 
				"        \"oldRate\" : 863.0\r\n" + 
				"    }";
		Document doc = Document.parse(json);
		return doc;
		
	}
	
	public static String tdmRenewalOuterDoc() {
		String json ="{\"GUID\" : \"236M649492018-07-31INDSUBSCR\",\r\n" + 
				"    \"ID\" : \"236M64949\",\r\n" + 
				"    \"renewalDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"    \"effectiveDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"    \"monthlyPremium\" : 942.0,\r\n" + 
				"    \"currentMonthlyPremium\" : 863.0}";
		return json;
	}
	
	public static List<Document> tdmRenewalBenefitsList() {
		String json = "{\r\n" + 
				"            \"effectiveDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"            \"renewalDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"            \"currentMonthlyPremium\" : 863.0,\r\n" + 
				"            \"currentTotalPremium\" : 863.0,\r\n" + 
				"            \"currentContractPlanName\" : \"KEYCARE HEALTHSMART\",\r\n" + 
				"            \"renewalMonthlyPremium\" : 942.0,\r\n" + 
				"            \"renewalTotalPremium\" : 942.0,\r\n" + 
				"            \"renewalContractPlanName\" : \"KEYCARE HEALTHSMART\",\r\n" + 
				"            \"product\" : \"MED\",\r\n" + 
				"            \"currentContractPlanCode\" : \"84012\",\r\n" + 
				"            \"renewalContractCode\" : \"84012\",\r\n" + 
				"            \"renewalProducts\" : [ \r\n" + 
				"                {\r\n" + 
				"                    \"renewalContractCode\" : \"84012\",\r\n" + 
				"                    \"renewalContractPlanName\" : \"KEYCARE HEALTHSMART\"\r\n" + 
				"                }\r\n" + 
				"            ]\r\n" + 
				"        }";
		Document benefitsDoc = Document.parse(json);
		List<Document> benefitsList = new ArrayList<Document>();
		benefitsList.add(benefitsDoc);
		return benefitsList;
		
	}
	
	public static String rawDoc() {
		String json ="{\r\n" + 
				"    \"contract\" : {\r\n" + 
				"        \"hcid\" : \"236M64949\",\r\n" + 
				"        \"contractId\" : \"851075981\",\r\n" + 
				"        \"product\" : \"KEYCARE HEALTHSMART\",\r\n" + 
				"        \"deductible\" : 5000.0,\r\n" + 
				"        \"effectiveDate\" : ISODate(\"2018-07-31T04:00:00.000Z\"),\r\n" + 
				"        \"newRate\" : 942.0,\r\n" + 
				"        \"oldRate\" : 863.0\r\n" + 
				"    },\r\n" + 
				"    \"policyHolderData\" : {\r\n" + 
				"        \"addressLine1\" : \"600 RADFORD ST\",\r\n" + 
				"        \"addressLine2\" : \"\",\r\n" + 
				"        \"addressLine3\" : \"\",\r\n" + 
				"        \"city\" : \"CHRISTIANSBURG\",\r\n" + 
				"        \"state\" : \"VA\",\r\n" + 
				"        \"zip\" : \"24073\",\r\n" + 
				"        \"phoneNumber\" : \"(540) 381-2367\"\r\n" + 
				"    },\r\n" + 
				"    \"policyHolderDetails\" : {\r\n" + 
				"        \"firstName\" : \"BRYAN A\",\r\n" + 
				"        \"lastName\" : \"RICE\",\r\n" + 
				"        \"uwLevel\" : \"2\",\r\n" + 
				"        \"dateOfBirth\" : ISODate(\"1964-09-10T04:00:00.000Z\")\r\n" + 
				"    },\r\n" + 
				"    \"spouseDetails\" : {\r\n" + 
				"        \"spouseFirstName\" : \"BENITA M\",\r\n" + 
				"        \"spouseLastName\" : \"RICE\",\r\n" + 
				"        \"spouseUwLevel\" : \"1\",\r\n" + 
				"        \"spouseDateOfBirth\" : ISODate(\"1970-09-08T04:00:00.000Z\")\r\n" + 
				"    },\r\n" + 
				"    \"dependentDetails\" : [ \r\n" + 
				"        {\r\n" + 
				"            \"dependentFirstName\" : \"STEPHANIE R\",\r\n" + 
				"            \"dependentLastName\" : \"RICE\",\r\n" + 
				"            \"dependentUwLevel\" : \"1\",\r\n" + 
				"            \"dependentDateOfBirth\" : ISODate(\"1998-09-30T04:00:00.000Z\")\r\n" + 
				"        }\r\n" + 
				"    ],\r\n" + 
				"    \"agentInfo\" : {\r\n" + 
				"        \"agentNumber\" : \"0001\",\r\n" + 
				"        \"firstName\" : \"SCOTT\",\r\n" + 
				"        \"middleName\" : \"A\",\r\n" + 
				"        \"lastName\" : \"MICHIE\"\r\n" + 
				"    },\r\n" + 
				"    \"agencyInfo\" : {\r\n" + 
				"        \"agencyNumber\" : \"AAC524\",\r\n" + 
				"        \"agencyName\" : \"SCOTT A MICHIE INC\",\r\n" + 
				"        \"agencyAddressLine1\" : \"2413 CAROLINA AVENUE\",\r\n" + 
				"        \"agencyAddressLine2\" : \"\",\r\n" + 
				"        \"agencyCity\" : \"ROANOKE\",\r\n" + 
				"        \"agencyState\" : \"VA\",\r\n" + 
				"        \"agencyZip\" : \"24014\"\r\n" + 
				"    },\r\n" + 
				"    \"GUID\" : \"236M649492018-07-31INDSUBSCR\",\r\n" + 
				"    \"start-date\" : \"2018-09-21 19:02:37.65\",\r\n" + 
				"    \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n" + 
				"    \"source-path\" : \"D:/Renewals/feedfile/VA/PHC.TST.BRXML.MPH7507.CATUP.D180810.XML\",\r\n" + 
				"    \"source\" : \"CHIPS\",\r\n" + 
				"    \"Version\" : \"V1\",\r\n" + 
				"    \"status\" : \"processed\",\r\n" + 
				"    \"Data_Quality_Check\" : \"passed\"\r\n" + 
				"}";
		return json;
	}
	
	public static Document tdmContactsListDoc() {
		String json = " {\r\n" + 
				"            \"addressType\" : \"default\",\r\n" + 
				"            \"addressLine1\" : \"600 RADFORD ST\",\r\n" + 
				"            \"cityName\" : \"CHRISTIANSBURG\",\r\n" + 
				"            \"stateCode\" : \"VA\",\r\n" + 
				"            \"postalCode\" : \"24073\"\r\n" + 
				"        }";
		Document doc = Document.parse(json);
		return doc;
	}
	public static BasicDBList tdmAgentsListDoc() {
		String json = "{\r\n" + 
				"            \"taxIDType\" : \"Writing\",\r\n" + 
				"            \"product\" : \"MED\",\r\n" + 
				"            \"name\" : \"SCOTT A MICHIE INC\",\r\n" + 
				"            \"taxID\" : \"LLGLNQRMNZ\",\r\n" + 
				"            \"agentID\" : \"LLGLNQRMNZ\"\r\n" + 
				"        }, \r\n" + 
				"        {\r\n" + 
				"            \"taxIDType\" : \"Paid\",\r\n" + 
				"            \"product\" : \"MED\",\r\n" + 
				"            \"name\" : \"SCOTT A MICHIE INC\",\r\n" + 
				"            \"taxID\" : \"LLGLNQRMNZ\",\r\n" + 
				"            \"agentID\" : \"LLGLNQRMNZ\"\r\n" + 
				"        }, \r\n" + 
				"        {\r\n" + 
				"            \"taxIDType\" : \"Parent\",\r\n" + 
				"            \"product\" : \"MED\",\r\n" + 
				"            \"name\" : \"SCOTT A MICHIE INC\",\r\n" + 
				"            \"taxID\" : \"LLGLNQRMNZ\",\r\n" + 
				"            \"agentID\" : \"LLGLNQRMNZ\"\r\n" + 
				"        }";
		Document doc = Document.parse(json);
		BasicDBList agentsList = new BasicDBList();
		agentsList.add(doc);
		return agentsList;
	}
	
	public static Document tdmRenewalsDoc() {
		String json = "{\r\n" + 
				"        \"renewalPeriod\" : 2018\r\n" + 
				"    }";
		Document doc = Document.parse(json);
		return doc;
	}
	public static List<BSONObject> tdmMemberListDoc() {
		String json = "{\r\n" + 
				"            \"spouseFirstName\" : \"BENITA M\",\r\n" + 
				"            \"spouseLastName\" : \"RICE\",\r\n" + 
				"            \"spouseUwLevel\" : \"1\",\r\n" + 
				"            \"spouseDateOfBirth\" : ISODate(\"1970-09-08T04:00:00.000Z\")\r\n" + 
				"        }";
		Document doc = Document.parse(json);
		BSONObject bsonObject = (BSONObject) JSON.parse(doc.toJson());
		List<BSONObject> memberList = new ArrayList<BSONObject>();
		memberList.add(bsonObject);
		return memberList;
	}
	public static Document planDoc(){
		String json = "{\r\n" + 
				"    \"_id\" : ObjectId(\"5ba9e6920f8206bdd32810e3\"),\r\n" + 
				"    \"planName\" : \"KEYCARE HEALTHSMART\",\r\n" + 
				"    \"productType\" : \"MED\",\r\n" + 
				"    \"contractCode\" : \"84012\"\r\n" + 
				"}";
		Document doc = Document.parse(json);
		return doc;
	}
	
	public static String xmlString() {
		String xmlString = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n" + 
				"<WP_FILE REPORT_NAME = \"BROKER_CATCHUP_RENEWAL_REPORT\" PROCESS_DATE = \"2018-08-10\" EFFECTIVE_DATE = \"2018-08-01\">                                                                   \r\n" + 
				" <AGENCY>                                                                                                                                                                           \r\n" + 
				"  <AGENCY_INFO>                                                                                                                                                                     \r\n" + 
				"   <AGENCY_NUMBER>AAB932</AGENCY_NUMBER>                                                                                                                                            \r\n" + 
				"   <AGENCY_NAME>RYAN W ATKINSONN</AGENCY_NAME>                                                                                                                                       \r\n" + 
				"   <AGENCY_ADDRESS>                                                                                                                                                                 \r\n" + 
				"    <AGENCY_ADDRESS_LN1>9464 CHAMBERLAYNE RD SUITE 202</AGENCY_ADDRESS_LN1>                                                                                                         \r\n" + 
				"    <AGENCY_ADDRESS_LN2></AGENCY_ADDRESS_LN2>                                                                                                                                       \r\n" + 
				"    <AGENCY_ADDRESS_CITY_STATE_ZIP>                                                                                                                                                 \r\n" + 
				"     <AGENCY_ADDRESS_CITY>MECHANICSVILLE</AGENCY_ADDRESS_CITY>                                                                                                                      \r\n" + 
				"     <AGENCY_ADDRESS_STATE>VA</AGENCY_ADDRESS_STATE>                                                                                                                                \r\n" + 
				"     <AGENCY_ADDRESS_ZIP>23116</AGENCY_ADDRESS_ZIP>                                                                                                                                 \r\n" + 
				"     </AGENCY_ADDRESS_CITY_STATE_ZIP>                                                                                                                                               \r\n" + 
				"    </AGENCY_ADDRESS>                                                                                                                                                               \r\n" + 
				"   </AGENCY_INFO> \r\n" + 
				"   <AGENTS_FOR_THIS_AGENCY>                                                                                                                                                          \r\n" + 
				"   <AGENT>                                                                                                                                                                          \r\n" + 
				"    <AGENT_INFO>                                                                                                                                                                    \r\n" + 
				"     <AGENT_NUMBER>0001</AGENT_NUMBER>                                                                                                                                              \r\n" + 
				"     <AGENT_NAME>                                                                                                                                                                   \r\n" + 
				"      <AGENT_NAME_FIRST>RYAN</AGENT_NAME_FIRST>                                                                                                                                     \r\n" + 
				"      <AGENT_NAME_MI>W</AGENT_NAME_MI>                                                                                                                                              \r\n" + 
				"      <AGENT_NAME_LAST>ATKINSONN</AGENT_NAME_LAST>                                                                                                                                   \r\n" + 
				"      </AGENT_NAME>                                                                                                                                                                 \r\n" + 
				"     </AGENT_INFO>                                                                                                                                                                  \r\n" + 
				"    <CONTRACTS_FOR_THIS_AGENT>                                                                                                                                                      \r\n" + 
				"     <CONTRACT>                                                                                                                                                                     \r\n" + 
				"      <HCID>635M58978</HCID>                                                                                                                                                        \r\n" + 
				"      <CONTRACT_ID>223881049</CONTRACT_ID>                                                                                                                                          \r\n" + 
				"      <PRODUCT>IND KEYCARE PREFERRED</PRODUCT>                                                                                                                                      \r\n" + 
				"      <DEDUCTIBLE>$2,500.00</DEDUCTIBLE>                                                                                                                                            \r\n" + 
				"      <EFFECTIVE_DATE>2018-08-01</EFFECTIVE_DATE>                                                                                                                                   \r\n" + 
				"      <NEW_RATE>$1,229.50</NEW_RATE>                                                                                                                                                \r\n" + 
				"      <OLD_RATE>$763.50</OLD_RATE>                                                                                                                                                  \r\n" + 
				"      </CONTRACT>  \r\n" + 
				"	<POLICY_HOLDER_DATA>                                                                                                                                                           \r\n" + 
				"      <POLICY_HOLDER_ADDRESS>                                                                                                                                                       \r\n" + 
				"       <POLICY_HOLDER_ADDRESS_LN1>10303 COLONY BEE PLACE</POLICY_HOLDER_ADDRESS_LN1>                                                                                                \r\n" + 
				"       <POLICY_HOLDER_ADDRESS_LN2></POLICY_HOLDER_ADDRESS_LN2>                                                                                                                      \r\n" + 
				"       <POLICY_HOLDER_ADDRESS_LN3></POLICY_HOLDER_ADDRESS_LN3>   \r\n" + 
				"      <POLICY_HOLDER_PHONE_NUMBER>(804) 240-6527</POLICY_HOLDER_PHONE_NUMBER>   	   \r\n" + 
				"       <POLICY_HOLDER_ADDRESS_CITY_STATE_ZIP>                                                                                                                                       \r\n" + 
				"        <POLICY_HOLDER_ADDRESS_CITY>MECHANICSVILLE</POLICY_HOLDER_ADDRESS_CITY>                                                                                                     \r\n" + 
				"        <POLICY_HOLDER_ADDRESS_STATE>VA</POLICY_HOLDER_ADDRESS_STATE>                                                                                                               \r\n" + 
				"        <POLICY_HOLDER_ADDRESS_ZIP>                                                                                                                                                 \r\n" + 
				"         <POLICY_HOLDER_ADDRESS_ZIP-5>23116</POLICY_HOLDER_ADDRESS_ZIP-5>                                                                                                           \r\n" + 
				"         <POLICY_HOLDER_ADDRESS_ZIP-4>1234</POLICY_HOLDER_ADDRESS_ZIP-4>                                                                                                                \r\n" + 
				"         </POLICY_HOLDER_ADDRESS_ZIP>                                                                                                                                               \r\n" + 
				"        </POLICY_HOLDER_ADDRESS_CITY_STATE_ZIP>                                                                                                                                     \r\n" + 
				"       </POLICY_HOLDER_ADDRESS>                                                                                                                                                                                                                                                       \r\n" + 
				"      </POLICY_HOLDER_DATA>   	  \r\n" + 
				"	<ENROLLMENT_DETAILS>                                                                                                                                                           \r\n" + 
				"      <POLICY_HOLDER_DETAILS>                                                                                                                                                       \r\n" + 
				"       <POLICY_HOLDER_FIRST_NAME>LISA B</POLICY_HOLDER_FIRST_NAME>                                                                                                                  \r\n" + 
				"       <POLICY_HOLDER_LAST_NAME>ATKINSONN</POLICY_HOLDER_LAST_NAME>                                                                                                                  \r\n" + 
				"       <POLICY_HOLDER_UW_LEVEL>1</POLICY_HOLDER_UW_LEVEL>                                                                                                                           \r\n" + 
				"       <POLICY_HOLDER_DATE_OF_BIRTH>1956-11-03</POLICY_HOLDER_DATE_OF_BIRTH>                                                                                                        \r\n" + 
				"      </POLICY_HOLDER_DETAILS>                                                                                                                                                      \r\n" + 
				"      </ENROLLMENT_DETAILS>                                                                                                                                                                                                                                                                                                                  \r\n" + 
				"     </CONTRACTS_FOR_THIS_AGENT>                                                                                                                                                    \r\n" + 
				"    </AGENT>                                                                                                                                                                        \r\n" + 
				"   </AGENTS_FOR_THIS_AGENCY>   \r\n" + 
				"  </AGENCY> \r\n" + 
				" <AGENCY>                                                                                                                                                                           \r\n" + 
				"  <AGENCY_INFO>                                                                                                                                                                     \r\n" + 
				"   <AGENCY_NUMBER>AAC524</AGENCY_NUMBER>                                                                                                                                            \r\n" + 
				"   <AGENCY_NAME>SCOTT A MICHIE INC</AGENCY_NAME>                                                                                                                                    \r\n" + 
				"   <AGENCY_ADDRESS>                                                                                                                                                                 \r\n" + 
				"    <AGENCY_ADDRESS_LN1>2413 CAROLINA AVENUE</AGENCY_ADDRESS_LN1>                                                                                                                   \r\n" + 
				"    <AGENCY_ADDRESS_LN2></AGENCY_ADDRESS_LN2>                                                                                                                                       \r\n" + 
				"    <AGENCY_ADDRESS_CITY_STATE_ZIP>                                                                                                                                                 \r\n" + 
				"     <AGENCY_ADDRESS_CITY>ROANOKE</AGENCY_ADDRESS_CITY>                                                                                                                             \r\n" + 
				"     <AGENCY_ADDRESS_STATE>VA</AGENCY_ADDRESS_STATE>                                                                                                                                \r\n" + 
				"     <AGENCY_ADDRESS_ZIP>24014</AGENCY_ADDRESS_ZIP>                                                                                                                                 \r\n" + 
				"     </AGENCY_ADDRESS_CITY_STATE_ZIP>                                                                                                                                               \r\n" + 
				"    </AGENCY_ADDRESS>                                                                                                                                                               \r\n" + 
				"   </AGENCY_INFO>                                                                                                                                                                   \r\n" + 
				"  <AGENTS_FOR_THIS_AGENCY>                                                                                                                                                          \r\n" + 
				"   <AGENT>                                                                                                                                                                          \r\n" + 
				"    <AGENT_INFO>                                                                                                                                                                    \r\n" + 
				"     <AGENT_NUMBER>0001</AGENT_NUMBER>                                                                                                                                              \r\n" + 
				"     <AGENT_NAME>                                                                                                                                                                   \r\n" + 
				"      <AGENT_NAME_FIRST>SCOTT</AGENT_NAME_FIRST>                                                                                                                                    \r\n" + 
				"      <AGENT_NAME_MI>A</AGENT_NAME_MI>                                                                                                                                              \r\n" + 
				"      <AGENT_NAME_LAST>MICHIE</AGENT_NAME_LAST>                                                                                                                                     \r\n" + 
				"      </AGENT_NAME>                                                                                                                                                                 \r\n" + 
				"     </AGENT_INFO>                                                                                                                                                                  \r\n" + 
				"    <CONTRACTS_FOR_THIS_AGENT>                                                                                                                                                      \r\n" + 
				"     <CONTRACT>                                                                                                                                                                     \r\n" + 
				"      <HCID>236M64949</HCID>                                                                                                                                                        \r\n" + 
				"      <CONTRACT_ID>851075981</CONTRACT_ID>                                                                                                                                          \r\n" + 
				"      <PRODUCT>KEYCARE HEALTHSMART</PRODUCT>                                                                                                                                        \r\n" + 
				"      <DEDUCTIBLE>$5,000.00</DEDUCTIBLE>                                                                                                                                            \r\n" + 
				"      <EFFECTIVE_DATE>2018-08-01</EFFECTIVE_DATE>                                                                                                                                   \r\n" + 
				"      <NEW_RATE>$942.00</NEW_RATE>                                                                                                                                                  \r\n" + 
				"      <OLD_RATE>$863.00</OLD_RATE>                                                                                                                                                  \r\n" + 
				"      </CONTRACT>                                                                                                                                                                   \r\n" + 
				"     <POLICY_HOLDER_DATA>                                                                                                                                                           \r\n" + 
				"      <POLICY_HOLDER_ADDRESS>                                                                                                                                                       \r\n" + 
				"       <POLICY_HOLDER_ADDRESS_LN1>600 RADFORD ST</POLICY_HOLDER_ADDRESS_LN1>                                                                                                        \r\n" + 
				"       <POLICY_HOLDER_ADDRESS_LN2></POLICY_HOLDER_ADDRESS_LN2>                                                                                                                      \r\n" + 
				"       <POLICY_HOLDER_ADDRESS_LN3></POLICY_HOLDER_ADDRESS_LN3>                                                                                                                      \r\n" + 
				"       <POLICY_HOLDER_ADDRESS_CITY_STATE_ZIP>                                                                                                                                       \r\n" + 
				"        <POLICY_HOLDER_ADDRESS_CITY>CHRISTIANSBURG</POLICY_HOLDER_ADDRESS_CITY>                                                                                                     \r\n" + 
				"        <POLICY_HOLDER_ADDRESS_STATE>VA</POLICY_HOLDER_ADDRESS_STATE>                                                                                                               \r\n" + 
				"        <POLICY_HOLDER_ADDRESS_ZIP>                                                                                                                                                 \r\n" + 
				"         <POLICY_HOLDER_ADDRESS_ZIP-5>24073</POLICY_HOLDER_ADDRESS_ZIP-5>                                                                                                           \r\n" + 
				"         <POLICY_HOLDER_ADDRESS_ZIP-4></POLICY_HOLDER_ADDRESS_ZIP-4>                                                                                                                \r\n" + 
				"         </POLICY_HOLDER_ADDRESS_ZIP>                                                                                                                                               \r\n" + 
				"        </POLICY_HOLDER_ADDRESS_CITY_STATE_ZIP>                                                                                                                                     \r\n" + 
				"       </POLICY_HOLDER_ADDRESS>                                                                                                                                                     \r\n" + 
				"      <POLICY_HOLDER_PHONE_NUMBER>(540) 381-2367</POLICY_HOLDER_PHONE_NUMBER>                                                                                                       \r\n" + 
				"      </POLICY_HOLDER_DATA>                                                                                                                                                         \r\n" + 
				"     <ENROLLMENT_DETAILS>                                                                                                                                                           \r\n" + 
				"      <POLICY_HOLDER_DETAILS>                                                                                                                                                       \r\n" + 
				"       <POLICY_HOLDER_FIRST_NAME>BRYAN A</POLICY_HOLDER_FIRST_NAME>                                                                                                                 \r\n" + 
				"       <POLICY_HOLDER_LAST_NAME>RICE</POLICY_HOLDER_LAST_NAME>                                                                                                                      \r\n" + 
				"       <POLICY_HOLDER_UW_LEVEL>2</POLICY_HOLDER_UW_LEVEL>                                                                                                                           \r\n" + 
				"       <POLICY_HOLDER_DATE_OF_BIRTH>1964-09-11</POLICY_HOLDER_DATE_OF_BIRTH>                                                                                                        \r\n" + 
				"      </POLICY_HOLDER_DETAILS>                                                                                                                                                      \r\n" + 
				"      <SPOUSE_DETAILS>                                                                                                                                                              \r\n" + 
				"       <SPOUSE_FIRST_NAME>BENITA M</SPOUSE_FIRST_NAME>                                                                                                                              \r\n" + 
				"       <SPOUSE_LAST_NAME>RICE</SPOUSE_LAST_NAME>                                                                                                                                    \r\n" + 
				"       <SPOUSE_UW_LEVEL>1</SPOUSE_UW_LEVEL>                                                                                                                                         \r\n" + 
				"       <SPOUSE_DATE_OF_BIRTH>1970-09-09</SPOUSE_DATE_OF_BIRTH>                                                                                                                      \r\n" + 
				"      </SPOUSE_DETAILS>                                                                                                                                                             \r\n" + 
				"      <DEPENDENT_DETAILS>                                                                                                                                                           \r\n" + 
				"       <DEPENDENT_FIRST_NAME>STEPHANIE R</DEPENDENT_FIRST_NAME>                                                                                                                     \r\n" + 
				"       <DEPENDENT_LAST_NAME>RICE</DEPENDENT_LAST_NAME>                                                                                                                              \r\n" + 
				"       <DEPENDENT_UW_LEVEL>1</DEPENDENT_UW_LEVEL>                                                                                                                                   \r\n" + 
				"       <DEPENDENT_DATE_OF_BIRTH>1998-10-01</DEPENDENT_DATE_OF_BIRTH>                                                                                                                \r\n" + 
				"      </DEPENDENT_DETAILS>                                                                                                                                                          \r\n" + 
				"      </ENROLLMENT_DETAILS>                                                                                                                                                         \r\n" + 
				"     </CONTRACTS_FOR_THIS_AGENT>                                                                                                                                                    \r\n" + 
				"    </AGENT>                                                                                                                                                                        \r\n" + 
				"   </AGENTS_FOR_THIS_AGENCY>                                                                                                                                                        \r\n" + 
				"  </AGENCY>     \r\n" + 
				" </WP_FILE>                                                                                                                                                                          \r\n" + 
				"";
		return xmlString;
	}
}
