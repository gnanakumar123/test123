/**
 * 
 */
package com.sparkTutorial.rdd.nasaApacheWebLogs;

import java.util.Arrays;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

/**
 * @author 238209
 *
 */
public class SubstractSolution {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Logger.getLogger("org").setLevel(Level.ERROR);
		
		SparkConf conf = new SparkConf().setAppName("substract").setMaster("local[*]");
		JavaSparkContext sc = new JavaSparkContext(conf);
		
		JavaRDD<String> group1 = sc.parallelize(Arrays.asList("A", "B", "C"));
		JavaRDD<String> group2 = sc.parallelize(Arrays.asList("C", "D", "E"));
		
		JavaRDD<String> subGroup = group1.subtract(group2);
		System.out.println(subGroup.count());
		
		subGroup.collect().forEach(line -> System.out.println(line));
		
		System.out.println(group2.take(2));

	}

}
