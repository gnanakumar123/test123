/**
 * 
 */
package com.sparkTutorial.streaming;

import java.util.Arrays;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;

/**
 * @author 238209
 *
 */
public class SparkStreamingExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Logger.getLogger("org").setLevel(Level.ERROR);
		SparkSession session = SparkSession.builder().appName("JavaStructuredNetworkWordCount").master("local[*]").getOrCreate();
		
		Dataset<Row> lines = session.readStream()
									.format("socket")
									.option("host", "localhost")
									.option("port", 9999)
									.load();
		
		Dataset<String> words = lines.as(Encoders.STRING())
									.flatMap((FlatMapFunction<String,String>) line -> Arrays.asList(line.split(" ")).iterator(), 
												Encoders.STRING());

		Dataset<Row> wordCounts =  words.groupBy("value").count();
		//wordCounts.show();
		
		StreamingQuery query = wordCounts.writeStream().outputMode("complete")
										 .format("console")
										 .start();
		
		try {
			query.awaitTermination();
		} catch (StreamingQueryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
