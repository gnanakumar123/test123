package com.anthem.marketplace.dataconsolidation.model;

import java.io.Serializable;
import java.util.Date;

public class Contract implements Serializable{

	private String hcid;
	private String contractId;
	private String product;
	private Double deductible;
	private Date effectiveDate;
	private Double newRate;
	private Double oldRate;
	
	public String getHcid() {
		return hcid;
	}
	public void setHcid(String hcid) {
		this.hcid = hcid;
	}
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public Double getDeductible() {
		return deductible;
	}
	public void setDeductible(Double deductible) {
		this.deductible = deductible;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public Double getNewRate() {
		return newRate;
	}
	public void setNewRate(Double newRate) {
		this.newRate = newRate;
	}
	public Double getOldRate() {
		return oldRate;
	}
	public void setOldRate(Double oldRate) {
		this.oldRate = oldRate;
	}
}
