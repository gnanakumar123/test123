package com.spark.mongo.example;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import static org.apache.spark.sql.functions.expr;

public class DataframeWithFixedLengthFile {

	public static void main(String[] args) {

		// Create a single Spark Session with reference to Mongo Db -
		// Database.Collection
		// Specify Spark MASTER URL to process to remove machine
		// SparkSession spark =
		// SparkSession.builder().master("spark://10.137.56.226:7077").
		SparkSession spark = SparkSession.builder().master("local").appName("MongoSparkConnectorIntro")
				.config("spark.mongodb.input.uri", "mongodb://127.0.0.1/test.test")
				.config("spark.mongodb.output.uri", "mongodb://127.0.0.1/test.test").config("spark.ui.port", "7077")
				.getOrCreate();

		// Create a Java Spark Context from a Spark Session
		JavaSparkContext jsc = new JavaSparkContext(spark.sparkContext());

		// Create a dataframe from a text file using Spark Session
		// Map the fields in the file against the above custom Schema ( data
		// types for each field )
		Dataset<Row> df = spark.read().format("csv") //
				.option("multiline", true) //
				.option("quote", "^") //
				.option("dateFormat", "M/d/y") //
				.option("inferSchema", false) //
				.load("src/main/resources/group_fixedlength_file.txt");

		System.out.println("Printing dataframe content:");
		df.show(false);

		df.createOrReplaceTempView("group_view");

		Dataset<Row> sqlResult = spark.sql(

				"SELECT SUBSTRING(value,1,3) as seqNumber,SUBSTRING(value,3,11) as groupId from group_view");
		
		sqlResult.show(false);
		
		//Dataset<Row> df2= df.withColumn("cutted", expr("substring(value, 1, 3)"));
       // df2.show();
        
        
		/*
		 * 1,2 3,8 9,15 16,22 23,29 30,39 40,44
		 */

		//Dataset<Row> df = df.seqNumber("cutted", expr("substring(value, 1, 2)"));

		/*
		 * df.select( df.value.substr(1,3).alias("seqNumber"),
		 * df.value.substr(4,8).alias("groupId"),
		 * df.value.substr(12,3).alias("firstName"),
		 * df.value.substr(12,3).alias("lastName"),
		 * df.value.substr(15,4).cast("double").alias("premium"),
		 * df.value.substr(12,3).cast("date").alias("renewalDate"),
		 * df.value.substr(12,3).alias("source"), ).show();
		 */

		jsc.close();

	}

}
