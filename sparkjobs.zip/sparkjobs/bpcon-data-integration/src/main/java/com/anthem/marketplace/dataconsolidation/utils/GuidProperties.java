package com.anthem.marketplace.dataconsolidation.utils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * This class reads GUIDs from properties file and returns them.  
 */

public class GuidProperties {

	static final  Logger logger = LoggerFactory.getLogger(GuidProperties.class);
	private static HashMap<String,String> hashMapproperty;
	private static GuidProperties instance;
	private GuidProperties() throws IOException, NoSuchMethodException, ClassNotFoundException,
			InvocationTargetException, IllegalAccessException {
		hashMapproperty = readProp("guid.properties");
	}

	public ProcessGuid getPropertyContext(String type) throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		ProcessGuid processList = new ProcessGuid();
		
		processList.setGuid(hashMapproperty.get(type+IConstants.GUID_FIELD));
		
		return processList;
				
	}

	public static synchronized GuidProperties getInstance() {
		if (instance == null) {
			try {
				instance = new GuidProperties();

			} catch (Exception e) {
				logger.error("Error{}", e);
			}
		}
		return instance;

	}

	private HashMap<String, String> readProp(String configpath) throws IOException, NoSuchMethodException,
			ClassNotFoundException, InvocationTargetException, IllegalAccessException {
		Properties prop = new Properties();
		prop.load(GuidProperties.class.getResourceAsStream("/" + configpath));
		Enumeration<?> propertyNames = prop.propertyNames();
		HashMap<String,String> propertyHashMap=new HashMap<>();
		while (propertyNames.hasMoreElements()) {
			String key = (String) propertyNames.nextElement();
			
							
				
				
				String Value = prop.getProperty(key);
				propertyHashMap.put(key, Value);
			}
	
		return propertyHashMap;
	}

}
