package com.anthem.marketplace.DataConsolidation.test;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;

import java.io.IOException;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.bson.BSONObject;
import org.bson.Document;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.FieldSetter;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.anthem.marketplace.dataconsolidation.model.VARenewal;
import com.anthem.marketplace.dataconsolidation.utils.ChipsUtils;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXml;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.BasicDBList;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.util.JSON;

import scala.Tuple2;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ MongoConnector.class, ReadMappingXmlSingleton.class, FieldNamesProperties.class })
public class ChipsUtilsTest {

	@Mock
	MongoCollection mockCollection;


	MongoConnector mongoConnectorMock;


	ReadMappingXmlSingleton readMappingXmlSingletonMock;

	
	ReadMappingXml readMappingXmlMock;


	FieldNamesProperties fileNamesPropertiesMock;
	

	HashMap<String,Document> planMap;
	
	HashMap<String,String> lookUpValues;

	@Before
	public void setup() {
		readMappingXmlSingletonMock = PowerMockito.mock(ReadMappingXmlSingleton.class);
		PowerMockito.mockStatic(ReadMappingXmlSingleton.class);
		readMappingXmlMock = PowerMockito.mock(ReadMappingXml.class);
		mongoConnectorMock = PowerMockito.mock(MongoConnector.class);
		PowerMockito.mockStatic(MongoConnector.class);
		PowerMockito.when(ReadMappingXmlSingleton.getInstance()).thenReturn(readMappingXmlSingletonMock);
		doReturn(readMappingXmlMock).when(readMappingXmlSingletonMock).getRead();
		fileNamesPropertiesMock = PowerMockito.mock(FieldNamesProperties.class);
		PowerMockito.mockStatic(FieldNamesProperties.class);
		PowerMockito.when(FieldNamesProperties.getInstance()).thenReturn(fileNamesPropertiesMock);
		
	}

	@Test
	public void getVADocumentTest() throws Exception {

		VARenewal vaRenewal = CHIPSConstants.createVARenewals();
		Row readFileContent = RowFactory.create(vaRenewal);
		ChipsUtils chipsUtils = ChipsUtils.getInstance();
		Document doc = chipsUtils.getVADocument(readFileContent);
		Document contractInfo = (Document) doc.get("contract");
		Document agencyInfo = (Document) doc.get("agencyInfo");
		Assert.assertEquals(vaRenewal.getContract().getHcid(), contractInfo.get("hcid").toString());
		Assert.assertEquals(vaRenewal.getContract().getOldRate(), contractInfo.get("oldRate"));
		Assert.assertEquals(vaRenewal.getContract().getNewRate(), contractInfo.get("newRate"));
		Assert.assertEquals(vaRenewal.getAgencyInfo().getAgencyNumber(), agencyInfo.get("agencyNumber"));
	}

	@Test
	public void getValueTypeDocument() {
		ChipsUtils chipsUtils = ChipsUtils.getInstance();
		Document doc = new Document("contract", new Document("hcid", "452976"));
		String key = "contract";
		String item = "hcid";
		String value = chipsUtils.getValue(doc, key, item);
		Assert.assertEquals("452976", value);
	}

	@Test
	public void getValueTypeListOfDocument() {
		ChipsUtils chipsUtils = ChipsUtils.getInstance();
		Document innerDoc = new Document("dependentFirstName", "firstName");
		List<Document> docList = new ArrayList<Document>();
		docList.add(innerDoc);
		Document doc = new Document("dependentDetails", docList);
		String key = "dependentDetails";
		String item = "dependentFirstName";
		String value = chipsUtils.getValue(doc, key, item);
		Assert.assertEquals("firstName", value);
	}

	@Test
	public void createRenewalsDocTest() {
		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames.setArrayFieldNames("renewalPeriod");
		ChipsUtils chipsUtils = ChipsUtils.getInstance();
		Document doc = chipsUtils.createRenewalsDoc(procFieldNames);
		Assert.assertEquals(Calendar.getInstance().get(Calendar.YEAR), doc.get("renewalPeriod"));
	}


	@Test
	public void createMemberDocListTest() throws Exception {
		Row readFileContent = RowFactory.create(CHIPSConstants.createVARenewals());
		BSONObject bsonObjectMock = getVADocument(readFileContent);
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		ChipsUtils chipsUtils = ChipsUtils.getInstance();
		List<BSONObject> memberDocList = chipsUtils.createMemberDocList(bsonFilterMock);
		Assert.assertEquals(2, memberDocList.size());
	}

	@Test
	public void addToDocumentTest() throws Exception {
		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames.setArrayFieldNames("ID,renewalDate,effectiveDate,monthlyPremium,currentMonthlyPremium");
		ChipsUtils chipsUtils = ChipsUtils.getInstance();
		String key = "contract";
		Row readFileContent = RowFactory.create(CHIPSConstants.createVARenewals());
		BSONObject bsonObjectMock = getVADocument(readFileContent);
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		/*
		 * ReadMappingXml readMappingXmlMock = PowerMockito.mock(ReadMappingXml.class);
		 * PowerMockito.whenNew(ReadMappingXml.class).withAnyArguments().thenReturn(
		 * readMappingXmlMock);
		 */
		doReturn("hcid").when(readMappingXmlMock)
				.getAttributeValueOfField(IConstants.CHIPS.concat("Renewals_tdm_Renewal"), "ID", "value");
		doReturn("effectiveDate").when(readMappingXmlMock)
				.getAttributeValueOfField(IConstants.CHIPS.concat("Renewals_tdm_Renewal"), "renewalDate", "value");
		doReturn("effectiveDate").when(readMappingXmlMock)
				.getAttributeValueOfField(IConstants.CHIPS.concat("Renewals_tdm_Renewal"), "effectiveDate", "value");
		doReturn("newRate").when(readMappingXmlMock)
				.getAttributeValueOfField(IConstants.CHIPS.concat("Renewals_tdm_Renewal"), "monthlyPremium", "value");
		doReturn("oldRate").when(readMappingXmlMock).getAttributeValueOfField(
				IConstants.CHIPS.concat("Renewals_tdm_Renewal"), "currentMonthlyPremium", "value");
		Document doc = new Document();
		chipsUtils.addToDocument(procFieldNames, bsonFilterMock, key, IConstants.CHIPS.concat("Renewals_tdm_Renewal"),
				doc);
		double monthlyPremium = doc.getDouble("monthlyPremium");
		double currentMonthlyPremium = doc.getDouble("currentMonthlyPremium");
		Assert.assertEquals(942.0, monthlyPremium, 0);
		Assert.assertEquals(863.0, currentMonthlyPremium, 0);
	}

	@Test
	public void createContactDocTest() throws Exception {

		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames
				.setArrayFieldNames("addressType,addressLine1,addressLine2,addressLine3,cityName,stateCode,postalCode");
		ChipsUtils chipsUtils = ChipsUtils.getInstance();

		VARenewal vaRenewal = CHIPSConstants.createVARenewals();
		Row readFileContent = RowFactory.create(vaRenewal);
		BSONObject bsonObjectMock = getVADocument(readFileContent);
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		doReturn("addressLine1").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("contacts"),
				"addressLine1", "value");
		doReturn("city").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("contacts"),
				"cityName", "value");
		doReturn("state").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("contacts"),
				"stateCode", "value");
		doReturn("zip").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("contacts"),
				"postalCode", "value");

		Document contactDoc = chipsUtils.createContactDoc(procFieldNames, bsonFilterMock, "contacts");

		Assert.assertEquals(vaRenewal.getPolicyHolderData().getAddressLine1(), contactDoc.get("addressLine1"));
		Assert.assertEquals(vaRenewal.getPolicyHolderData().getCity(), contactDoc.get("cityName"));
		Assert.assertEquals(vaRenewal.getPolicyHolderData().getState(), contactDoc.get("stateCode"));
		Assert.assertEquals(vaRenewal.getPolicyHolderData().getZip(), contactDoc.get("postalCode"));
	}

	private BSONObject getVADocument(Row readFileContent) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		VARenewal vaRenewal = (VARenewal) readFileContent.get(0);
		mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));
		String json = mapper.writeValueAsString(vaRenewal);
		BSONObject bsonObject = (BSONObject) JSON.parse(json);
		return bsonObject;
	}
	


	@Test
	public void createDetailDocumentTest() throws Exception {

		ProcessFieldNames memberDetail = new ProcessFieldNames();
		ProcessFieldNames memberDetailPremium = new ProcessFieldNames();
		ProcessFieldNames memberDetailRenewal = new ProcessFieldNames();
		ProcessFieldNames memberDetailCurrent = new ProcessFieldNames();
		memberDetail.setArrayFieldNames(
				"ID,type,relationship,renewalDate,firstName,lastName,dateofBirth,age,gender,tobaccoUsage,tobaccoWellness,contacts,agents");
		memberDetailPremium
				.setArrayFieldNames("currentMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,monthlyPremium");
		memberDetailRenewal
				.setArrayFieldNames("currentContractPlanCode,currentContractPlanName,renewalContractPlanCode,renewalContractPlanName,productType,monthlyPremium");
		memberDetailCurrent
				.setArrayFieldNames("currentContractPlanCode,currentContractPlanName,currentTotalPremium,productType,currentMonthlyPremium");

		ChipsUtils chipsUtils = ChipsUtils.getInstance();
		BSONObject bsonObjectMock = CHIPSConstants.clientBSONObject();
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		String sourceCollection[] = { "Renewals_tdm_Client", "Renewals_tdm_Renewal" };

		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);
		doReturn(mockCollection).when(mongoConnectorMock).getCollectionDetail(any(String.class), any(String.class),
				any(String.class));
		FindIterable iterable = PowerMockito.mock(FindIterable.class);
		PowerMockito.when(mockCollection.find(new Document("GUID", "236M649492018-07-31INDSUBSCR")
				.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE)
				.append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED))).thenReturn(iterable);
		Document mockDoc = CHIPSConstants.tdmRenewalDoc();
		PowerMockito.when(iterable.first()).thenReturn(mockDoc);

		doReturn(memberDetailPremium).when(fileNamesPropertiesMock).getPropertyContext("ChipsmemberDetailPremium");
		doReturn(memberDetailRenewal).when(fileNamesPropertiesMock).getPropertyContext("ChipsmemberDetailRenewal");
		doReturn(memberDetailCurrent).when(fileNamesPropertiesMock).getPropertyContext("ChipsmemberDetailCurrent");

		createDocumentMappingMock(memberDetail, "memberDetail");
		createDocumentMappingMock(memberDetailPremium, "ChipsmemberDetailPremium");
		createDocumentMappingMock(memberDetailRenewal, "ChipsmemberDetailRenewal");
		createDocumentMappingMock(memberDetailCurrent, "ChipsmemberDetailCurrent");

		Document detailDoc = chipsUtils.createDetailDocument(memberDetail, bsonFilterMock, "TDM", sourceCollection);
		List<Document> agentDoc = (List<Document>) detailDoc.get("agents");
		List<Document> benefitDoc = (List<Document>) detailDoc.get("Benefits");
		Assert.assertEquals(1, agentDoc.size());
		Assert.assertNotNull(detailDoc.get("contacts"));
		Assert.assertEquals(2, benefitDoc.size());
		Assert.assertEquals("KEYCARE HEALTHSMART", benefitDoc.get(0).get("currentContractPlanName"));
		Assert.assertEquals("KEYCARE HEALTHSMART", benefitDoc.get(1).get("renewalContractPlanName"));
		Assert.assertEquals("84012", benefitDoc.get(1).get("renewalContractPlanCode"));
		Assert.assertEquals(Double.parseDouble("863.0"), benefitDoc.get(0).getDouble("currentMonthlyPremium"),0);
		Assert.assertEquals(Double.parseDouble("942.0"), benefitDoc.get(1).getDouble("monthlyPremium"),0);
		
	}
	
	private void createDocumentMappingMock(ProcessFieldNames memberDetail,String key) {
		for(String fieldName : memberDetail.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
			if(fieldName.equals("monthlyPremium")) {
				doReturn("renewalMonthlyPremium").when(readMappingXmlMock).getAttributeValueOfField(key,
						fieldName, "value");
			}else if(fieldName.equals("renewalContractPlanCode")){
				doReturn("renewalContractCode").when(readMappingXmlMock).getAttributeValueOfField(key,
						fieldName, "value");
			}else if(fieldName.equals("productType")){
				doReturn("product").when(readMappingXmlMock).getAttributeValueOfField(key,
						fieldName, "value");
			}else {
				doReturn(fieldName).when(readMappingXmlMock).getAttributeValueOfField(key,
						fieldName, "value");
			}
		}
	}
	
	@Test
	public void createSummaryBenefits() {
		
		ProcessFieldNames memberSummary = new ProcessFieldNames();
		ProcessFieldNames memberSummaryBenefits= new ProcessFieldNames();
		
		memberSummary.setArrayFieldNames("ID,renewalDate,enrollmentType,type,effectiveDate,firstName,lastName,dateofBirth,age,gender,agents,contacts");
		memberSummaryBenefits.setArrayFieldNames("productType,productSubType,renewalDate,currentContractPlanCode,renewalLetterCode,currentContractPlanName,enrollmentCode,renewalProducts,contractPlanCode,productType");

		ChipsUtils chipsUtils = ChipsUtils.getInstance();
		BSONObject bsonObjectMock = CHIPSConstants.clientBSONObject();
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		String sourceCollection[] = { "Renewals_tdm_Client", "Renewals_tdm_Renewal" };
		
		createDocumentMappingMock(memberSummary, "memberSummary");
		createDocumentMappingMock(memberSummaryBenefits, "memberSummaryBenefitsModified");
		Document mockRenewalDoc = CHIPSConstants.tdmRenewalDoc();
		List<Document> benefitsDocMock = (List<Document>) mockRenewalDoc.get(IConstants.RENEWAL_DETAILS);
		
		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);
		FindIterable iterable = PowerMockito.mock(FindIterable.class);
		doReturn(benefitsDocMock).when(mongoConnectorMock).getRenewalDocumentSDS(bsonFilterMock, "UDM", sourceCollection[1],  IConstants.UDM_DB, IConstants.RENEWAL_DETAILS);
		doReturn(mockCollection).when(mongoConnectorMock).getCollectionDetail(any(String.class), any(String.class),
				any(String.class));
		PowerMockito.when(
				mockCollection.find(new Document("ID", "236M64949").append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE)
						.append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)))
				.thenReturn(iterable);
		PowerMockito.when(iterable.first()).thenReturn(mockRenewalDoc);
		Document summaryDoc = chipsUtils.createSummaryDocument(memberSummary, memberSummaryBenefits, bsonFilterMock, "UDM", sourceCollection);
		
		List<Document> agentDoc = (List<Document>) summaryDoc.get("agents");
		List<Document> benefitDoc = (List<Document>) summaryDoc.get("renewalSummary");
		Assert.assertEquals(1, agentDoc.size());
		Assert.assertNotNull(summaryDoc.get("contacts"));
		Assert.assertEquals(1, benefitDoc.size());
		Assert.assertEquals("KEYCARE HEALTHSMART",benefitDoc.get(0).get("currentContractPlanName"));
		Assert.assertEquals("84012",benefitDoc.get(0).get("currentContractPlanCode"));
	}
	
	@Test
	public void createAgentsList() throws Exception {
		
		
		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames.setArrayFieldNames("taxIDType,product,name");
		
		VARenewal vaRenewals = CHIPSConstants.createVARenewals();
		vaRenewals.getAgentInfo().setAgentNumber("0004");
		vaRenewals.getAgencyInfo().setAgencyName(null);
		
		Row vaRowContent = RowFactory.create(vaRenewals);
		BSONObject bsonObjectMock = getVADocument(vaRowContent);
		ChipsUtils chipsUtils = ChipsUtils.getInstance();
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		String sourceCollection[] = { "Renewals_tdm_Client", "Renewals_tdm_Renewal" };
		
		doReturn("true").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("agents"),
				"product", IConstants.PROD_TYPE);
		doReturn("false").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("agents"),
				"taxIDType", IConstants.PROD_TYPE);
		doReturn("false").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("agents"),
				"name", IConstants.PROD_TYPE);
		doReturn("agencyName").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("agents"),
				"name", "value");
		
		planMap = new HashMap<String,Document>();
		planMap.put("KEYCARE HEALTHSMART", CHIPSConstants.planDoc());
		Field f1 = chipsUtils.getClass().getDeclaredField("planMap");
		f1.setAccessible(true);
		f1.set(chipsUtils, planMap);
		
		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);
		FindIterable iterable = PowerMockito.mock(FindIterable.class);
		doReturn(mockCollection).when(mongoConnectorMock).getCollectionDetail(any(String.class), any(String.class),
				any(String.class));
		PowerMockito.when(
				mockCollection.find(new Document("agentId", "AC5240004")))
				.thenReturn(iterable);
		Document lookUpMock = CHIPSConstants.lookUpNameNotNullDoc();
		PowerMockito.when(iterable.first()).thenReturn(lookUpMock);
		
		BasicDBList agentsList = chipsUtils.createAgentsList(procFieldNames, bsonFilterMock, "agents", "TDM");
		
		Document agentDoc = (Document) agentsList.get(0);
		Assert.assertEquals(1, agentsList.size());
		Assert.assertNotNull(agentDoc.get("name"));
	}
	
	@Test
	public void createAgentsListWithNameNotNull() throws Exception {
		
		
		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames.setArrayFieldNames("taxIDType,product,name");
		
		VARenewal vaRenewals = CHIPSConstants.createVARenewals();
		Row vaRowContent = RowFactory.create(vaRenewals);
		BSONObject bsonObjectMock = getVADocument(vaRowContent);
		ChipsUtils chipsUtils = ChipsUtils.getInstance();
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		String sourceCollection[] = { "Renewals_tdm_Client", "Renewals_tdm_Renewal" };
		
		doReturn("true").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("agents"),
				"product", IConstants.PROD_TYPE);
		doReturn("false").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("agents"),
				"taxIDType", IConstants.PROD_TYPE);
		doReturn("false").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("agents"),
				"name", IConstants.PROD_TYPE);
		doReturn("agencyName").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("agents"),
				"name", "value");
		
		planMap = new HashMap<String,Document>();
		planMap.put("KEYCARE HEALTHSMART", CHIPSConstants.planDoc());
		Field f1 = chipsUtils.getClass().getDeclaredField("planMap");
		f1.setAccessible(true);
		f1.set(chipsUtils, planMap);
		
		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);
		FindIterable iterable = PowerMockito.mock(FindIterable.class);
		doReturn(mockCollection).when(mongoConnectorMock).getCollectionDetail(any(String.class), any(String.class),
				any(String.class));
		PowerMockito.when(
				mockCollection.find(new Document("agentId", "AC5240001")))
				.thenReturn(iterable);
		Document lookUpMock = CHIPSConstants.lookUpDoc();
		PowerMockito.when(iterable.first()).thenReturn(lookUpMock);
		
		BasicDBList agentsList = chipsUtils.createAgentsList(procFieldNames, bsonFilterMock, "agents", "TDM");
		
		Document agentDoc = (Document) agentsList.get(0);
		Assert.assertEquals(1, agentsList.size());
		Assert.assertNotNull(agentDoc.get("name"));
	}
	
	@Test
	public void createAgentsNameForAgencyNameNotNullTest() throws Exception {
		
		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames.setArrayFieldNames("taxIDType,product,name");
		
		VARenewal vaRenewals = CHIPSConstants.createVARenewals();
		vaRenewals.getAgentInfo().setAgentNumber("0002");
		vaRenewals.getAgencyInfo().setAgencyName(null);
		Row vaRowContent = RowFactory.create(vaRenewals);
		BSONObject bsonObjectMock = getVADocument(vaRowContent);
		ChipsUtils chipsUtils = ChipsUtils.getInstance();
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		String sourceCollection[] = { "Renewals_tdm_Client", "Renewals_tdm_Renewal" };
		
		doReturn("true").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("agents"),
				"product", IConstants.PROD_TYPE);
		doReturn("false").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("agents"),
				"taxIDType", IConstants.PROD_TYPE);
		doReturn("false").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("agents"),
				"name", IConstants.PROD_TYPE);
		
		planMap = new HashMap<String,Document>();
		planMap.put("KEYCARE HEALTHSMART", CHIPSConstants.planDoc());
		Field f = chipsUtils.getClass().getDeclaredField("planMap");
		f.setAccessible(true);
		f.set(chipsUtils, planMap);
		 
		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);
		FindIterable iterable = PowerMockito.mock(FindIterable.class);
		doReturn(mockCollection).when(mongoConnectorMock).getCollectionDetail(any(String.class), any(String.class),
				any(String.class));
		PowerMockito.when(
				mockCollection.find(new Document("agentId", "AC5240002")))
				.thenReturn(iterable);
		Document lookUpMock = CHIPSConstants.lookUpAgencyNameDoc();
		PowerMockito.when(iterable.first()).thenReturn(lookUpMock);
		
		BasicDBList agentsList = chipsUtils.createAgentsList(procFieldNames, bsonFilterMock, "agents", "TDM");
		
		Document agentDoc = (Document) agentsList.get(0);
		Assert.assertEquals(1, agentsList.size());
		Assert.assertNotNull(agentDoc.get("name"));
	}
	
	@Test
	public void createAgencyNameNullList() throws Exception {
		
		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames.setArrayFieldNames("taxIDType,product,name");
		VARenewal vaRenewals = CHIPSConstants.createVARenewals();
		vaRenewals.getAgentInfo().setAgentNumber("0003");
		vaRenewals.getAgencyInfo().setAgencyName(null);
		Row vaRowContent = RowFactory.create(vaRenewals);
		BSONObject bsonObjectMock = getVADocument(vaRowContent);
		ChipsUtils chipsUtils = ChipsUtils.getInstance();
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		String sourceCollection[] = { "Renewals_tdm_Client", "Renewals_tdm_Renewal" };
		
		doReturn("true").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("agents"),
				"product", IConstants.PROD_TYPE);
		doReturn("false").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("agents"),
				"taxIDType", IConstants.PROD_TYPE);
		doReturn("false").when(readMappingXmlMock).getAttributeValueOfField(IConstants.CHIPS.concat("agents"),
				"name", IConstants.PROD_TYPE);
		
		planMap = new HashMap<String,Document>();
		planMap.put("KEYCARE HEALTHSMART", CHIPSConstants.planDoc());
		Field f = chipsUtils.getClass().getDeclaredField("planMap");
		f.setAccessible(true);
		f.set(chipsUtils, planMap);
		 
		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);
		FindIterable iterable = PowerMockito.mock(FindIterable.class);
		doReturn(mockCollection).when(mongoConnectorMock).getCollectionDetail(any(String.class), any(String.class),
				any(String.class));
		PowerMockito.when(
				mockCollection.find(new Document("agentId", "AC5240003")))
				.thenReturn(iterable);
		Document lookUpMock = CHIPSConstants.lookUpForAgentNamePopulate();
		PowerMockito.when(iterable.first()).thenReturn(lookUpMock);
		
		BasicDBList agentsList = chipsUtils.createAgentsList(procFieldNames, bsonFilterMock, "agents", "TDM");
		
		Document agentDoc = (Document) agentsList.get(0);
		Assert.assertEquals(1, agentsList.size());
		Assert.assertNotNull(agentDoc.get("name"));
	}
	
	@Test
	public void createRenewalBenefitsTest() throws Exception {
		
		ProcessFieldNames benefitFieldName = new ProcessFieldNames();
		benefitFieldName.setArrayFieldNames("effectiveDate,renewalDate,currentMonthlyPremium,currentTotalPremium,currentContractPlanName,renewalMonthlyPremium,renewalTotalPremium,renewalContractPlanName");
		
		ProcessFieldNames renewalProductsFieldName = new ProcessFieldNames();
		renewalProductsFieldName.setArrayFieldNames("renewalContractCode,renewalContractPlanName");

		
		Row vaRowContent = RowFactory.create(CHIPSConstants.createVARenewals());
		BSONObject bsonObjectMock = getVADocument(vaRowContent);
		ChipsUtils chipsUtils = ChipsUtils.getInstance();
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		
		doReturn("effectiveDate").when(readMappingXmlMock)
		.getAttributeValueOfField(IConstants.CHIPSBENEFITS, "effectiveDate", IConstants.VALUE);
		doReturn("oldRate").when(readMappingXmlMock)
		.getAttributeValueOfField(IConstants.CHIPSBENEFITS, "currentMonthlyPremium", IConstants.VALUE);
		doReturn("newRate").when(readMappingXmlMock)
		.getAttributeValueOfField(IConstants.CHIPSBENEFITS, "renewalMonthlyPremium", IConstants.VALUE);
		doReturn("oldRate").when(readMappingXmlMock)
		.getAttributeValueOfField(IConstants.CHIPSBENEFITS, "currentTotalPremium", IConstants.VALUE);
		doReturn("newRate").when(readMappingXmlMock)
		.getAttributeValueOfField(IConstants.CHIPSBENEFITS, "renewalTotalPremium", IConstants.VALUE);
		doReturn("effectiveDate").when(readMappingXmlMock)
		.getAttributeValueOfField(IConstants.CHIPSBENEFITS, "renewalDate", IConstants.VALUE);
		doReturn("product").when(readMappingXmlMock)
		.getAttributeValueOfField(IConstants.CHIPSBENEFITS, "currentContractPlanName", IConstants.VALUE);
		doReturn("product").when(readMappingXmlMock)
		.getAttributeValueOfField(IConstants.CHIPSBENEFITS, "renewalContractPlanName", IConstants.VALUE);
		
		
		doReturn(renewalProductsFieldName).when(fileNamesPropertiesMock).getPropertyContext(IConstants.CHIPS.concat("renewalProducts"));
		
		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);
		doReturn(mockCollection).when(mongoConnectorMock).getCollectionDetail(any(String.class), any(String.class),
				any(String.class));
		FindIterable iterable = PowerMockito.mock(FindIterable.class);
		doReturn(iterable).when(mockCollection).find();
		
		Document metaDoc = CHIPSConstants.metaDoc();
		List<Document> benefitsList = chipsUtils.createRenewalBenefits(benefitFieldName, bsonFilterMock, "Renewals_CHIPS", metaDoc,IConstants.TDM_DB);
		Document benefitDoc = benefitsList.get(0);
		Assert.assertEquals(863.0, benefitDoc.getDouble("currentMonthlyPremium"),0);
		Assert.assertEquals(942.0, benefitDoc.getDouble("renewalMonthlyPremium"),0);
		Assert.assertEquals("KEYCARE HEALTHSMART", benefitDoc.getString("currentContractPlanName"));
	}
}
