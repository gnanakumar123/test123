package com.anthem.marketplace.dataconsolidation.utils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

/*
 * This class reads mongoDB connector values from properties file and returns them.  
 */

public class InputConnectors {
	static final  Logger logger = LoggerFactory.getLogger(InputConnectors.class);
	static HashMap<String,ProcessConnector> connectorList=new HashMap<>();
	private static InputConnectors instance;

	private InputConnectors() throws IOException, NoSuchMethodException, ClassNotFoundException,
			InvocationTargetException, IllegalAccessException {

		connectorList=readProp("connector.properties");

	}



	public List<ServerAddress> getMongoPropertyContext(String type) {
		String[] arrayOfServer = connectorList.get(type).getArrayClusterIPAddress();
		String[] arrayOfPorts = connectorList.get(type).getArrayClusterPorts();
		List<ServerAddress> listServerAddress = new ArrayList<>();
		for (int indexCounter = 0; indexCounter < arrayOfServer.length; indexCounter++)
			listServerAddress
					.add(new ServerAddress(arrayOfServer[indexCounter], Integer.parseInt(arrayOfPorts[indexCounter])));

		return listServerAddress;
	}
	/*BPP-38521 : Implement Mongodb SSL Feature to Data Load Project */
	public boolean checkSSLFlag(String type){
		return (Boolean) Boolean.parseBoolean(connectorList.get(type).getSSL()); 
	}
	
	
	public boolean checkAuthenticationFlag(String type){
		return (Boolean) Boolean.parseBoolean(connectorList.get(type).getAuthenticationCheck());//processConnector.getAuthenticationCheck();
	}
	

	public List<MongoCredential> getMongoCredentials(String type){
		List<MongoCredential> credentialList=new ArrayList<>();
		String[] arrayOfUserName=connectorList.get(type).getArrayClusterUserName();
		String[] arrayOfPassword=connectorList.get(type).getArrayClusterPassWord();
		
	
		String dataBase = connectorList.get(type).getDBName();
		for (int indexCounter = 0; indexCounter < arrayOfUserName.length; indexCounter++) {
			credentialList.add(MongoCredential.createScramSha1Credential(arrayOfUserName[indexCounter], dataBase,
					arrayOfPassword[indexCounter].toCharArray()));
		}
		
		return credentialList;
	}

	public static synchronized InputConnectors getInstance() {
		if (null == instance) {
			try {
				instance = new InputConnectors();

			} catch (Exception e) {
				logger.error("Error{}", e);
			}
			
		}
		return instance;
	}
	public HashMap<String,ProcessConnector> getConnectorList(){
		return connectorList;
	}

	private HashMap<String, ProcessConnector> readProp(String configpath) throws IOException, NoSuchMethodException, ClassNotFoundException,
			InvocationTargetException, IllegalAccessException {
		Properties prop = new Properties();
		prop.load(InputConnectors.class.getResourceAsStream("/" + configpath));
		Enumeration<?> propertyNames = prop.propertyNames();
		
		while (propertyNames.hasMoreElements()) {
			    String key = (String) propertyNames.nextElement();
			    String[] keys = key.split("\\.");
			    if(keys.length==2){
			    ProcessConnector processConnector = getProcessConnector(keys[0]);
				Class<?> cls = Class.forName("com.anthem.marketplace.dataconsolidation.utils.ProcessConnector");
				String tempPropertyValue = prop.getProperty(key);
				
				if (key.contains("Array")) {
					Method method = cls.getDeclaredMethod("set" + keys[1], new Class[] { String[].class });
					method.invoke(processConnector, new Object[] { tempPropertyValue.split(",") });
				} else {
					Method method = cls.getDeclaredMethod("set" + keys[1], String.class);
					method.invoke(processConnector, tempPropertyValue);
				}
		}}
		return connectorList;
		}
	private ProcessConnector getProcessConnector(String type) {ProcessConnector process = null;
	if (connectorList.get(type)==null) {
		process = new ProcessConnector();
		connectorList.put(type, process);
	} else
		process = connectorList.get(type);
	return process;
	}
}