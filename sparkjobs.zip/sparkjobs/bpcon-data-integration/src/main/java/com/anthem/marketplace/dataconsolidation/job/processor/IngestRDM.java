package com.anthem.marketplace.dataconsolidation.job.processor;

import java.io.File;
import java.io.Serializable;
import java.net.URI;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.anthem.marketplace.dataconsolidation.filesutils.UtilityInterface;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.SystemProperties;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
/*
 * This class Starts Ingestion Process
 */

public class IngestRDM implements Serializable {

	private static final long serialVersionUID = 1L;
	static final Logger logger = LoggerFactory.getLogger(IngestRDM.class);

	/*
	 * This method ingest data into sourceDB.sorceCollection on mongoDB
	 * 
	 * @param processInput stores input related parameters
	 * 
	 * @param sourcePath stores path to fileSystem for input files
	 * 
	 * @param type stores process type value
	 * 
	 * @param guidvalue stores GUID
	 * 
	 * @param priority stores job priority
	 * 
	 * @param strType stores file type
	 * 
	 * @return boolean value depending on ingestion process
	 */

	public boolean ingest(ProcessInput processInput, String sourcePath, String guidvalue, String strType) {
		java.util.Date date = new java.util.Date();
		String sourceCollection = processInput.getSourceCollection();
		// collect input files from source path
		try {
			if (!sourcePath.isEmpty()) {
				/*
				 * This condition is added because for ASCS file names differ by
				 * dates hence to match it with regular expression and fetch
				 * correct file from specified directory
				 * 
				 */
				SystemProperties.initializeProperties("eas");
				String hadoopFileSystem = SystemProperties.getProperty(IConstants.HADOOP_FILESYSTEM);

				logger.debug("Hadoop Switch : " + hadoopFileSystem);

				if (hadoopFileSystem.equals("true")) {
					Configuration conf;
					FileSystem fs;
					FileStatus[] status;
					UtilityInterface utilityInterface;

					try {
						List<FileStatus> preFiles =  new ArrayList<>();
						List<FileStatus> otherFiles =  new ArrayList<>();
						conf = new Configuration();
						conf.set("fs.hdfs.impl", org.apache.hadoop.hdfs.DistributedFileSystem.class.getName());
						String hadoopUri = SystemProperties.getProperty(IConstants.HADOOP_URI);
						fs = FileSystem.get(new URI(hadoopUri), conf);
						status = fs.listStatus(new Path(sourcePath));
						
						for (int i = 0; i < status.length; i++) {
							
							String inputFileName = "";
							if (status[i].isFile()){
								
								inputFileName = status[i].getPath().toString().substring((status[i].getPath().toString().lastIndexOf('/')) + 1,status[i].getPath().toString().length());

							if (inputFileName.contains("_")	&& inputFileName.substring(0, inputFileName.indexOf('_')).equals("PRE"))
								preFiles.add(status[i]);
							else
								otherFiles.add(status[i]);}

						}
						
						if(preFiles.size() >= 1)
						{
							
							for (FileStatus aFile : preFiles) {
							
								if (aFile.isFile()) {
							utilityInterface = Utility.createObject(strType);
							utilityInterface.ingestRDMprocess(processInput, aFile.getPath().toString(), guidvalue,strType);
							Path path = aFile.getPath();
							String fileName = path.getParent() + IConstants.ARCHIVE + path.getName()
									+ new Timestamp(date.getTime()).toString().replaceAll(IConstants.REPLACE_COLON,
											IConstants.REPLACE_DASH);							
							
							fs.rename(new Path(path.toString()), new Path(fileName));							
							
							}
							}
						}
						for (FileStatus aFile : otherFiles) {
							if (aFile.isFile()) {
							utilityInterface = Utility.createObject(strType);
							utilityInterface.ingestRDMprocess(processInput, aFile.getPath().toString(), guidvalue,strType);
							Path path = aFile.getPath();
							String fileName = path.getParent() + IConstants.ARCHIVE + path.getName()
									+ new Timestamp(date.getTime()).toString().replaceAll(IConstants.REPLACE_COLON,
											IConstants.REPLACE_DASH);
							fs.rename(new Path(path.toString()), new Path(fileName));							
							
							}
							}
						
						
					} catch (Exception e) {
						logger.debug("File not found");
					} finally {
						conf = null;
						fs = null;
						status = null;
						utilityInterface = null;
					}

				}

				else {

					File dir;
					File[] files;
					UtilityInterface utilityInterface;
					try {
						dir = new File(sourcePath);
						files = dir.listFiles();
						if (files.length == 0) 
							logger.debug("The directory is empty");
						else {							
							List<File> preFiles =  new ArrayList<>();
							List<File> otherFiles =  new ArrayList<>();

							for (File inputFile : files) {
								if (inputFile.isFile())
								{						
								
									if (inputFile.getName().contains("_") && inputFile.getName().substring(0, inputFile.getName().indexOf('_')).equals("PRE"))									
										preFiles.add(inputFile);								
									else									
										otherFiles.add(inputFile);
								}
							}
							if(preFiles.size() >= 1)
							{
							for (File aFile : preFiles) {
								if (aFile.isFile()) {
									utilityInterface = Utility.createObject(strType);
									utilityInterface.ingestRDMprocess(processInput, sourcePath + "/" + aFile.getName(),guidvalue, strType);
									try {
										aFile.renameTo(
												new File(
														sourcePath + IConstants.ARCHIVE + aFile.getName()
																+ new Timestamp(date.getTime()).toString().replaceAll(
																		IConstants.REPLACE_COLON,
																		IConstants.REPLACE_DASH)));
									} catch (Exception e) {
										logger.error("Unable to Archive File" + e);
									}finally{
										preFiles = null;
									}
								}
							}
							}
							for (File aFile : otherFiles) {
								if (aFile.isFile()) {
									utilityInterface = Utility.createObject(strType);
									utilityInterface.ingestRDMprocess(processInput, sourcePath + "/" + aFile.getName(),guidvalue, strType);
									try {
										aFile.renameTo(
												new File(
														sourcePath + IConstants.ARCHIVE + aFile.getName()
																+ new Timestamp(date.getTime()).toString().replaceAll(
																		IConstants.REPLACE_COLON,
																		IConstants.REPLACE_DASH)));
									} catch (Exception e) {
										logger.error("Unable to Archive File" + e);
									}finally{
										otherFiles = null;
									}
								}
							}
						}
						
					
					} catch (Exception e) {
					logger.error(IConstants.ERROR_PREPEND, e);
					
					} finally {
						dir = null;
						files = null;
						utilityInterface = null;
					}
				}
				logger.info("Done");
				logger.info("RDM Done for --> "
						+ strType.split(IConstants.SPLIT_DOT)[strType.split(IConstants.SPLIT_DOT).length - 1]);
				return true;

			} else {

				logger.error("No sample file available to process" + sourcePath + sourceCollection);
				return false;
			}

		} catch (Exception e) {
			logger.error("Exception:  "+ e);
		} finally {
			date = null;
		}

		return false;
	}

}