package com.anthem.marketplace.DataConsolidation.test;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.bson.BSONObject;
import org.bson.Document;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.filesutils.UtilityInterface;
import com.anthem.marketplace.dataconsolidation.filesutils.WSGRS;
import com.anthem.marketplace.dataconsolidation.job.processor.IngestRDM;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.FixedFileMetaDataProperties;
import com.anthem.marketplace.dataconsolidation.utils.GetSysProperties;
import com.anthem.marketplace.dataconsolidation.utils.GuidProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.InputConnectors;
import com.anthem.marketplace.dataconsolidation.utils.InputProperties;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFixedFileMetaData;
import com.anthem.marketplace.dataconsolidation.utils.ProcessGuid;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXml;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SystemProperties;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.util.JSON;

import scala.Tuple2;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "org.apache.hadoop.*", "javax.*", "com.sun.org.apache.*", "org.apache.log4j.*", "org.w3c.dom.*",
		"org.apache.xerces.*" })
@PrepareForTest({ WSGRS.class, ReadMappingXmlSingleton.class, MongoConnector.class, FieldNamesProperties.class,FixedFileMetaDataProperties.class,ReadMappingXml.class,
		Utility.class, SparkContextSingleton.class })

public class WSGRSTest {

	@Mock
	ReadMappingXmlSingleton readMappingXmlSingletonMock;

	@Mock
	ReadMappingXml readMappingXmlMock;

	@Mock
	SparkContextSingleton sparkContextSingletonMock;

	@Mock
	JavaSparkContext javaSparkContextMock;

	@Mock
	FieldNamesProperties fileNamesPropertiesMock;

	@Mock
	MongoConnector mongoConnectorMock;

	@Mock
	FixedFileMetaDataProperties fixedFileMetaDataPropertiesMock;

	// @Mock
	GuidProperties guidPropertiesMock;

	@Mock
	GetSysProperties getSysPropertiesMock;

	@Mock
	InputConnectors inputConnectorsMock;

	@Mock
	InputProperties inputPropertiesMock;

	@Mock
	ProcessInput processInput;

	@Mock
	ProcessGuid processGuid;

	@Mock
	IngestRDM irdObj;

	@Mock
	UtilityInterface utilityInterface;

	@Mock
	SystemProperties systemProperties;

	@Mock
	BSONObject bsonObjectMock;

	@Mock
	Utility utility;

	WSGRS wsgrs = (WSGRS) Utility.createObject("com.anthem.marketplace.dataconsolidation.filesutils.WSGRS");

	String sourceCollection = "WSGRS";

	String delimeted = " ";

	static final Logger logger = LoggerFactory.getLogger(IngestRDM.class);

	@Before
	public void setup() {

		/* ReadMappingXml Mock Singleton */

		PowerMockito.mockStatic(ReadMappingXmlSingleton.class);

		readMappingXmlSingletonMock = PowerMockito.mock(ReadMappingXmlSingleton.class);
		PowerMockito.when(ReadMappingXmlSingleton.getInstance()).thenReturn(readMappingXmlSingletonMock);

		readMappingXmlMock = PowerMockito.mock(ReadMappingXml.class);
		doReturn(readMappingXmlMock).when(readMappingXmlSingletonMock).getRead();

		/* SparkContextSingleton Mock Singleton */
		PowerMockito.mockStatic(SparkContextSingleton.class);

		sparkContextSingletonMock = PowerMockito.mock(SparkContextSingleton.class);
		PowerMockito.when(SparkContextSingleton.getInstance()).thenReturn(sparkContextSingletonMock);

		javaSparkContextMock = PowerMockito.mock(JavaSparkContext.class);
		doReturn(javaSparkContextMock).when(sparkContextSingletonMock).getSparkContext();

		/* MongoConnector Mock */
		PowerMockito.mockStatic(MongoConnector.class);
		mongoConnectorMock = PowerMockito.mock(MongoConnector.class);

		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);

		/* FieldNamesProperties Mock */
		PowerMockito.mockStatic(FieldNamesProperties.class);
		fileNamesPropertiesMock = PowerMockito.mock(FieldNamesProperties.class);

		PowerMockito.when(FieldNamesProperties.getInstance()).thenReturn(fileNamesPropertiesMock);

		/* FixedFileMetaDataProperties Mock */
		 PowerMockito.mockStatic(FixedFileMetaDataProperties.class);
		fixedFileMetaDataPropertiesMock = PowerMockito.mock(FixedFileMetaDataProperties.class);
		PowerMockito.when(FixedFileMetaDataProperties.getInstance()).thenReturn(fixedFileMetaDataPropertiesMock);

		/* GuidProperties Mock */
		// PowerMockito.mockStatic(GuidProperties.class);
		guidPropertiesMock = PowerMockito.mock(GuidProperties.class);

		// PowerMockito.when(GuidProperties.getInstance()).thenReturn(guidPropertiesMock);

		/* GuidProperties Mock */
		// PowerMockito.mockStatic(GetSysProperties.class);
		getSysPropertiesMock = PowerMockito.mock(GetSysProperties.class);

		// PowerMockito.when(GetSysProperties.getInstance()).thenReturn(getSysPropertiesMock);

		/* InputConnectors Mock */
		// PowerMockito.mockStatic(InputConnectors.class);
		inputConnectorsMock = PowerMockito.mock(InputConnectors.class);

		// PowerMockito.when(InputConnectors.getInstance()).thenReturn(inputConnectorsMock);

		/* InputProperties Mock */
		// PowerMockito.mockStatic(InputProperties.class);
		inputPropertiesMock = PowerMockito.mock(InputProperties.class);

		// PowerMockito.when(InputProperties.getInstance()).thenReturn(inputPropertiesMock);

		/* Utility Mock */
		PowerMockito.mockStatic(Utility.class);

	}
	
	@Test
	public void createGuidTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		
		String sourceCollection= "Renewals_WSGRS_Detail_MemBenInfo";	
		String delimeted =		"false";	
		Row  readFileContent	= RowFactory.create("70ACES    360853                 0000027129AAR9V     MED                 09702855901         09702855901         EMP609.6000                                                      942.53C01                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             REXTR V 2.0     2018101518000039");	
		String guidvalue = "GroupID1" ;	
		String type= "wsgrs_membeninfodet";
		
		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("11");
		processFixedFileMetaData.setend("20");
		
		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("GroupID1", type);
		
		wsgrs.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}
	
	
	@Test
	public void createFlagTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		
		String sourceCollection= "Renewals_WSGRS_Detail_MemBenInfo";	
		String delimeted =		"false";	
		Row  readFileContent	= RowFactory.create("70ACES    360853                 0000027129AAR9V     MED                 09702855901         09702855901         EMP609.6000                                                      942.53C01                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             REXTR V 2.0     2018101518000039");	
		String guidvalue = "GroupID1" ;	
		String type= "wsgrs_membeninfodet";
		
		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("11");
		processFixedFileMetaData.setend("20");
		
		Map<String,String> mandatoryFields = new HashMap<String,String>();
		mandatoryFields.put("1", "GroupID1");
		
		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(any(String.class), any(String.class));
		
		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("GroupID1", type);
		
		wsgrs.createFlag( delimeted,  sourceCollection,  readFileContent,  type);
		
	}
	
	
	
	@Test
	public void appendRawTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
	
		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/WSGRS/MemberBenInfo";
		Row  readFileContent	= RowFactory.create("70ACES    360853                 0000027129AAR9V     MED                 09702855901         09702855901         EMP609.6000                                                      942.53C01                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             REXTR V 2.0     2018101518000039");	
		
		String type ="wsgrs_membeninfodet";
		
		ProcessInput processInput1 = new ProcessInput();
		processInput1.setType("wsgrs_membeninfodet");
		processInput1.setSourceDB("RAW");
		processInput1.setSourceCollection("Renewals_WSGRS_Detail_MemBenInfo");
		
		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames.setArrayFieldNames("Record_type,Source_ID,GroupID1,GroupID2,Filler1,Prod_ID1,Prod_ID2,Prod_ID3,Prod_ID4,Subscriber_ID,Member_ID,Enrollment_Type,Current_Monthly_Prem,Member_LD_ClassID,Curr_Member_Salary,Curr_Member_Vol,Curr_ACA_Ins_Fee,Curr_ACA_ReIns_Fee,Curr_ACA_Exchng_Fee,Renewal_Monthly_Premium,Filler2,Audit_Trail_OperatorId,Audit_Trail_Prog_NM,Audit_Trail_Process_DT,Audit_Trail_Process_Time");
		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);
	
		String dataType ="String";
		String fieldNames ="Record_type";
		
		doReturn(dataType).when(readMappingXmlMock).getAttributeValueOfField(type,fieldNames, IConstants.DATATYPE);
		
		
		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("11");
		processFixedFileMetaData.setend("20");
		processFixedFileMetaData.setFieldName(fieldNames);
		
		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext(fieldNames, type);
		
		wsgrs.appendRaw(processInput1, sourcePath, "360853EMPSUBSCRALL", true, readFileContent);
	}
	
	
	@Test (expected = NullPointerException.class)
	public void selectFieldsTest()  {
		
		String value = "false";
		
		//String fieldNames = "medBrokerWritingTin" ;
		
		String type ="wsgrs_gpinfodet";
		String fieldNames = "addressLine3";
		
		BSONObject bsonObjectMock =  rawBSONObject();
		Tuple2<Object, BSONObject> bsonFilter = new Tuple2<>("1", bsonObjectMock);
		
		//Tuple2<Object, BSONObject> bsonFilter = ; 
				//"{ "_id" : "5bdc39af9ec007399438e9d1" , "GUID" : "403253NVA20190101SGGROUPALL" , "Record_type" : "40" , "State_CD" : "NV" , "Business_CD" : "A" , "MBU_Type" : "G" , "Source_ID" : "ISG" , "GroupID1" : "403253" , "GroupID2" : "" , "Target_Bill_Entity" : "403253" , "Group_Name" : "MOUNTAIN LAKE MGMT INC" , "Group_Billing_Addr1" : "STE101" , "Group_Billing_Addr2" : "6817 S EASTERN AVE" , "Group_Billing_City" : "LAS VEGAS" , "Group_Billing_State" : "NV" , "Group_Billing_Zip" : "89119" , "Group_Service_Addr1" : "395 MOUNTAIN LAKE COURT" , "Group_Service_Addr2" : "" , "Group_Service_City" : "INCLINE VILLAGE" , "Group_Service_State" : "NV" , "Group_Service_Zip" : "89451" , "Group_Service_County_CD" : "031" , "Group_Contact_Name" : "SUSAN K MYERS" , "Group_Original_EffDT" : { "$date" : "2006-07-01T04:00:00.000Z"} , "Group_RenewalDT" : { "$date" : "2019-01-01T05:00:00.000Z"} , "Group_Status" : "0" , "SIC" : "6799" , "Filler1" : "" , "Filler2" : "" , "Filler3" : "" , "Association_CD" : "" , "Association_Name" : "" , "Paper_Billing" : "" , "Filler4" : "Debbie Palmer" , "Filler5" : "" , "Account_Manager_ID" : "NV014" , "Sales_Rep_ID" : "NV014" , "Underwriter_ID" : "88" , "OnExchangeInd" : "OF" , "Group_SizeInd" : "1" , "Renewal_Format" : "acarenewal" , "Group_Change_Ind" : "" , "Member_Change_Ind" : "" , "Dental_Subscriber_Cnt" : "" , "Vision_Subscriber_Cnt" : "" , "Target_Dental_EligibleLives_Count" : "" , "Target_Vision_EligibleLives_Count" : "" , "Current_Dental_EligibleLives_Count" : "" , "Current_Vision_EligibleLives_Count" : "" , "Dental_Prior_Coverage" : "N" , "Group_FDocID" : "3806480168" , "Broker_FDocID" : "3806480137" , "Filler6" : "3806480168          3806480137" , "Audit_Trail_Oper_Id" : "REXTR V" , "Audit_Trail_Pgm_Name" : "2.0" , "Audit_Trail_Process_Date" : { "$date" : "2018-10-15T04:00:00.000Z"} , "Audit_Trail_Process_Time" : "18000006" , "type" : "SG" , "relationship" : "GROUP" , "start-date" : "2018-11-02 17:19:03.62" , "end-date" : "9999-12-31 00:00:00:000" , "source-path" : "D:/372712/Employer Broker/FeedFile/apps/Renewals/WSGRS/GroupInfo/WSGRS_Group_Info_PROD_20181015180006_Name.txt" , "source" : "WSGRS" , "Version" : "V1" , "status" : "un-processed" , "Data_Quality_Check" : "passed" }";
		
		String collName = "contacts";
		
		String sourcecollection = "Renewals_WSGRS_Detail_GroupInfo";
		
		doReturn(value).when(readMappingXmlMock).getAttributeValueOfField(type,fieldNames, IConstants.DATATYPE);
		
		wsgrs.selectFields( fieldNames,bsonFilter,  collName, sourcecollection);
		
	}
	
	
	@Test (expected = NullPointerException.class)
	public void selectFieldsTest2()  {
		
		String value = "false";
		
		//String fieldNames = "medBrokerWritingTin" ;
		
		String type ="wsgrs_gpinfodet";
		String fieldNames = "addressLine3";
		
		Document bsondoc = new Document(); 
		
		//Tuple2<Object, BSONObject> bsonFilter = ; 
				//"{ "_id" : "5bdc39af9ec007399438e9d1" , "GUID" : "403253NVA20190101SGGROUPALL" , "Record_type" : "40" , "State_CD" : "NV" , "Business_CD" : "A" , "MBU_Type" : "G" , "Source_ID" : "ISG" , "GroupID1" : "403253" , "GroupID2" : "" , "Target_Bill_Entity" : "403253" , "Group_Name" : "MOUNTAIN LAKE MGMT INC" , "Group_Billing_Addr1" : "STE101" , "Group_Billing_Addr2" : "6817 S EASTERN AVE" , "Group_Billing_City" : "LAS VEGAS" , "Group_Billing_State" : "NV" , "Group_Billing_Zip" : "89119" , "Group_Service_Addr1" : "395 MOUNTAIN LAKE COURT" , "Group_Service_Addr2" : "" , "Group_Service_City" : "INCLINE VILLAGE" , "Group_Service_State" : "NV" , "Group_Service_Zip" : "89451" , "Group_Service_County_CD" : "031" , "Group_Contact_Name" : "SUSAN K MYERS" , "Group_Original_EffDT" : { "$date" : "2006-07-01T04:00:00.000Z"} , "Group_RenewalDT" : { "$date" : "2019-01-01T05:00:00.000Z"} , "Group_Status" : "0" , "SIC" : "6799" , "Filler1" : "" , "Filler2" : "" , "Filler3" : "" , "Association_CD" : "" , "Association_Name" : "" , "Paper_Billing" : "" , "Filler4" : "Debbie Palmer" , "Filler5" : "" , "Account_Manager_ID" : "NV014" , "Sales_Rep_ID" : "NV014" , "Underwriter_ID" : "88" , "OnExchangeInd" : "OF" , "Group_SizeInd" : "1" , "Renewal_Format" : "acarenewal" , "Group_Change_Ind" : "" , "Member_Change_Ind" : "" , "Dental_Subscriber_Cnt" : "" , "Vision_Subscriber_Cnt" : "" , "Target_Dental_EligibleLives_Count" : "" , "Target_Vision_EligibleLives_Count" : "" , "Current_Dental_EligibleLives_Count" : "" , "Current_Vision_EligibleLives_Count" : "" , "Dental_Prior_Coverage" : "N" , "Group_FDocID" : "3806480168" , "Broker_FDocID" : "3806480137" , "Filler6" : "3806480168          3806480137" , "Audit_Trail_Oper_Id" : "REXTR V" , "Audit_Trail_Pgm_Name" : "2.0" , "Audit_Trail_Process_Date" : { "$date" : "2018-10-15T04:00:00.000Z"} , "Audit_Trail_Process_Time" : "18000006" , "type" : "SG" , "relationship" : "GROUP" , "start-date" : "2018-11-02 17:19:03.62" , "end-date" : "9999-12-31 00:00:00:000" , "source-path" : "D:/372712/Employer Broker/FeedFile/apps/Renewals/WSGRS/GroupInfo/WSGRS_Group_Info_PROD_20181015180006_Name.txt" , "source" : "WSGRS" , "Version" : "V1" , "status" : "un-processed" , "Data_Quality_Check" : "passed" }";
		
		String collName = "contacts";
		
		String sourcecollection = "Renewals_WSGRS_Detail_GroupInfo";
		
		doReturn(value).when(readMappingXmlMock).getAttributeValueOfField(type,fieldNames, IConstants.DATATYPE);
		
		wsgrs.getClass();
		
		wsgrs.selectFields( fieldNames,  bsondoc,  collName,  sourcecollection) ;
		
	}
	
	/*@Test (expected = NullPointerException.class)
	public void selectFieldsTest3()  {
		
		String value = "false";
		
		//String fieldNames = "medBrokerWritingTin" ;
		
		String type ="wsgrs_gpinfodet";
		String fieldNames = "addressLine3";
		
		Document docRen = new Document(); 
		
		//Tuple2<Object, BSONObject> bsonFilter = ; 
				//"{ "_id" : "5bdc39af9ec007399438e9d1" , "GUID" : "403253NVA20190101SGGROUPALL" , "Record_type" : "40" , "State_CD" : "NV" , "Business_CD" : "A" , "MBU_Type" : "G" , "Source_ID" : "ISG" , "GroupID1" : "403253" , "GroupID2" : "" , "Target_Bill_Entity" : "403253" , "Group_Name" : "MOUNTAIN LAKE MGMT INC" , "Group_Billing_Addr1" : "STE101" , "Group_Billing_Addr2" : "6817 S EASTERN AVE" , "Group_Billing_City" : "LAS VEGAS" , "Group_Billing_State" : "NV" , "Group_Billing_Zip" : "89119" , "Group_Service_Addr1" : "395 MOUNTAIN LAKE COURT" , "Group_Service_Addr2" : "" , "Group_Service_City" : "INCLINE VILLAGE" , "Group_Service_State" : "NV" , "Group_Service_Zip" : "89451" , "Group_Service_County_CD" : "031" , "Group_Contact_Name" : "SUSAN K MYERS" , "Group_Original_EffDT" : { "$date" : "2006-07-01T04:00:00.000Z"} , "Group_RenewalDT" : { "$date" : "2019-01-01T05:00:00.000Z"} , "Group_Status" : "0" , "SIC" : "6799" , "Filler1" : "" , "Filler2" : "" , "Filler3" : "" , "Association_CD" : "" , "Association_Name" : "" , "Paper_Billing" : "" , "Filler4" : "Debbie Palmer" , "Filler5" : "" , "Account_Manager_ID" : "NV014" , "Sales_Rep_ID" : "NV014" , "Underwriter_ID" : "88" , "OnExchangeInd" : "OF" , "Group_SizeInd" : "1" , "Renewal_Format" : "acarenewal" , "Group_Change_Ind" : "" , "Member_Change_Ind" : "" , "Dental_Subscriber_Cnt" : "" , "Vision_Subscriber_Cnt" : "" , "Target_Dental_EligibleLives_Count" : "" , "Target_Vision_EligibleLives_Count" : "" , "Current_Dental_EligibleLives_Count" : "" , "Current_Vision_EligibleLives_Count" : "" , "Dental_Prior_Coverage" : "N" , "Group_FDocID" : "3806480168" , "Broker_FDocID" : "3806480137" , "Filler6" : "3806480168          3806480137" , "Audit_Trail_Oper_Id" : "REXTR V" , "Audit_Trail_Pgm_Name" : "2.0" , "Audit_Trail_Process_Date" : { "$date" : "2018-10-15T04:00:00.000Z"} , "Audit_Trail_Process_Time" : "18000006" , "type" : "SG" , "relationship" : "GROUP" , "start-date" : "2018-11-02 17:19:03.62" , "end-date" : "9999-12-31 00:00:00:000" , "source-path" : "D:/372712/Employer Broker/FeedFile/apps/Renewals/WSGRS/GroupInfo/WSGRS_Group_Info_PROD_20181015180006_Name.txt" , "source" : "WSGRS" , "Version" : "V1" , "status" : "un-processed" , "Data_Quality_Check" : "passed" }";
		
		String coll = "contacts";
		
		String sourcecollection = "Renewals_WSGRS_Detail_GroupInfo";
		
		doReturn(value).when(readMappingXmlMock).getAttributeValueOfField(type,fieldNames, IConstants.DATATYPE);
		
		wsgrs.selectFields( fieldNames,  docRen,  coll);
		
	}*/
	
	@Test 
	public void appendCollectionsTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException  {
		BSONObject bsonObjectMock =  rawBSONObject();
		Tuple2<Object, BSONObject> bsonFilter = new Tuple2<>("1", bsonObjectMock);
		
		Document docRen = new Document();
		docRen.getClass();
		docRen.append("Agent_TaxID", "3613435478");
		docRen.append("Agency_TaxID", "3613435478");
		docRen.append("Gen_Agency_TaxID", "3613435478");
		
		
		ProcessFieldNames procFieldNamesAgent = new ProcessFieldNames();
		procFieldNamesAgent.setArrayFieldNames("taxID,agentID,taxIDType,product,agentReference,name,AOREffectiveDate,AOREndDate");
		doReturn(procFieldNamesAgent).when(fileNamesPropertiesMock).getPropertyContext(IConstants.CLIENT_AGENT);
		
		String[] product = { IConstants.AGENT_TAX_ID, IConstants.AGENCY_TAX_ID,
				IConstants.GEN_AGENCY_TAX_ID };
		
		wsgrs.appendCollections(product, IConstants.PROD_TYPE, IConstants.PRODUCT, "agentID",procFieldNamesAgent, IConstants.CLIENT_AGENT, bsonFilter, any(Document.class), sourceCollection, "TDM");
		
	}
	
	@Test (expected = NullPointerException.class)
	public void appendCollectionsTest1() throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException   {
		
		Document doc = new Document();
		String[] addr1 = { "billing", "service" };
		BSONObject bsonObjectMock =  rawBSONObject();
		Tuple2<Object, BSONObject> bsonFilter = new Tuple2<>("1", bsonObjectMock);
		
		ProcessFieldNames procFieldNamesClientContacts = new ProcessFieldNames();
		procFieldNamesClientContacts.setArrayFieldNames("addressType,addressLine1,addressLine2,addressLine3,countryCode,cityName,countyCode,countyName,stateCode,stateName,postalCode,phoneTypeCode,phoneAreaCode,phoneNumber,emailAddress");
		doReturn(procFieldNamesClientContacts).when(fileNamesPropertiesMock).getPropertyContext(IConstants.CLIENT_CONTACTS);
		
		wsgrs.appendCollections(addr1, IConstants.ADDR_TYPE, IConstants.ADDRESS_TYPE, IConstants.STATE_CODE,procFieldNamesClientContacts, IConstants.CLIENT_CONTACTS, bsonFilter, "TDM");
		
	}
	
	/*@Test  //(expected = NullPointerException.class)
	public void appendCollectionsTest2() throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException   {
		
		String[] product = { IConstants.AGENT_TAX_ID, IConstants.AGENCY_TAX_ID,IConstants.GEN_AGENCY_TAX_ID };
		
		ProcessFieldNames procFieldNamesagentsModified = new ProcessFieldNames();
		procFieldNamesagentsModified.setArrayFieldNames("agentID,taxIDType,product,agentReference,name,AOREffectiveDate,AOREndDate");
		doReturn(procFieldNamesagentsModified).when(fileNamesPropertiesMock).getPropertyContext("agentsModified");
		
		String fieldNames="agentID";
		String dataType ="String";
		
		doReturn(dataType).when(readMappingXmlMock).getAttributeValueOfField(IConstants.WSGRS_RENEWALS.concat("agentsModified"), fieldNames, IConstants.PROD_TYPE);
		
		wsgrs.appendCollections(product, IConstants.PROD_TYPE, IConstants.PRODUCT, "agentID",procFieldNamesagentsModified, "agentsModified", any(Document.class));
		
	}*/
	
	
	@Test(expected= NullPointerException.class)
	public void ingestRDMProcessTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		HashMap<String, ProcessInput> inputProperties = new HashMap<>();

		String[] list = { "wsgrs_gpinfodet", "wsgrs_gpbeninfodet", "wsgrs_meminfodet", "wsgrs_membeninfodet",
				"wsgrs_gpbrinfodet" };
		
		String guidValue = "GroupID1,State_CD";
		
		 processInput.setArraySourcePath(list);
		
			  processInput.setType("wsgrs_gpinfodet");
			  processInput.setSourceCollection("Renewals_WSGRS_GroupInfo");
			  processInput.setDelimeted("true");
			  processInput.setDelimeter("\\|");
			  processInput.setSourceDB("RAW");
			  processInput.setFailedCollection("Renewals_WSGRS_DQ_Reject");
			  
			  String sourcePath =" D:/372712/Employer Broker/FeedFile/apps/Renewals/WSGRS/GroupInfo";
			  
			  wsgrs.ingestRDMprocess(processInput,sourcePath, guidValue, processInput.getType());
		
	}

	@Test
	public void ingestSDSProcessTestone()
	{
		
		String sourceDb = "RAW";
		String sourceCollection= "Renewals_SGRS_GroupInfo";
		Tuple2<Object, BSONObject> bsonFilter = new Tuple2<>("1", bsonObjectMock);
		ProcessFieldNames procFieldNames= new ProcessFieldNames();
		String targetDb ="TDM";
		String targetCollection ="Renewals_tdm_Renewal"; 
		String targetDetailCollection ="Renewals_tdm_Client";
		String sourceDbTDM= "TDM";
		
		wsgrs.ingestSDSProcess(sourceDb, sourceCollection, bsonFilter, procFieldNames, targetDb, targetCollection, targetDetailCollection, sourceDbTDM);
	}
	
	@Test
	public void ingestSDSProcessTestTwo()
	{
		String sourceDb = "RAW";
		String sourceCollection= "Renewals_SGRS_GroupInfo";
		wsgrs.ingestSDSProcess(sourceDb, sourceCollection);
		
	}
	
	@Test
	public void ingestSDSProcessTestThree()
	{
		String sourceDb = "RAW";
		String[] sourceColl ={"Renewals_tdm_Renewal","Renewals_tdm_Client"};
		Tuple2<Object, BSONObject> bsonFilter = new Tuple2<>("1", bsonObjectMock);

		String targetDb ="TDM";
		String targetCollection ="Renewals_tdm_Renewal"; 
		String sourceDbTDM= "TDM";
		
		wsgrs.ingestSDSProcess(sourceDb, sourceCollection);
		
	}
	
	
	private String Equals(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	@Test(expected = NullPointerException.class)
	public void wsgrsIngestTDMProcessTest() throws Exception {
		BSONObject bsonObjectMock = rawBSONObject();
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		
		String appendCollection = "renewals,contacts,agents";
		
		ProcessFieldNames clientFieldNames = new ProcessFieldNames();
		clientFieldNames.setArrayFieldNames("ID,type,relationship,renewalDate,effectiveDate,monthlyPremium,currentMonthlyPremium");
		doReturn(clientFieldNames).when(fileNamesPropertiesMock).getPropertyContext(IConstants.WSGRS_RENEWALS.concat("Renewals_tdm_Renewal").toString());
		
		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames.setArrayFieldNames("effectiveDate,renewalDate,currentMonthlyPremium,currentTotalPremium,currentContractPlanName,renewalMonthlyPremium,renewalTotalPremium,renewalContractPlanName");
		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(IConstants.RENEWAL_DETAILS);
	
		/*PowerMockito.doAnswer(new Answer<Void>() {
	        @Override
	        public Void answer(InvocationOnMock invocation) throws ParseException {
	        	 Document doc = (Document) invocation.getArguments()[4];
	        	 	doc.append("ID", "236M64949");
		    		doc.append("renewalDate", new Timestamp(new java.util.Date().getTime()).toString());
		    		doc.append("effectiveDate", new Timestamp(new java.util.Date().getTime()).toString());
		    		doc.append("monthlyPremium", Double.parseDouble("942.0"));
		    		doc.append("currentMonthlyPremium", Double.parseDouble("863.0"));
				return null;
	        }
	    }).when(wsgrs).addToDocument(any(ProcessFieldNames.class), any(Tuple2.class), any(String.class), any(Document.class));
		*/
		
		
		Document doc = wsgrs.ingestTDMProcess("RDM", "Renewals_WSGRS_Detail_GroupInfo", bsonFilterMock, 
				"TDM",	"Renewals_tdm_Client", "None");
	}
	
	
	public static BSONObject rawBSONObject() {
String clientrdm = "{    \r\n" + 
 " \"_id\" : ObjectId(\"5b2a1a533b113945328f942e\"),\r\n" + 
 " \"GUID\" : \"152559CAB20180601SGGROUPALL\",\r\n" + 
 " \"Record_type\" : \"40\",\r\n" + 
 " \"State_CD\" : \"CA\",\r\n" + 
 " \"Business_CD\" : \"B\",\r\n" + 
 " \"MBU_Type\" : \"G\",\r\n" + 
 " \"Source_ID\" : \"WGS\",\r\n" + 
 " \"GroupID1\" : \"152559\",\r\n" + 
 " \"GroupID2\" : \"\",\r\n" + 
 " \"Target_Bill_Entity\" : \"152559\",\r\n" + 
 " \"Group_Name\" : \"HARBOR HEALTH CARE INC\",\r\n" + 
 " \"Group_Billing_Addr1\" : \"16917 CLARK AVE\",\r\n" + 
 " \"Group_Billing_Addr2\" : \"\",\r\n" + 
 " \"Group_Billing_City\" : \"BELLFLOWER\",\r\n" + 
 " \"Group_Billing_State\" : \"CA\",\r\n" + 
 " \"Group_Billing_Zip\" : \"907060000\",\r\n" + 
 " \"Group_Service_Addr1\" : \"16917 CLARK AVE\",\r\n" + 
 " \"Group_Service_Addr2\" : \"\",\r\n" + 
 " \"Group_Service_City\" : \"BELLFLOWER\",\r\n" + 
 " \"Group_Service_State\" : \"CA\",\r\n" + 
 " \"Group_Service_Zip\" : \"907060000\",\r\n" + 
 " \"Group_Service_County_CD\" : \"037\",\r\n" + 
 " \"Group_Contact_Name\" : \"CHERYL LOFLIN WERTZ\",\r\n" + 
 " \"Group_Original_EffDT\" : ISODate(\"2005-06-01T04:00:00.000Z\"),\r\n" + 
 " \"Group_RenewalDT\" : ISODate(\"2018-06-01T04:00:00.000Z\"),\r\n" + 
 " \"Group_Status\" : \"0\",\r\n" + 
 " \"SIC\" : \"8399\",\r\n" + 
 " \"Filler1\" : \"\",\r\n" + 
 " \"Filler2\" : \"\",\r\n" + 
 " \"Filler3\" : \"\",\r\n" + 
 " \"Association_CD\" : \"\",\r\n" + 
 " \"Association_Name\" : \"\",\r\n" + 
 " \"Paper_Billing\" : \"\",\r\n" + 
 " \"Filler4\" : \"\",\r\n" + 
 " \"Filler5\" : \"\",\r\n" + 
 " \"Account_Manager_ID\" : \"CA099\",\r\n" + 
 " \"Sales_Rep_ID\" : \"GM005\",\r\n" + 
 " \"Underwriter_ID\" : \"999\",\r\n" + 
 " \"OnExchangeInd\" : \"OF\",\r\n" + 
 " \"Group_SizeInd\" : \"1\",\r\n" + 
 " \"Renewal_Format\" : \"acarenewal\",\r\n" + 
 " \"Group_Change_Ind\" : \"\",\r\n" + 
 " \"Member_Change_Ind\" : \"\",\r\n" + 
 " \"Dental_Subscriber_Cnt\" : \"\",\r\n" + 
 " \"Vision_Subscriber_Cnt\" : \"\",\r\n" + 
 " \"Target_Dental_EligibleLives_Count\" : \"\",\r\n" + 
 " \"Target_Vision_EligibleLives_Count\" : \"\",\r\n" + 
 " \"Current_Dental_EligibleLives_Count\" : \"\",\r\n" + 
 " \"Current_Vision_EligibleLives_Count\" : \"\",\r\n" + 
 " \"Dental_Prior_Coverage\" : \"N\",\r\n" + 
 " \"Group_FDocID\" : \"3613435478\",\r\n" + 
 " \"Broker_FDocID\" : \"3613435477\",\r\n" + 
 " \"Filler6\" : \"3613435478          3613435477\",\r\n" + 
 " \"Audit_Trail_Oper_Id\" : \"REXTR V\",\r\n" + 
 " \"Audit_Trail_Pgm_Name\" : \"2.0\",\r\n" + 
 " \"Audit_Trail_Process_Date\" : ISODate(\"2018-03-15T04:00:00.000Z\"),\r\n" + 
 " \"Audit_Trail_Process_Time\" : \"12000003\",\r\n" + 
 " \"type\" : \"SG\",\r\n" + 
 " \"relationship\" : \"GROUP\",\r\n" + 
 " \"start-date\" : \"2018-06-20 09:11:03.527\",\r\n" + 
 " \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n" + 
 " \"source-path\" : \"hdfs://mom9n90291.wellpoint.com:8020/apps/Renewals/WSGRS/GroupInfo/WSGRS_Group_Info_PROD_20180315120003.txt\",\r\n" + 
 " \"source\" : \"WSGRS\",\r\n" + 
 " \"Version\" : \"V1\",\r\n" + 
 " \"status\" : \"processed\",\r\n" + 
 " \"Data_Quality_Check\" : \"passed\" \r\n }";

		Document doc = (Document) Document.parse(clientrdm);
		BSONObject bsonObject = (BSONObject) JSON.parse(doc.toJson());
		return bsonObject;
	}
	
	
	
	@Test (expected = AssertionError.class)
	public void wsgrsIngestUDMProcessExceptionTest() {

		BSONObject bsonObjectMock = null;
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);


		Document doc = wsgrs.ingestUDMProcess("", "", bsonFilterMock, "ADS",
				"Renewals_udm_Client", "None");
		
		Assert.assertNull(doc);
	}

	@Test
	public void wsgrsIngestUDMProcessTest() {
		BSONObject bsonObjectMock = clientBSONObject();
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		Document doc = wsgrs.ingestUDMProcess("TDM", "Renewals_tdm_Client", bsonFilterMock, "ADS",
				"Renewals_udm_Client", "None");
	}

	public static BSONObject clientBSONObject() {
		String clientTdm = "{  \r\n" + "     \"_id\" : ObjectId(\"5b2a1d4467933441675bba49\"),\r\n"
				+ "	   \"GUID\" : \"152559CAB20180601SGGROUPALL\",\r\n" + "    \"ID\" : \"152559\",\r\n"
				+ "    \"groupID\" : \"152559\",\r\n" + "    \"sourceID\" : \"WGS\",\r\n" + "    \"type\" : \"SG\",\r\n"
				+ "    \"name\" : \"HARBOR HEALTH CARE INC\",\r\n" + "    \"billingEntity\" : \"152559\",\r\n"
				+ "\"SIC\" : \"8399\",\r\n" + "\"contactName\" : \"CHERYL LOFLIN WERTZ\",\r\n"
				+ "\"effectiveDate\" : ISODate(\"2005-06-01T04:00:00.000Z\"),\r\n"
				+ "\"renewalDate\" : ISODate(\"2018-06-01T04:00:00.000Z\"),\r\n"
				+ "\"accountManagerID\" : \"CA099\",\r\n" + "\"salesRepID\" : \"GM005\",\r\n"
				+ "\"underwriterID\" : \"999\",\r\n" + "\"exchangeIndicator\" : \"OF\",\r\n" + "\"size\" : \"1\",\r\n"
				+ "\"businessCode\" : \"B\",\r\n" + "\"relationship\" : \"GROUP\",\r\n" + "\"groupStatus\" : \"0\",\r\n"
				+ "\"MBUType\" : \"G\",\r\n" + "\"groupFDocID\" : \"3613435478\",\r\n"
				+ "\"brokerFDocID\" : \"3613435477\",\r\n" + "\"Employee\" : [ \r\n" + "    {  \r\n"
				+ "        \"subscriberID\" : \"757A70267020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"DEBORAH\",\r\n" + "        \"lastName\" : \"SPIVEY\",\r\n"
				+ "        \"dateofBirth\" : \"19580126\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"3109 LOS FLORES APT A\",\r\n"
				+ "                \"cityName\" : \"LYNWOOD\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"902620000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"759M88832020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"JANINE\",\r\n" + "        \"lastName\" : \"MCILVAINE\",\r\n"
				+ "        \"dateofBirth\" : \"19891020\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"4543 MONOGRAM AVE\",\r\n"
				+ "                \"cityName\" : \"LAKEWOOD\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"907130000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"781A70267020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"JANET\",\r\n" + "        \"lastName\" : \"JOHNSON\",\r\n"
				+ "        \"dateofBirth\" : \"19560401\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"601 NORTH KIRBY STREET\",\r\n"
				+ "                \"cityName\" : \"HEMET\",\r\n" + "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"925450000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"518A70267020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"NIKKIA\",\r\n" + "        \"lastName\" : \"FULLER\",\r\n"
				+ "        \"dateofBirth\" : \"19730619\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"139 EAST 66TH ST\",\r\n"
				+ "                \"cityName\" : \"LOS ANGELES\",\r\n"
				+ "                \"countyCode\" : \"037\",\r\n" + "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"900030000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"259M88725020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"MIRANDA\",\r\n" + "        \"lastName\" : \"MITCHELL-LOFLIN\",\r\n"
				+ "        \"dateofBirth\" : \"19951218\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"11 BLUEJAY DR.\",\r\n"
				+ "                \"cityName\" : \"ALISO VIEJO\",\r\n"
				+ "                \"countyCode\" : \"059\",\r\n" + "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"926560000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"545A78586010\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"JOHN\",\r\n" + "        \"lastName\" : \"GRAY III\",\r\n"
				+ "        \"dateofBirth\" : \"19780918\",\r\n" + "        \"gender\" : \"M\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"10807 EXCELSIOR DR\",\r\n"
				+ "                \"cityName\" : \"NORWALK\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"906500000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"307A75626010\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"ARMINGOL\",\r\n" + "        \"lastName\" : \"PILAPIL JR\",\r\n"
				+ "        \"dateofBirth\" : \"19600812\",\r\n" + "        \"gender\" : \"M\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"12022 ARMSDALE AVE\",\r\n"
				+ "                \"cityName\" : \"WHITTIER\",\r\n" + "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"906040000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"569A70267020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"TOYLING\",\r\n" + "        \"lastName\" : \"JOHNSON\",\r\n"
				+ "        \"dateofBirth\" : \"19591122\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"2264 E 115TH ST\",\r\n"
				+ "                \"cityName\" : \"LOS ANGELES\",\r\n"
				+ "                \"countyCode\" : \"037\",\r\n" + "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"900590000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"581M85060020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"CEOLA\",\r\n" + "        \"lastName\" : \"WEBB\",\r\n"
				+ "        \"dateofBirth\" : \"19610119\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"9530 ARTESIA BLVD APT 3\",\r\n"
				+ "                \"cityName\" : \"BELLFLOWER\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"907060000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"318A70267010\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"WAYNE\",\r\n" + "        \"lastName\" : \"WERTZ\",\r\n"
				+ "        \"dateofBirth\" : \"19631026\",\r\n" + "        \"gender\" : \"M\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"11 BLUE JAY DR\",\r\n"
				+ "                \"cityName\" : \"ALISO VIEJO\",\r\n"
				+ "                \"countyCode\" : \"059\",\r\n" + "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"926560000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"340A72836020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"LETICIA\",\r\n" + "        \"lastName\" : \"SMITH\",\r\n"
				+ "        \"dateofBirth\" : \"19740811\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"1618 1/2 W 105TH ST\",\r\n"
				+ "                \"cityName\" : \"LOS ANGELES\",\r\n"
				+ "                \"countyCode\" : \"037\",\r\n" + "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"900470000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"061M76177020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"SHARON\",\r\n" + "        \"lastName\" : \"NEAL\",\r\n"
				+ "        \"dateofBirth\" : \"19901231\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"771 1/2 E VIA WANDA\",\r\n"
				+ "                \"cityName\" : \"LONG BEACH\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"908050000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"860M80601010\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"DAVID\",\r\n" + "        \"lastName\" : \"WALKER\",\r\n"
				+ "        \"dateofBirth\" : \"19900328\",\r\n" + "        \"gender\" : \"M\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"15911 S CARPINTERO 4\",\r\n"
				+ "                \"cityName\" : \"BELLFLOWER\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"907060000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"597A73855020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"CHRISTINA\",\r\n" + "        \"lastName\" : \"MARTINEZ\",\r\n"
				+ "        \"dateofBirth\" : \"19550929\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"7400 ARTESIA BLVD APT1401\",\r\n"
				+ "                \"cityName\" : \"BUENA PARK\",\r\n" + "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"906210000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"622A70267010\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"ERICK\",\r\n" + "        \"lastName\" : \"POTTS\",\r\n"
				+ "        \"dateofBirth\" : \"19700728\",\r\n" + "        \"gender\" : \"M\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"1023 STEELE DRIVE\",\r\n"
				+ "                \"cityName\" : \"BREA\",\r\n" + "                \"countyCode\" : \"059\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"928210000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"892A78728020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"SHANTELL\",\r\n" + "        \"lastName\" : \"HEARD\",\r\n"
				+ "        \"dateofBirth\" : \"19901018\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"9346 MAPLE STREET\",\r\n"
				+ "                \"cityName\" : \"BELLFLOWER\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"907060000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"899A70910020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"VICKIE\",\r\n" + "        \"lastName\" : \"RHODES\",\r\n"
				+ "        \"dateofBirth\" : \"19550130\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"11535 214TH ST\",\r\n"
				+ "                \"cityName\" : \"LAKEWOOD\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"907150000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"654A70267010\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"STEVEN\",\r\n" + "        \"lastName\" : \"SHERMAN\",\r\n"
				+ "        \"dateofBirth\" : \"19691208\",\r\n" + "        \"gender\" : \"M\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"3211 CERRITOS AVE\",\r\n"
				+ "                \"cityName\" : \"SIGNAL HILL\",\r\n"
				+ "                \"countyCode\" : \"037\",\r\n" + "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"907550000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"401A70267020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"CHERYL\",\r\n" + "        \"lastName\" : \"LOFLIN WERTZ\",\r\n"
				+ "        \"dateofBirth\" : \"19570618\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"11 BLUE JAY DRIVE\",\r\n"
				+ "                \"cityName\" : \"ALISO VIEJO\",\r\n"
				+ "                \"countyCode\" : \"059\",\r\n" + "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"926560000\"            }        ],\r\n"
				+ "        \"Dependent\" : [ \r\n" + "            {  \r\n"
				+ "                \"memberID\" : \"401A70267050\",\r\n"
				+ "                \"relationship\" : \"DPNDT\",\r\n" + "                \"firstName\" : \"JACOB\",\r\n"
				+ "                \"lastName\" : \"LOFLIN\",\r\n"
				+ "                \"dateofBirth\" : \"19930625\",\r\n" + "                \"gender\" : \"M\",\r\n"
				+ "                \"tobaccoUsage\" : \"N\",\r\n" + "                \"tobaccoWellness\" : \"N\",\r\n"
				+ "                \"otherWellness\" : \"N\",\r\n" + "                \"consumerChoice\" : \"N\",\r\n"
				+ "                \"calCobraStateContInd\" : \"N\",\r\n" + "                \"contacts\" : [ \r\n"
				+ "                    {  \r\n" + "                        \"addressType\" : \"mailing\",\r\n"
				+ "                        \"addressLine1\" : \"11 BLUE JAY DRIVE\",\r\n"
				+ "                        \"cityName\" : \"ALISO VIEJO\",\r\n"
				+ "                        \"countyCode\" : \"059\",\r\n"
				+ "                        \"stateName\" : \"CA\",\r\n"
				+ "                        \"postalCode\" : \"926560000\"                    }                ]            },\r\n"
				+ "             {  \r\n" + "                \"memberID\" : \"401A70267070\",\r\n"
				+ "                \"relationship\" : \"DPNDT\",\r\n"
				+ "                \"firstName\" : \"ALLISON\",\r\n" + "                \"lastName\" : \"WERTZ\",\r\n"
				+ "                \"dateofBirth\" : \"19980728\",\r\n" + "                \"gender\" : \"F\",\r\n"
				+ "                \"tobaccoUsage\" : \"N\",\r\n" + "                \"tobaccoWellness\" : \"N\",\r\n"
				+ "                \"otherWellness\" : \"N\",\r\n" + "                \"consumerChoice\" : \"N\",\r\n"
				+ "                \"calCobraStateContInd\" : \"N\",\r\n" + "                \"contacts\" : [ \r\n"
				+ "                    {  \r\n" + "                        \"addressType\" : \"mailing\",\r\n"
				+ "                        \"addressLine1\" : \"11 BLUE JAY DRIVE\",\r\n"
				+ "                        \"cityName\" : \"ALISO VIEJO\",\r\n"
				+ "                        \"countyCode\" : \"059\",\r\n"
				+ "                        \"stateName\" : \"CA\",\r\n"
				+ "                        \"postalCode\" : \"926560000\"                    }                ]            }        ]    },\r\n"
				+ "     {  \r\n" + "        \"subscriberID\" : \"678M90041020\",\r\n"
				+ "        \"relationship\" : \"SCRBR\",\r\n" + "        \"firstName\" : \"MAGDALENA\",\r\n"
				+ "        \"lastName\" : \"CHAVEZ\",\r\n" + "        \"dateofBirth\" : \"19530529\",\r\n"
				+ "        \"gender\" : \"F\",\r\n" + "        \"tobaccoUsage\" : \"N\",\r\n"
				+ "        \"tobaccoWellness\" : \"N\",\r\n" + "        \"otherWellness\" : \"N\",\r\n"
				+ "        \"consumerChoice\" : \"N\",\r\n" + "        \"calCobraStateContInd\" : \"N\",\r\n"
				+ "        \"contacts\" : [ \r\n" + "            {  \r\n"
				+ "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"14411 CORBY AVE\",\r\n"
				+ "                \"cityName\" : \"NORWALK\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"906500000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"687A69594020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"CLAUDIA\",\r\n" + "        \"lastName\" : \"TREJO\",\r\n"
				+ "        \"dateofBirth\" : \"19840417\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"12219 ROSETON AVENUE\",\r\n"
				+ "                \"cityName\" : \"NORWALK\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"906500000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"947M90041020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"EMILY\",\r\n" + "        \"lastName\" : \"MENDOZA AVILA\",\r\n"
				+ "        \"dateofBirth\" : \"19980316\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"461 E MORNINGSIDE ST\",\r\n"
				+ "                \"cityName\" : \"LONG BEACH\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"908050000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"960A74652020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"CHERYL\",\r\n" + "        \"lastName\" : \"PEARSON\",\r\n"
				+ "        \"dateofBirth\" : \"19671107\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"15911 S CARPINTERO AVE 4\",\r\n"
				+ "                \"cityName\" : \"BELLFLOWER\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"907060000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"451A71584020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"MARIA\",\r\n" + "        \"lastName\" : \"BENITEZ\",\r\n"
				+ "        \"dateofBirth\" : \"19650603\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"3358 LOS FLORES BLVD B\",\r\n"
				+ "                \"cityName\" : \"LYNWOOD\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"902620000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"695A24924020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"TAKESHA\",\r\n" + "        \"lastName\" : \"ANDERSON\",\r\n"
				+ "        \"dateofBirth\" : \"19790129\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"721 1/2 WEST IMPERIAL HWY\",\r\n"
				+ "                \"cityName\" : \"LOS ANGELES\",\r\n"
				+ "                \"countyCode\" : \"037\",\r\n" + "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"900440000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"201M90059020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"RUBY\",\r\n" + "        \"lastName\" : \"TURPIN\",\r\n"
				+ "        \"dateofBirth\" : \"19541231\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"15947 CALIFORNIA AVE\",\r\n"
				+ "                \"cityName\" : \"PARAMOUNT\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"907230000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"476M79804010\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"ROBERT\",\r\n" + "        \"lastName\" : \"MORGAN\",\r\n"
				+ "        \"dateofBirth\" : \"19960709\",\r\n" + "        \"gender\" : \"M\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"139 E 66TH ST\",\r\n"
				+ "                \"cityName\" : \"LOS ANGELES\",\r\n"
				+ "                \"countyCode\" : \"037\",\r\n" + "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"900030000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"729M85863020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"MARIAMA\",\r\n" + "        \"lastName\" : \"KAMARA\",\r\n"
				+ "        \"dateofBirth\" : \"19680304\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"8346 TELEGRAPH RD\",\r\n"
				+ "                \"cityName\" : \"DOWNEY\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"902400000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"736A70314020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"INGRID\",\r\n" + "        \"lastName\" : \"THOMASSON\",\r\n"
				+ "        \"dateofBirth\" : \"19750414\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"1049 E HILL ST\",\r\n"
				+ "                \"cityName\" : \"LONG BEACH\",\r\n" + "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"908060000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"737A70267020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"TAMMY\",\r\n" + "        \"lastName\" : \"BENNETT\",\r\n"
				+ "        \"dateofBirth\" : \"19650713\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"PO BOX 735\",\r\n"
				+ "                \"cityName\" : \"COMPTON\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"902230000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    },\r\n" + "     {  \r\n"
				+ "        \"subscriberID\" : \"740A71574020\",\r\n" + "        \"relationship\" : \"SCRBR\",\r\n"
				+ "        \"firstName\" : \"CYNTHIA\",\r\n" + "        \"lastName\" : \"STEWART\",\r\n"
				+ "        \"dateofBirth\" : \"19621016\",\r\n" + "        \"gender\" : \"F\",\r\n"
				+ "        \"tobaccoUsage\" : \"N\",\r\n" + "        \"tobaccoWellness\" : \"N\",\r\n"
				+ "        \"otherWellness\" : \"N\",\r\n" + "        \"consumerChoice\" : \"N\",\r\n"
				+ "        \"calCobraStateContInd\" : \"N\",\r\n" + "        \"contacts\" : [ \r\n"
				+ "            {  \r\n" + "                \"addressType\" : \"mailing\",\r\n"
				+ "                \"addressLine1\" : \"5499 LIME AVE C\",\r\n"
				+ "                \"cityName\" : \"LONG BEACH\",\r\n" + "                \"countyCode\" : \"037\",\r\n"
				+ "                \"stateName\" : \"CA\",\r\n"
				+ "                \"postalCode\" : \"908050000\"            }        ],\r\n"
				+ "        \"Dependent\" : []    }],\r\n" + "\"contacts\" : [ \r\n" + "    {  \r\n"
				+ "        \"addressType\" : \"billing\",\r\n" + "        \"addressLine1\" : \"16917 CLARK AVE\",\r\n"
				+ "        \"cityName\" : \"BELLFLOWER\",\r\n" + "        \"countyCode\" : \"037\",\r\n"
				+ "        \"stateCode\" : \"CA\",\r\n" + "        \"stateName\" : \"CA\",\r\n"
				+ "        \"postalCode\" : \"907060000\"    },\r\n" + "     {  \r\n"
				+ "        \"addressType\" : \"service\",\r\n" + "        \"addressLine1\" : \"16917 CLARK AVE\",\r\n"
				+ "        \"cityName\" : \"BELLFLOWER\",\r\n" + "        \"countyCode\" : \"037\",\r\n"
				+ "        \"stateCode\" : \"CA\",\r\n" + "        \"stateName\" : \"CA\",\r\n"
				+ "        \"postalCode\" : \"907060000\"    }],\r\n" + "\"agents\" : [ \r\n" + "    {  \r\n"
				+ "        \"taxID\" : \"JLKLJPLPWY\",\r\n" + "        \"agentID\" : \"592472656E\",\r\n"
				+ "        \"taxIDType\" : \"Writing\",\r\n" + "        \"product\" : \"default\",\r\n"
				+ "        \"name\" : \"INSURANCE OFFICE OF AMERICA INC\"    },\r\n" + "     {  \r\n"
				+ "        \"taxID\" : \"UNKNOWN\",\r\n" + "        \"agentID\" : \"\",\r\n"
				+ "        \"taxIDType\" : \"Parent\",\r\n" + "        \"product\" : \"default\",\r\n"
				+ "        \"name\" : \"NULL\"    },\r\n" + "     {  \r\n" + "        \"taxID\" : \"UNKNOWN\",\r\n"
				+ "        \"agentID\" : \"\",\r\n" + "        \"taxIDType\" : \"Paid\",\r\n"
				+ "        \"product\" : \"default\",\r\n" + "        \"name\" : \"NULL\"    }],\r\n"
				+ "\"renewals\" : {  \r\n" + "    \"renewalPeriod\" : 2018,\r\n"
				+ "    \"renewalReference\" : \"152559CAB20180601SGGROUPALL\"},\r\n"
				+ "\"start-date\" : \"2018-08-22 23:20:31.009\",\r\n"
				+ "\"end-date\" : \"2018-08-22 23:51:53.925\",\r\n"
				+ "\"source-path\" : \"hdfs://mom9n90291.wellpoint.com:8020/apps/Renewals/WSGRS/GroupInfo/WSGRS_Group_Info_PROD_20180315120003.txt\",\r\n"
				+ "\"source\" : \"WSGRS\",\r\n" + "\"Version\" : \"V1\",\r\n" + "\"status\" : \"processed\",\r\n"
				+ "\"Data_Quality_Check\" : \"passed\" \r\n" + "}";
		Document doc = (Document) Document.parse(clientTdm);
		BSONObject bsonObject = (BSONObject) JSON.parse(doc.toJson());
		return bsonObject;
	}

	
	
	
	
}
