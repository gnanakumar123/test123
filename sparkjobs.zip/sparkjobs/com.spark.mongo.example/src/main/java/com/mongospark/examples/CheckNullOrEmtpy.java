package com.mongospark.examples;

import java.io.Serializable;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import static org.apache.spark.sql.functions.when;
import static org.apache.spark.sql.functions.lit;

public class CheckNullOrEmtpy implements Serializable {

	public static void main(String[] args) {

		SparkSession spark = SparkSession.builder().master("local").appName("MongoSparkConnectorIntro")
				.config("spark.mongodb.input.uri", "mongodb://127.0.0.1/test.agent_lookup")
				.config("spark.mongodb.output.uri", "mongodb://127.0.0.1/test.agent_lookup").getOrCreate();

		// Create a Java Spark Context from a Spark Session
		JavaSparkContext jsc = new JavaSparkContext(spark.sparkContext());

		StructType groupBrokerSchema = DataTypes.createStructType(
				new StructField[] { DataTypes.createStructField("seqNumber", DataTypes.StringType, true),
						DataTypes.createStructField("groupId", DataTypes.StringType, true),
						DataTypes.createStructField("currentPremium", DataTypes.StringType, true),
						DataTypes.createStructField("renewalPremium", DataTypes.StringType, true)

				});

		Dataset<Row> groupBrokerDf = spark.read().format("csv") //
				.schema(groupBrokerSchema).option("header", "true") //
				.option("multiline", true) //
				.option("sep", ";") //
				.option("quote", "^") //
				.option("dateFormat", "M/d/y") //
				.option("inferSchema", true) //
				.load("src/main/resources/checknull.txt");

		String[] str = { "currentPremium", "renewalPremium" };

		Dataset<Row> groupBrokerDf1 = groupBrokerDf.withColumn("newCurrentPremium",
				when(groupBrokerDf.col("currentPremium").isNull(), lit("0").cast("double")));
		// Dataset<Row> nullreplaceDf =groupBrokerDf.na().fill(0.0,str);
		groupBrokerDf1.show(false);

	}

}
