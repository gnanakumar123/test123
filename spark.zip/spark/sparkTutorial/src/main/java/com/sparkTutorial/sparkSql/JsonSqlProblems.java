package com.sparkTutorial.sparkSql;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import static org.apache.spark.sql.functions.col;

import java.util.Arrays;

public class JsonSqlProblems {
	public static void main(String[] args) {
		Logger.getLogger("org").setLevel(Level.ERROR);

		// Create a Spark Session
		SparkSession session = SparkSession.builder().appName("SQLSurvey").master("local[*]").getOrCreate();
		
		// Create data set from sample
		//Dataset<Row> sample = session.createDataFrame(Arrays.asList(1,2,3), Integer.class);
		//sample.show();
		
		// Load data from csv file
		Dataset<Row> realEstate = session.read().option("header", "true").csv("in/RealEstate.csv");
		realEstate.printSchema();
		
		// Load the data from JSON file
		Dataset<Row> names = session.read().json("in/members.json");
		names.show();
		
		// Print the Schema
		
		// show the table contents
		
		// Show only the column name
		//names.select("name").show();
		names.select(col("name"), col("age")).show();
		
		// Show max age of members
		Dataset<Row> ages = names.selectExpr("max(age)");
		ages.show();
		
		ages.select(col("max(age)").as("Maximum Age")).show();
		
		// Group by city
		names.groupBy(col("city")).count().show();
		
		// Show the members with ages more than 60
		names.filter(col("age").$greater("60")).show();
		names.printSchema();
		
		// type cast the data types
		Dataset<Row> schemaDF = names.withColumn("age", col("age").cast("integer"));
		schemaDF.printSchema();
		
		names.filter(col("age").$greater(60)).show();
		
		// Show the age column in months
		names.select(col("age").$times(12)).show();
		
		// Limit the number of rows
		names.limit(2).show();
		
	}
}
