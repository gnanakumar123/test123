package com.anthem.marketplace.dataconsolidation.utils;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/*
 * This class reads ingest and transform related parameters from properties file and returns them.  
 */

public class InvokeType {
	static final  Logger logger = LoggerFactory.getLogger(InvokeType.class);
	private ArrayList<String> processList = new ArrayList<>();
	private static InvokeType instance;

	private InvokeType() throws IOException, NoSuchMethodException, ClassNotFoundException, InvocationTargetException,
			IllegalAccessException {

		processList = readProp("type.properties");


	}



	public List<String> getPropertyContext() {
		return processList;
	}
	

	public static synchronized InvokeType getInstance( ) {		//type needs to be passed...
		if (null == instance) {
			try {
				instance = new InvokeType();

			} catch (Exception e) {
				logger.error("Error{}", e);
			}
			
		}
		return instance;
	}
	
	
	private ArrayList<String> readProp(String configpath) throws IOException, NoSuchMethodException,
			ClassNotFoundException, InvocationTargetException, IllegalAccessException {
		ArrayList<String> strList = new ArrayList<>();
		Properties prop = new Properties();
		prop.load(InvokeType.class.getResourceAsStream("/"+configpath));
		Enumeration<?> propertyNames = prop.propertyNames();
		while (propertyNames.hasMoreElements()) {
			String key = (String) propertyNames.nextElement();
			String tempPropertyValue = prop.getProperty(key);
			if (Boolean.parseBoolean(tempPropertyValue))
				strList.add(key);
				
		}

		return strList;
	}	
	
}