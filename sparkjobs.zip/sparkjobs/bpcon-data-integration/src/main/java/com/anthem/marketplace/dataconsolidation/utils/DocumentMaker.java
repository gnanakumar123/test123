package com.anthem.marketplace.dataconsolidation.utils;

import java.io.InputStream;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

public class DocumentMaker {
	
	
	private static String MAP_XML="/mapping.xml";
	static final Logger logger = LoggerFactory.getLogger(ReadMappingXml.class);
	
	
	
	private  InputStream getMappingStream(){
		return getClass().getResourceAsStream(MAP_XML);
	}
	public Document createDocument(){
		
		Document doc = null;

		 try {
			
			DocumentBuilderFactory  dbFactory = DocumentBuilderFactory.newInstance();
			
			 dbFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
			 dbFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
			 dbFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
			 dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
			 dbFactory.setXIncludeAware(false);
			 dbFactory.setExpandEntityReferences(false);
			 
			 DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			 doc = dBuilder.parse(getMappingStream());
			 
		 } catch (Exception e) {
				// TODO Auto-generated catch block
			 logger.error(IConstants.ERROR_PREPEND, e);
					
		 }
		return doc;
	}
	}


