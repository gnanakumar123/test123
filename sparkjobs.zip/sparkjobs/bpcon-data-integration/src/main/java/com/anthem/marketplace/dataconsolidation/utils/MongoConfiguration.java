/**
 * 
 */
package com.anthem.marketplace.dataconsolidation.utils;

import org.apache.hadoop.conf.Configuration;

/**
 * @author AF07403
 *
 */
public class MongoConfiguration {

	/**
	 * 
	 */
	String sourceDb;
	String collection;
	Configuration conf;

	/* Performance Improvement Added inputQuery */
	//public Configuration setConfiguration(String type, String inputQuery) { 
	public MongoConfiguration(String sourceDb, String collection) {

		this.sourceDb = sourceDb;
		this.collection = collection;

	}

	public Configuration setConfiguration(String type) {

		conf = new Configuration();
		conf.set(IConstants.MONGO_INPUT_FORMAT_KEY, IConstants.MONGO_INPUT_FORMAT_VALUE);

		String confAddress = getConfAddress(type);
		conf.set(IConstants.MONGO_INPUT_URI, confAddress);

		conf.set("mongo.input.split.read_shard_chunks", "true");
		conf.set("mongo.input.split.create_input_splits", "false");
		/* Start : Performance Improvement Added inputQuery */
		//if(StringUtils.isNotEmpty(inputQuery))
	    //	conf.set("mongo.input.query", inputQuery);
		/* End : Performance Improvement Added inputQuery */
		return conf;
	}

	// private
	public String getConfAddress(String type) {

		SystemProperties.initializeProperties("connector");
		String confAddress = "";
			String localPort[] = SystemProperties.getProperty(type+"."+IConstants.ARRAY_CLUSTER_PORTS).split(",");
			String ipAdd[] = SystemProperties.getProperty(type+"."+IConstants.ARRAY_CLUSTER_IPADDRESS).split(",");
			String confAuthFlag = SystemProperties.getProperty(type+"."+IConstants.CONF_AUTH_FLAG);

			if (confAuthFlag.equals("false")){
				confAddress = "mongodb://" + ipAdd[0] + ":" + localPort[0] + "/"+ sourceDb + "." + collection;
			}else {
				String userName[] = SystemProperties.getProperty(type+"."+IConstants.ArrayClusterUserName).split(",");
				String passWord[] = SystemProperties.getProperty(type+"."+IConstants.ArrayClusterPassWord).split(",");
				confAddress = userName[0] + ":" + passWord[0] + "@" + ipAdd[0] + ":" + localPort[0]+",";
				confAddress="mongodb://" + confAddress.substring(0,confAddress.length()-1)+"/" + sourceDb + "." + collection;
				if (SystemProperties.getProperty(type + "." + IConstants.REPLICA_SET).equals("true")) {
					confAddress += "?replicaSet=" + SystemProperties.getProperty(type + "." + IConstants.REPLICA_SET_VALUE);
					/*BPP-38521 : Implement Mongodb SSL Feature to Data Load Project */
					if (SystemProperties.getProperty(type + "." + IConstants.SSL).equals("true"))
						confAddress += "&ssl=true";  
				} else {
					if (SystemProperties.getProperty(type + "." + IConstants.SSL).equals("true"))
						confAddress += "?ssl=true"; 
					/*BPP-38521 : Implement Mongodb SSL Feature to Data Load Project */
				}
			}

		return confAddress;
	}

}
