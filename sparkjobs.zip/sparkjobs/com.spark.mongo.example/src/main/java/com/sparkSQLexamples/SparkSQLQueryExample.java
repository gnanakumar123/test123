package com.sparkSQLexamples;

import static org.apache.spark.sql.functions.col;

import java.util.HashMap;
import java.util.Map;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.bean.Group;
import com.mongodb.spark.MongoSpark;
import com.mongodb.spark.config.WriteConfig;

public final class SparkSQLQueryExample {

	public static void main(final String[] args) throws InterruptedException {

		SparkSession spark = SparkSession.builder().master("local").appName("MongoSparkConnectorIntro")
				.config("spark.mongodb.input.uri", "mongodb://127.0.0.1/test.myCollection")
				.config("spark.mongodb.output.uri", "mongodb://127.0.0.1/test.myCollection").getOrCreate();

		JavaSparkContext jsc = new JavaSparkContext(spark.sparkContext());

		// Create a custom ReadConfig
		/*
		 * Map<String, String> readOverrides = new HashMap<String, String>();
		 * readOverrides.put("collection", "test");
		 * readOverrides.put("readPreference.name", "secondaryPreferred");
		 * ReadConfig readConfig =
		 * ReadConfig.create(jsc).withOptions(readOverrides);
		 */

		// Create a custom WriteConfig
		/*
		 * Map<String, String> writeOverrides = new HashMap<String, String>();
		 * writeOverrides.put("collection", "test");
		 * writeOverrides.put("writeConcern.w", "majority"); WriteConfig
		 * writeConfig = WriteConfig.create(jsc).withOptions(writeOverrides);
		 */

		StructType schema = DataTypes.createStructType(
				new StructField[] { DataTypes.createStructField("groupId", DataTypes.StringType, true),
						DataTypes.createStructField("firstName", DataTypes.StringType, true),
						DataTypes.createStructField("lastName", DataTypes.StringType, true),
						DataTypes.createStructField("premium", DataTypes.StringType, true),
						DataTypes.createStructField("renewalDate", DataTypes.StringType, true),

				});

		Dataset<Row> df = spark.read().format("csv") //
				.schema(schema).option("header", "true") //
				.option("multiline", true) //
				.option("sep", ";") //
				.option("quote", "^") //
				.option("dateFormat", "M/d/y") //
				.option("inferSchema", true) //
				// .load("/home/ubuntu/sparkwithjava/project2/src/main/resources/amazonProducts.txt");
				.load("src/main/resources/group.txt");

		System.out.println("Printing dataframe content:");

		// show 7 records and all characters of each column
		// df.show(7, false);

		df.foreach(item -> {
			System.out.println(item);
		});

		MongoSpark.save(df.write().option("database", "test").option("collection", "test").mode("overwrite"));

		// Selecting a column from a DF
		df.select("groupId").show();

		// Load data with explicit schema

		Dataset<Group> explicitDS = MongoSpark.load(jsc).toDS(Group.class);
		explicitDS.printSchema();
		explicitDS.show();

		// Register the DataFrame as a SQL temporary view
		df.createOrReplaceTempView("group");

		System.out.println("Spark SQL's dataframe content:");
		Dataset<Row> sqlDF = spark.sql("SELECT seqNumber,groupId FROM group");
		sqlDF.show();

		Dataset<Row> duplicatesRemovedDf = df.dropDuplicates("groupId");
		duplicatesRemovedDf.show();

		Dataset<Row> orderedDf = duplicatesRemovedDf.orderBy(col("groupId").asc());
		orderedDf.show();

		// Dataset<Group> houseDS = orderedDf.map(new GroupMapper(),
		// Encoders.bean(Group.class));

		// Write the data to the "hundredClub" collection
		// MongoSpark.write(sqlDF).option("collection",
		// "test").mode("append").save();

		// MongoSpark.write(sqlDF).option("collection",
		// "test").mode("append").save();

		// MongoSpark.

		// Create a RDD of 10 documents
		/*
		 * JavaRDD<Document> sparkDocuments = jsc.parallelize(asList(1, 2, 3, 4,
		 * 5, 6, 7, 8, 9, 10)) .map(new Function<Integer, Document>() { public
		 * Document call(final Integer i) throws Exception { return
		 * Document.parse("{spark: " + i + "}"); } });
		 */

		// MongoSpark.save(sparkDocuments, writeConfig);

		// MongoSpark.save();

		jsc.close();

	}

}
