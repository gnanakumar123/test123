package com.mongospark.examples;

import java.io.Serializable;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;



public class LoadLookupWithCollectAsMapExample_2 implements Serializable {

	public static void main(String[] args) {

		SparkSession spark = SparkSession.builder().master("local").appName("MongoSparkConnectorIntro")
				.config("spark.mongodb.input.uri", "mongodb://127.0.0.1/test.agent_lookup")
				.config("spark.mongodb.output.uri", "mongodb://127.0.0.1/test.agent_lookup").getOrCreate();

		// Create a Java Spark Context from a Spark Session
		JavaSparkContext jsc = new JavaSparkContext(spark.sparkContext());

		StructType agentLookupSchemas = DataTypes.createStructType(
				new StructField[] { DataTypes.createStructField("agentTaxId", DataTypes.StringType, true),
						DataTypes.createStructField("encryptedTin", DataTypes.StringType, true),
						DataTypes.createStructField("agentName", DataTypes.StringType, true)

				});

		Dataset<Row> agentLookDf = spark.read().format("csv") //
				.schema(agentLookupSchemas).option("header", "true") //
				.option("multiline", true) //
				.option("sep", ";") //
				.option("quote", "^") //
				.option("dateFormat", "M/d/y") //
				.option("inferSchema", true) //
				.load("src/main/resources/agent_lookup.txt");
		agentLookDf.show(false);

		StructType groupBrokerSchema = DataTypes.createStructType(
				new StructField[] { DataTypes.createStructField("seqNumber", DataTypes.StringType, true),
						DataTypes.createStructField("groupId", DataTypes.StringType, true),
						DataTypes.createStructField("writingAgentTin", DataTypes.StringType, true),
						DataTypes.createStructField("writingAgentName", DataTypes.StringType, true),
						DataTypes.createStructField("paidAgentTin", DataTypes.StringType, true),
						DataTypes.createStructField("paidAgentName", DataTypes.StringType, true),
						DataTypes.createStructField("GeneralAgentTin", DataTypes.StringType, true),
						DataTypes.createStructField("GeneralAgentName", DataTypes.StringType, true)

				});

		Dataset<Row> groupBrokerDf = spark.read().format("csv") //
				.schema(groupBrokerSchema).option("header", "true") //
				.option("multiline", true) //
				.option("sep", ";") //
				.option("quote", "^") //
				.option("dateFormat", "M/d/y") //
				.option("inferSchema", true) //
				.load("src/main/resources/group_broker.txt");
		groupBrokerDf.show(false);

		agentLookDf.createOrReplaceTempView("agentlookup");
		groupBrokerDf.createOrReplaceTempView("groupbroker");
		
		Dataset<Row> sqlDF = spark.sql("SELECT \r\n" + 
				"		gb.groupId,\r\n" + 
				"		al1.encryptedTin as writingAgentEncryptedTin,\r\n" + 
				"		al2.encryptedTin as paidAgentEncryptedTin,\r\n" + 
				"		al3.encryptedTin as generalAgentEncryptedTin\r\n" + 
				"		FROM groupbroker gb\r\n" + 
				"		LEFT OUTER JOIN agentlookup al1 ON al1.agentTaxId = gb.writingAgentTin\r\n" + 
				"		LEFT OUTER JOIN agentlookup al2 ON al2.agentTaxId = gb.paidAgentTin\r\n" + 
				"		LEFT OUTER JOIN agentlookup al3 ON al3.agentTaxId = gb.GeneralAgentTin");
		sqlDF.show();
		
		

		/*
		SELECT 
		gb.groupId,
		all.encryptedTin as writingAgentEncryptedTin,
		al2.encryptedTin as paidAgentEncryptedTin,
		al3.encryptedTin as generalAgentEncryptedTin
		FROM groupbroker gb
		LEFT OUTER JOIN agentlookup al1 ON al1.agentTaxId = gb.writingAgentTin
		LEFT OUTER JOIN agentlookup al2 ON al2.agentTaxId = gb.paidAgentTin
		LEFT OUTER JOIN agentlookup al3 ON al3.agentTaxId = gb.GeneralAgentTin
		
		*/

	}

}
