package com.anthem.marketplace.dataconsolidation.model;

import java.io.Serializable;

public class AgencyInfo implements Serializable {

	private String agencyNumber;
	private String agencyName;
	private String agencyAddressLine1;
	private String agencyAddressLine2;
	private String agencyCity;
	private String agencyState;
	private String agencyZip;
	public String getAgencyNumber() {
		return agencyNumber;
	}
	public void setAgencyNumber(String agencyNumber) {
		this.agencyNumber = agencyNumber;
	}
	public String getAgencyName() {
		return agencyName;
	}
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}
	public String getAgencyAddressLine1() {
		return agencyAddressLine1;
	}
	public void setAgencyAddressLine1(String agencyAddressLine1) {
		this.agencyAddressLine1 = agencyAddressLine1;
	}
	public String getAgencyAddressLine2() {
		return agencyAddressLine2;
	}
	public void setAgencyAddressLine2(String agencyAddressLine2) {
		this.agencyAddressLine2 = agencyAddressLine2;
	}
	public String getAgencyCity() {
		return agencyCity;
	}
	public void setAgencyCity(String agencyCity) {
		this.agencyCity = agencyCity;
	}
	public String getAgencyState() {
		return agencyState;
	}
	public void setAgencyState(String agencyState) {
		this.agencyState = agencyState;
	}
	public String getAgencyZip() {
		return agencyZip;
	}
	public void setAgencyZip(String agencyZip) {
		this.agencyZip = agencyZip;
	}
}
