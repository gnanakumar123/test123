package com.anthem.marketplace.dataconsolidation.utils;

import java.io.Serializable;

/*
 * Class file for Input Properties file
 */

public class ProcessInput implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String performTransformation;
	private String type;
	private String sourceDB;
	private String sourceCollection; 
	private String[] arraySourcePath;
	private String ingestJobName;
	private String transformSourceDB;
	private String transformSourceCollection;
	private String transformTargetDB;
	private String transformTargetCollection;
	private String transformJobName;
	private String failedCollection;
	private String delimeter;
	private String delimeted;
	private String appendedTransformCollection;
	private String performUDM;
	private String uDMSourceDB;
	private String uDMSourceCollection;
	private String uDMTargetDB;
	private String uDMTargetCollection;
	private String uDMJobName;
	private String uDMTargetDetailCollection;
	private String uDMTime;
	private String rDMTime;
	private String tDMTime;
	private String parentCollection;
	private String sourceField;
	private String fileType;
	private String performSDS;
	private String sDSSourceDB;
	private String sDSSourceCollection;
	private String sDSTargetDB;
	private String sDSTargetCollection;
	private String sDSTargetDetailCollection;
	private String sDSJobName;
	private String sDSTime;
	private String sDSSourceField;
	private String sDSCommissionStatement;
	private String pdfPath;
	private String domain;
	
	
	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public ProcessInput(){
		super();
	}
	
	public ProcessInput(String type){
		this.type = type;
	}

	public ProcessInput(String dBName, String collectionName, String type, String delimeter, String delimeted,
			String failedCollection, String parentCollection) {
		this.sourceDB = dBName;
		this.sourceCollection = collectionName;
		this.type = type;
		this.delimeter = delimeter;
		this.delimeted = delimeted;
		this.failedCollection = failedCollection;
		this.parentCollection = parentCollection;
	}

	public ProcessInput(String dBName, String collectionName, String type, String delimeter, String delimeted,
			String failedCollection) {
		this.sourceDB = dBName;
		this.sourceCollection = collectionName;
		this.type = type;
		this.delimeter = delimeter;
		this.delimeted = delimeted;
		this.failedCollection = failedCollection;
	}

	public ProcessInput(String dBName, String collectionName, String targetdb, String targetCollection,
			String appendedCollection) {
		this.sourceDB = dBName;
		this.sourceCollection = collectionName;
		this.transformTargetDB = targetdb;
		this.transformTargetCollection = targetCollection;
		this.appendedTransformCollection=appendedCollection;
	}
	
	public ProcessInput(String dBName, String collectionName, String targetdb, String targetCollection) {
		this.uDMSourceDB=dBName;
		this.uDMSourceCollection=collectionName;
		this.uDMTargetDB = targetdb;
		this.uDMTargetCollection = targetCollection;
	}
	
	public ProcessInput(String dBName, String collectionName, String targetdb, String targetCollection, boolean flag) {
		this.sDSSourceDB=dBName;
		this.sDSSourceCollection=collectionName;
		this.sDSTargetDB = targetdb;
		this.sDSTargetCollection = targetCollection;
	}
	
	
	

	public String getSDSCommissionStatement() {
		return sDSCommissionStatement;
	}

	public void setSDSCommissionStatement(String sDSCommissionStatement) {
		this.sDSCommissionStatement = sDSCommissionStatement;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	
	public String getParentCollection() {
		return parentCollection;
	}

	public void setParentCollection(String parentCollection) {
		this.parentCollection = parentCollection;
	}
	

	public String getUDMTime() {
		return uDMTime;
	}

	public void setUDMTime(String uDMTime) {
		this.uDMTime = uDMTime;
	}

	public String getRDMTime() {
		return rDMTime;
	}

	public void setRDMTime(String rDMTime) {
		this.rDMTime = rDMTime;
	}

	public String getTDMTime() {
		return tDMTime;
	}
	public String getSourceField() {
		return sourceField;
	}

	public void setSourceField(String sourceField) {
		this.sourceField = sourceField;
	}

	public void setTDMTime(String tDMTime) {
		this.tDMTime = tDMTime;
	}

	public String getUDMTargetDetailCollection() {
		return uDMTargetDetailCollection;
	}

	public void setUDMTargetDetailCollection(String uDMTargetDetailCollection) {
		this.uDMTargetDetailCollection = uDMTargetDetailCollection;
	}

	public String getAppendedTransformCollection() {
		return appendedTransformCollection;
	}

	public void setAppendedTransformCollection(String appendedTransformCollection) {
		this.appendedTransformCollection = appendedTransformCollection;
	}
	
	public String getPerformTransformation() {
		return performTransformation;
	}

	public void setPerformTransformation(String performTransformation) {
		this.performTransformation = performTransformation;
	}

	
	
	public String getFailedCollection() {
		return failedCollection;
	}

	public void setFailedCollection(String failedCollection) {
		this.failedCollection = failedCollection;
	}

	
	public void setType(String type){
		this.type = type;
	}
	
	public String getType() {
		return type;
	}
	
	public String getIngestJobName() {
		return ingestJobName;
	}

	public void setIngestJobName(String ingestJobName) {
		this.ingestJobName = ingestJobName;
	}

	public String getTransformJobName() {
		return transformJobName;
	}

	public void setTransformJobName(String transformJobName) {
		this.transformJobName = transformJobName;
	}

	public String getSourceDB() {
		return sourceDB;
	}
	public void setSourceDB(String sourceDB) {
		this.sourceDB = sourceDB;
	}
	
	public String getSourceCollection() {
		return sourceCollection;
	}
	
	public void setSourceCollection(String sourceCollection) {
		this.sourceCollection = sourceCollection;
	}	
	
	public String[] getArraySourcePath() {
		return arraySourcePath;
	}

	public void setArraySourcePath(String[] arraySourcePath) {
		this.arraySourcePath = arraySourcePath;
	}

	public String getTransformSourceDB() {
		return transformSourceDB;
	}

	public void setTransformSourceDB(String transformSourceDB) {
		this.transformSourceDB = transformSourceDB;
	}

	public String getTransformSourceCollection() {
		return transformSourceCollection;
	}

	public void setTransformSourceCollection(String transformSourceCollection) {
		this.transformSourceCollection = transformSourceCollection;
	}

	public String getTransformTargetDB() {
		return transformTargetDB;
	}

	public void setTransformTargetDB(String transformTargetDB) {
		this.transformTargetDB = transformTargetDB;
	}

	public String getTransformTargetCollection() {
		return transformTargetCollection;
	}

	public void setTransformTargetCollection(String transformTargetCollection) {
		this.transformTargetCollection = transformTargetCollection;
	}
	
	public String getDelimeter() {
		return delimeter;
	}

	public void setDelimeter(String delimeter) {
		this.delimeter = delimeter;
	}

	public String getDelimeted() {
		return delimeted;
	}

	public void setDelimeted(String delimeted) {
		this.delimeted = delimeted;
	}

	public String getPerformUDM() {
		return performUDM;
	}

	public void setPerformUDM(String performUDM) {
		this.performUDM = performUDM;
	}

	public String getUDMSourceDB() {
		return uDMSourceDB;
	}

	public void setUDMSourceDB(String uDMSourceDB) {
		this.uDMSourceDB = uDMSourceDB;
	}

	public String getUDMSourceCollection() {
		return uDMSourceCollection;
	}

	public void setUDMSourceCollection(String uDMSourceCollection) {
		this.uDMSourceCollection = uDMSourceCollection;
	}

	public String getUDMTargetDB() {
		return uDMTargetDB;
	}

	public void setUDMTargetDB(String uDMTargetDB) {
		this.uDMTargetDB = uDMTargetDB;
	}

	public String getUDMTargetCollection() {
		return uDMTargetCollection;
	}

	public void setUDMTargetCollection(String uDMTargetCollection) {
		this.uDMTargetCollection = uDMTargetCollection;
	}

	public String getUDMJobName() {
		return uDMJobName;
	}

	public void setUDMJobName(String uDMJobName) {
		this.uDMJobName = uDMJobName;
	}
	
	public String getSDSTargetDetailCollection() {
		return sDSTargetDetailCollection;
	}

	public void setSDSTargetDetailCollection(String sDSTargetDetailCollection) {
		this.sDSTargetDetailCollection = sDSTargetDetailCollection;
	}

	public String getPerformSDS() {
		return performSDS;
	}

	public void setPerformSDS(String performSDS) {
		this.performSDS = performSDS;
	}

	public String getSDSSourceDB() {
		return sDSSourceDB;
	}

	public void setSDSSourceDB(String SDSSourceDB) {
		this.sDSSourceDB = SDSSourceDB;
	}

	public String getSDSSourceCollection() {
		return sDSSourceCollection;
	}

	public void setSDSSourceCollection(String SDSSourceCollection) {
		this.sDSSourceCollection = SDSSourceCollection;
	}

	public String getSDSTargetDB() {
		return sDSTargetDB;
	}

	public void setSDSTargetDB(String SDSTargetDB) {
		this.sDSTargetDB = SDSTargetDB;
	}

	public String getSDSTargetCollection() {
		return sDSTargetCollection;
	}

	public void setSDSTargetCollection(String SDSTargetCollection) {
		this.sDSTargetCollection = SDSTargetCollection;
	}

	public String getSDSJobName() {
		return sDSJobName;
	}

	public void setSDSJobName(String SDSJobName) {
		this.sDSJobName = SDSJobName;
	}

	public String getSDSTime() {
		return sDSTime;
	}

	public void setSDSTime(String SDSTime) {
		this.sDSTime = SDSTime;
	}	

	public String getSDSSourceField() {
		return sDSSourceField;
	}

	public void setSDSSourceField(String sDSSourceField) {
		this.sDSSourceField = sDSSourceField;
	}
	public String getPdfPath() {
		return pdfPath;
	}

	public void setPdfPath(String pdfPath) {
		this.pdfPath = pdfPath;
	}

	@Override
	public String toString() {
		return "{type:" + this.type + ",SourceDB:" + this.sourceDB + ",SourceCollection:" + this.sourceCollection
				+ ",sourcePath:" + this.arraySourcePath[0] + ",targetDB:" + this.transformTargetDB
				+ ",targetCollection:" + this.transformTargetCollection + ", delimeter" + this.delimeter + ", delimeted"
				+ this.delimeted + "}";
	}
}
