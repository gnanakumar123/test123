package com.anthem.marketplace.dataconsolidation.job.processor;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import org.apache.hadoop.conf.Configuration;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.bson.BSONObject;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.filesutils.UtilityInterface;
import com.anthem.marketplace.dataconsolidation.utils.CDCProperties;
import com.anthem.marketplace.dataconsolidation.utils.ChangeDataCapture;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.MongoConfiguration;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessCDC;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.MongoCommandException;
import com.mongodb.hadoop.MongoInputFormat;

/*
 * This class Starts Transformation Process
 */

public class IngestTDM implements Serializable {

	private static final long serialVersionUID = 1L;
	static final Logger logger = LoggerFactory.getLogger(IngestTDM.class);

	/*
	 * This method ingest data into sourceDB.sorceCollection on mongoDB
	 * 
	 * @param processInput stores input related parameters
	 * 
	 * @param priority stores job priority
	 * 
	 * @param strType stores file type
	 * 
	 * @param failedCollection stores name of collection where rejected data to
	 * be added
	 * 
	 * @return boolean value depending on transformation process
	 */
	public boolean readAndTransform(ProcessInput processInput, String strType, String failedCollection,
			String sourcePath) {
		JavaPairRDD<Object, BSONObject> documents;

		try {
			String sourceDb = processInput.getTransformSourceDB();
			String sourceCollection = processInput.getTransformSourceCollection();
			final String[] sourceCollectionArray = sourceCollection.split(IConstants.SPLIT_COMMA);
			String targetDb = processInput.getTransformTargetDB();
			String targetCollection = processInput.getTransformTargetCollection();
			String appendedCollection = processInput.getAppendedTransformCollection();
			String sourceField = processInput.getSourceField();
			ProcessCDC proc = null;

			try {
				proc = CDCProperties.getInstance().getPropertyContext(processInput.getFileType() + IConstants.TDM_DB);
			} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
					| IllegalArgumentException | InvocationTargetException readAndTransformException) {
				logger.error("IngestTDM.readAndTransform" + readAndTransformException);
			}
			logger.debug("TDM Started for --> "
					+ strType.split(IConstants.SPLIT_DOT)[strType.split(IConstants.SPLIT_DOT).length - 1]);

			JavaSparkContext scTransform = SparkContextSingleton.getInstance().getSparkContext();
			long count = MongoConnector.getInstance().getCollectionDetail(sourceDb, sourceCollection, IConstants.RDM_DB)
					.count(new Document(IConstants.STATUS_FIELD, IConstants.UNPROCESSED).append(IConstants.SOURCE_FIELD,
							sourceField));
			 if (count > 0) {
				logger.info("---count---"+count);
				for (String sourceColl : sourceCollectionArray) {
					/* Start : Performance Improvement Added inputQuery  */
					//String inputQuery="{'status':'un-processed','source':'"+sourceField+"','end-date':'"+IConstants.MAX_DATE+"'}";
					//Configuration mongodbConfig = new MongoConfiguration(sourceDb, sourceColl).setConfiguration(IConstants.RDM_DB, inputQuery);
					/* End : Performance Improvement Added inputQuery  */
					Configuration mongodbConfig = new MongoConfiguration(sourceDb, sourceColl).setConfiguration(IConstants.RDM_DB);
					mongodbConfig.set("mongo.input.notimeout", "true");
					Boolean performCDC = Boolean.parseBoolean(proc.getPerformCDC());
					documents = scTransform
							.newAPIHadoopRDD(mongodbConfig, MongoInputFormat.class, Object.class, BSONObject.class)
							.filter(bsonFilter -> {
           
								UtilityInterface utilityInterface = Utility.createObject(strType);
								/* Start BPP-22918 Letter codes 'NLX' and 'CN' are used to suppress renewals for ISG ACA Individual */
								if (null!=bsonFilter._2.get(IConstants.SOURCE_FIELD) && bsonFilter._2.get(IConstants.SOURCE_FIELD).toString().contains(IConstants.ISG_ACA)
										&& ((null !=bsonFilter._2.get("medRenewalLtrCde") && (bsonFilter._2.get("medRenewalLtrCde").toString().contains("CN") || bsonFilter._2.get("medRenewalLtrCde").toString().contains("NLX")))
										|| (null !=bsonFilter._2.get("denRenewalLtrCde") && (bsonFilter._2.get("denRenewalLtrCde").toString().contains("CN") || bsonFilter._2.get("denRenewalLtrCde").toString().contains("NLX")))
										|| (null !=bsonFilter._2.get("visRenewalLtrCde") && (bsonFilter._2.get("visRenewalLtrCde").toString().contains("CN") || bsonFilter._2.get("visRenewalLtrCde").toString().contains("NLX"))))){
									return false;
								}
								else if (bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString()
										.contains(sourcePath)
										&&
										bsonFilter._2.get(IConstants.STATUS_FIELD).toString()
										.contains(IConstants.UNPROCESSED)
										&& 
										 (bsonFilter._2.get(IConstants.END_DATE_FIELD) != null && 
												bsonFilter._2.get(IConstants.END_DATE_FIELD).toString()
												.contains(IConstants.MAX_DATE))) {
									for (String tarColl : targetCollection.split(IConstants.SPLIT_COMMA)) {

										ArrayList<Document> documentsIngest = new ArrayList<>();
										ArrayList<Document> failedList = new ArrayList<>();

										Document metaDoc = null;
										
										try {
											//logger.info("---calling tdm process---",bsonFilter._2().get("hcid"));
												metaDoc = utilityInterface.ingestTDMProcess(sourceDb, sourceColl,
														bsonFilter, targetDb, tarColl, appendedCollection);
											if (metaDoc != null) {
												if (performCDC) {

													ChangeDataCapture cdc = new ChangeDataCapture();
													cdc.implementCdc(targetDb, tarColl, metaDoc, documentsIngest,
															failedList, false,IConstants.TDM_DB);
													MongoConnector.getInstance().insertData(documentsIngest, targetDb,
															tarColl,IConstants.TDM_DB);
													MongoConnector.getInstance().insertData(failedList, targetDb,
															failedCollection,IConstants.TDM_DB);
												} else {

													MongoConnector.getInstance().replaceSummaryDocument(targetDb,
															tarColl, metaDoc,IConstants.TDM_DB);
												}
											}
											//logger.info("---inserted tdm process---",bsonFilter._2().get("hcid"));
										} catch (Exception e) {
											logger.error("Error While Ingesting TDM",e);
										} finally {
											metaDoc = null;
											documentsIngest = null;
											failedList = null;
										}

									}
									return true;
								} else
									return false;

							});

					try {
						documents.count();
							MongoConnector.getInstance().updateAllStatus(sourceDb, sourceColl, sourcePath,IConstants.RDM_DB);
							/* Start BPP-33129 Reverse source path issue for ISG_ACA, WSGRS */
							for (String appendedColl : appendedCollection.split(IConstants.SPLIT_COMMA)) {
							
							MongoConnector.getInstance().updateAllDetailStatus(sourceDb, appendedColl,
								ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
										IConstants.REVERSE_SOURCE_PATH_FIELD, appendedColl, IConstants.VALUE),IConstants.RDM_DB);
							}
							/* End BPP-33129 Reverse source path issue for ISG_ACA, WSGRS */
						logger.debug("TDM Done for --> "
								+ strType.split(IConstants.SPLIT_DOT)[strType.split(IConstants.SPLIT_DOT).length - 1]);
					} catch (MongoCommandException e) {
						logger.error("Mongo Exception Occured" + e);
						
						return false;
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Exception:  "+ e);
		} finally {
			documents = null;
		}

		return true;
	}
}
