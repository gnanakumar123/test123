package com.anthem.marketplace.dataconsolidation.filesutils;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.IteratorUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.bson.BSONObject;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.utils.ChangeDataCapture;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.FixedFileMetaDataProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFixedFileMetaData;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.DistinctIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

import scala.Tuple2;

/*
 * This class implements UtilityInterface and Serializable and performs Ingestion, Transformation of WSGRS 
 * renewals input files
 * @author : MongoDB Team
 * @version : 1.0
 * @Date : June 2016
 * It returns nothing.
 */
public class WSGRS implements UtilityInterface, Serializable {

	private static final long serialVersionUID = 1L;
	static final Logger logger = LoggerFactory.getLogger(WSGRS.class);
	public static ArrayList<String> neglectList = new ArrayList<String>();
	HashMap<String,String> planNames = new HashMap<String,String>();  /* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
	String[] statesIncludeForFlagging = new String[]{"OH"};
	String[] tinsIncludedForFlagging = new String[]{"341754192E","311273990E","311627358E","311768631E","311281724E"};
	
			

	/*
	 * This method creates GUID
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param delimeted stores delimited character
	 * 
	 * @param readFileContent stores input file data
	 * 
	 * @param guidvalue stores guid values retrieve from properties file
	 * 
	 * @param type stores type of file
	 * 
	 * @return String GUID
	 */
	public String createGuid(String sourceCollection, String delimeted, Row readFileContent, String guidvalue,
			String type) {

		String guid = "";
		List<ProcessFixedFileMetaData> guidPosition = new ArrayList<>();
		try {
			for (String item : guidvalue.split(IConstants.SPLIT_COMMA)) {
				guidPosition.add(FixedFileMetaDataProperties.getInstance().getPropertyContext(item, type));
			}

		} catch (Exception e) {
			logger.error("Unable to find MetaData for Fixed Width File" + e);
		}
		for (ProcessFixedFileMetaData item : guidPosition) {
			guid += (readFileContent.toString().substring(Integer.parseInt(item.getStart()),
					Integer.parseInt(item.getEnd()) + 1)).trim();
		}

		if (sourceCollection.equals("Renewals_WSGRS_Detail_GroupInfo"))
			guid = guid.concat("SGGROUPALL");
		else
			guid = guid.concat("EMPSUBSCRALL");

		return guid;
	}

	/*
	 * This method checks mandatory fields for file for data Quality check
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param delimeted stores delimited character
	 * 
	 * @param readFileContent stores input file data
	 * 
	 * @param type stores type of file
	 * 
	 * @return boolean value based on data Quality check passed.
	 */
	public boolean createFlag(String delimeted, String sourceCollection, Row readFileContent, String type) {
		boolean flag = false;
		ProcessFixedFileMetaData metadata;
		Map<String, String> mandatoryFields = ReadMappingXmlSingleton.getInstance().getRead().getMandatoryFields(type,
				IConstants.REQUIRED_ATTRIBUTE);
		for (String item : mandatoryFields.values()) {
			try {
				metadata = FixedFileMetaDataProperties.getInstance().getPropertyContext(item, type);

				flag = (readFileContent.toString()
						.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()))
						.trim() == null)
						|| readFileContent.toString()
								.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()))
								.trim().isEmpty();
			} catch (Exception e) {
				logger.error("Failed To Retrieve start and end properties" + e);
			}
			if (flag)
				break;
		}
		return flag;
	}

	/*
	 * This method adds fileName and its respective value to a document and
	 * returns it.
	 * 
	 * @param processInput stores input properties related parameters
	 * 
	 * @param sourcePath stores source path of input file
	 * 
	 * @param guid stores GUID
	 * 
	 * @param flag stores value retrieve from data Quality check method
	 * 
	 * @param readFileContent stores Row of a input file
	 * 
	 * @return Document
	 */
	public Document appendRaw(ProcessInput processInput, String sourcePath, String guid, boolean flag,
			Row readFileContent) {

		String type = processInput.getType();
		String sourceDB = processInput.getSourceDB();
		String sourceCollection = processInput.getSourceCollection();
		String value;
		ProcessFixedFileMetaData metadata;
		ProcessFieldNames procFieldNames;
		boolean checkFlag = false;
		String errorFieldName = "";

		Document doc = new Document();

		try {

			procFieldNames = FieldNamesProperties.getInstance().getPropertyContext(type);
			doc.append(IConstants.GUID, guid);

			// for each filedNames
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				errorFieldName = fieldNames;
				// get dataType for each fieldName for given collectionName
				String dataType = ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(type,
						fieldNames, IConstants.DATATYPE);

				metadata = FixedFileMetaDataProperties.getInstance().getPropertyContext(fieldNames, type);
				value = readFileContent.toString()
						.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()) + 1)
						.trim();
				// if empty value then append it as it is to document
				if (value.equals("null") || value.equals(""))
					doc.append(fieldNames, value);

				// else change its dataType as specified and convert zonal
				// fields to zonal decimal number
				else {
					checkFlag = Utility.applyZone(sourceCollection, fieldNames, value.trim(), doc, dataType,
							readFileContent, IConstants.WSGRS);
					if (checkFlag)
						flag = true;
				}
			}

			if (sourceCollection.equals("Renewals_WSGRS_Detail_GroupInfo")) {
				doc.append("type", "SG");
				doc.append("relationship", "GROUP");
			} else {
				doc.append("type", "EMP");
				doc.append("relationship", "SUBSCR");
			}

			Utility.insertMetadata(doc, sourceDB, sourceCollection, guid, sourcePath, IConstants.WSGRS, flag,
					true, IConstants.RDM_DB);

			// catch Exceptions and add respective errorCode and its description
		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.WSGRS, IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.WSGRS, IConstants.RDM_DB);
		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.WSGRS, IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.RAW_DATA,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.WSGRS,
					IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.WSGRS, IConstants.RDM_DB);
		}

		return doc;
	}

	/*
	 * This method selects attributes to decide fields to be selected from BCC
	 * or BCBSGA Raw data.
	 * 
	 * @param fieldNames stores field names
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param collName stores collection name
	 * 
	 * @return attribute name
	 */
	public String selectFields(String fieldNames, Tuple2<Object, BSONObject> bsonFilter, String collName,
			String sourcecollection) {

		if (ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField(sourcecollection.concat(collName), fieldNames, IConstants.PROD_TYPE)
				.equals("false"))
			return IConstants.VALUE;

		else if ((bsonFilter._2.get(IConstants.MEDBROKERWRITINGTIN) == null)
				|| (bsonFilter._2.get(IConstants.MEDBROKERWRITINGTIN).toString().trim().equals("")))
			return IConstants.DENTAL;
		else
			return IConstants.MEDICAL;
	}

	public String selectFields(String fieldNames, Document bsonFilter, String collName, String sourcecollection) {

		if (ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField(sourcecollection.concat(collName), fieldNames, IConstants.PROD_TYPE)
				.equals("false"))
			return IConstants.VALUE;

		else if ((bsonFilter.get(IConstants.MEDBROKERWRITINGTIN) == null)
				|| (bsonFilter.get(IConstants.MEDBROKERWRITINGTIN).toString().trim().equals("")))
			return IConstants.DENTAL;
		else
			return IConstants.MEDICAL;
	}

	private String selectFields(String fieldNames, Document docRen, String coll) {
		if (ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField(IConstants.WSGRS_RENEWALS.concat(coll), fieldNames, IConstants.PROD_TYPE)
				.equals(IConstants.STRING_FALSE))
			return IConstants.VALUE;

		else if ((docRen.get(IConstants.MEDBROKERWRITINGTIN) == null)
				|| (docRen.get(IConstants.MEDBROKERWRITINGTIN).toString().trim().equals("")))
			return IConstants.DENTAL;
		else
			return IConstants.MEDICAL;
	}

	/*
	 * This method performs transformation on WSGRS Renewals Raw data.
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source collection name
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param transColl stores target collection name
	 * 
	 * @param appendedCollection stores collection name whose data to be
	 * appended as embedded doc. i.t summary to detail
	 * 
	 * @return transformed Document
	 */

	
	@Override
	public Document ingestTDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String appendedCollection) {

		Document metaDoc = new Document();
		/* Start:BPP-27124,BPP-27127,BPP-27129 */
		List<String> lifeDistinctBenefits = new ArrayList<String>();
		DistinctIterable<String> iterableLife = null;
		/*End:BPP-27124,BPP-27127,BPP-27129 */
		FindIterable<Document> iterable = null;
		FindIterable<Document> iterableGroupBroker = null;
		FindIterable<Document> iterableMem = null;

		List<Document> newIterable = new ArrayList<Document>();

		boolean flag = false;
		String groupID = "";
		String guid = "";
		ProcessFieldNames renewalFieldNames = null;
		ProcessFieldNames procFieldNamesClientContacts = null;
		ProcessFieldNames procFieldNamesAgent;
		ProcessFieldNames procFieldNamesRen;
		ProcessFieldNames procFieldGroupBenNames = null;
		ProcessFieldNames procFieldMemBenNames = null;
		ProcessFieldNames procFieldGrouprenewalProducts = null;
		ProcessFieldNames procFieldMemrenewalProducts = null;
		String sourcePath = "";
		Document benefitInfo = new Document();
		ProcessFieldNames clientFieldNames = null;
		ProcessFieldNames procFieldNamesEmployee = null;
		ProcessFieldNames procFieldNamesEmployeeContacts = null;
		ProcessFieldNames procFieldNamesEmployeeDependent = null;
		ProcessFieldNames procFieldNamesEmployeeDependentContacts = null;

		neglectList.add("");
		neglectList.add(null);
		try {
			clientFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.WSGRS_RENEWALS.concat(targetCollection).toString());
			procFieldMemBenNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.WSGRS_RENEWALS_MEM_BEN);
			procFieldGroupBenNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.WSGRS_RENEWALS_GRP_BEN);
			procFieldGrouprenewalProducts = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.WSGRS_RENEWALS_GRP_REN_PRODS);
			procFieldMemrenewalProducts = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.WSGRS_RENEWALS_MEM_REN_PRODS);
			procFieldNamesEmployee = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.WSGRS_RENEWALS_GRP_INFO_EMP);
			procFieldNamesEmployeeContacts = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.WSGRS_RENEWALS_GRP_INFO_EMP_CON);
			procFieldNamesEmployeeDependent = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.WSGRS_DETAIL_GROUP_INFO_EMP_DEPENDENT);
			procFieldNamesEmployeeDependentContacts = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.WSGRS_RENEWALS_GRP_INFO_EMP_DEP_CON);

		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e) {
			logger.error("Exception:  " + e);
		}

		// outer fields for doc of tdm_client and tdm_renewals
		/*appendedCollection : wsgrs_gpinfodet.AppendedTransformCollection=Renewals_WSGRS_Detail_GroupBenInfo,Renewals_WSGRS_Detail_GroupBrokerInfo,Renewals_WSGRS_Detail_MemBenInfo,Renewals_WSGRS_Detail_MemInfo*/
		/*targetCollection : wsgrs_gpinfodet.TransformTargetCollection=Renewals_tdm_Renewal,Renewals_tdm_Client */
		addToDocument(clientFieldNames, bsonFilter, sourceCollection.concat(targetCollection), metaDoc);
		sourcePath = bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString();
		groupID = bsonFilter._2.get(IConstants.GROUP_ID1).toString();
		iterable = MongoConnector.getInstance().getAllRenewalDocument(IConstants.GROUP_ID1, groupID, sourceDb,
				appendedCollection.split(IConstants.COMMA)[0], IConstants.RDM_DB);//appendedCollection[0]:Renewals_WSGRS_Detail_GroupBenInfo 
		iterableGroupBroker = MongoConnector.getInstance().getAllRenewalDocument(IConstants.GROUP_ID1, groupID,
				sourceDb, appendedCollection.split(IConstants.COMMA)[1], IConstants.RDM_DB);//appendedCollection[1]:Renewals_WSGRS_Detail_GroupBrokerInfo 
		for (Document d : iterable)
			newIterable.add(d);
		for (Document d : iterableGroupBroker)
			newIterable.add(d);
		iterableGroupBroker = null;

		try {

			if (targetCollection.contains("Renewals_tdm_Renewal")) {
				iterable = MongoConnector.getInstance().getAllRenewalDocument(IConstants.GROUP_ID1, groupID,
						IConstants.MMBR_RELATIONSHIP, IConstants.SCRBR, sourceDb, 
						appendedCollection.split(IConstants.COMMA)[3], IConstants.RDM_DB);//appendedCollection[3]:Renewals_WSGRS_Detail_MemInfo 
				FindIterable<Document> dependentIterable;

				try {
					procFieldNamesClientContacts = FieldNamesProperties.getInstance()
							.getPropertyContext(IConstants.WSGRS_RENEWALS.concat(IConstants.CLIENT_CONTACTS));
				} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
						| IllegalArgumentException | InvocationTargetException e) {
					logger.error(IConstants.ERROR_PREPEND, e);
				}

				List<Document> empList = new ArrayList<>();
				for (Document document : iterable) {
					Document subscrDoc = new Document();

					subscrDoc.append(IConstants.REN_ID, document.get(IConstants.MEMBER_ID));
					subscrDoc.append("Type", document.get("type"));
					/* String memId = document.get(IConstants.MEMBER_ID).toString();
					iterableMem = MongoConnector.getInstance().getAllRenewalDocument(IConstants.MEMBER_ID, memId,
							sourceDb, appendedCollection.split(IConstants.COMMA)[2], IConstants.RDM_DB);
					Since Member id[dependents] will not be having Life products, using SubscriberID fetching all the Life and NonLife products */
					/* Start:BPP-27124,BPP-27127,BPP-27129 */
					String memId="";
					String subId = document.get(IConstants.SUBSCRIBER_ID).toString();
					
					//Fetch all Non-Life products benefit information from the,[RAW Layer] 'Renewals_WSGRS_Detail_MemBenInfo' collection, by passing parameter GroupId and SubscriberId
					iterableMem = MongoConnector.getInstance().getAllNonLifeRenewalDocumentWithSubscriberID(groupID, subId,
							sourceDb, appendedCollection.split(IConstants.COMMA)[2], IConstants.RDM_DB);//appendedCollection[2]:Renewals_WSGRS_Detail_MemBenInfo  
					/* End:BPP-27124,BPP-27127,BPP-27129 */
					List<Document> renDetailList = new ArrayList<Document>();
					List<Document> renewalProducts = null;
					
			// Iterating all non life products from Member Benefit at Employee Level	
				/* Start:BPP-27124,BPP-27127,BPP-27129 */
					addNonLifeProductsAtEmployeeLevel(iterableMem, procFieldMemBenNames, procFieldMemrenewalProducts, renDetailList);
			
					
					//Getting Benefit information for life products,using the 'SUBSCRIBER_ID'
					iterableMem = MongoConnector.getInstance().getAllLifeRenewalDocumentWithSubscriberID(groupID, subId,
							sourceDb, appendedCollection.split(IConstants.COMMA)[2], IConstants.RDM_DB);   //Renewals_WSGRS_Detail_MemBenInfo
					
					//Getting Distinct Life Products from Group Benefit Info , using prodID1 i.e "PD63"
					iterableLife = MongoConnector.getInstance().getDistinctLifeBenefits(groupID, sourceDb,
							appendedCollection.split(IConstants.COMMA)[0], IConstants.RDM_DB);//Renewals_WSGRS_Detail_GroupBenInfo Renewal tdm Renewal
					
					lifeDistinctBenefits = IteratorUtils.toList(iterableLife.iterator());
	
					// Iterating all  life products from Member Benefit at Employee Level	
					addLifeProductsAtEmployeeLevel(sourceDb, appendedCollection, lifeDistinctBenefits, iterableMem,
							groupID, procFieldMemBenNames, procFieldMemrenewalProducts, renDetailList);
					
					/* End:BPP-27124,BPP-27127,BPP-27129 */
					subscrDoc.append(IConstants.RENEWAL_DETAILS, renDetailList);

					dependentIterable = MongoConnector.getInstance().getMemberDocument(IConstants.SUBSCRIBER_ID,
							document.getString(IConstants.SUBSCRIBER_ID), IConstants.MMBR_RELATIONSHIP,
							IConstants.SCRBR, IConstants.GROUP_ID1, document.getString(IConstants.GROUP_ID1), sourceDb,
							appendedCollection.split(IConstants.COMMA)[3], IConstants.RDM_DB);   //Renewals_WSGRS_Detail_MemInfo

					List<Document> dependentDocList = new ArrayList<>();
					for (Document dependentDocument : dependentIterable) {
						Document dependentDoc = new Document();
						memId = dependentDocument.get(IConstants.MEMBER_ID).toString();
						iterableMem = MongoConnector.getInstance().getAllRenewalDocument(IConstants.MEMBER_ID, memId,
								sourceDb, appendedCollection.split(IConstants.COMMA)[2], IConstants.RDM_DB);  //Renewals_WSGRS_Detail_MemBenInfo
						renDetailList = new ArrayList<Document>();
						for (Document docRen : iterableMem) {
							Document renDoc = new Document();
							addToDocument(procFieldMemrenewalProducts, docRen, IConstants.WSGRS_RENEWALS_MEM_REN_PRODS,
									renDoc);
							renewalProducts = new ArrayList<>();
							renewalProducts.add(renDoc);
							Document doc = new Document();
							doc.append(IConstants.RENEWAL_PRODUCTS, renewalProducts);
						
							addToDocument(procFieldMemBenNames, docRen,
									IConstants.WSGRS_DETAIL_MEM_INFO.concat(IConstants.RENEWAL_DETAILS), doc);
							/* Start : BPP-28222 WSGRS feed from "FACETS" Source , "Product" Field should be 'Prod_ID2'*/
							if(null!= docRen.getString("Source_ID") && docRen.getString("Source_ID").equals("FACETS")  && null!= docRen.getString("Prod_ID2")) {
								doc.append("currentContractPlanCode", docRen.getString("Prod_ID2"));

							}
							/* End : BPP-28222 WSGRS feed from "FACETS" Source , "Product" Field should be 'Prod_ID2'*/
							renDetailList.add(doc);
						}
						dependentDoc.append(IConstants.RENEWAL_DETAILS, renDetailList);
						dependentDoc.append(IConstants.REN_ID, dependentDocument.get(IConstants.MEMBER_ID));
						dependentDocList.add(dependentDoc);

					}
					dependentIterable= null;
					subscrDoc.append(IConstants.DEPENDENT_RENEWAL, dependentDocList);
					empList.add(subscrDoc);

				}
				metaDoc.append(IConstants.EMPLOYEE_RENEWAL, empList);
				for (Document docRen : newIterable) {
					if (docRen.getString(IConstants.RECORD_TYPE_REN).equals("90")) {
						benefitInfo = docRen;
					}
				}
				BasicDBList renDetailList = new BasicDBList();
				double monthlyPrem = 0.00, curMonthlyPrem = 0.00;
		
				// Iterating all non life products at Group Level
		/*Start BPP-27124,BPP-27127,BPP-27129 */
				addNonLifeProductsAtGroupLevel(sourceCollection, newIterable, renewalFieldNames,
						procFieldGroupBenNames, procFieldGrouprenewalProducts, renDetailList);
				
				
				iterable = MongoConnector.getInstance().getAllRenewalDocument(IConstants.GROUP_ID1, groupID, sourceDb,
						appendedCollection.split(IConstants.COMMA)[0], IConstants.RDM_DB);//Renewals_WSGRS_Detail_GroupBenInfo Renewal tdm Renewal

				//Getting life products from Group Benefit Info
				iterableLife = MongoConnector.getInstance().getDistinctLifeBenefits(groupID, sourceDb,
						appendedCollection.split(IConstants.COMMA)[0], IConstants.RDM_DB);//Renewals_WSGRS_Detail_GroupBenInfo Renewal tdm Renewal
				
				lifeDistinctBenefits = IteratorUtils.toList(iterableLife.iterator());
				
				// Iterating all life products at Group Level
				addLifeProductsAtGroupLevel(sourceDb, sourceCollection, appendedCollection,
						lifeDistinctBenefits, iterable, groupID, renewalFieldNames, procFieldGroupBenNames,
						procFieldGrouprenewalProducts, renDetailList);
/* END: BPP-27124,BPP-27127,BPP-27129 */
				try {
					String grpID = metaDoc.getString("ID");
					curMonthlyPrem = MongoConnector.getInstance().getCurMonthlyPrem(sourceDb,
							appendedCollection.split(IConstants.COMMA)[2], IConstants.RDM_DB, grpID); //Renewals_WSGRS_Detail_MemBenInfo

					monthlyPrem = MongoConnector.getInstance().getMonthlyPrem(sourceDb,
							appendedCollection.split(IConstants.COMMA)[2], IConstants.RDM_DB, grpID);//Renewals_WSGRS_Detail_MemBenInfo
					metaDoc.append(IConstants.MON_PREM, monthlyPrem);
					metaDoc.append(IConstants.CURR_MON_PREMIUM, curMonthlyPrem);
				} catch (Exception e) {
					logger.error(IConstants.ERROR_PREPEND, e);
				}
				metaDoc.append("parentTIN", benefitInfo.get(IConstants.GEN_AGENCY_TAX_ID));
				metaDoc.append("payeeTIN", benefitInfo.get("payeeTIN"));
				metaDoc.append("writingTIN", benefitInfo.get(IConstants.AGENT_TAX_ID));
				metaDoc.append(IConstants.RENEWAL_DETAILS, renDetailList);

			}
			// for tdm_client
			else {
				iterable = MongoConnector.getInstance().getAllRenewalDocument(IConstants.GROUP_ID1, groupID,
						IConstants.MMBR_RELATIONSHIP, IConstants.SCRBR, sourceDb,
						appendedCollection.split(IConstants.COMMA)[3], IConstants.RDM_DB);
				FindIterable<Document> dependentIterable;
				String[] addr = { "mailing" };

				List<Document> empList = new ArrayList<>();
				for (Document document : iterable) {
					Document subscrDoc = new Document();
					addToDocument(procFieldNamesEmployee, document, IConstants.WSGRS_RENEWALS_GRP_INFO_EMP, subscrDoc);
					BasicDBList contactList = appendCollections(addr, IConstants.ADDR_TYPE, IConstants.ADDRESS_TYPE,
							IConstants.STATE_CODE, procFieldNamesEmployeeContacts, IConstants.CLIENT_CONTACTS, document,
							IConstants.WSGRS_DETAIL_MEM_INFO);

					subscrDoc.append(IConstants.CLIENT_CONTACTS, contactList);

					dependentIterable = MongoConnector.getInstance().getMemberDocument(IConstants.SUBSCRIBER_ID,
							document.getString(IConstants.SUBSCRIBER_ID), IConstants.MMBR_RELATIONSHIP,
							IConstants.SCRBR, IConstants.GROUP_ID1, document.getString(IConstants.GROUP_ID1), sourceDb,
							appendedCollection.split(IConstants.COMMA)[3], IConstants.RDM_DB);
					List<Document> dependentDocList = new ArrayList<>();
					for (Document dependentDocument : dependentIterable) {

						Document dependentDoc = new Document();
						addToDocument(procFieldNamesEmployeeDependent, dependentDocument,
								IConstants.WSGRS_DETAIL_GROUP_INFO_EMP_DEPENDENT, dependentDoc);

						BasicDBList dependentcontactList = appendCollections(addr, IConstants.ADDR_TYPE,
								IConstants.ADDRESS_TYPE, IConstants.STATE_CODE, procFieldNamesEmployeeDependentContacts,
								IConstants.CLIENT_CONTACTS, document, IConstants.WSGRS_DETAIL_GROUP_INFO_EMP_DEPENDENT);

						dependentDoc.append(IConstants.CLIENT_CONTACTS, dependentcontactList);

						dependentDocList.add(dependentDoc);

					}
					subscrDoc.append(IConstants.DEPENDENT, dependentDocList);
					empList.add(subscrDoc);

				}
				iterable = null;
				metaDoc.append(IConstants.EMPLOYEE, empList);
				procFieldNamesClientContacts = FieldNamesProperties.getInstance()
						.getPropertyContext(IConstants.WSGRS_RENEWALS.concat(IConstants.CLIENT_CONTACTS));
				procFieldNamesAgent = FieldNamesProperties.getInstance()
						.getPropertyContext(IConstants.WSGRS_RENEWALS.concat(IConstants.CLIENT_AGENT));

				procFieldNamesRen = FieldNamesProperties.getInstance()
						.getPropertyContext(IConstants.WSGRS_RENEWALS.concat(IConstants.CLIENT_RENEWAL));

				int year = Calendar.getInstance().get(Calendar.YEAR);
				BasicDBList docList = new BasicDBList();
				Document doc = new Document();
				String[] addr1 = { "billing", "service" };
				docList = appendCollections(addr1, IConstants.ADDR_TYPE, IConstants.ADDRESS_TYPE, IConstants.STATE_CODE,
						procFieldNamesClientContacts, IConstants.CLIENT_CONTACTS, bsonFilter, sourceCollection);

				metaDoc.append(IConstants.CLIENT_CONTACTS, docList);
				docList = new BasicDBList();
				for (Document docRen : newIterable) {
					if (docRen.getString(IConstants.RECORD_TYPE_REN).equals("90")) {
						String[] product = { IConstants.AGENT_TAX_ID, IConstants.AGENCY_TAX_ID,
								IConstants.GEN_AGENCY_TAX_ID };
						docList = appendCollections(product, IConstants.PROD_TYPE, IConstants.PRODUCT, "agentID",
								procFieldNamesAgent, IConstants.CLIENT_AGENT, bsonFilter, docRen, sourceCollection, targetDb);
					}
				}
				newIterable = null;
				if (docList.size() > 0)
					metaDoc.append(IConstants.CLIENT_AGENT, docList);
				else
					metaDoc.append(IConstants.CLIENT_AGENT, null);
				docList = null;
				for (String fieldNames : procFieldNamesRen.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
					String selectFieldAttribute = selectFields(fieldNames, bsonFilter, IConstants.CLIENT_RENEWAL,
							sourceCollection);
					if (fieldNames.equals("renewalPeriod"))
						doc.append(fieldNames, year);
					else if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(sourceCollection.concat(IConstants.CLIENT_RENEWAL), fieldNames,
									selectFieldAttribute))))

						doc.append(fieldNames,
								bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
										.getAttributeValueOfField(sourceCollection.concat(IConstants.CLIENT_RENEWAL),
												fieldNames, selectFieldAttribute)));
					
				}
				metaDoc.append(IConstants.CLIENT_RENEWAL, doc);
				doc= null;

			}

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		

		guid = metaDoc.get(IConstants.GUID).toString();
		Utility.insertMetadata(metaDoc, targetDb, targetCollection, guid, sourcePath, IConstants.WSGRS, flag,
				true, IConstants.TDM_DB);
		
		renewalFieldNames = null;
		procFieldNamesClientContacts = null;
		procFieldNamesAgent = null;
		procFieldNamesRen = null;
		procFieldGroupBenNames = null;
		procFieldMemBenNames = null;
		procFieldGrouprenewalProducts = null;
		procFieldMemrenewalProducts = null;
		clientFieldNames = null;
		procFieldNamesEmployee = null;
		procFieldNamesEmployeeContacts = null;
		procFieldNamesEmployeeDependent = null;
		procFieldNamesEmployeeDependentContacts = null;
		System.gc();
		
		
		return metaDoc;

	}
/*Start BPP-27124,BPP-27127,BPP-27129 */
	/**
	 * @param sourceDb
	 * @param sourceCollection
	 * @param appendedCollection
	 * @param lifeDistinctBenefits
	 * @param iterable
	 * @param groupID
	 * @param renewalFieldNames
	 * @param procFieldGroupBenNames
	 * @param procFieldGrouprenewalProducts
	 * @param renDetailList
	 * This method add life products in Renewal_tdm_Renewals at Group Level
	 * 
	 */
	private void addLifeProductsAtGroupLevel(String sourceDb, String sourceCollection,
			String appendedCollection, List<String> lifeDistinctBenefits, FindIterable<Document> iterable,
			String groupID, ProcessFieldNames renewalFieldNames, ProcessFieldNames procFieldGroupBenNames,
			ProcessFieldNames procFieldGrouprenewalProducts, BasicDBList renDetailList) {
		for (Document docRen : iterable) {
			String currentProdType = docRen.getString(IConstants.CURRENT_PROD_TYPE);
			String productId1 = docRen.getString(IConstants.PRODUCT_ID1);
			 if((null!= currentProdType && currentProdType.equals("LFE") && lifeDistinctBenefits.contains(productId1))) {
				 lifeDistinctBenefits.remove(lifeDistinctBenefits.indexOf(productId1));
				Document doc = new Document();
				// grp benefit :80 	// Group Level Adding the plan details[Benefits in Renewal_tdm_Renewals]
				if (docRen.getString(IConstants.RECORD_TYPE_REN).equals("80")) {
					Document renDoc = new Document();
					addToDocument(procFieldGrouprenewalProducts, docRen, IConstants.WSGRS_RENEWALS_GRP_REN_PRODS,
							renDoc);

					List<Document> renewalProducts = new ArrayList<>();		
					addToDocument(procFieldGroupBenNames, docRen,
							sourceCollection.concat(IConstants.RENEWAL_DETAILS), doc);
					//WSGRS Change BPP-23129
					Document docDetail = new Document();
					List<Document> detailList = new ArrayList<>();
							try {
								renewalFieldNames = FieldNamesProperties.getInstance()
										.getPropertyContext(IConstants.WSGRS_RENEWALS.concat("lifeProducts"));
							} catch (ClassNotFoundException | NoSuchMethodException | SecurityException
									| IllegalAccessException | IllegalArgumentException
									| InvocationTargetException e) {

								logger.error("Exception:  " + e);
							}
							addToDocument(renewalFieldNames, docRen, sourceCollection.concat("lifeProducts"),
									docDetail);
							detailList.add(docDetail);
							doc.append("lifeProducts", detailList);
					detailList = null;
					/*Fetching the Life related Premiums from the Member benefite Info */
					Double lifeMonthlyPremium = MongoConnector.getInstance().getLifeMonthlyPrem(sourceDb,
							appendedCollection.split(IConstants.COMMA)[2], IConstants.RDM_DB, groupID,docRen.getString("Product_ID1").toString()); 
					
					renDoc.append("monthlyPremium", lifeMonthlyPremium);
					renDoc.append(IConstants.PRODUCT_TYPE, doc.get(IConstants.PRODUCT_TYPE));
					renDoc.append("renewalContractPlanName", "");
					renewalProducts.add(renDoc);
					doc.append(IConstants.RENEWAL_PRODUCTS, renewalProducts);
					// Adding the life products at group Level in 'Benefits' document present in 'Renewals_tdm_Renewal' Collection
					renDetailList.add(doc);
				}
			}
		}
	}

	/**
	 * @param sourceCollection
	 * @param newIterable
	 * @param renewalFieldNames
	 * @param procFieldGroupBenNames
	 * @param procFieldGrouprenewalProducts
	 * @param renDetailList
	 * This method add non life products in Renewal_tdm_Renewals at Group Level
	 * @return
	 */
	private void addNonLifeProductsAtGroupLevel(String sourceCollection, List<Document> newIterable,
			ProcessFieldNames renewalFieldNames, ProcessFieldNames procFieldGroupBenNames,
			ProcessFieldNames procFieldGrouprenewalProducts, BasicDBList renDetailList) {
		for (Document docRen : newIterable) {
			String currentProdType = docRen.getString("Current_Prod_Type");
			
		 if(!(null!= currentProdType && currentProdType.equals("LFE"))) {
			Document doc = new Document();
			// grp benefit :80
			if (docRen.getString(IConstants.RECORD_TYPE_REN).equals("80")) {
				Document renDoc = new Document();
				addToDocument(procFieldGrouprenewalProducts, docRen, IConstants.WSGRS_RENEWALS_GRP_REN_PRODS,
						renDoc);

				List<Document> renewalProducts = new ArrayList<>();
				
				addToDocument(procFieldGroupBenNames, docRen,
						sourceCollection.concat(IConstants.RENEWAL_DETAILS), doc);
				//WSGRS Change BPP-23129
				String dentalProductTypes = "DEN";
				Document docDetail = new Document();
				List<Document> detailList = new ArrayList<>();

				if (currentProdType.equals(dentalProductTypes)) {
					try {
						renewalFieldNames = FieldNamesProperties.getInstance()
								.getPropertyContext(IConstants.WSGRS_RENEWALS.concat("dentalTiers"));
					} catch (ClassNotFoundException | NoSuchMethodException | SecurityException
							| IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {

						logger.error("Exception:  " + e);
					}
					addToDocument(renewalFieldNames, docRen, sourceCollection.concat("dentalTiers"), docDetail);
					detailList.add(docDetail);
					doc.append("dentalTiers", detailList);

				}						
				detailList = null;
				renDoc.append(IConstants.PRODUCT_TYPE, doc.get(IConstants.PRODUCT_TYPE));
				renDoc.append("renewalContractPlanName", "");
				/* Start : BPP-28222 WSGRS feed from "FACETS" Source , "Product" Field should be 'Prod_ID2'*/
				if(null!= docRen.getString("Source_ID") && docRen.getString("Source_ID").equals("FACETS") && null!= docRen.getString("Product_ID2") && null!= docRen.getString("Target_Product_ID1")) {
					doc.append("currentContractPlanCode", docRen.getString("Product_ID2"));
					renDoc.append("contractPlanCode", docRen.getString("Target_Product_ID1"));
				}
				/* End : BPP-28222 WSGRS feed from "FACETS" Source , "Product" Field should be 'Prod_ID2'*/
				renewalProducts.add(renDoc);
				doc.append(IConstants.RENEWAL_PRODUCTS, renewalProducts);
				// Adding the Non life products at group Level in 'Benefits' document present in 'Renewals_udm_Renewal' Collection
				renDetailList.add(doc);
			}
		  }
		}
	}

	/**
	 * @param sourceDb
	 * @param appendedCollection
	 * @param lifeDistinctBenefits
	 * @param iterableMem
	 * @param groupID
	 * @param procFieldMemBenNames
	 * @param procFieldMemrenewalProducts
	 * @param renDetailList
	 * This methods add life products in Renewal_tdm_Renewals collection at EmployeeLevel
	 */
	private void addLifeProductsAtEmployeeLevel(String sourceDb, String appendedCollection,
			List<String> lifeDistinctBenefits, FindIterable<Document> iterableMem, String groupID,
			ProcessFieldNames procFieldMemBenNames, ProcessFieldNames procFieldMemrenewalProducts,
			List<Document> renDetailList) {
		List<Document> renewalProducts;
		
		for (Document docRen : iterableMem) {
			String prodId1 = docRen.getString(IConstants.PROD_ID1);
			String subId =docRen.getString(IConstants.SUBSCRIBER_ID);
			if(lifeDistinctBenefits.contains(prodId1)){
				lifeDistinctBenefits.remove(lifeDistinctBenefits.indexOf(prodId1)); /* Removing the Life product from the lifeDistinctBenefits */
				Document renDoc = new Document();
				renewalProducts = new ArrayList<>();
				addToDocument(procFieldMemrenewalProducts, docRen, IConstants.WSGRS_RENEWALS_MEM_REN_PRODS,
						renDoc);
				Double lifeCurrentMonthlyPremium = MongoConnector.getInstance().getLifeSubscriberCurrentMonthlyPrem(sourceDb,
						appendedCollection.split(IConstants.COMMA)[2], IConstants.RDM_DB, groupID,prodId1,subId); 
				
				Double lifeMonthlyPremium = MongoConnector.getInstance().getLifeSubscriberMonthlyPrem(sourceDb,
						appendedCollection.split(IConstants.COMMA)[2], IConstants.RDM_DB, groupID,prodId1,subId); 
											
				renDoc.append("currentMonthlyPremium", lifeCurrentMonthlyPremium);
				renDoc.append("monthlyPremium", lifeMonthlyPremium);
				renewalProducts.add(renDoc);
				Document doc = new Document();
				doc.append(IConstants.RENEWAL_PRODUCTS, renewalProducts);
				addToDocument(procFieldMemBenNames, docRen,
						IConstants.WSGRS_DETAIL_MEM_INFO.concat(IConstants.RENEWAL_DETAILS), doc);
				doc.append("currentMonthlyPremium", lifeCurrentMonthlyPremium);
				//Adding the life products in 'Benefits' document under 'EmployeeRenewal' present in 'Renewals_tdm_Renewal'Collection
				renDetailList.add(doc);
				}
		}
	}

	/**
	 * @param iterableMem
	 * @param procFieldMemBenNames
	 * @param procFieldMemrenewalProducts
	 * @param renDetailList
	 * This method adds Non-Life[Med,Den,Vis] products in Renewal_tdm_Renewals at EmployeeLevel
	 */
	private void addNonLifeProductsAtEmployeeLevel(FindIterable<Document> iterableMem, ProcessFieldNames procFieldMemBenNames,
			ProcessFieldNames procFieldMemrenewalProducts, List<Document> renDetailList) {
		List<Document> renewalProducts;
		for (Document docRen : iterableMem) {
			Document renDoc = new Document();
			renewalProducts = new ArrayList<>();
			addToDocument(procFieldMemrenewalProducts, docRen, IConstants.WSGRS_RENEWALS_MEM_REN_PRODS,
					renDoc);
			renewalProducts.add(renDoc);
			Document doc = new Document();
			doc.append(IConstants.RENEWAL_PRODUCTS, renewalProducts);
			addToDocument(procFieldMemBenNames, docRen,
					IConstants.WSGRS_DETAIL_MEM_INFO.concat(IConstants.RENEWAL_DETAILS), doc);
			/* Start : BPP-28222 WSGRS feed from "FACETS" Source , "Product" Field should be 'Prod_ID2'*/
			if(null!= docRen.getString("Source_ID") && docRen.getString("Source_ID").equals("FACETS") && null!= docRen.getString("Prod_ID2")) {
				doc.append("currentContractPlanCode", docRen.getString("Prod_ID2"));
			}
	       /* End : BPP-28222 WSGRS feed from "FACETS" Source , "Product" Field should be 'Prod_ID2'*/
			//Adding the Non-Life[Med,Den,Vis] products in 'Benefits' document under 'EmployeeRenewal' present in 'Renewals_tdm_Renewal'Collection
			renDetailList.add(doc);
}
	}
/*End BPP-27124,BPP-27127,BPP-27129 */
	private void addToDocument(ProcessFieldNames processFieldNames, Tuple2<Object, BSONObject> bsonFilter,
			String mappingName, Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

		}

	}

	private void addToDocument(ProcessFieldNames processFieldNames, Document bsonFilter, String mappingName,
			Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

		}

	}

	private BasicDBList appendCollections(String[] arr, String prodAddr, String fieldType, String mandatoryField,
			ProcessFieldNames procFieldNames, String coll, Document bsonFilter, String sourcecollection) {
		BasicDBList docList = new BasicDBList();
		for (String taxid : arr) {
			Document addrDoc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
				if (ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(sourcecollection.concat(coll), fieldNames, prodAddr)
						.equals(IConstants.STRING_TRUE)) {
					if (fieldNames.equals(fieldType)) {
						addrDoc.append(fieldNames, taxid);
					} else {
						if (!neglectList.contains(bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
								.getAttributeValueOfField(sourcecollection.concat(coll), fieldNames, taxid))))
							addrDoc.append(fieldNames, bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
									.getAttributeValueOfField(sourcecollection.concat(coll), fieldNames, taxid)));

					}
				} else {
					if (!neglectList.contains(bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(sourcecollection.concat(coll), fieldNames// ,IConstants.VALUE)));
									, selectFields(fieldNames, bsonFilter, coll, sourcecollection)))))
						addrDoc.append(fieldNames,
								bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
										sourcecollection.concat(coll), fieldNames// ,IConstants.VALUE)));
										, selectFields(fieldNames, bsonFilter, coll, sourcecollection))));
				}
			}
			docList.add(addrDoc);
		}
		return docList;
	}

	public BasicDBList appendCollections(String[] arr, String prodAddr, String fieldType, String mandatoryField,
			ProcessFieldNames procFieldNames, String coll, Tuple2<Object, BSONObject> bsonFilter, Document docRen,
			String sourcecollection, String targetDb) {
		BasicDBList docList = new BasicDBList();
		// String producerTIN;
		try {
			String agentTaxID, agencyTaxID, genAgencyTaxID;
			agentTaxID = docRen.get(IConstants.AGENT_TAX_ID).toString();
			agencyTaxID = docRen.get(IConstants.AGENCY_TAX_ID).toString();
			genAgencyTaxID = docRen.get(IConstants.GEN_AGENCY_TAX_ID).toString();
			
			/* BPP-23960  & BPP-24151 : Renewal Summary - Paid and Parent agents */
			
			if(null != agentTaxID){
				docRen.append(IConstants.AGENT_TAX_ID,agentTaxID);
			}
			
			if(null != agencyTaxID){
					docRen.append(IConstants.AGENCY_TAX_ID,agencyTaxID);
			}
			
			if(null != genAgencyTaxID){
					docRen.append(IConstants.GEN_AGENCY_TAX_ID,genAgencyTaxID);
			}

			String agentTaxType, agencyTaxType, genAgencyTaxType;
			agentTaxType = "Writing";
			agencyTaxType = "Paid";
			genAgencyTaxType = "Parent";
			String defaultAgentTaxType, defaultAgencyTaxType, defaultGenAgencyTaxType;
			defaultAgentTaxType = "Writing";
			defaultAgencyTaxType = "Paid";
			defaultGenAgencyTaxType = "Parent";
			
			if (genAgencyTaxID != null && !genAgencyTaxID.equals("")) {
				genAgencyTaxType = "Parent";
			} else {
				genAgencyTaxType = "";
			}
			
			if (agencyTaxID != null && !agencyTaxID.equals("")) {
				agencyTaxType = "Paid";
			} else {
				agencyTaxType = "";
			}
			
			if (agentTaxID != null && !agentTaxID.equals("")){
				agentTaxType = "Writing";
			} else {
				agentTaxType = "";
			}
			
			List<String> defTypeList = new ArrayList<String>();
			defTypeList.add(defaultAgentTaxType);
			defTypeList.add(defaultAgencyTaxType);
			defTypeList.add(defaultGenAgencyTaxType);

			List<String> typeList = new ArrayList<String>();
			typeList.add(agentTaxType);
			typeList.add(agencyTaxType);
			typeList.add(genAgencyTaxType);
			int i = 0;
			String dType;
			for (String type : typeList) {

				dType = defTypeList.get(i);
				i++;
				Document d = new Document();
				if (type != null && !type.equals("")) {

					for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
						if (fieldNames.equals(IConstants.TAX_ID_TYPE))
							d.append(fieldNames, dType);
						else if (fieldNames.equals(fieldType))
							d.append(fieldNames, IConstants.DEFAULT);
						// d.append(fieldNames, IConstants.WRITING);

						else if (docRen.get(ReadMappingXmlSingleton.getInstance().getRead()
								.getAttributeValueOfField(sourcecollection.concat("taxID"), fieldNames, type)) != null)
							d.append(fieldNames, docRen.get(ReadMappingXmlSingleton.getInstance().getRead()
									.getAttributeValueOfField(sourcecollection.concat("taxID"), fieldNames, type)));
					}
					String producerTIN = null;
					String agentName = null;
					try {
						 //BPP-3800 -Adding Encrypted taxID in TDM 
						producerTIN = d.get("agentID").toString();
						agentName = d.get("name").toString();
						if (producerTIN != null && producerTIN.length() > 0) {
							
							MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail("enrollmentDB","brokerinfo", "APP");
							/*BasicDBList orList = new BasicDBList();
							orList.add( new Document("brokerIdentifier",producerTIN) );
							orList.add(new Document("brokerIdentifier",agentTaxID));*/
							
							Document agent = (Document) collcheck.find(new Document("brokerIdentifier",producerTIN)).first();
							
							//Document agent = (Document) collcheck.find(new Document("starBrokerTin",producerTIN)).first();
							
							if(agent != null && agent.getString("encryptedTin") != null){
								d.append("taxID", agent.getString("encryptedTin"));
								d.append("name", agent.getString("agentOrAgencyName"));
							}else{
								d.append("taxID", "UNKNOWN");
								if(agentName != null && agentName.length() > 0){
									d.append("name", agentName);
								}else{
									d.append("name", "");
								}
						  }
						}else{
							d.append("taxID", "UNKNOWN");
							d.append("name", "NULL");
						}
						//logger.info("---agentid--"+producerTIN+"---name--"+agentName);
					} catch (Exception e) {
						logger.error(producerTIN + "Can't fetch from DumpFiles");
					}

					docList.add(d);
				}

			}

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return docList;

	}

	public BasicDBList appendCollections(String[] arr, String prodAddr, String fieldType, String mandatoryField,
			ProcessFieldNames procFieldNames, String coll, Tuple2<Object, BSONObject> bsonFilter,
			String sourcecollection) {
		BasicDBList docList = new BasicDBList();
		for (String taxid : arr) {
			Document addrDoc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
				if (ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(sourcecollection.concat(coll), fieldNames, prodAddr)
						.equals(IConstants.STRING_TRUE)) {
					if (fieldNames.equals(fieldType)) {
						addrDoc.append(fieldNames, taxid);
					} else {
						if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
								.getAttributeValueOfField(sourcecollection.concat(coll), fieldNames, taxid))))
							addrDoc.append(fieldNames, bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
									.getAttributeValueOfField(sourcecollection.concat(coll), fieldNames, taxid)));

					}
				} else {
					if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(sourcecollection.concat(coll), fieldNames// ,IConstants.VALUE)));
									, selectFields(fieldNames, bsonFilter, coll, sourcecollection)))))
						addrDoc.append(fieldNames,
								bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
										.getAttributeValueOfField(sourcecollection.concat(coll), fieldNames// ,IConstants.VALUE)));
												, selectFields(fieldNames, bsonFilter, coll, sourcecollection))));
				}
			}
			docList.add(addrDoc);
		}
		return docList;
	}

	public BasicDBList appendCollections(String[] arr, String prodAddr, String fieldType, String mandatoryField,
			ProcessFieldNames procFieldNames, String coll, Document docRen) {
		BasicDBList docList = new BasicDBList();
		for (String taxid : arr) {
			Document addrDoc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
				if (ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(IConstants.WSGRS_RENEWALS.concat(coll), fieldNames, prodAddr)
						.equals(IConstants.STRING_TRUE)) {
					if (fieldNames.equals(fieldType)) {
						addrDoc.append(fieldNames, taxid);
					} else {
						addrDoc.append(fieldNames, docRen.get(ReadMappingXmlSingleton.getInstance().getRead()
								.getAttributeValueOfField(IConstants.WSGRS_RENEWALS.concat(coll), fieldNames, taxid)));
					}
				} else {
					addrDoc.append(fieldNames,
							docRen.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
									IConstants.WSGRS_RENEWALS.concat(coll), fieldNames,
									selectFields(fieldNames, docRen, coll))));
				}
			}
			if (!addrDoc.get(mandatoryField).equals(""))
				docList.add(addrDoc);
		}
		return docList;
	}

	/*
	 * This method performs unified transformation on WSGRS transformed data.
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source collection name
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param targetCollection stores target collection name
	 * 
	 * @param targetDetailCollection stores collection name whose data is
	 * appended as embedded doc. i.t summary to detail
	 * 
	 * @return transformed Document
	 */
	@SuppressWarnings("unchecked")
	public Document ingestUDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection) {

		Document metaDoc = new Document();
		try {
			metaDoc.putAll(bsonFilter._2.toMap());

			metaDoc.remove(IConstants.ID);
		} catch (Exception e) {
			logger.error("Exception:  " + e);
		}
		return metaDoc;
	}

	@Override
	public void ingestRDMprocess(ProcessInput processInput, String sourcePath, String guidvalue, String strType) {
		List<Document> detailList = new ArrayList<>();
		List<Document> failedList = new ArrayList<>();

		String typ = processInput.getType();
		String sourceCollection = processInput.getSourceCollection();
		String delimeted = processInput.getDelimeted();
		String delimeter = processInput.getDelimeter();
		String sourceDB = processInput.getSourceDB();
		String failedCollection = processInput.getFailedCollection();
		
		JavaSparkContext scIngest = SparkContextSingleton.getInstance().getSparkContext();
		JavaRDD<String> filePartition = scIngest.textFile(sourcePath, 4);
		filePartition.count();   
		JavaRDD<Row> readFile = filePartition.map(record -> RowFactory.create((Object[]) record.split(delimeter, -1)));

		readFile.foreachPartition(partitionIterator -> {

			ProcessInput process = new ProcessInput(sourceDB, sourceCollection, typ, delimeter, delimeted,
					failedCollection);
			partitionIterator.forEachRemaining(readFileContent -> {
				String typeofData;
				String type = process.getType();
				typeofData = readFileContent.toString().substring(1, 3).trim();
				switch (typeofData.toString()) {
				case "00":
					break;
				case "99":
					break;
				default:
					String guid = this.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);

					boolean flag = this.createFlag(delimeted, sourceCollection, readFileContent, type);
					Document doc = this.appendRaw(process, sourcePath, guid, flag, readFileContent);
					ChangeDataCapture cdc = new ChangeDataCapture();
					cdc.implementWSGRSCdc(sourceDB, sourceCollection, doc, detailList, failedList, IConstants.RDM_DB);
					break;
				}
				if(detailList.size() >= 500){
					MongoConnector.getInstance().insertData(detailList, sourceDB, sourceCollection, IConstants.RDM_DB);
					MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
					detailList.clear();
					failedList.clear();
				}
			});

			MongoConnector.getInstance().insertData(detailList, sourceDB, sourceCollection, IConstants.RDM_DB);
			MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
		});
	}

	@Override
	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection,
			Tuple2<Object, BSONObject> bsonFilter, ProcessFieldNames procFieldNames, String targetDb,
			String targetCollection, String targetDetailCollection, String sourceDbTDM) {
		return null;
	}

	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection) {
		return null;
	}

	 @SuppressWarnings("unchecked")
	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection, ProcessInput processInput) {
		ProcessFieldNames groupDetail = null;

		ProcessFieldNames groupSummary = null;
		ProcessFieldNames groupSummaryBenefits = null;

		try {
			groupDetail = FieldNamesProperties.getInstance().getPropertyContext("groupDetail" + "Modified");

			groupSummary = FieldNamesProperties.getInstance().getPropertyContext("groupSummary");
			groupSummaryBenefits = FieldNamesProperties.getInstance().getPropertyContext("groupSummaryBenefits");
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e1) {
			logger.error(IConstants.ERROR_PREPEND, e1);
		}
		String[] sourceColl = sourceCollection;
		List<Document> docDetailList = new ArrayList<>();
		List<Document> docSummaryList = new ArrayList<>();

		Document doc = new Document();
		Document summaryDoc = new Document();

		try {

			addToDocument(groupDetail, bsonFilter, "groupDetail", doc);
			for (String metaData : IConstants.getMetadata())
				doc.append(metaData, bsonFilter._2.get(metaData));

			doc.append(IConstants.RENEWAL_DETAILS, MongoConnector.getInstance().getRenewalDocumentSDSDetail(doc,
					sourceDb, sourceColl[1], IConstants.UDM_DB,targetDb)); /* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
			if (bsonFilter._2.get(IConstants.EXCH_IND) != null){
				doc.append(IConstants.EXCH_IND, bsonFilter._2.get(IConstants.EXCH_IND).equals("OF") ? "Off" : "On");
			}
			
			
			docDetailList.add(doc);
			List<Document> subDocs = null;
			subDocs = getDetailDocs(bsonFilter, sourceDb, sourceColl, processInput,targetDb); /* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
			for (Document d : subDocs)
				docDetailList.add(d);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}

		addToDocument(groupSummary, bsonFilter, "groupSummary", summaryDoc);
		summaryDoc.append("ID", bsonFilter._2.get("billingEntity"));
		summaryDoc.append("groupFDocID", bsonFilter._2.get("groupFDocID"));
		summaryDoc.append("brokerFDocID", bsonFilter._2.get("brokerFDocID"));
		if(summaryDoc.containsKey("contacts")){
			ArrayList<BasicDBObject> contacts = (ArrayList<BasicDBObject>) summaryDoc.get("contacts");
			ArrayList<BasicDBObject> scontacts = new ArrayList<BasicDBObject> ();
			for(int i=0; i < contacts.size(); i ++){
				BasicDBObject obj = contacts.get(i);
				if(obj.containsKey("addressType")){
					if(obj.getString("addressType").equalsIgnoreCase("service") || obj.getString("addressType").equalsIgnoreCase("mailing")){
						scontacts.add(obj);
						summaryDoc.replace("contacts", scontacts);
					}
				}
				
				//OH Renewal Changes				
				if(obj.containsField("stateCode")){
					if(statesIncludeForFlagging != null && statesIncludeForFlagging.length >0){
						List<String> stateCode = Arrays.asList(statesIncludeForFlagging);
						if(stateCode.contains(obj.getString("stateCode"))){
							if(tinsIncludedForFlagging != null && tinsIncludedForFlagging.length >0){
								List<String> flagTins = Arrays.asList(tinsIncludedForFlagging);
								flagOHSubAgentsToFalse(summaryDoc,flagTins);													
							}
						}					
					}	
				}		
			}
		}
		
		for (String metaData : IConstants.getMetadata())
			summaryDoc.append(metaData, bsonFilter._2.get(metaData));
		int count = 0;
		if (bsonFilter._2.get(IConstants.EMPLOYEE) != null)
			count = ((BasicDBList) bsonFilter._2.get(IConstants.EMPLOYEE)).size();
		summaryDoc.append("employeeCount", count);
		if (bsonFilter._2.get(IConstants.EXCH_IND) != null)
			summaryDoc.append(IConstants.EXCH_IND, bsonFilter._2.get(IConstants.EXCH_IND).equals("OF") ? "Off" : "On");
		// for summary

		Object benefitsObject = MongoConnector.getInstance().getRenewalDocumentSDS(doc, sourceDb, sourceColl[1],
				IConstants.UDM_DB);
		List<Document> benefitsList = (ArrayList<Document>) benefitsObject;
		benefitsObject = null;
		List<Document> updatedBenefitsList = new ArrayList<>();
		for (Document benefitDocument : benefitsList) {
			/* Start BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
			if(benefitDocument.get("renewalProducts") != null){
				List<Document> objRenewalDoc = (List)benefitDocument.get("renewalProducts");
				for(Document renewalDocs:objRenewalDoc){
					renewalDocs.append("renewalContractPlanName",getPlanName(renewalDocs.get("contractPlanCode").toString(),targetDb,IConstants.SDSREN_DB));
				}
				
			}
			/* End BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
			Document updatedBenefitDocument = new Document();
			addToDocument(groupSummaryBenefits, benefitDocument, "groupSummaryBenefits", updatedBenefitDocument);
			updatedBenefitsList.add(updatedBenefitDocument);

		}
		MongoConnector.getInstance().putCalFields(summaryDoc, sourceDb, sourceColl[1], IConstants.UDM_DB);

		MongoConnector.getInstance().addGrpDelta(summaryDoc);
		summaryDoc.append("renewalSummary", updatedBenefitsList);

		docSummaryList.add(summaryDoc);
		try {

			MongoConnector.getInstance().removePrevious(targetDb, targetCollection, targetDetailCollection,
					IConstants.SDSREN_DB, summaryDoc,IConstants.WSGRS);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		MongoConnector.getInstance().insertData(docDetailList, targetDb, targetDetailCollection, IConstants.SDSREN_DB);
		MongoConnector.getInstance().insertData(docSummaryList, targetDb, targetCollection, IConstants.SDSREN_DB);
		MongoConnector.getInstance().updateStatus(sourceDb, sourceColl[0], bsonFilter, IConstants.UDM_DB);
		benefitsList = null;
		updatedBenefitsList = null;
		summaryDoc = null;
		docDetailList = null;
		docSummaryList = null;
		System.gc();
		return null;
	}

	@SuppressWarnings("unchecked")
	private List<Document> getDetailDocs(Tuple2<Object, BSONObject> bson, String sourceDb, String[] sourceColl,
			ProcessInput processInput,String targetDb)/* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */ {

		Document doc = new Document();
		doc.putAll(bson._2.toMap());
		ProcessFieldNames groupEmployeeDetail = null;
		ProcessFieldNames groupDependentDetail = null;
		List<Document> subDocs = new ArrayList<>();
		try {
			groupEmployeeDetail = FieldNamesProperties.getInstance().getPropertyContext("groupEmployeeDetail");
			groupDependentDetail = FieldNamesProperties.getInstance().getPropertyContext("groupDependentDetail");
			BasicDBList empDocList = (BasicDBList) doc.get(IConstants.EMPLOYEE);
			for (Object emp : empDocList) {
				List<Document> relatedDependentDoc = new ArrayList<>();
				BasicDBList dependents = (BasicDBList) ((BasicDBObject) emp).get(IConstants.DEPENDENT);

				((BasicDBObject) emp).remove(IConstants.DEPENDENT);
				Document empDoc = new Document();
				Document tempDoc1 = new Document();

				tempDoc1.putAll(((BasicDBObject) emp).toMap());
				addToDocument(groupEmployeeDetail, tempDoc1, "groupEmployeeDetail", empDoc);

				try {
					if (bson._2.containsField(IConstants.GROUP_ID))
						empDoc.append(IConstants.GROUP_ID, bson._2.get(IConstants.GROUP_ID));
				} catch (Exception e) {
					logger.error(IConstants.ERROR_PREPEND, e);
				}
				// benefits for Employees
				Object empBenefits = getBenefits((Document) tempDoc1, sourceDb, sourceColl[1], IConstants.EMPLOYEE,
						doc.get("ID"), bson, sourceColl[0], processInput,targetDb); /* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
				empDoc.append(IConstants.BENEFITS, empBenefits);
				empDoc.append(IConstants.TYPE, "EMP");
				
				if (bson._2.containsField("renewalDate"))
					empDoc.append("renewalDate",bson._2.get("renewalDate"));
				
				
				for (String metaData : IConstants.getMetadata())
					empDoc.append(metaData, bson._2.get(metaData));
				tempDoc1 = null;
				for (Object o : dependents) {
					Document dependDoc = new Document();
					Document tempDoc = new Document();

					tempDoc.putAll(((BasicDBObject) o).toMap());
					addToDocument(groupDependentDetail, tempDoc, "groupDependentDetail", dependDoc);
					Object depBenefits = getBenefits((Document) tempDoc, sourceDb, sourceColl[1], IConstants.DEPENDENT,
							doc.get("ID"), bson, sourceColl[0], processInput,targetDb); /* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
					dependDoc.append(IConstants.BENEFITS, depBenefits);
					dependDoc.append(IConstants.TYPE, IConstants.DEPENDENT);
					relatedDependentDoc.add(dependDoc);

				}
				empDoc.append(IConstants.DEPENDENT, relatedDependentDoc);
				subDocs.add(empDoc);
			}
			doc.remove(IConstants.EMPLOYEE);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return subDocs;
	}

	@SuppressWarnings("unchecked")
	private Object getBenefits(Document d, String sourceDb, String sourceColl, String type, Object object,
			Tuple2<Object, BSONObject> bson, String sourceColl2, ProcessInput processInput,String targetDb)/* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */ {
		try {

			if (type.equals(IConstants.EMPLOYEE)) {
				Document query = new Document();
				Document query1 = new Document();
				Document query2 = new Document();
				Document query3 = new Document();
				query.append("$match",
						new Document("ID", object).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED));
				query1.append("$unwind", "$EmployeeRenewal");
				query2.append("$match", new Document().append("EmployeeRenewal.ID", d.get("subscriberID")));
				query3.append("$project", new Document().append(IConstants.RENEWAL_DETAILS, "$EmployeeRenewal.Benefits")
						.append("_id", 0));

				MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
						sourceColl, IConstants.UDM_DB);
				List<Document> l = new ArrayList<>();
				l.add(query);
				l.add(query1);
				l.add(query2);
				l.add(query3);

				// List pipeline;
				// Class resultClass;
				AggregateIterable<Document> ddd = collcheck.aggregate(l);
				if (ddd.first() != null) {
					Document doc = ddd.first();

					if (!doc.containsKey(IConstants.RENEWAL_DETAILS))
						return null;
					List<Document> renDetails = (List<Document>) doc.get(IConstants.RENEWAL_DETAILS);

					ProcessFieldNames groupDetailPremium = null;
					groupDetailPremium = FieldNamesProperties.getInstance().getPropertyContext("groupDetailPremium");
					List<Document> benefits = new ArrayList<>();
					for (Document renDoc : renDetails) {
						ArrayList<Document> renProdList = (ArrayList<Document>) renDoc.get("renewalProducts");
						Document tempDoc = renProdList.get(0);
						Document premiumDoc = new Document();
						List<Document> premiumDocList = new ArrayList<>();
						Document benefitDoc = new Document();
						addToDocument(groupDetailPremium, tempDoc, "groupDetailPremium", premiumDoc);
						benefitDoc.append(IConstants.BENEFITTYPE, "renewalProducts");
						benefitDoc.append("enrollmentType", renDoc.get("enrollmentType"));
						premiumDocList.add(premiumDoc);
						benefitDoc.append("premium", premiumDocList);
						benefitDoc.append("currentContractPlanCode", renDoc.get("currentContractPlanCode"));
						benefitDoc.append("currentContractPlanName", renDoc.get("Current_Prod_Name"));
						//benefitDoc.append("renewalContractPlanName", ""); /* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */

						try {
							MongoCollection<Document> collcheck0 = MongoConnector.getInstance()
									.getCollectionDetail(sourceDb, sourceColl, IConstants.UDM_DB);
							query.append("$match", new Document("GUID", bson._2.get("GUID"))
									.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED));
							query1.append("$unwind", "$Benefits");
							query2.append("$match", new Document().append("Benefits.currentContractPlanCode",
									renDoc.get("currentContractPlanCode")));
							query3.append("$project",
									new Document().append(IConstants.RENEWAL_DETAILS, "$Benefits").append("_id", 0));
							List<Document> l2 = new ArrayList<>();
							l2.add(query);
							l2.add(query1);
							l2.add(query2);
							l2.add(query3);
							AggregateIterable<Document> ddd0 = collcheck0.aggregate(l2);
							if (ddd0.first() != null) {
								Document doc0 = ddd0.first();
								if (!doc0.containsKey(IConstants.RENEWAL_DETAILS))
									return null;
								Document tempDoc0 = (Document) doc0.get(IConstants.RENEWAL_DETAILS);
								String productType = tempDoc0.get("productType").toString();
								String productSubType = tempDoc0.get("productSubType").toString();
								renDoc.append("productType", productType);
								benefitDoc.append("productType", productType);
								benefitDoc.append("currentContractPlanName", tempDoc0.get("currentContractPlanName"));
								renDoc.append("currentContractPlanName", tempDoc0.get("currentContractPlanName"));
								renDoc.append("productSubType", productSubType);
								List<Document> renewalProd = (List<Document>) tempDoc0.get(IConstants.RENEWAL_PRODUCTS);
								if (renewalProd != null && renewalProd.size() > 0){
									benefitDoc.append("renewalContractPlanCode",
											renewalProd.get(0).get(IConstants.CONTRACT_PLAN_CODE));
									/* Start BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
									benefitDoc.append("renewalContractPlanName", 
											getPlanName(renewalProd.get(0).get(IConstants.CONTRACT_PLAN_CODE).toString()
													,targetDb,targetDb)
											);
								}
									/* End BPP-34308 : Renewal Service performance degradation issues (Data fix)  */else{
									benefitDoc.append("renewalContractPlanCode", "");
									benefitDoc.append("renewalContractPlanName", ""); /* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
								}
							}

						} catch (Exception e) {
							logger.error(IConstants.ERROR_PREPEND, e);
						}
						renDoc.append(IConstants.BENEFITTYPE, IConstants.CURRENTPRODUCTS);
						renDoc.remove("renewalProducts");
						benefits.add(renDoc);
						benefits.add(benefitDoc);

					}

					return benefits;

				}

			} else if (type.equals(IConstants.DEPENDENT)) {
				Document query = new Document();
				Document query1 = new Document();
				Document query2 = new Document();
				Document query3 = new Document();
				Document query4 = new Document();
				query.append("$match",
						new Document("ID", object).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED));
				query1.append("$unwind", "$EmployeeRenewal");
				query2.append("$unwind", "$EmployeeRenewal.DependentRenewal");

				query3.append("$match",
						new Document().append("EmployeeRenewal.DependentRenewal.ID", d.get("memberID")));// change
																											// ?
				query4.append("$project",
						new Document().append(IConstants.RENEWAL_DETAILS, "$EmployeeRenewal.DependentRenewal.Benefits")
								.append("_id", 0));

				MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
						sourceColl, IConstants.UDM_DB);

				List<Document> l = new ArrayList<>();
				l.add(query);
				l.add(query1);
				l.add(query2);
				l.add(query3);
				l.add(query4);

				AggregateIterable<Document> ddd = collcheck.aggregate(l);
				if (ddd.first() != null) {
					Document doc = ddd.first();
					List<Document> renDetails = (List<Document>) doc.get(IConstants.RENEWAL_DETAILS);
					ProcessFieldNames groupDetailPremium = null;
					groupDetailPremium = FieldNamesProperties.getInstance().getPropertyContext("groupDetailPremium");
					List<Document> benefits = new ArrayList<>();
					ArrayList<Document> renProdList = null;
					List<Document> premiumDocList = null;
					for (Document renDoc : renDetails) {
						renProdList = (ArrayList<Document>) renDoc.get("renewalProducts");
						Document tempDoc = renProdList.get(0);
						Document premiumDoc = new Document();
						premiumDocList = new ArrayList<>();
						Document benefitDoc = new Document();
						addToDocument(groupDetailPremium, tempDoc, "groupDetailPremium", premiumDoc);
						benefitDoc.append("contractPlanCode", tempDoc.getString("contractPlanCode"));
						benefitDoc.append(IConstants.BENEFITTYPE, "renewalProducts");
						premiumDocList.add(premiumDoc);
						benefitDoc.append("premium", premiumDocList);
						benefitDoc.append("currentContractPlanCode", renDoc.get("currentContractPlanCode"));
						benefitDoc.append("currentContractPlanName", renDoc.get("currentContractPlanName"));
						renDoc.append(IConstants.BENEFITTYPE, IConstants.CURRENTPRODUCTS);
						renDoc.remove("renewalProducts");
						benefits.add(renDoc);

					}

					return benefits;
				}

			}
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return null;
	}

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceColl, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String sourceDbTDM) {
		return null;
	}
	/* Start BPP-34308 : Renewal Service performance degradation issues (Data fix)  */	
	private String getPlanName(String planCode,String sourceDb,String dbType){
		String strPlanName ="";		
		
		if(planNames.get(planCode) != null){
			return planNames.get(planCode);
		}
		
		FindIterable<Document> objPlanName = MongoConnector.getInstance().
				getPlanName("contractID", planCode, sourceDb, "RenewalPlanDetails", IConstants.SDSREN_DB);
		
		for(Document objPlan:objPlanName){
			strPlanName = objPlan.getString("productMKTName");
			planNames.put(planCode, strPlanName);
			return strPlanName;
		}		
		return strPlanName;
	}
	/* End BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
	
	
	@SuppressWarnings("unchecked")
	private void flagOHSubAgentsToFalse(Document summaryDoc,List<String> flagTins){
		List<BasicDBObject> agentDocList = new ArrayList<BasicDBObject>();
		try{
			
			if(summaryDoc.get("agents") != null){
				agentDocList = (ArrayList<BasicDBObject >) summaryDoc.get("agents");
				boolean bWriting = false;
				boolean bPaid = false;
				boolean bParent = false;
				
				for(BasicDBObject agentDoc:agentDocList){
					if((agentDoc.get("agentID") != null && agentDoc.getString("agentID").length() >0
							&& flagTins.contains(agentDoc.getString("agentID"))) &&
							(agentDoc.get("taxIDType") != null && 
							 agentDoc.getString("taxIDType").length() >0 &&
							 agentDoc.getString("taxIDType").equalsIgnoreCase("Writing"))){
						bWriting = true;
					}
					if((agentDoc.get("agentID") != null && agentDoc.getString("agentID").length() >0
							&& flagTins.contains(agentDoc.getString("agentID"))) &&
							(agentDoc.get("taxIDType") != null && 
							 agentDoc.getString("taxIDType").length() >0 &&
							 agentDoc.getString("taxIDType").equalsIgnoreCase("Paid"))){
						bPaid = true;
					}
					if((agentDoc.get("agentID") != null && agentDoc.getString("agentID").length() >0
							&& flagTins.contains(agentDoc.getString("agentID"))) &&
							(agentDoc.get("taxIDType") != null && 
							 agentDoc.getString("taxIDType").length() >0 &&
							 agentDoc.getString("taxIDType").equalsIgnoreCase("Parent"))){
						bParent = true;
					}
					
				}				
				
				if(bWriting != bPaid || bWriting != bParent || bPaid != bParent){
					for(BasicDBObject agentDoc:agentDocList){
						if(!bWriting){
							if((agentDoc.get("taxIDType") != null && 
									 agentDoc.getString("taxIDType").length() >0 &&
									 agentDoc.getString("taxIDType").equalsIgnoreCase("Writing"))){
								agentDoc.append("isVisible", false);
								agentDoc.append("ModifiedBy", "RDP");							
							}
						}
						
						if (!bPaid){
							if((agentDoc.get("taxIDType") != null && 
									 agentDoc.getString("taxIDType").length() >0 &&
									 agentDoc.getString("taxIDType").equalsIgnoreCase("Paid"))){
								agentDoc.append("isVisible", false);
								agentDoc.append("ModifiedBy", "RDP");							
							}
						}
						
						if (!bParent){
							if((agentDoc.get("taxIDType") != null && 
									 agentDoc.getString("taxIDType").length() >0 &&
									 agentDoc.getString("taxIDType").equalsIgnoreCase("Parent"))){
								agentDoc.append("isVisible", false);
								agentDoc.append("ModifiedBy", "RDP");							
							}
						}
					}
				}
			}
		}catch(Exception e){
			logger.error(IConstants.ERROR_PREPEND, e);
		}
	}		
}