package com.anthem.marketplace.dataconsolidation.utils;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang.StringUtils;
import org.apache.spark.sql.Row;
import org.bson.BSONObject;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.filesutils.CHIPS;
import com.anthem.marketplace.dataconsolidation.model.VARenewal;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.BasicDBList;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

import scala.Tuple2;

public class ChipsUtils implements Serializable {

	private static ChipsUtils instance;
	public List<String> fieldsList = new ArrayList<String>();
	static final Logger logger = LoggerFactory.getLogger(ChipsUtils.class);
	public ArrayList<String> neglectList = new ArrayList<>(Arrays.asList("", null));
	private HashMap<String, Document> planMap = new HashMap<>();
	private HashMap<String, String> lookUpValues = new HashMap<>();
	private HashMap<String, String> lookUpValuesByName = new HashMap<>();

	private ChipsUtils() {

	}

	public static synchronized ChipsUtils getInstance() {
		if (instance == null) {
			try {
				instance = new ChipsUtils();

			} catch (Exception e) {
				logger.error("Error{}", e);
			}
		}
		return instance;
	}

	public List<BSONObject> createMemberDocList(Tuple2<Object, BSONObject> bsonFilter) {
		List<BSONObject> memberDocList = new ArrayList<BSONObject>();
		BSONObject spouseDetails = (BSONObject) bsonFilter._2.get(IConstants.SPOUSEDETAILS);
		List<BSONObject> dependentDetails = (List<BSONObject>) bsonFilter._2.get(IConstants.DEPENDENTDETAILS);
		if (null != spouseDetails) {
			memberDocList.add(spouseDetails);
		}
		if (dependentDetails != null) {
			memberDocList.addAll(dependentDetails);
		}
		return memberDocList;
	}

	public Document createRenewalsDoc(ProcessFieldNames procFieldNames) {
		Document renewalsDoc = new Document();
		for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
			if (fieldNames.equals("renewalPeriod")) {
				int year = Calendar.getInstance().get(Calendar.YEAR);
				renewalsDoc.append(fieldNames, year);
			}
		}
		return renewalsDoc;
	}

	public BasicDBList createAgentsList(ProcessFieldNames procFieldNames, Tuple2<Object, BSONObject> bsonFilter,
			String coll, String targetDb) {

		BasicDBList agentsDocList = new BasicDBList();
		BSONObject agencyInfo = (BSONObject) bsonFilter._2.get(IConstants.AGENCYINFO);
		BSONObject agentInfo = (BSONObject) bsonFilter._2.get(IConstants.AGENTINFO);
		BSONObject contractInfo = (BSONObject) bsonFilter._2.get(IConstants.CONTRACT);
		String[] types = { "Writing" };
		for (String type : types) {
			Document agentDoc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
				if (ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(IConstants.CHIPS.concat(coll), fieldNames, IConstants.PROD_TYPE)
						.equals(IConstants.STRING_TRUE)) {
					if (fieldNames.equals(IConstants.PRODUCT)) {
						String planName = contractInfo.get("product").toString();
						Document planDoc = planMap.get(planName);
						if (planDoc != null && planDoc.get("productType") != null) {
							agentDoc.append(fieldNames, planDoc.get("productType"));
						}
					}
				} else if (fieldNames.equals(IConstants.TAX_ID_TYPE)) {
					agentDoc.append(fieldNames, type);
				} else {
					Object value = agencyInfo.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(IConstants.CHIPS.concat(coll), fieldNames, IConstants.VALUE));

					if (!neglectList.contains(value))
						agentDoc.append(fieldNames, value);
				}

			}
			populateEncytedFields(agentDoc, agencyInfo, agentInfo, targetDb);
			agentsDocList.add(agentDoc);
			
			if(agencyInfo.get("agencyName") != null && agencyInfo.get("agencyName").toString().length() >0){
				Document parentDoc = new Document();
				populateEncytedFieldsByName(parentDoc, agencyInfo, agentInfo, targetDb);				
				if(parentDoc.get("taxID") != null || parentDoc.get("agentID") != null){
					agentsDocList.add(parentDoc);
				}				
			}			
		}
		return agentsDocList;
	}

	public Document createContactDoc(ProcessFieldNames procFieldNames, Tuple2<Object, BSONObject> bsonFilter,
			String coll) {

		Document doc = new Document();
		BSONObject policyHolderData = (BSONObject) bsonFilter._2().get(IConstants.POLICYHOLDERDATA);
		for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (fieldNames.equals("addressType")) {
				doc.append(fieldNames, IConstants.DEFAULT);
			} else {
				Object value = policyHolderData.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(IConstants.CHIPS.concat(coll), fieldNames, IConstants.VALUE));
				if (!neglectList.contains(value))
					doc.append(fieldNames, value);
			}
		}
		return doc;
	}

	public List<Document> createRenewalBenefits(ProcessFieldNames procFieldNames, Tuple2<Object, BSONObject> bsonFilter,
			String sourceCollection, Document metaDoc, String targetDb) {
		List<Document> benefitDocList = new ArrayList<Document>();
		BSONObject contractInfo = (BSONObject) bsonFilter._2.get(IConstants.CONTRACT);
		do {
			Document benefitDoc = new Document();

			for (String benefitFieldName : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				Object value = contractInfo.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(IConstants.CHIPSBENEFITS, benefitFieldName, IConstants.VALUE));
				if (!neglectList.contains(value)) {
					benefitDoc.append(benefitFieldName, value);
				}
			}
			populatePlanCode(benefitDoc, targetDb, contractInfo.get("product").toString());
			List<Document> renewalProducts = getRenewalProducts(sourceCollection, benefitDoc, contractInfo, metaDoc);
			benefitDoc.append("renewalProducts", renewalProducts);

			benefitDocList.add(benefitDoc);
		} while (fieldsList.size() > 0);
		return benefitDocList;
	}

	private void populatePlanCode(Document benefitDoc, String targetDb, String planName) {
		Document planDoc = getPlanDoc(benefitDoc, targetDb, planName);
		if (planDoc != null) {
			benefitDoc.append(IConstants.PRODUCT, planDoc.get("productType"));
			benefitDoc.append("currentContractPlanCode", planDoc.get("contractCode"));
			benefitDoc.append("renewalContractCode", planDoc.get("contractCode"));
		}
	}

	private Document getPlanDoc(Document benefitDoc, String targetDb, String planName) {
		if (planMap.isEmpty()) {
			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(targetDb,
					"chips_plans", IConstants.TDM_DB);
			FindIterable<Document> planDocs = collcheck.find();
			for (Document plan : planDocs) {
				planMap.put(plan.getString("planName"), plan);
			}
		}
		return planMap.get(planName);
	}

	private void populateEncytedFields(Document doc, BSONObject agencyInfo, BSONObject agentInfo, String targetDb) {

		String key = agencyInfo.get("agencyNumber").toString().substring(1)
				.concat(agentInfo.get("agentNumber").toString());
		try {

			if (key != null && key.length() > 0) {
				if(lookUpValues.get(key) == null) {
					getLookUpValues(key,targetDb,agentInfo,doc.getString("name"),false);
				}
				String[] lookUpValue = lookUpValues.get(key).split(IConstants.SPLIT_PIPE);
				doc.append("name", lookUpValue[0]);
				doc.append("taxID", lookUpValue[1]);
				doc.append("agentID", lookUpValue[1]);
			}
		}catch(	Exception e)
		{
			logger.error(key + "Can't fetch from DumpFiles");
		}
	}
	
	private void populateEncytedFieldsByName(Document doc, BSONObject agencyInfo, BSONObject agentInfo, String targetDb) {

		String key = agencyInfo.get("agencyName").toString();
		try {

			if (key != null && key.length() > 0) {
				if(lookUpValuesByName.get(key) == null) {
					getLookUpValues(key,targetDb,agentInfo,agencyInfo.get("agencyName").toString(),true);
				}
				
				if(lookUpValuesByName.get(key) != null){
					String[] lookUpValueByName = lookUpValuesByName.get(key).split(IConstants.SPLIT_PIPE);
					if(lookUpValueByName != null && lookUpValueByName.length >0){
						doc.append("name", lookUpValueByName[0]);
						doc.append("taxID", lookUpValueByName[1]);
						doc.append("agentID", lookUpValueByName[1]);
						doc.append("taxIDType", "Parent");
					}
				}
			}
		}catch(	Exception e)
		{
			logger.error(key + "Can't fetch from DumpFiles");
		}
	}

	private void getLookUpValues(String key, String targetDb, BSONObject agentInfo, String name,boolean bFlag) {
		
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail("enrollmentDB",
				"brokerinfo", "APP");
		Document docRen = null;
		
		if(bFlag){
			docRen = (Document) collcheck.find(new Document("agentOrAgencyName", key)).first();
		}else{
			docRen = (Document) collcheck.find(new Document("brokerIdentifier", key)).first();
		}		
		
		StringBuilder lookUpName = new StringBuilder();
		
		//if(name == null) {
		if(docRen != null){
			String encryptedTaxId = docRen.getString("encryptedTin");
			String agencyName = docRen.getString("agentOrAgencyName");
			if (bFlag) {
				lookUpValues.put(key, agencyName.concat(IConstants.PIPE).concat(encryptedTaxId));
				lookUpValuesByName.put(key, agencyName.concat(IConstants.PIPE).concat(encryptedTaxId));
				
			} else {
				if (agencyName != null && !(agencyName.equalsIgnoreCase("NULL"))) {
					lookUpName.append(agencyName);
				}
				if (lookUpName.length() <= 0) {
					if (agentInfo.get("lastName") != null) {
						lookUpName.append(agentInfo.get("lastName").toString() + ", ");
					}
					if (agentInfo.get("firstName") != null) {
						lookUpName.append(agentInfo.get("firstName").toString() + " ");
					}
					if (agentInfo.get("middleName") != null) {
						lookUpName.append(agentInfo.get("middleName")).toString();
					}
				}
			lookUpValues.put(key, lookUpName.append(IConstants.PIPE).append(encryptedTaxId).toString());
			}
		}
		//}else {
			//lookUpValues.put(key, name.concat(IConstants.PIPE).concat(encryptedTaxId).toString());
		//}
	}

	private List<Document> getRenewalProducts(String sourceCollection, Document outerDoc, BSONObject contractInfo,
			Document metaDoc) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.CHIPS.concat("renewalProducts"));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}
			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	public Document createSummaryDocument(ProcessFieldNames memberSummary, ProcessFieldNames memberSummaryBenefits,
			Tuple2<Object, BSONObject> bsonFilter, String sourceDb, String[] sourceCollection) {

		Document summaryDoc = new Document();
		addToDocument(memberSummary, bsonFilter, "memberSummary", summaryDoc);
		insertMetaDoc(bsonFilter, summaryDoc);
		// getting summary benefitsList
		List<Document> updatedBenefitsList = createSummaryBenefits(bsonFilter, memberSummaryBenefits, sourceDb,
				sourceCollection);
		putPremiumFields(summaryDoc, sourceDb, sourceCollection[1], IConstants.UDM_DB);
		MongoConnector.getInstance().addGrpDelta(summaryDoc);
		summaryDoc.append("renewalSummary", updatedBenefitsList);
		summaryDoc.append("groupName",
				(summaryDoc.get(IConstants.LASTNAME) + ", " + summaryDoc.get(IConstants.FIRSTNAME)).toUpperCase());
		return summaryDoc;
	}

	private List<Document> createSummaryBenefits(Tuple2<Object, BSONObject> bsonFilter,
			ProcessFieldNames memberSummaryBenefits, String sourceDb, String[] sourceCollection) {
		// TODO Auto-generated method stub
		List<Document> updatedBenefitsList = new ArrayList<Document>();

		Object benefitsObject = MongoConnector.getInstance().getRenewalDocumentSDS(bsonFilter, sourceDb,
				sourceCollection[1], IConstants.UDM_DB, IConstants.RENEWAL_DETAILS);
		@SuppressWarnings("unchecked")
		List<Document> benefitsList = (ArrayList<Document>) benefitsObject;
		for (Document benefitDocument : benefitsList) {
			Document updatedBenefitDocument = new Document();
			addToDocument(memberSummaryBenefits, benefitDocument, "memberSummaryBenefitsModified",
					updatedBenefitDocument);
			@SuppressWarnings("unchecked")
			ArrayList<Document> renProdList = (ArrayList<Document>) updatedBenefitDocument.get("renewalProducts");
			for (Document d : renProdList) {
				d.put("contractPlanCode", d.get("renewalContractCode"));
				d.remove("renewalContractCode");
				d.put("productType", updatedBenefitDocument.get("productType"));
				d.put("renewalContractPlanName", d.get("renewalContractPlanName"));
			}
			updatedBenefitsList.add(updatedBenefitDocument);
		}
		return updatedBenefitsList;
	}

	public Document createDetailDocument(ProcessFieldNames memberDetail, Tuple2<Object, BSONObject> bsonFilter,
			String sourceDb, String[] sourceCollection) {
		Document detailDoc = new Document();
		addToDocument(memberDetail, bsonFilter, "memberDetail", detailDoc);
		detailDoc.append("exchangeIndicator", "No");
		detailDoc.append("ratingArea", "");
		insertMetaDoc(bsonFilter, detailDoc);
		detailDoc.append("groupName",
				(detailDoc.get(IConstants.LASTNAME) + ", " + detailDoc.get(IConstants.FIRSTNAME)).toUpperCase());
		detailDoc.append(IConstants.RENEWAL_DETAILS,
				getRenewalDetailBenefits(bsonFilter, sourceDb, sourceCollection[1], IConstants.UDM_DB));
		detailDoc.append("dependentsCovered", bsonFilter._2.get("dependentsCovered"));
		return detailDoc;
	}

	private void insertMetaDoc(Tuple2<Object, BSONObject> bsonFilter, Document doc) {
		for (String metaData : IConstants.getMetadata())
			doc.append(metaData, bsonFilter._2.get(metaData));
	}

	private void addToDocument(ProcessFieldNames processFieldNames, Tuple2<Object, BSONObject> bsonFilter,
			String mappingName, Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));
		}

	}

	private void addToDocument(ProcessFieldNames processFieldNames, Document bsonFilter, String mappingName,
			Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

		}

	}

	public void addToDocument(ProcessFieldNames processFieldNames, Tuple2<Object, BSONObject> bsonFilter, String key,
			String mappingName, Document document) {

		BSONObject bsonObject = (BSONObject) bsonFilter._2.get(key);
		if (bsonObject != null) {
			for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
				if (!neglectList.contains(bsonObject.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

					document.append(fieldNames, bsonObject.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

			}
		}

	}

	private void putPremiumFields(Document summaryDoc, String sourceDb, String sourceColl, String udmDb) {

		double currPrem = 0.00, monPrem = 0.00;
		Document d = null;
		try {
			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, sourceColl,
					udmDb);
			d = collcheck.find(new Document("ID", summaryDoc.getString("ID"))
					.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE)
					.append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)).first();
			if (d.containsKey(IConstants.CURR_MON_PREMIUM))
				currPrem = d.getDouble(IConstants.CURR_MON_PREMIUM);
			if (d.containsKey(IConstants.MON_PREM))
				monPrem = d.getDouble(IConstants.MON_PREM);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		summaryDoc.append(IConstants.CURR_MON_PREMIUM, currPrem);
		summaryDoc.append(IConstants.MON_PREM, monPrem);

	}

	private Object getRenewalDetailBenefits(Tuple2<Object, BSONObject> bsonFilter, String sourceDb, String sourceColl,
			String dbType) {
		try {

			ProcessFieldNames memberDetailPremium = null;
			ProcessFieldNames memberDetailRenewal = null;
			ProcessFieldNames memberDetailCurrent = null;
			memberDetailPremium = FieldNamesProperties.getInstance().getPropertyContext("ChipsmemberDetailPremium");
			memberDetailRenewal = FieldNamesProperties.getInstance().getPropertyContext("ChipsmemberDetailRenewal");
			memberDetailCurrent = FieldNamesProperties.getInstance().getPropertyContext("ChipsmemberDetailCurrent");
			List<Document> benefits = new ArrayList<>();

			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, sourceColl,
					dbType);

			Document docRen = (Document) collcheck.find(new Document("GUID", bsonFilter._2.get("GUID").toString())
					.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE)
					.append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)).first();
			List<Document> renDetails = (List<Document>) docRen.get(IConstants.RENEWAL_DETAILS);

			for (Document renDoc : renDetails) {
				Document premiumDoc = new Document();
				List<Document> premiumDocList = new ArrayList<>();
				Document benefitDoc = new Document();
				Document currBenefitDoc = new Document();
				addToDocument(memberDetailPremium, renDoc, "ChipsmemberDetailPremium", premiumDoc);
				premiumDoc.append("renewalSubsidy", "No");
				premiumDoc.append("renewalPremiumwithoutSubsidy", renDoc.get("renewalPremiumwithoutSubsidy"));

				benefitDoc.append(IConstants.BENEFITTYPE, "renewalProducts");
				premiumDocList.add(premiumDoc);
				benefitDoc.append("premium", premiumDocList);
				addToDocument(memberDetailRenewal, renDoc, "ChipsmemberDetailRenewal", benefitDoc);
				benefitDoc.append("renewalSubsidy", "No");

				addToDocument(memberDetailCurrent, renDoc, "ChipsmemberDetailCurrent", currBenefitDoc);
				currBenefitDoc.append("currentSubsidy", "No");
				currBenefitDoc.append("currentPremiumwithoutSubsidy", renDoc.get("currentPremiumwithoutSubsidy"));
				currBenefitDoc.append(IConstants.BENEFITTYPE, IConstants.CURRENTPRODUCTS);

				benefits.add(currBenefitDoc);
				benefits.add(benefitDoc);

			}

			return benefits;

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return null;

	}

	public Document getVADocument(Row readFileContent) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		VARenewal vaRenewal = (VARenewal) readFileContent.get(0);
		mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));
		Document doc = Document.parse(mapper.writeValueAsString(vaRenewal));
		return doc;
	}

	public String getValue(Document bson, String key, String item) {

		String value = "";
		Object object = bson.get(key);
		if (object instanceof Document) {
			Document doc = (Document) object;
			if (doc != null && doc.get(item) != null)
				value = doc.get(item).toString();
		} else if (object instanceof List<?>) {
			List<Document> docList = (List<Document>) object;
			for (Document doc : docList) {
				if (doc != null && doc.get(item) != null) {
					value = doc.getString(item).toString();
				}
			}
		}
		return value;
	}

}
