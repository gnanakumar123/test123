package com.sparkTutorial.sparkSql;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import static org.apache.spark.sql.functions.col;

public class JsonSqlSolutions {
	public static void main(String[] args) {
		Logger.getLogger("org").setLevel(Level.ERROR);

		// Create a Spark Session
		SparkSession session = SparkSession.builder().appName("JsonSQLProblems").master("local[1]").getOrCreate();
		
		// Load the data from JSON file
		Dataset<Row> names = session.read().json("in/members.json");
		
		// Print the Schema
		names.printSchema();
		
		// show the table contents
		names.show();
		
		// Show only the column name
		names.select(col("name")).show();
		
		// Show max age of members
		Dataset<Row> maxAge = names.selectExpr("max(age)");
		maxAge.show();
		
		maxAge.select(col("max(age)").as("Maximum Age")).show();
		
		// Group by city
		names.groupBy(col("city")).count().show();
		
		// Show the members with ages more than 60
		names.filter(col("age").$greater(60)).show();
		
		Dataset<Row> typedDs = names.withColumn("age", col("age").cast("integer"));
		typedDs.printSchema();
		
		typedDs.filter(col("age").$greater(60)).show();
		
		typedDs.select(col("name"), col("age").$times(12)).show();
		
		typedDs.limit(2).show();
	}
}
