package com.anthem.marketplace.dataconsolidation.job.processor;

import java.io.Serializable;

import org.apache.hadoop.conf.Configuration;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.bson.BSONObject;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.filesutils.UtilityInterface;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.MongoConfiguration;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.hadoop.MongoInputFormat;

public class IngestSDS implements Serializable {
	/*
	 * This method transforms sourceDB.sorceCollection data and stores into
	 * targetDB.targetCollection
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source Collection name
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param targetCollection stores target Collection name
	 * 
	 * @param priority stores job priorities
	 * 
	 * @return nothing
	 */

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static final Logger logger = LoggerFactory.getLogger(IngestSDS.class);

	
	public boolean readAndSDSTransform(ProcessInput processInput, String targetDetailCollection, String strType,
			String sdsStatement, String sourcePath) {
		JavaPairRDD<Object, BSONObject> documents;
		Configuration mongodbConfig;
		try {
			String sourceDb = processInput.getSDSSourceDB();
			String sourceCollection = processInput.getSDSSourceCollection();
			String targetDb = processInput.getSDSTargetDB();
			String targetCollection = processInput.getSDSTargetCollection();
			JavaSparkContext scTransform = SparkContextSingleton.getInstance().getSparkContext();
			String sourceField = processInput.getSourceField();

			logger.debug("SDS Started for --> "
					+ strType.split(IConstants.SPLIT_DOT)[strType.split(IConstants.SPLIT_DOT).length - 1]);

			String sourceColl[] = sourceCollection.split(IConstants.SPLIT_COMMA);
			long count = MongoConnector.getInstance()
						.getCollectionDetail(sourceDb, sourceColl[0], IConstants.UDM_DB)
						.count(new Document(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)
								.append(IConstants.SOURCE_FIELD, sourceField));
				if (count > 0) {
					/* Start : Performance Improvement Added inputQuery  */
					//String inputQuery="{'status':'un-processed','source':'"+sourceField+"','end-date':'"+IConstants.MAX_DATE+"'}";
					//mongodbConfig = new MongoConfiguration(sourceDb, sourceColl[0]).setConfiguration(IConstants.UDM_DB, inputQuery);
					/* End : Performance Improvement Added inputQuery  */
					mongodbConfig = new MongoConfiguration(sourceDb, sourceColl[0]).setConfiguration(IConstants.UDM_DB);
					documents = scTransform
							.newAPIHadoopRDD(mongodbConfig, MongoInputFormat.class, Object.class, BSONObject.class)
							.filter(bsonFilter -> {
								if (bsonFilter._2.get(IConstants.STATUS_FIELD).toString()
										.contains(IConstants.UNPROCESSED)
										&& bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString()
												.contains(sourcePath)
										&& bsonFilter._2.get(IConstants.END_DATE_FIELD).toString()
												.contains(IConstants.MAX_DATE)) {


									
									return true;
								} else
									return false;
							});
					documents.count();
					
					JavaPairRDD<Object, BSONObject> partionedDocuments = documents.repartition(6); 

					documents = null;					
					
					partionedDocuments.foreachPartition(tuple -> {
						
						tuple.forEachRemaining(tObject ->{
							
							UtilityInterface utilityInterface = Utility.createObject(strType);
							try {
								utilityInterface.ingestSDSProcess(sourceDb,
										sourceCollection.split(IConstants.SPLIT_COMMA), tObject, targetDb,
										targetCollection, targetDetailCollection, processInput);

							} catch (Exception e) {
								logger.error(IConstants.ERROR_PREPEND, e);
							}
							
						});
					});
					//Configuration mongodbConfig2 = new MongoConfiguration(sourceDb, sourceColl[1]).setConfiguration(IConstants.UDM_DB,inputQuery); //Performance Improvement added inputQuery for MongoConfiguration 
					Configuration mongodbConfig2 = new MongoConfiguration(sourceDb, sourceColl[1])
							.setConfiguration(IConstants.UDM_DB);
					JavaPairRDD<Object, BSONObject> documents2 = scTransform
							.newAPIHadoopRDD(mongodbConfig2, MongoInputFormat.class, Object.class, BSONObject.class)
							.filter(bsonFilter2 -> {
								MongoConnector.getInstance().updateStatus(sourceDb, sourceColl[1], bsonFilter2,
										IConstants.UDM_DB);
								return true;
							});

					documents2.count();

					logger.debug("SDS DONE FOR ======> "
							+ strType.split(IConstants.SPLIT_DOT)[strType.split(IConstants.SPLIT_DOT).length - 1]);
				}
		} catch (Exception e) {
			logger.error("Exception:  " + e);
		} finally {
			documents = null;
			mongodbConfig = null;
		}
		return true;
	}

}