package com.anthem.marketplace.dataconsolidation.utils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.bson.Document;
import org.apache.spark.sql.Row;
import com.anthem.marketplace.dataconsolidation.filesutils.UtilityInterface;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utility {
	static int headerGrpId = 0;
	static boolean setHeaderGrpId = true;
	static int sortKey = 0;
	static int counter = 0;
	static final Logger logger = LoggerFactory.getLogger(Utility.class);
	static String files = "";

	static Map<String, Boolean> map = new HashMap<>();
	static Map<String, Boolean> maptrans = new HashMap<>();

	public static void insertMetadata(Document doc, String sourceDB, String sourceCollection, String guid,
			String sourcePath, String type, boolean flag, boolean performCdc,String dbType) {
		java.util.Date date = new java.util.Date();
		String version = "v0";
		doc.append(IConstants.SOURCE_PATH_FIELD, sourcePath);

		doc.append(IConstants.START_DATE_FIELD, new Timestamp(date.getTime()).toString());
		doc.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE);
		doc.append(IConstants.SOURCE_FIELD, type.toUpperCase());
		try {
			if (performCdc)
				version = MongoConnector.getInstance().getVersion(sourceDB, sourceCollection, guid,dbType);
			else
				version = "v0";
			if (version.isEmpty())
				version = IConstants.VERSION;
			else {
				String replace = version.substring(1);
				int count = Integer.parseInt(replace) + 1;
				version = IConstants.LETTER_V + count;
			}
		} catch (Exception e) {
			logger.error("Version MetaData not available in mongoDB" + e);
		}
		doc.append(IConstants.VERSION_FIELD, version);
		if (flag) {
			doc.append(IConstants.STATUS_FIELD, IConstants.FAILED);
			doc.append(IConstants.DQC_FIELD, IConstants.FAILED);
		} else {
			doc.append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED);
			doc.append(IConstants.DQC_FIELD, IConstants.PASSED);
		}

	}

	public static void addToList(Document doc, List<Document> docList, List<Document> failedList) {

		if (doc.containsKey(IConstants.DQC_FIELD) && doc.containsValue(IConstants.PASSED)) {

			docList.add(doc);
		} else {
			failedList.add(doc);
			logger.error("Data_Quality_Check failed. Document moved to Reject Collection for GUID: "
					+ doc.get(IConstants.GUID));
		}
	}

	public static boolean applyZone(String sourceCollection, String fieldNames, String value, Document doc,
			String dataType, Row readFileContent,String type) throws ParseException {

		boolean flag = false;
		double amt = 0;
		int amtflag = 0;
		try {
			if (ReadMappingXmlSingleton.getInstance().getRead().getMandatoryFields(sourceCollection,
					IConstants.ZONED_ATTRIBUTE) != null
					&& ReadMappingXmlSingleton.getInstance().getRead()
							.getMandatoryFields(sourceCollection, IConstants.ZONED_ATTRIBUTE).values()
							.contains(fieldNames)) {
				
				int precision = Integer.parseInt(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(sourceCollection, fieldNames, "precision"));
				
				if (!value.isEmpty() && value != null)
					amt = ZonedDecimalParser.getDecimal(value.trim(), precision);
				else
					amt = 0.0;
				amtflag = 1;
			}

			if (amtflag == 0) {
				switch (dataType) {
				case "Integer":
					if (value != null && !value.equalsIgnoreCase("") && !value.equalsIgnoreCase("null")) {
						if (fieldNames.equals(IConstants.CHECK_AMOUNT)) {
							
							doc.append(fieldNames,Integer.parseInt(value) / 100);
						} else {
							
							doc.append(fieldNames, Integer.parseInt(value.replaceAll("-", "").replaceAll(",", "")));
						}
					} else
						doc.append(fieldNames, null);
					break;

				case "Double":
					if (value.equals(null) || value.trim().equals("") || value.equalsIgnoreCase("null") || value.trim().isEmpty()) {
						doc.append(fieldNames, null);
					} else {

						value = value.replaceAll(IConstants.COMMA, "").replaceAll("\\$", "");

						if (value.indexOf('-') == value.length() - 1)
							value = '-' + value.substring(0, value.length() - 1);
						doc.append(fieldNames, Double.parseDouble(value));
					}

					break;

				case "Date":

					if (value != null && !value.equalsIgnoreCase("") && !value.equalsIgnoreCase("null") && !"00-00-00".equals(value)
							&& !"-00-00".equals(value) && matchPattern("Date", value)) {
						DateFormat formatter = new SimpleDateFormat("MM-dd-yy");
						formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
						Date date = formatter.parse(value);
						doc.append(fieldNames, date);

					}

					else
						doc.append(fieldNames, null);

					break;

				case "Date YYYY-MM-DD":

					if (value != null && !value.equalsIgnoreCase("") && !value.equalsIgnoreCase("null") && !"0000-00-00".equals(value)) {

						DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
						formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
						Date date = formatter.parse(value);
						doc.append(fieldNames, date);

					}

					else
						doc.append(fieldNames, null);

					break;

				case "Date MMDDYYYY":

					if (value != null && !value.equalsIgnoreCase("") && !value.equalsIgnoreCase("null") && !"00000000".equals(value)) {

						DateFormat formatter = new SimpleDateFormat("MMddyyyy");
						formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
						Date date = formatter.parse(value);
						doc.append(fieldNames, date);
					}

					else
						doc.append(fieldNames, null);

					break;

				case "Date YYYYMMDD":
					if (value != null && !value.equalsIgnoreCase("") && !value.equalsIgnoreCase("null") && !"00000000".equals(value)) {

						DateFormat formatter = new SimpleDateFormat("yyyyMMdd");
						formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
						Date date = formatter.parse(value);
						doc.append(fieldNames, date);
					}

					else
						doc.append(fieldNames, null);

					break;

				case "Date MM/DD/YYYY":
					if (value != null && !value.equalsIgnoreCase("") && !value.equalsIgnoreCase("null") && !"00000000".equals(value)) {

						DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
						formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
						Date date = formatter.parse(value);
						doc.append(fieldNames, date);
					}

					else
						doc.append(fieldNames, null);

					break;

				case "Date YYMMDD":
					if (value != null && !value.equalsIgnoreCase("") && !value.equalsIgnoreCase("null") && !"000000".equals(value)) {

						DateFormat formatter = new SimpleDateFormat("yyMMdd");
						formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
						Date date = formatter.parse(value);
						doc.append(fieldNames, date);

					}

					else
						doc.append(fieldNames, null);

					break;

				case "Date MM-DD-YY":
					if (value != null && !value.equalsIgnoreCase("") && !value.equalsIgnoreCase("null") && !"00-00-00".equals(value)) {

						DateFormat formatter = new SimpleDateFormat("MM-dd-yy");
						formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
						Date date = formatter.parse(value);
						doc.append(fieldNames, date);
					}

					else
						doc.append(fieldNames, null);

					break;

				default:
					/*
					 * condition added because for indSenCmmts, smgpCmmts
					 * fieldNames it should display generic name comments and
					 * for indCmsnSchedType, smgpCommSchedule it should display
					 * generic name commissionSchedule
					 */
					doc.append(fieldNames, value);

				}
			}


			else{
				doc.append(fieldNames, amt);
			}

		} catch (NullPointerException e) {
			flag = true;
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.CREATING_VALUE, "Exception:  "+ e,
					readFileContent.toString(), fieldNames, type,IConstants.RDM_DB);
			logger.error(e + "" + LogCleaner.cleanLog(fieldNames));
		} catch (ArrayIndexOutOfBoundsException e) {
			flag = true;
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.CREATING_VALUE, "Exception:  "+ e,
					readFileContent.toString(), fieldNames, type,IConstants.RDM_DB);
			logger.error(e + "");
		} catch (ClassCastException e) {
			flag = true;
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.CREATING_VALUE, "Exception:  "+ e,
					readFileContent.toString(), fieldNames, type,IConstants.RDM_DB);
			logger.error(e + "");
		} catch (NumberFormatException e) {
			flag = true;
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.CREATING_VALUE,
					"Exception:  "+ e, readFileContent.toString(), fieldNames, type,IConstants.RDM_DB);
			logger.error(e + "");
		} catch (Exception e) {
			flag = true;
			if (ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(sourceCollection, fieldNames,
					"avoidParsingError") != null
					&& ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(sourceCollection, fieldNames, "avoidParsingError")
							.equals(IConstants.STRING_TRUE)) {
				flag = false; // Value of flag changed due to requirement of
								// smgpSetlEffDate or any other date(Unparsable
								// date will be changed to null).
				doc.append(fieldNames, null);
			}

			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.CREATING_VALUE, "Exception:  "+ e,
					readFileContent.toString(), fieldNames, type,IConstants.RDM_DB);
			logger.error(e + "");
		}

		return flag;

	}

	public static UtilityInterface createObject(String strType) {

		Class<?> cls;
		UtilityInterface utilityInterface = null;
		try {
			
			cls = Class.forName(strType);

			utilityInterface = (UtilityInterface) cls.newInstance();
		} catch (Exception e) {
			logger.error(e + "");
		}

		return utilityInterface;
	}

	public static void createErrorCodeDescription(String errorCode, String method, String message, String data,
			String fieldName, String type,String dbType) {
		HashMap<String,ProcessConnector> connectorList=InputConnectors.getInstance().getConnectorList();
		String errorDescription = ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField(IConstants.ERROR_COLLECTION, errorCode, IConstants.VALUE);
//				+ method + IConstants.SEPARATOR + message + " for field: " + fieldName + " for Source: " + type;
		MongoConnector.getInstance().createErrorLog(connectorList.get(dbType).getDBName(), type+"_"+IConstants.ERROR_COLLECTION, errorCode, errorDescription,
				data,dbType,method,message,fieldName,type);
		}

	public static void createErrorCodeDescription(String errorCode, String method, String message, String data,String dbType,String type) {
		HashMap<String,ProcessConnector> connectorList=InputConnectors.getInstance().getConnectorList();
		String errorDescription = ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
				IConstants.ERROR_COLLECTION, errorCode, IConstants.VALUE);
//				+ method + IConstants.SEPARATOR + message;
		MongoConnector.getInstance().createErrorLog(connectorList.get(dbType).getDBName(),type+"_"+IConstants.ERROR_COLLECTION, errorCode, errorDescription,
				data,dbType,method,message);

	}

	public static void setIngestion(String type) {
		map.put(type, true);

	}

	public static boolean runTransformation(String type) {

		String Transformation = ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField("Transformation", type, "value");
		for (String fields : Transformation.split(IConstants.SPLIT_COMMA)) {
			if (map.get(fields) == null || map.get(fields).equals(false))
				return false;
		}

		return true;
	}

	public static void setTransformation(String type) {
		maptrans.put(type, true);

	}

	/*public static void restoreHashMap(String type) {
		String Transformation = ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField("Transformation", type, "value");
		for (String fields : Transformation.split(IConstants.SPLIT_COMMA)) {
			map.put(fields, false);
		}

	}
*/
	

	public static boolean matchPattern(String type, String value) {
		boolean var = false;
		switch (type) {
		case "Date":
			Pattern datePattern = Pattern.compile("(\\d{2})-(\\d{2})-(\\d{2})");
			Matcher dateMatcher = datePattern.matcher(value);
			if (dateMatcher.find()) {
				var = true;
			}
			break;
		}

		return var;

	}
	public static String getConfAddress(String sourceDb, String collection,String type) {

		SystemProperties.initializeProperties("connector");
		String confAddress = "";
			String localPort[] = SystemProperties.getProperty(type+"."+IConstants.ARRAY_CLUSTER_PORTS).split(",");
			String ipAdd[] = SystemProperties.getProperty(type+"."+IConstants.ARRAY_CLUSTER_IPADDRESS).split(",");
			String confAuthFlag = SystemProperties.getProperty(type+"."+IConstants.CONF_AUTH_FLAG);

			if (confAuthFlag.equals("false")){
				confAddress = "mongodb://" + ipAdd[0] + ":" + localPort[0] + "/"+ sourceDb + "." + collection;
			}else {
				String userName[] = SystemProperties.getProperty(type+"."+IConstants.ArrayClusterUserName).split(",");
				String passWord[] = SystemProperties.getProperty(type+"."+IConstants.ArrayClusterPassWord).split(",");
				confAddress = userName[0] + ":" + passWord[0] + "@" + ipAdd[0] + ":" + localPort[0]+",";
				confAddress="mongodb://" + confAddress.substring(0,confAddress.length()-1)+"/" + sourceDb + "." + collection;
				if(SystemProperties.getProperty(type+"."+IConstants.REPLICA_SET).equals("true"))
					confAddress+="?replicaSet="+SystemProperties.getProperty(type+"."+IConstants.REPLICA_SET_VALUE);
			}

		return confAddress;
	}


}
