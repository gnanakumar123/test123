package com.anthem.marketplace.dataconsolidation.utils;

public class ProcessConnector {
	private String[] arrayClusterIPAddress;
	private String[] arrayClusterPorts;
	private String[] arrayClusterUserName;
	private String[] arrayClusterPassWord;
	private String authenticationCheck;
	private String replicaSet;
	private String	replicaSetValue;
	private String dBName;
	private String ssl; /*BPP-38521 : Implement Mongodb SSL Feature to Data Load Project */
	
public String getDBName() {
		return dBName;
	}
	public void setDBName(String dBName) {
		this.dBName = dBName;
	}
	public String getReplicaSet() {
		return replicaSet;
	}

	public void setReplicaSet(String replicaSet) {
		this.replicaSet = replicaSet;
	}

	public String getReplicaSetValue() {
		return replicaSetValue;
	}

	public void setReplicaSetValue(String replicaSetValue) {
		this.replicaSetValue = replicaSetValue;
	}

	public String getAuthenticationCheck() {
		return authenticationCheck;
	}

	public void setAuthenticationCheck(String authenticationCheck) {
		this.authenticationCheck = authenticationCheck;
	}

	public String[] getArrayClusterUserName() {
		return arrayClusterUserName;
	}

	public void setArrayClusterUserName(String[] arrayClusterUserName) {
		this.arrayClusterUserName = arrayClusterUserName;
	}

	public String[] getArrayClusterPassWord() {
		return arrayClusterPassWord;
	}

	public void setArrayClusterPassWord(String[] arrayClusterPassWord) {
		this.arrayClusterPassWord = arrayClusterPassWord;
	}

	public String[] getArrayClusterIPAddress() {
		return arrayClusterIPAddress;
	}

	public void setArrayClusterIPAddress(String[] arrayClusterIPAddress) {
		this.arrayClusterIPAddress = arrayClusterIPAddress;
	}

	public String[] getArrayClusterPorts() {
		return arrayClusterPorts;
	}

	public void setArrayClusterPorts(String[] arrayClusterPorts) {
		this.arrayClusterPorts = arrayClusterPorts;
	}


	@Override
	public String toString() {
		return "{Host IP:"+this.arrayClusterIPAddress+",Host Port:"+this.arrayClusterPorts;
	}
	/**
	 * @return the ssl
	 */
	public String getSSL() { 
		return ssl;
	}
	/**
	 * @param ssl the ssl to set
	 */
	public void setSSL(String ssl) {
		this.ssl = ssl;
	}
}
