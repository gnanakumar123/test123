package com.anthem.marketplace.dataconsolidation.utils;

import java.util.HashMap;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/*
 * This class sets command and calls execute method of interface based on jobs.
 * @author : MongoDB Team
 * @version : 1.0
 * @Date : April 2016
 * It returns nothing.
 */
public class XmlToHashMap {
	public static HashMap<String, String> loadXmlHashMap() {
		HashMap<String, String> readMappingXml = new HashMap<>();
		Document document = new DocumentMaker().createDocument();

		NodeList childs = document.getFirstChild().getChildNodes();
		Node child;
		for (int i = 0; i < childs.getLength(); i++) {
			child = childs.item(i);

			NodeList nodeList = child.getChildNodes();
			for (int k = 0; k < nodeList.getLength(); k++) {
				Node value = nodeList.item(k);

				if (value.hasAttributes()) {
					for (int l = 0; l < value.getAttributes().getLength(); l++) {
						Node attribute = value.getAttributes().item(l);
						readMappingXml.put(child.getNodeName() + value.getTextContent() + attribute.getNodeName(),
								attribute.getTextContent());

					}

				}

			}
		}
		return readMappingXml;
	}

	public static HashMap<String, HashMap<String, String>> loadXmlHashMapMandatoryFields() {
		HashMap<String, HashMap<String, String>> readMappingXml = new HashMap<>();
		Document document = new DocumentMaker().createDocument();

		NodeList childs = document.getFirstChild().getChildNodes();
		Node child;
		for (int i = 0; i < childs.getLength(); i++) {
			child = childs.item(i);

			readMappingXml.put(child.getNodeName() + "required", new HashMap<>());
			readMappingXml.put(child.getNodeName() + "summary", new HashMap<>());
			readMappingXml.put(child.getNodeName() + "zoned", new HashMap<>());

			NodeList nodeList = child.getChildNodes();
			for (int k = 0; k < nodeList.getLength(); k++) {

				Node tempNode = nodeList.item(k);
				if (tempNode.getNodeType() == Node.ELEMENT_NODE) {
					Element value = (Element) tempNode;

					if (value.getAttribute("required").equals("true"))
						readMappingXml.get(child.getNodeName() + "required").put(value.getAttribute("index"),
								value.getTextContent());
					if (value.getAttribute("summary").equals("true"))
						readMappingXml.get(child.getNodeName() + "summary").put(value.getAttribute("index"),
								value.getTextContent());
					if (value.getAttribute("zoned").equals("true"))
						readMappingXml.get(child.getNodeName() + "zoned").put(value.getAttribute("index"),
								value.getTextContent());

				}

			}

		}
		return readMappingXml;
	}
}