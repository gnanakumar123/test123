package com.anthem.marketplace.dataconsolidation.filesutils;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.bson.BSONObject;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.utils.ChangeDataCapture;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.FixedFileMetaDataProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFixedFileMetaData;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Sorts;

import scala.Tuple2;

/*
* This class implements UtilityInterface and Serializable and performs Ingestion, Transformation of BCC and 
 * BCBSGA renewals input files
* @author : MongoDB Team
* @version : 1.0
* @Date : June 2016
* It returns nothing.
*/
public class facets_GBD implements UtilityInterface, Serializable {

	private static final long serialVersionUID = 1L;
	static final Logger logger = LoggerFactory.getLogger(facets_GBD.class);
	public static ArrayList<String> neglectList = new ArrayList<String>();
	public List<String> fieldsList;

	/*
	 * This method creates GUID
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param delimeted stores delimited character
	 * 
	 * @param readFileContent stores input file data
	 * 
	 * @param guidvalue stores guid values retrieve from properties file
	 * 
	 * @param type stores type of file
	 * 
	 * @return String GUID
	 */
	public String createGuid(String sourceCollection, String delimeted, Row readFileContent, String guidvalue,
			String type) {
		String guid = "";
		String errorFieldName = "";
		try {
			List<ProcessFixedFileMetaData> guidPosition = new ArrayList<>();

			for (String item : guidvalue.split(IConstants.SPLIT_COMMA)) {
				errorFieldName = item;
				guidPosition.add(FixedFileMetaDataProperties.getInstance().getPropertyContext(item, type));
			}

			for (ProcessFixedFileMetaData item : guidPosition) {
				guid += (readFileContent.toString().substring(Integer.parseInt(item.getStart()),
						Integer.parseInt(item.getEnd()) + 1)).trim();
			}
			guid = guid.concat("MED").concat("SUBSCR");
		}
		// catch Exceptions and add respective errorCode and its description
		catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_GBD,
					IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_GBD,
					IConstants.RDM_DB);

		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_GBD,
					IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_GBD,
					IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_GBD,
					IConstants.RDM_DB);
		}

		return guid;
	}

	/*
	 * This method checks mandatory fields for file for data Quality check
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param delimeted stores delimited character
	 * 
	 * @param readFileContent stores input file data
	 * 
	 * @param type stores type of file
	 * 
	 * @return boolean value based on data Quality check passed.
	 */
	public boolean createFlag(String delimeted, String sourceCollection, Row readFileContent, String type) {
		boolean flag = false;
		ProcessFixedFileMetaData metadata;
		String errorFieldName = "";
		try {
			// determine which files are mandatory from mapping.xml based on
			// type supplied
			Map<String, String> mandatoryFields = ReadMappingXmlSingleton.getInstance().getRead()
					.getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);
			for (String item : mandatoryFields.values()) {
				errorFieldName = item;
				metadata = FixedFileMetaDataProperties.getInstance().getPropertyContext(item, type);
				// check if mandatoryFields available in input content file
				flag = (readFileContent.toString()
						.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()))
						.trim() == null)
						|| readFileContent.toString()
								.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()))
								.trim().isEmpty();

				if (flag)
					break;
			}
			// if false then set error as null value found for mandatory fields.
			if (flag) {
				Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
						IConstants.DATA_QUALITY_ERROR_CHECK, readFileContent.toString(), errorFieldName,
						IConstants.FACETS_GBD, IConstants.RDM_DB);
			}
		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_GBD,
					IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_GBD,
					IConstants.RDM_DB);

		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_GBD,
					IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_GBD,
					IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_GBD,
					IConstants.RDM_DB);
		}
		return flag;
	}

	/*
	 * This method adds fileName and its respective value to a document and
	 * returns it.
	 * 
	 * @param processInput stores input properties related parameters
	 * 
	 * @param sourcePath stores source path of input file
	 * 
	 * @param guid stores GUID
	 * 
	 * @param flag stores value retrieve from data Quality check method
	 * 
	 * @param readFileContent stores Row of a input file
	 * 
	 * @return Document
	 */
	public Document appendRaw(ProcessInput processInput, String sourcePath, String guid, boolean flag,
			Row readFileContent) {

		String type = processInput.getType();

		String sourceDB = processInput.getSourceDB();
		String sourceCollection = processInput.getSourceCollection();
		String value;
		ProcessFixedFileMetaData metadata;
		ProcessFieldNames procFieldNames;
		boolean checkFlag = false;
		String errorFieldName = "";

		Document doc = new Document();
		try {
			procFieldNames = FieldNamesProperties.getInstance().getPropertyContext(type);
			doc.append(IConstants.GUID, guid);

			// for each filedNames
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				errorFieldName = fieldNames;
				// get dataType for each fieldName for given collectionName
				String dataType = ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(type,
						fieldNames, IConstants.DATATYPE);

				metadata = FixedFileMetaDataProperties.getInstance().getPropertyContext(fieldNames, type);
				value = readFileContent.toString()
						.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()) + 1)
						.trim();

				// if empty value then append it as it is to document
				if (value.isEmpty())
					doc.append(fieldNames, value);

				// else change its dataType as specified and convert zonal
				// fields to zonal decimal number
				else {
					checkFlag = Utility.applyZone(sourceCollection, fieldNames, value.trim(), doc, dataType,
							readFileContent, IConstants.FACETS_GBD);
				}

			}

			// insert metaData
			Utility.insertMetadata(doc, sourceDB, sourceCollection, guid, sourcePath, IConstants.FACETS_GBD, flag,
					true, IConstants.RDM_DB);

			// catch Exceptions and add respective errorCode and its description
		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.GBD_FACETS, IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.GBD_FACETS, IConstants.RDM_DB);
		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.GBD_FACETS, IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.RAW_DATA,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.GBD_FACETS,
					IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.GBD_FACETS, IConstants.RDM_DB);
		}

		return doc;
	}

	/*
	 * This method selects attributes to decide fields to be selected from BCC
	 * or BCBSGA Raw data.
	 * 
	 * @param fieldNames stores field names
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param collName stores collection name
	 * 
	 * @return attribute name
	 */
	/* TODO ::These to methods are not not used in the FACETS_GBD double check and remove these methods */
	public String selectFields(String fieldNames, Tuple2<Object, BSONObject> bsonFilter, String collName) {

		if (ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField(IConstants.GBD_FACETS.concat(collName), fieldNames, IConstants.PROD_TYPE)
				.equals(IConstants.STRING_FALSE))
			return IConstants.VALUE;

		else if ((bsonFilter._2.get(IConstants.MEDBROKERWRITINGTIN) == null)
				|| (bsonFilter._2.get(IConstants.MEDBROKERWRITINGTIN).toString().trim().equals("")))
			return IConstants.DENTAL;
		else
			return IConstants.MEDICAL;
	}

	public String selectMultiFields(String fieldNames, Tuple2<Object, BSONObject> bsonFilter, String collName,
			String sourceCollection) {
		List<String> selectFieldsList = new ArrayList<String>();
		if (ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField(sourceCollection.concat(collName), fieldNames, IConstants.PROD_TYPE)
				.equals("false")) {
			return IConstants.VALUE;
		} else {

			if (!((bsonFilter._2.get(IConstants.MEDBROKERWRITINGTIN) == null)
					|| (bsonFilter._2.get(IConstants.MEDBROKERWRITINGTIN).toString().trim().equals("")))) {
				selectFieldsList.add(IConstants.MEDICAL);
			}
			if (!((bsonFilter._2.get(IConstants.DENBROKERWRITINGTIN) == null)
					|| (bsonFilter._2.get(IConstants.DENBROKERWRITINGTIN).toString().trim().equals("")))) {
				selectFieldsList.add(IConstants.DENTAL);
			}
		}
		if (selectFieldsList.size() > 0)
			fieldsList = selectFieldsList;
		return "Multi";
	}

	/*
	 * This method performs transformation on BCC or BCBSGA Raw data.
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source collection name
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param targetCollection stores target collection name
	 * 
	 * @param appendedCollection stores collection name whose data to be
	 * appended as embedded doc. i.t summary to detail
	 * 
	 * @return transformed Document
	 */
	public Document ingestTDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String transColl, String appendedCollection) {

		Document metaDoc = new Document();
		boolean flag = false;
		String guid = "";
		ProcessFieldNames procFieldNames = null;
		String sourcePath = "";
		ProcessFieldNames clientFieldNames = null;
		//MongoConnector objMongoConnector= MongoConnector.getInstance();
		neglectList.add("");
		neglectList.add(null);
		try {
			clientFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.GBD_FACETS.concat(transColl).toString());
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e1) {
			logger.error(IConstants.ERROR_PREPEND, e1);

		}
		if (clientFieldNames.getArrayFieldNames() == null)
			return new Document();

		for (String fieldNames : clientFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
			if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(IConstants.GBD_FACETS.concat(transColl), fieldNames, IConstants.VALUE))))
				metaDoc.append(fieldNames, bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(IConstants.GBD_FACETS.concat(transColl), fieldNames, IConstants.VALUE)
				));
		}
		metaDoc.append("type", "MED");
		//List<Document> innerDocList = new ArrayList<Document>();
		if (transColl.contains("Renewals_tdm_Renewal")) {

			fieldsList = new ArrayList<String>();
			Document doc = new Document();
			try {
				procFieldNames = FieldNamesProperties.getInstance()
						.getPropertyContext(IConstants.FACETS_ANTHEM_REN_DET);
			} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
					| IllegalArgumentException | InvocationTargetException e) {
				logger.error("Exception:  " + e);
			}
			
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				Object value = bsonFilter._2
						.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
								IConstants.GBD_FACETS.concat(IConstants.BENEFITS), fieldNames, IConstants.VALUE));

				if (!neglectList.contains(
						bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
								IConstants.GBD_FACETS.concat(IConstants.BENEFITS), fieldNames, IConstants.VALUE)))) {
					if ("productType".equalsIgnoreCase(fieldNames) && "M".equals(value.toString()))
						doc.append(fieldNames, "MSUP");
					else
						doc.append(fieldNames,
								bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
										.getAttributeValueOfField(IConstants.GBD_FACETS.concat(IConstants.BENEFITS),
												fieldNames, IConstants.VALUE)));
				}
			}


			List<Document> renewalProducts = getRenewalProducts(sourceCollection, doc);
			doc.append("renewalProducts", renewalProducts);
			List<Document> benefitList = new ArrayList<>();
			benefitList.add(doc);
			metaDoc.append(IConstants.BENEFITS, benefitList);
		}

		else {
			int year = Calendar.getInstance().get(Calendar.YEAR);
			for (String coll : appendedCollection.split(IConstants.SPLIT_COMMA)) {
				Document doc = new Document();
				try {
					procFieldNames = FieldNamesProperties.getInstance()
							.getPropertyContext(IConstants.GBD_FACETS.concat(coll));
				} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
						| IllegalArgumentException | InvocationTargetException e) {
					logger.error("Exception:  " + e);
				}

				if (coll.equals(IConstants.CLIENT_CONTACTS)) {
					BasicDBList contactList = new BasicDBList();
					Document d = new Document();

					/*for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
						if (fieldNames.equals(IConstants.ADDRESS_TYPE)) {
							d.append(fieldNames, IConstants.MAILING);
						} else if (!neglectList.contains(bsonFilter._2
								.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
										IConstants.GBD_FACETS.concat(coll), fieldNames, IConstants.VALUE))))
							d.append(fieldNames,
									bsonFilter._2.get(
											ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
													IConstants.GBD_FACETS.concat(coll), fieldNames, IConstants.VALUE)));
					}
					contactList.add(d);
					d = new Document();*/

					for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
						if (fieldNames.equals(IConstants.ADDRESS_TYPE)) {
							d.append(fieldNames, IConstants.HOME);
						} else if (!neglectList.contains(bsonFilter._2
								.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
										IConstants.GBD_FACETS.concat(coll).concat(IConstants.OTHER), fieldNames,
										IConstants.VALUE))))
							d.append(fieldNames,
									bsonFilter._2.get(
											ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
													IConstants.GBD_FACETS.concat(coll).concat(IConstants.OTHER),
													fieldNames, IConstants.VALUE)));
					}
					contactList.add(d);
					metaDoc.append(coll, contactList);

				} else if (coll.equals(IConstants.CLIENT_AGENT)) {
					List<Document> agentDocList = new ArrayList<Document>();
					if(bsonFilter._2().get("AgencyTIN") != null 
							&& bsonFilter._2().get("AgencyTIN").toString().length() >0){
						agentDocList.add(MongoConnector.getInstance().appendContacts(targetDb,bsonFilter._2().get("AgencyTIN").toString(),"Parent"));
					}
					if(bsonFilter._2().get("AgentTIN") != null 
								&& bsonFilter._2().get("AgentTIN").toString().length() >0){
						agentDocList.add(MongoConnector.getInstance().appendContacts(targetDb,bsonFilter._2().get("AgentTIN").toString(),"Writing"));
					}				
					metaDoc.append(coll, agentDocList);
				}

			}
		}

		sourcePath = bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString();

		guid = metaDoc.get(IConstants.GUID).toString();
		// insert metaData
		Utility.insertMetadata(metaDoc, targetDb, transColl, guid, sourcePath, IConstants.FACETS_GBD, flag, true,
				IConstants.TDM_DB);

		if (metaDoc.getString(IConstants.REN_ID) != null)
			return metaDoc;

		else
			return null;
	}

	@SuppressWarnings("deprecation")
	public List<Document> getRenewalProducts(String sourceCollection, Document outerDoc, BSONObject bsonObject) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}
			double monPrem = 0.0, currMonPrem = 0.0;
			try {
				if (bsonObject.containsKey("medOldRate") && (bsonObject.get("medOldRate") != null)) {
					monPrem += (Double) bsonObject.get("medOldRate");
					doc.remove("renewalMonthlyPremium");
				}
				if (bsonObject.containsKey("denOldRate") && (bsonObject.get("denOldRate") != null)) {
					monPrem += (Double) bsonObject.get("denOldRate");

				}
				if (bsonObject.containsKey("medNewRate")) {
					currMonPrem += (Double) bsonObject.get("medNewRate");

				}
				if (bsonObject.containsKey("denNewRate")) {
					currMonPrem += (Double) bsonObject.get("denNewRate");

				}
			} catch (Exception e) {
				logger.error(IConstants.ERROR_PREPEND, e);
			}
			doc.append(IConstants.MON_PREM, monPrem);
			if (outerDoc.containsKey(IConstants.CURR_MON_PREMIUM))
				outerDoc.remove(IConstants.CURR_MON_PREMIUM);
			outerDoc.append(IConstants.CURR_MON_PREMIUM, currMonPrem);
			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	public List<Document> getGrpRenewalProducts(String sourceCollection, Document outerDoc, BSONObject bsonObject,
			Document metaDoc) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}
			double monPrem = 0.0, currMonPrem = 0.0;
			try {
				if (bsonObject.containsKey("medOldRate") && (bsonObject.get("medOldRate") != null)) {
					monPrem += (Double) bsonObject.get("medOldRate");
					doc.remove("renewalMonthlyPremium");
				}
				if (bsonObject.containsKey("denOldRate") && (bsonObject.get("denOldRate") != null)) {
					monPrem += (Double) bsonObject.get("denOldRate");

				}
				if (bsonObject.containsKey("medNewRate")) {
					currMonPrem += (Double) bsonObject.get("medNewRate");

				}
				if (bsonObject.containsKey("denNewRate")) {
					currMonPrem += (Double) bsonObject.get("denNewRate");

				}
			} catch (Exception e) {
				logger.error(IConstants.ERROR_PREPEND, e);
			}
			if (metaDoc.containsKey(IConstants.MON_PREM))
				metaDoc.remove(IConstants.MON_PREM);
			metaDoc.append(IConstants.MON_PREM, monPrem);
			if (metaDoc.containsKey(IConstants.CURR_MON_PREMIUM))
				metaDoc.remove(IConstants.CURR_MON_PREMIUM);
			metaDoc.append(IConstants.CURR_MON_PREMIUM, currMonPrem);
			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	public List<Document> getRenewalProducts(String sourceCollection, Document outerDoc) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.GBD_FACETS.concat("renewalProducts").concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames))) {
					if ("ProductType".equalsIgnoreCase(fieldNames)
							&& "M".equalsIgnoreCase(outerDoc.get(fieldNames).toString())) {
						doc.append(fieldNames, "MSUP");
					} else
						doc.append(fieldNames, outerDoc.get(fieldNames));
				}

			}

			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	/*
	 * This method performs unified transformation on ASCS transformed data.
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source collection name
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param targetCollection stores target collection name
	 * 
	 * @param targetDetailCollection stores collection name whose data is
	 * appended as embedded doc. i.t summary to detail
	 * 
	 * @return transformed Document
	 */
	@SuppressWarnings("unchecked")
	public Document ingestUDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection) {

		Document metaDoc = new Document();
		try {
			metaDoc.putAll(bsonFilter._2.toMap());

			metaDoc.remove(IConstants.ID);
		} catch (Exception e) {
			logger.error("Exception:  " + e);
		}
		return metaDoc;
	}

	/*
	 * this method inserts data into mongoDB for given specifications
	 * 
	 * @processInput stores input related parameters
	 * 
	 * @sourcePath stores file location path
	 * 
	 * @guidvalue stores GUID
	 * 
	 * @priority stores priority of process
	 * 
	 * @strType stores type of input file.
	 * 
	 * @return nothing
	 */
	@Override
	public void ingestRDMprocess(ProcessInput processInput, String sourcePath, String guidvalue, String strType) {
		List<Document> docList = new ArrayList<>();
		List<Document> failedList = new ArrayList<>();

		String sourceCollection = processInput.getSourceCollection();
		String delimeted = processInput.getDelimeted();
		String delimeter = processInput.getDelimeter();
		String type = processInput.getType();
		String sourceDB = processInput.getSourceDB();
		String failedCollection = processInput.getFailedCollection();
		String parentCollection = processInput.getParentCollection();
		JavaSparkContext scIngest = SparkContextSingleton.getInstance().getSparkContext();
		JavaRDD<String> filePartition = scIngest.textFile(sourcePath, 12);
		filePartition.count();
		JavaRDD<Row> readFile = filePartition.map(record -> RowFactory.create((Object[]) record.split(delimeter, -1)));
		readFile.foreachPartition(partitionIterator -> {

			ProcessInput process = new ProcessInput(sourceDB, sourceCollection, type, delimeter, delimeted,
					failedCollection, parentCollection);
			partitionIterator.forEachRemaining(readFileContent -> {
				String guid = this.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
				boolean flag = this.createFlag(delimeted, sourceCollection, readFileContent, type);
				Document doc = this.appendRaw(process, sourcePath, guid, flag, readFileContent);
				ChangeDataCapture cdc = new ChangeDataCapture();
				cdc.implementCdc(sourceDB, sourceCollection, doc, docList, failedList, IConstants.RDM_DB);

				if(docList.size() >= 500){
					MongoConnector.getInstance().insertData(docList, sourceDB, sourceCollection, IConstants.RDM_DB);
					MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
					docList.clear();
					failedList.clear();
				}
			});
			MongoConnector.getInstance().insertData(docList, sourceDB, sourceCollection, IConstants.RDM_DB);
			MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
		});

	}

	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection,
			Tuple2<Object, BSONObject> bsonFilter, ProcessFieldNames procFieldNames, String targetDb,
			String targetCollection, String targetDetailCollection, String sourceDbTDM) {
		return null;
	}

	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection) {
		return null;
	}

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection, ProcessInput processInput) {
		ProcessFieldNames memberSummary = null;
		ProcessFieldNames memberDetail = null;
		ProcessFieldNames memberSummaryBenefits = null;
		try {
			memberSummary = FieldNamesProperties.getInstance().getPropertyContext("memberSummary");
			memberDetail = FieldNamesProperties.getInstance().getPropertyContext(IConstants.MEMBER_DETAIL);
			memberSummaryBenefits = FieldNamesProperties.getInstance().getPropertyContext("memberSummaryBenefits");
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e1) {
			logger.error(IConstants.ERROR_PREPEND, e1);
		}

		String[] sourceColl = sourceCollection;
		List<Document> docDetailList = new ArrayList<>();
		List<Document> docSummaryList = new ArrayList<>();

		Document doc = new Document();
		Document summaryDoc = new Document();

		try {
			addToDocument(memberDetail, bsonFilter, IConstants.MEMBER_DETAIL, doc);
			for (String metaData : IConstants.getMetadata())
				doc.append(metaData, bsonFilter._2.get(metaData));
			doc.append(IConstants.RENEWAL_DETAILS, MongoConnector.getInstance()
					.getRenewalDocumentSDSDetail(bsonFilter, sourceDb, sourceColl[1], IConstants.UDM_DB));
			doc.append(IConstants.FULLNAME, (bsonFilter._2.get(IConstants.LASTNAME).toString() + ", "
					+ bsonFilter._2.get(IConstants.FIRSTNAME).toString()).toUpperCase());
			doc.append("facets_groupID", bsonFilter._2.get("facets_groupID"));
			docDetailList.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		summaryDoc.append(IConstants.FULLNAME, (bsonFilter._2.get(IConstants.LASTNAME).toString() + ", "
				+ bsonFilter._2.get(IConstants.FIRSTNAME).toString()).toUpperCase());
		addToDocument(memberSummary, bsonFilter, "memberSummary", summaryDoc);
		for (String metaData : IConstants.getMetadata())
			summaryDoc.append(metaData, bsonFilter._2.get(metaData));
		
		MongoConnector.getInstance().addBrokerAgentAgencyInfo(targetDb,summaryDoc);

		Object benefitsObject = MongoConnector.getInstance().getRenewalDocumentSDS(bsonFilter, sourceDb,
				sourceColl[1], IConstants.UDM_DB, IConstants.RENEWAL_DETAILS);
		@SuppressWarnings("unchecked")
		List<Document> benefitsList = (ArrayList<Document>) benefitsObject;
		List<Document> updatedBenefitsList = new ArrayList<>();
		for (Document benefitDocument : benefitsList) {
			Document updatedBenefitDocument = new Document();
			addToDocument(memberSummaryBenefits, benefitDocument, "memberSummaryBenefitsGBD", updatedBenefitDocument);
			updatedBenefitDocument.append("currentContractPlanCode", "");
			updatedBenefitsList.add(updatedBenefitDocument);

		}
		summaryDoc.append("renewalSummary", updatedBenefitsList);
		convertCalFields(summaryDoc, sourceDb, sourceColl[1], IConstants.UDM_DB);
		
		MongoConnector.getInstance().addGrpDelta(summaryDoc);
		summaryDoc.append(IConstants.PLAN, IConstants.MED);
		
		docSummaryList.add(summaryDoc);
		try {

			MongoConnector.getInstance().removePreviousDocuments(targetDb, targetCollection, targetDetailCollection,
					IConstants.SDSREN_DB, summaryDoc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		MongoConnector.getInstance().insertData(docDetailList, targetDb, targetDetailCollection, IConstants.SDSREN_DB);
		MongoConnector.getInstance().insertData(docSummaryList, targetDb, targetCollection, IConstants.SDSREN_DB);
		MongoConnector.getInstance().updateStatus(sourceDb, sourceColl[0], bsonFilter, IConstants.UDM_DB);
		return null;
	}

	private void convertCalFields(Document summaryDoc, String sourceDb, String sourceCollection, String udmDb) {

		double currPrem = 0.0, monPrem = 0.0;
		Document d = null;
		try {
			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
					sourceCollection, udmDb);
			/* BPP-31928 : Not getting latest record , added Un-processed status */
			d = collcheck.find(new Document("ID", summaryDoc.getString("ID")).append(IConstants.END_DATE_FIELD,
					IConstants.MAX_DATE)).first();
			if (d.containsKey(IConstants.CURR_MON_PREMIUM))
				currPrem = Double.parseDouble(d.get(IConstants.CURR_MON_PREMIUM).toString());
			if (d.containsKey(IConstants.MON_PREM))
				monPrem = Double.parseDouble(d.get(IConstants.MON_PREM).toString());
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		summaryDoc.append(IConstants.CURR_MON_PREMIUM, currPrem);
		summaryDoc.append(IConstants.MON_PREM, monPrem);

	}

	private void addToDocument(ProcessFieldNames processFieldNames, Tuple2<Object, BSONObject> bsonFilter,
			String mappingName, Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

		}

	}

	private void addToDocument(ProcessFieldNames processFieldNames, Document bsonFilter, String mappingName,
			Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)))) {
				if ("ProductType".equalsIgnoreCase(fieldNames)
						&& "M".equalsIgnoreCase(bsonFilter
								.get(ReadMappingXmlSingleton.getInstance().getRead()
										.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))
								.toString())) {
					document.append(fieldNames, "MSUP");
				} else if ("renewalProducts".equalsIgnoreCase(fieldNames)) {
					List<Document> renewalProducts = processRenewalProducts(
							bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
									.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)),
							bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
									.getAttributeValueOfField(mappingName, "currentContractPlanName", IConstants.VALUE))
									.toString());
					document.append(fieldNames, renewalProducts);
				} else
					document.append(fieldNames, bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));
			}

		}

	}


	private List<Document> processRenewalProducts(Object object, String planName) {
		List<Document> modifiedDocuments = new ArrayList<>();
		for (Document d : (List<Document>) object) {
			d.append("contractPlanCode", "");
			d.append("renewalContractPlanName", planName);
			modifiedDocuments.add(d);
		}

		return modifiedDocuments;
	}

	public List<Document> getGrpRenewalProducts(String sourceCollection, Document outerDoc, Document summaryDoc) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance().getPropertyContext(
					IConstants.ISG_REN.concat(IConstants.RENEWAL_PRODUCTS).concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}
			double monPrem = 0.0, currMonPrem = 0.0;
			if (doc.containsKey(IConstants.RENEWAL_MONTHLY_PREMIUM)) {
				monPrem = doc.getDouble(IConstants.RENEWAL_MONTHLY_PREMIUM);
				doc.remove(IConstants.RENEWAL_MONTHLY_PREMIUM);
			}
			if (outerDoc.containsKey(IConstants.CURR_MON_PREMIUM)) {
				currMonPrem = outerDoc.getDouble(IConstants.CURR_MON_PREMIUM);
				outerDoc.remove(IConstants.CURR_MON_PREMIUM);
			}
			summaryDoc.append(IConstants.CURR_MON_PREMIUM, currMonPrem);
			summaryDoc.append(IConstants.MON_PREM, monPrem);
			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceColl, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String sourceDbTDM) {
		return null;
	}
	
}