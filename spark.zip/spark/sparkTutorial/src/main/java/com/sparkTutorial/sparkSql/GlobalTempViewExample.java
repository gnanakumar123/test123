package com.sparkTutorial.sparkSql;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.sql.AnalysisException;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class GlobalTempViewExample {
	public static void main(String[] args) {
		Logger.getLogger("org").setLevel(Level.ERROR);

		// Create a Spark Session
		SparkSession session = SparkSession.builder().appName("JsonSQLProblems").master("local[1]").getOrCreate();
		
		// Load the data from JSON file
		Dataset<Row> names = session.read().json("in/members.json");
		
		try {
			// Create a Global Temp View
			names.createGlobalTempView("members");
			
			// Execute the Query
			session.sql("select * from global_temp.members").show();
			
			session.sql("select * from global_temp.members where age < 50").show();
			
		} catch (AnalysisException e) {
			e.printStackTrace();
		}
		
	}
}
