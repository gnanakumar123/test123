package com.anthem.marketplace.dataconsolidation.utils;

/*
 * This class creates constant variables to be used in other classes
 */

public final class IConstants {

	public static final String SOURCE_DB = "sourceDB";
	public static final String SOURCE_COLLECTION = "sourceCollection";
	public static final String ERROR_PREPEND = "Error{}";
	public static final String REJECT_COLLECTION = "DQ_Reject";
	public static final String TARGET_DB = "targetDB";
	public static final String TARGET_COLLECTION = "targetCollection";
	public static final String TARGET_DETAIL_COLLECTION = "targetDetailCollection";
	public static final String SOURCE_PATH = "sourcePath";
	public static final String TYPE = "type";
	public static final String FAILED = "failed";
	public static final String PASSED = "passed";
	public static final String GUID = "GUID";
	public static final String START = ".start";
	public static final String END = ".end";
	public static final String SOURCE_PATH_FIELD = "source-path";
	public static final String REVERSE_SOURCE_PATH_FIELD = "reverse-source-path";
	public static final String STATUS_FIELD = "status";
	public static final String START_DATE_FIELD = "start-date";
	public static final String END_DATE_FIELD = "end-date";
	public static final String SOURCE_FIELD = "source";
	public static final String VERSION_FIELD = "Version";
	public static final String DQC_FIELD = "Data_Quality_Check";
	public static final String PROCESSED = "processed";
	public static final String UNPROCESSED = "un-processed";
	public static final String MAX_DATE = "9999-12-31 00:00:00:000";
	public static final String MONGO_INPUT_FORMAT_KEY = "mongo.job.input.format";
	public static final String MONGO_INPUT_FORMAT_VALUE = "com.mongodb.hadoop.MongoInputFormat";
	public static final String MONGO_AUTH_URI = "mongo.auth.uri";
	public static final String MONGO_INPUT_URI = "mongo.input.uri";
	public static final String ID = "_id";
	public static final String ARCHIVE = "/archive/";
	public static final String SPLIT_PIPE = "\\|";
	public static final String PIPE = "|"; // VA Chips Changes
	public static final String SPLIT_COMMA = "\\,";
	public static final String SPLIT_DOT = "\\.";
	public static final String REPLACE_COLON = ":";
	public static final String REPLACE_DASH = "-";
	public static final String VERSION = "V1";
	public static final String LETTER_V = "V";
	public static final String STRING_TRUE = "true";
	public static final String STRING_FALSE = "false";
	public static final String REQUIRED_ATTRIBUTE = "required";
	public static final String SUMMARY_ATTRIBUTE = "summary";
	public static final String ZONED_ATTRIBUTE = "zoned";
	public static final String REFERENCE = "reference";
	private static final String[] METADATA = { IConstants.START_DATE_FIELD, IConstants.END_DATE_FIELD,
			IConstants.SOURCE_PATH_FIELD, IConstants.SOURCE_FIELD, IConstants.VERSION_FIELD, IConstants.STATUS_FIELD,
			IConstants.DQC_FIELD };

	
	//public static final String DETAIL_REFERENCE = "Producers";
	public static final String VALUE = "value";
	public static final String CHECK_AMOUNT = "check_amount";
	public static final String ERROR_CODE = "Error-Code";
	public static final String ERROR_DESCRIPTION = "Error-Description";
	public static final String ERROR_COLLECTION = "ErrorCollection";
	public static final String NULL_ERROR_CODE = "1001";
	public static final String ARRAY_EEROR_CODE = "2001";
	public static final String NUMBER_CONVERSION_ERROR_CODE = "7001";
	public static final String CAST_ERROR_CODE = "4001";
	public static final String GENERIC_ERROR_CODE = "6001";
	public static final String GUID_ERROR_METHOD = "creating guid.";
	public static final String DATA_QUALITY_CHECK = "data quality check.";
	public static final String RAW_DATA = "creating raw document.";
	public static final String CREATING_VALUE = "converting value to proper type.";
	public static final String DATA = "Data";
	public static final String DATA_QUALITY_ERROR_CHECK="Null value occurred at Data Quality Check";
	public static final Object DUPLICATE = "Duplicate Value";
	public static final String DATE = "DATE";
	public static final String COMMA = ",";
	
	public static final String REN_ID = "ID";
	public static final String RENEWAL_DETAILS = "Benefits";
	public static final String FACETS_ANTHEM_REN_DET = "FACETS_ANTHEMBenefits";
	public static final String RETAIN_COMMA=",(?=([^\"]*\"[^\"]*\")*[^\"]*$)";
	public static final String INVERTED_COMMA = "\"";
	public static final String BLANK = "";
	public static final String DATATYPE = "dataType";
    public static final String PROD_TYPE = "prodType";    
	public static final String MEDICAL = "medical";
	public static final String DENTAL = "dental";
	public static final String ISG_REN_DET = "ISG_RENEWALSBenefits";
	
	public static final String ISG_REN = "ISG_RENEWALS";
	public static final String ISG_ACA = "ISG(ACA)";
	public static final String FACETS_ANTHEM = "FACETS_ANTHEM";
	public static final String FACETS_U65 = "FACETS(U65)";
	public static final String FACETS_O65 = "FACETS(O65)";
	public static final String WSGRS_RENEWALS = "WSGRS_RENEWALS";
	public static final String ISG_NONACA = "Renewals_ISG_NONACA";
	public static final String RENEWALS_ISG_NONACA_NE = "Renewals_ISG_NONACA_NE";
	public static final String ISGNONACA = "ISG(NON ACA)";
	public static final String WSGRS = "WSGRS";
	public static final String GBD_FACETS = "Renewals_FACETS_GBD";
	public static final String FACETS_GBD = "FACETS GBD";
	public static final String GBD_FACETS_TYPE = "facets_GBD";
	
	public static final String DENWRITINGTINENC = "DEN_WRITING_TIN_ENCRYPT";
	public static final String MEDWRITINGTINENC = "MED_WRITING_TIN_ENCRYPT";
	public static final String VISWRITINGTINENC = "VIS_WRITING_TIN_ENCRYPT";  //BPP-34001 ISGACA Vision Renewals
	//public static final String PDWRITINGTINENC = "PD_WRITING_TIN_ENCRYPT";
		
	public static final String DENPARENTTINENC = "DEN_PARENT_TIN_ENCRYPT";
	public static final String MEDPARENTTINENC = "MED_PARENT_TIN_ENCRYPT";
	
	public static final String DENPAIDTINENC = "DEN_PAID_TIN_ENCRYPT";
	public static final String MEDPAIDTINENC = "MED_PAID_TIN_ENCRYPT";
	
	public static final String MEDWRITINGTIN = "MED_MBR_RTNG_TIER";
	public static final String DENWRITINGTIN = "DEN_MBR_RTNG_TIER";
	public static final String PDWRITINGTIN = "PD_MBR_RTNG_TIER";
	
	public static final String ADDR_TYPE = "addrType";
	public static final String CLIENT_CONTACTS = "contacts";
	public static final String CLIENT_AGENT = "agents";
	public static final String CLIENT_MEMBER = "Client_Member";
	
	public static final String DEFAULT = "default";
	public static final String RECORD_TYPE_REN = "Record_type";
	public static final String HCID = "HCID";
	public static final String TAX_ID_TYPE = "taxIDType";
	public static final String PRODUCT = "product";
	public static final String STATEMENT_ID = "statementID";
	public static final String ARRAY_CLUSTER_IPADDRESS = "ArrayClusterIPAddress"; 
	public static final String ARRAY_CLUSTER_PORTS = "ArrayClusterPorts";
	public static final String ArrayClusterUserName = "ArrayClusterUserName";
	public static final String ArrayClusterPassWord = "ArrayClusterPassWord";
	public static final String CONF_AUTH_FLAG = "AuthenticationCheck";
	public static final String REPLICA_SET_VALUE="ReplicaSetValue";
	public static final String REPLICA_SET="ReplicaSet";
	public static final String CLIENT_RENEWAL = "renewals";
	public static final String GROUP_ID1 = "GroupID1";
	
	public static final String ISG_NONACA_REN_DET = "Renewals_ISG_NONACABenefits"; 
	public static final String ISG_NONACA_NE_REN_DET = "Renewals_ISG_NONACA_NEBenefits"; 
	public static final String HADOOP_FILESYSTEM = "HadoopFileSystem";
	public static final String HADOOP_URI = "HadoopUri";
	public static final String PRODUCT_TYPE = "productType";
	public static final String ARRAYFIELDNAMES = ".ArrayFieldNames";
	public static final String GUID_FIELD=".Guid";
	public static final String UID_FIELD = ".Uid";
	public static final String STR_TYPE_PATH = "com.anthem.marketplace.dataconsolidation.filesutils.";
	public static final String SPARK_CONF_FLAG = "SparkConfFlag";
	public static final String CACHE_DB_NAME= "CacheDBName";
	public static final String CACHE_COLLECTION_NAME= "CacheCollectionName";
	

	public static final String APP_NAME="AppName";
	public static final String SPARK_MASTER="SparkMaster";
	public static final String EXECUTOR_MEMORY="ExecutorMemory";
	public static final String DRIVER_MEMORY="DriverMemory";
	public static final String JAR_NAME="JarName";

	public static final String RDM_DB="RDM";
	public static final String TDM_DB="TDM";
	public static final String UDM_DB="UDM";
	public static final String SDSCOMM_DB="SDSCOMM";
	public static final String SDSREN_DB ="SDSREN";
	
	public static final String MEDBROKERWRITINGTIN = "medBrokerWritingTin";
	public static final String DENBROKERWRITINGTIN = "denBrokerWritingTin";
	
	public static final String BENEFITS = "Benefits";
	public static final String EMPLOYEE="Employee";
	public static final String EMPLOYEE_RENEWAL="EmployeeRenewal";
	public static final String DEPENDENT="Dependent";
	public static final String DEPENDENT_RENEWAL="DependentRenewal";
	public static final String WSGRS_DETAIL_MEM_INFO="Renewals_WSGRS_Detail_MemInfo";
	public static final String SUBSCRIBER_ID="Subscriber_ID";
	public static final String WSGRS_DETAIL_GROUP_INFO_EMP_DEPENDENT="WSGRS_Detail_GroupInfoEmployeeDependent";
	public static final String MMBR_RELATIONSHIP="Mmbr_Relationship";
	public static final String MEMBER_ID="Member_ID";
	public static final String RENEWAL_PRODUCTS="renewalProducts";
	public static final String WSGRS_RENEWALS_GRP_REN_PRODS="WSGRS_RENEWALSGrouprenewalProducts";
	public static final String WSGRS_RENEWALS_MEM_REN_PRODS="WSGRS_RENEWALSMemrenewalProducts";
	public static final String WSGRS_RENEWALS_GRP_INFO_EMP="WSGRS_Detail_GroupInfoEmployee";
	public static final String WSGRS_RENEWALS_MEM_BEN="WSGRS_RENEWALSMemBenefits";
	public static final String WSGRS_RENEWALS_GRP_BEN="WSGRS_RENEWALSGroupBenefits";
	public static final String WSGRS_RENEWALS_GRP_INFO_EMP_CON="WSGRS_Detail_GroupInfoEmployeecontacts";
	public static final String WSGRS_RENEWALS_GRP_INFO_EMP_DEP_CON="WSGRS_Detail_GroupInfoEmployeeDependentcontacts";
	public static final String SCRBR="SCRBR";
	public static final String STATE_CODE="stateCode";
	public static final String ADDRESS_TYPE="addressType";
	public static final String AGENT_TAX_ID="Agent_TaxID";
	public static final String AGENCY_TAX_ID="Agency_TaxID";
	public static final String GEN_AGENCY_TAX_ID="Gen_Agency_TaxID";
	public static final String GROUP_ID = "groupID";
	
	public static final String PLAN = "plan";
	public static final String MED = "MED";
	public static final String BENEFITTYPE = "benefitType";
	public static final String CURRENTPRODUCTS = "currentProducts";
	public static final String PROD_ID1 = "Prod_ID1";
	public static final String TOTAL = "total";
	public static final String CURR_MON_PREM = "Current_Monthly_Prem";
	public static final String CURR_MON_PREMIUM = "currentMonthlyPremium";
	public static final String RENEWAL_MON_PREM = "Renewal_Monthly_Premium";
	public static final String MON_PREM = "monthlyPremium";
	public static final String MODIFIED = "Modified";
	
	public static final String HOME = "Home";
	public static final String OTHER = "Other";
	public static final String WRITING = "Writing";
	public static final String PAID = "Paid";
	public static final String PARENT = "Parent";
	public static final String FULLNAME = "groupName";
	public static final String FIRSTNAME = "firstName";
	public static final String MIDDLENAME = "middleName";
	public static final String LASTNAME = "lastName";
	//public static final String WSGRS_GROUPBENINFO_COLLNAME="Renewals_WSGRS_Detail_GroupBenInfo";
	//public static final String TARGET_PROD_ID1 = "Target_Product_ID1";
	public static final String MEMBER_DETAIL = "memberDetail";
	public static final String RENEWAL_MONTHLY_PREMIUM = "renewalMonthlyPremium";
	public static final String EXCH_IND = "exchangeIndicator";
	public static final String WSGRS_GROUPINFO_COLLNAME = "Renewals_WSGRS_Detail_GroupInfo";
	public static final String CURR_CONT_PLAN_CODE = "currentContractPlanCode";
	public static final String CONTRACT_PLAN_CODE = "contractPlanCode";
	public static final String EXCHG_IND = "EXCHG_IND";
	public static final String PLAN_SBSDY = "PLAN_SBSDY";
	public static final String RENEWAL_SUBSIDY = "RENEWAL_SUBSIDY";
	
	public static final String AGENT="agent"; // BPP-24163 : ISGNONACA NE
	
	public static String SGRS="SGRS";
    public static final String PROD_ID2 = "Prod_ID2"; // Added For WSGRS
	public static final String SGRS_RENEWALS = "SGRS_RENEWALS";
	public static final String SGRS_RENEWALS_MEM_REN_PRODS="SGRS_RENEWALSMemrenewalProducts";
	public static final String SGRS_RENEWALS_MEM_BEN="sgrs_memberbeninfo";
	public static final String SGRS_RENEWALS_GRP_BEN="sgrs_groupbeninfo";
	public static final String SGRS_RENEWALS_GRP_REN_PRODS="SGRS_RENEWALSGrouprenewalProducts";
	public static final String SGRS_DETAIL_MEM_INFO="Renewals_SGRS_Detail_MemInfo";
	public static final String currentPlan = "currentPlan";
	public static final String renewalPlan = "renewalPlan";
	public static final String renewalPlanCode = "contractPlanCode";
	public static final String renewalContractPlanName = "renewalContractPlanName";
	public static final String renewalContractPlanCode = "renewalContractPlanCode";
	public static final String SGRS_RENEWALS_GRP_INFO_EMP="SGRS_Detail_GroupInfoEmployee";
	public static final String Renewals_SGRS_GroupInfo ="Renewals_SGRS_GroupInfo";
	public static final String RELATIONSHIP="relationship";
	public static final String Writing_Agent_TaxID ="Writing_Agent_TaxID";
	public static final String Parent_Agent_TaxID ="Parent_Agent_TaxID";
	public static final String CURRENT_PRODUCT_TYPE = "currentProductType";
	
	public static final String BRKRTIN ="brkrTin";
	public static final String TAX_ID = "taxID";
	
	/*Start BPP-23124,BPP-23127,BPP-23129*/
	public static final String PRODUCT_ID1 = "Product_ID1";
	public static final String CURRENT_PROD_TYPE = "Current_Prod_Type";
	public static final String LFE = "LFE";
	/*End */
	
	public static final String SSL = "SSL"; /*BPP-38521 : Implement Mongodb SSL Feature to Data Load Project */
	
	/* Start BPP-31959 */
	public static final String LOOKUP_PROD="LOOKUP_PROD";
	/* VA Renewals Chips */
	public static final String VA_RENEWALS = "Va_Renewals";
	public static final String CHIPs_RENEWAL = "chips_renewal";
	public static final String CHIPS = "Chips";
	public static final String CHIPSBENEFITS = "ChipsBenefits";
	public static final String POLICYHOLDERDATA = "policyHolderData";
	public static final String POLICYHOLDERDETAILS = "policyHolderDetails";
	public static final String SPOUSEDETAILS = "spouseDetails";
	public static final String CONTRACT = "contract";
	public static final String AGENCYINFO = "agencyInfo";
	public static final String AGENTINFO = "agentInfo";
	public static final String DEPENDENTDETAILS = "dependentDetails";
	/* VA Renewals Chips */
	
	private IConstants() {
	}

	public static String[] getMetadata() {
		return METADATA;
	}

}
