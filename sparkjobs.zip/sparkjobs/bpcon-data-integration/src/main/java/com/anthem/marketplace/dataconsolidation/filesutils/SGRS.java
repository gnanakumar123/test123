/**
 * BPP-8945 - Accomodate SGRS Small group legacy renewals
 * This class implements UtilityInterface and Serializable and performs Ingestion, Transformation of SGRS 
 * renewals input files
 */
package com.anthem.marketplace.dataconsolidation.filesutils;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.bson.BSONObject;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.utils.ChangeDataCapture;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.FixedFileMetaDataProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFixedFileMetaData;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

import scala.Tuple2;

public class SGRS implements UtilityInterface, Serializable {

	private static final long serialVersionUID = 1L;
	static final Logger logger = LoggerFactory.getLogger(SGRS.class);

	public static ArrayList<String> neglectList = new ArrayList<String>();

	@Override
	public String createGuid(String sourceCollection, String delimeted, Row readFileContent, String guidvalue,
			String type) {
		String guid = "";
		String errorFieldName = "";
		try {
			for (String item : guidvalue.split(IConstants.SPLIT_COMMA)) {
				int index = Integer.parseInt(ReadMappingXmlSingleton.getInstance().getRead().getIndex(type, item));
				guid += readFileContent.getString(index).trim();
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.SGRS, IConstants.RDM_DB);
		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.SGRS, IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.SGRS, IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.SGRS, IConstants.RDM_DB);
		}
		return guid;
	}

	@Override
	public boolean createFlag(String delimeted, String sourceCollection, Row readFileContent, String type) {
		boolean flag = false;
		String errorFieldName = "";
		try {
			// determine which files are mandatory from mapping.xml based on
			// type supplied
			Map<String, String> mandatoryFields = ReadMappingXmlSingleton.getInstance().getRead()
					.getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);
			for (String item : mandatoryFields.keySet()) {
				errorFieldName = item;
				// check if mandatoryFields available in input content file
				flag = readFileContent.getString(Integer.parseInt(item)) == null
						|| ("".equals(readFileContent.getString(Integer.parseInt(item))));
				if (flag)
					break;
			}
			
			// if false then set error as null value found for mandatory fields.
			if (flag) {
				Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
						IConstants.DATA_QUALITY_ERROR_CHECK, readFileContent.toString(), errorFieldName,
						IConstants.SGRS, IConstants.RDM_DB);
			}

		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.SGRS, IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.SGRS, IConstants.RDM_DB);
		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.SGRS, IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.SGRS, IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.SGRS, IConstants.RDM_DB);
		}
		return flag;
	}

	@Override
	public Document appendRaw(ProcessInput processInput, String sourcePath, String guid, boolean flag,
			Row readFileContent) {
		String type = processInput.getType();
		String sourceDB = processInput.getSourceDB();
		String sourceCollection = processInput.getSourceCollection();
		boolean checkFlag = false;
		ProcessFieldNames procFieldNames;
		String value;
		Document doc = new Document();
		String errorFieldName = "";
		try {
			procFieldNames = FieldNamesProperties.getInstance().getPropertyContext(type);
			doc.append(IConstants.GUID, guid);
			//System.out.println("Type:::::::::::::"+type);

			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
				errorFieldName = fieldNames;
				// get dataType from mapping.xml for specified field.
				//System.out.println("error field names:    "+fieldNames);
				String dataType = ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(type,
						fieldNames, IConstants.DATATYPE);
				//System.out.println("dataType field names:    "+dataType);
				value = readFileContent
						.getString(Integer
								.parseInt(ReadMappingXmlSingleton.getInstance().getRead().getIndex(type, fieldNames)))
						.trim().replace(IConstants.INVERTED_COMMA, IConstants.BLANK);
				// change dataType of fields and convert zonal fields to zonal
				// decimal number
				System.out.println("field names::::::::::::"+fieldNames+"::::::::::Value:::::::::"+value);
				checkFlag = Utility.applyZone(sourceCollection, fieldNames, value.trim(), doc, dataType,
						readFileContent, IConstants.SGRS);
				if (checkFlag)
					flag = true;
			}
			
			if (sourceCollection.equals(IConstants.Renewals_SGRS_GroupInfo)) {
				//doc.append("type", "SG");
				System.out.println("State:::::::::::::::::"+doc.getString("State_CD"));
				if(doc.getString("State_CD") != null && 
						! doc.getString("State_CD").equalsIgnoreCase("VA")){
					doc.append("type", "SG");
				}else{
					doc.append("type", "LG");
				}
				doc.append("relationship", "GROUP");
			} else {
				doc.append("type", "EMP");
				doc.append("relationship", "SUBSCR");
			}

			Utility.insertMetadata(doc, sourceDB, sourceCollection, guid, sourcePath, IConstants.SGRS_RENEWALS, flag,
					true, IConstants.RDM_DB);

			// catch Exceptions and add respective errorCode and its description
		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.SGRS, IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.SGRS, IConstants.RDM_DB);
		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.SGRS, IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.RAW_DATA,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.SGRS, IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.SGRS, IConstants.RDM_DB);
		}
		return doc;
	}

	@Override
	public Document ingestTDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String appendedCollection) {
		int year =0;
		Document doc = null;
		String sourcePath = "";
		boolean flag = true;
		String groupID = "";
		FindIterable<Document> iterableMemInfo = null;
		FindIterable<Document> iterableGroupBenInfo = null;
		FindIterable<Document> iterableMemBenInfo = null;
		
		try {
			doc = new Document();
			sourcePath = checkNullReturnBlank(bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD));
			year = Calendar.getInstance().get(Calendar.YEAR);
			groupID = checkNullReturnBlank(bsonFilter._2.get(IConstants.GROUP_ID1));
			
			doc.append("_id", bsonFilter._2.get("_id"));
			doc.append("GUID", checkNullReturnBlank(bsonFilter._2.get("GUID")));
			doc.append("ID", checkNullReturnBlank(bsonFilter._2.get(IConstants.GROUP_ID1)));
			doc.append("type",  checkNullReturnBlank(bsonFilter._2.get("type")));
					
	
			String agentTaxID, agencyTaxID, genAgencyTaxID;
			agentTaxID = checkNullReturnBlank(bsonFilter._2.get("Writing_Agent_TaxID"));
			agencyTaxID = checkNullReturnBlank(bsonFilter._2.get("Parent_Agent_TaxID"));
			genAgencyTaxID = checkNullReturnBlank(bsonFilter._2.get(IConstants.GEN_AGENCY_TAX_ID));
			
			/*BPP-23960  & BPP-24151*/
			if(agencyTaxID == null || agencyTaxID.length() ==0){
				if(agentTaxID !=null && agentTaxID.length() > 0){
					agencyTaxID = agentTaxID;
				}
			}
			
			if(genAgencyTaxID == null || genAgencyTaxID.length() ==0){
				if(agencyTaxID !=null && agencyTaxID.length() >0){
					genAgencyTaxID = agencyTaxID;
				}
			}
			
			doc.append("renewalDate", bsonFilter._2.get("Group_RenewalDT"));
			doc.append("effectiveDate", bsonFilter._2.get("Group_RenewalDT"));
			
			doc.append("source-path", checkNullReturnBlank(bsonFilter._2.get("source-path")));
			doc.append("source", checkNullReturnBlank(bsonFilter._2.get("source")));
			doc.append("Version", checkNullReturnBlank(bsonFilter._2.get("Version")));
			doc.append("status", checkNullReturnBlank(bsonFilter._2.get("status")));
			doc.append("Data_Quality_Check", checkNullReturnBlank(bsonFilter._2.get("Data_Quality_Check")));
			
			
			if (targetCollection.contains("Renewals_tdm_Client")) {
				doc.append("sourceID",  "ISG");
				doc.append("groupID", checkNullReturnBlank(bsonFilter._2.get("GroupID1")));
				doc.append("name", checkNullReturnBlank(bsonFilter._2.get("Group_Name")));
				doc.append("billingEntity",checkNullReturnBlank(bsonFilter._2.get(IConstants.GROUP_ID1)));
				doc.append("SIC", checkNullReturnBlank(bsonFilter._2.get("SIC")));
				doc.append("underwriterID", checkNullReturnBlank(bsonFilter._2.get("rating_area")));
				doc.append("relationship", checkNullReturnBlank(bsonFilter._2.get("relationship")));
				doc.append("exchangeIndicator", checkNullReturnBlank(bsonFilter._2.get("OnExchangeInd")));
				doc.append("contactName", checkNullReturnBlank(bsonFilter._2.get("Group_Name")));
				//Association_CD
				doc.append("associationCode", checkNullReturnBlank(bsonFilter._2.get("Association_CD")));
				doc.append("associationName", checkNullReturnBlank(bsonFilter._2.get("Association_Name")));
				
				//Employee
				List<Document> employeeList = new ArrayList<>();
				
				iterableMemInfo = MongoConnector.getInstance().getAllRenewalDocument(IConstants.GROUP_ID1, bsonFilter._2.get(IConstants.GROUP_ID1).toString(),
						sourceDb,appendedCollection.split(IConstants.COMMA)[3], IConstants.RDM_DB);
				for (Document documentMemInfo : iterableMemInfo) {
					Document individualEmployeeList = new Document();
					individualEmployeeList.append("subscriberID", checkNullReturnBlank(documentMemInfo.get("Subscriber_ID")));
					individualEmployeeList.append("relationship",checkNullReturnBlank(documentMemInfo.get("relationship")));
					
					String strName = checkNullReturnBlank(documentMemInfo.get("Mmbr_Name"));
					String[] strArrayValue = strName.split(",");
					if(strArrayValue != null && strArrayValue.length > 0){
						individualEmployeeList.append("firstName",strArrayValue[1]);
						individualEmployeeList.append("lastName",strArrayValue[0]);
					}else{
						individualEmployeeList.append("firstName","");
						individualEmployeeList.append("lastName","");
					}
										
					individualEmployeeList.append("age",documentMemInfo.get("age"));
					
					List<Document> dependantList = new ArrayList<>();
					individualEmployeeList.append("Dependent",dependantList);
					employeeList.add(individualEmployeeList);
					
				}								
				doc.append("Employee", employeeList);
				//Contacts
				List<Document> contactLists = new ArrayList<>();
				Document contactList = new Document();
				contactList.append("addressType","service");
				contactList.append("stateCode", checkNullReturnBlank(bsonFilter._2.get("State_CD")));
				contactList.append("stateName", checkNullReturnBlank(bsonFilter._2.get("State_CD")));
				contactLists.add(contactList);
				doc.append("contacts", contactLists);
				//agents
				List<Document> agentsList = new ArrayList<>();
				agentsList.add(appendContacts(targetDb,agentTaxID,"Paid"));
				agentsList.add(appendContacts(targetDb,agencyTaxID,"Parent"));
				agentsList.add(appendContacts(targetDb,genAgencyTaxID,"Writing"));
				doc.append("agents", agentsList);
				
				//Renewals
				Document renewalDoc = new Document();
				renewalDoc.append("renewalPeriod", year);
				renewalDoc.append("renewalReference", checkNullReturnBlank(bsonFilter._2.get("GUID")));				
				doc.append("renewals", renewalDoc);
								
			}else{
				doc.append("currentMonthlyPremium", checkNullReturnBlank(bsonFilter._2.get("current_premium")));
				doc.append("monthlyPremium", checkNullReturnBlank(bsonFilter._2.get("renewal_premium")));
				
				doc.append("parentTIN", agencyTaxID);
				doc.append("payeeTIN", agentTaxID);
				doc.append("writingTIN", genAgencyTaxID);
				
				//Employee Renewals
				List<Document> employeeRenewal = new ArrayList<>();
				//Benefits
				List<Document> employeeBenefits = new ArrayList<>();
								
				List<Document> benefitList = new ArrayList<>();
				iterableMemInfo = MongoConnector.getInstance().getMemberDocument(
					IConstants.GROUP_ID1, bsonFilter._2.get(IConstants.GROUP_ID1).toString(),
					sourceDb,appendedCollection.split(IConstants.COMMA)[3], IConstants.RDM_DB);
					
				if(iterableMemInfo != null){
					Document individualEmployeeRenewal = null;
					Document benefitDocument = null;
					List<Document> benefitLists = null;
					for(Document documentMemInfo:iterableMemInfo){
						individualEmployeeRenewal = new Document();
						benefitLists = new ArrayList<>();
						individualEmployeeRenewal.append("ID", checkNullReturnBlank(documentMemInfo.get("Subscriber_ID")));
						individualEmployeeRenewal.append("Type", checkNullReturnBlank(documentMemInfo.get("type")));
						
						iterableMemBenInfo = MongoConnector.getInstance().getMemberDocument(
								IConstants.GROUP_ID1, bsonFilter._2.get(IConstants.GROUP_ID1).toString(),
								"Subscriber_ID",documentMemInfo.getString("Subscriber_ID").toString(),
								sourceDb,appendedCollection.split(IConstants.COMMA)[2], IConstants.RDM_DB);
						for(Document documentMemBenInfo:iterableMemBenInfo){		
							benefitDocument = new Document();

							List<Document> renewalProductList = new ArrayList<>();
							Document renewalProducts = new Document();
							renewalProducts.append("monthlyPremium", checkNullReturnBlank(documentMemBenInfo.get("Renewal_Monthly_Premium")));
							renewalProducts.append("ratingMethod", "MEMBER");
							renewalProductList.add(renewalProducts);
							benefitDocument.append("renewalProducts",renewalProductList);
							
							benefitDocument.append("enrollmentType",checkNullReturnBlank(documentMemBenInfo.get("Enrollment_Type")));
							benefitDocument.append("currentContractPlanCode",checkNullReturnBlank(documentMemBenInfo.get("currentPlanCode")));
							benefitDocument.append("currentMonthlyPremium",checkNullReturnBlank(documentMemBenInfo.get("Current_Monthly_Prem")));
							
							FindIterable<Document> iterableLocalGroupBenInfo = MongoConnector.getInstance().getMemberDocument(
									IConstants.GROUP_ID1, bsonFilter._2.get(IConstants.GROUP_ID1).toString(),
									"currentPlanCode",documentMemBenInfo.getString("currentPlanCode").toString(),
									sourceDb,appendedCollection.split(IConstants.COMMA)[0], IConstants.RDM_DB);
							
							for(Document documentLocalGroupBenInfo:iterableLocalGroupBenInfo){	
								benefitDocument.append("renewalContractPlanName",checkNullReturnBlank(documentLocalGroupBenInfo.get("renewalPlan")));
							}
							List<Document> dependantRenewal = new ArrayList<>();
							benefitDocument.append("DependentRenewal", dependantRenewal);
							
							benefitLists.add(benefitDocument);
							
						}
						
						individualEmployeeRenewal.append("Benefits", benefitLists);
						benefitList.add(individualEmployeeRenewal);
					}
				}
	
				doc.append("EmployeeRenewal", benefitList);
				
				//Group Benefits		
				iterableGroupBenInfo = MongoConnector.getInstance().getAllRenewalDocument(IConstants.GROUP_ID1, bsonFilter._2.get(IConstants.GROUP_ID1).toString(),
						sourceDb,appendedCollection.split(IConstants.COMMA)[0], IConstants.RDM_DB);
				
				for(Document documentGroupBenInfo:iterableGroupBenInfo){
					Document individualBenefits = new Document();
					individualBenefits.append("productType", checkNullReturnBlank(documentGroupBenInfo.get("currentProductType")).toUpperCase());
					individualBenefits.append("enrollmentType",checkNullReturnBlank(documentGroupBenInfo.get("type")));
					individualBenefits.append("currentContractPlanCode", checkNullReturnBlank(documentGroupBenInfo.get("currentPlanCode")));
					individualBenefits.append("currentContractPlanName", checkNullReturnBlank(documentGroupBenInfo.get("currentPlan")));
					individualBenefits.append("renewalDate", documentGroupBenInfo.get("Group_RenewalDT"));
					individualBenefits.append("currentRatingMethod","MEMBER");
					individualBenefits.append("currentMonthlyPremium", checkNullReturnBlank(documentGroupBenInfo.get("Current_Monthly_Premium")));
					List<Document> renewalProductList = new ArrayList<>();
					Document renewalProducts = new Document();
					renewalProducts.append("monthlyPremium", checkNullReturnBlank(documentGroupBenInfo.get("Renewal_Monthly_Premium")));
					renewalProducts.append("contractPlanCode", checkNullReturnBlank(documentGroupBenInfo.get("renewalPlanCode")));
					renewalProducts.append("productType", checkNullReturnBlank(documentGroupBenInfo.get("currentProductType")).toUpperCase());
					renewalProducts.append("enrollmentType",checkNullReturnBlank(documentGroupBenInfo.get("type")));
					renewalProducts.append("renewalContractPlanName", checkNullReturnBlank(documentGroupBenInfo.get("renewalPlan")));
					renewalProducts.append("ratingMethod","MEMBER");
					renewalProductList.add(renewalProducts);
					individualBenefits.append("renewalProducts", renewalProductList);
					employeeBenefits.add(individualBenefits);
				}				
				//Benefits
				doc.append("Benefits", employeeBenefits);
			}
			
			
			flag = false;
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		String guid = doc.get(IConstants.GUID).toString();
		Utility.insertMetadata(doc, targetDb, targetCollection, guid, sourcePath, IConstants.SGRS_RENEWALS, flag, true,
				IConstants.TDM_DB);
		return doc;

		
	}

	@Override
	public Document ingestUDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection) {
		Document document = new Document();
		try {
			document.putAll(bsonFilter._2.toMap());
			document.remove(IConstants.ID);
		} catch (Exception e) {
			logger.error("Exception:  " + e);
		}
		return document;
	}

	@Override
	public void ingestRDMprocess(ProcessInput processInput, String sourcePath, String guidvalue, String strType) {
		List<Document> detailList = new ArrayList<>();
		List<Document> failedList = new ArrayList<>();

		String typ = processInput.getType();
		String sourceCollection = processInput.getSourceCollection();
		String delimeted = processInput.getDelimeted();
		String delimeter = processInput.getDelimeter();
		String sourceDB = processInput.getSourceDB();
		String failedCollection = processInput.getFailedCollection();
		JavaSparkContext scIngest = SparkContextSingleton.getInstance().getSparkContext();
		JavaRDD<String> filePartition = scIngest.textFile(sourcePath, 4);
		filePartition.count();
		JavaRDD<Row> readFile = filePartition.map(record -> RowFactory.create((Object[]) record.split(delimeter, -1)));

		readFile.foreachPartition(partitionIterator -> {

			ProcessInput process = new ProcessInput(sourceDB, sourceCollection, typ, delimeter, delimeted,
					failedCollection);
			partitionIterator.forEachRemaining(readFileContent -> {
				String type = process.getType();
				String guid = this.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
				boolean flag = this.createFlag(delimeted, sourceCollection, readFileContent, type);
				Document doc = this.appendRaw(process, sourcePath, guid, flag, readFileContent);
				ChangeDataCapture cdc = new ChangeDataCapture();
				cdc.implementSGRSCdc(sourceDB, sourceCollection, doc, detailList, failedList, IConstants.RDM_DB);
			});

			MongoConnector.getInstance().insertData(detailList, sourceDB, sourceCollection, IConstants.RDM_DB);
			MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
		});

	}

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceColl, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String sourceDbTDM) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceColl, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String sourceDbTDM, ProcessInput processInput) {
		// TODO Implement this method
		Document renewalDetailsDoc = new Document();
		Document renewalSummaryDoc = new Document();
		ProcessFieldNames groupSummaryBenefits = null;
		
		List<Document> docSummaryList = new ArrayList<>();
		List<Document> docDetailsList = new ArrayList<>();
		
		try{
			//Renewal Summary Collection
			groupSummaryBenefits = FieldNamesProperties.getInstance().getPropertyContext("sgrsGroupSummaryBenefits");
			renewalSummaryDoc.append("source-path", checkNullReturnBlank(bsonFilter._2.get("source-path")));
			renewalSummaryDoc.append("source", checkNullReturnBlank(bsonFilter._2.get("source")));
			renewalSummaryDoc.append("Version", checkNullReturnBlank(bsonFilter._2.get("Version")));
			renewalSummaryDoc.append("status", checkNullReturnBlank(bsonFilter._2.get("status")));
			renewalSummaryDoc.append("Data_Quality_Check", checkNullReturnBlank(bsonFilter._2.get("Data_Quality_Check")));
			
			renewalSummaryDoc.append("_id",bsonFilter._2.get("_id"));
			renewalSummaryDoc.append("ID",checkNullReturnBlank(bsonFilter._2.get("ID")));
			renewalSummaryDoc.append("renewalDate",bsonFilter._2.get("renewalDate"));
			renewalSummaryDoc.append("groupID",checkNullReturnBlank(bsonFilter._2.get("groupID")));
			renewalSummaryDoc.append("type",checkNullReturnBlank(bsonFilter._2.get("type")));
			renewalSummaryDoc.append("sourceID",checkNullReturnBlank(bsonFilter._2.get("sourceID")));
			
			renewalSummaryDoc.append("effectiveDate",bsonFilter._2.get("effectiveDate"));
			renewalSummaryDoc.append("SIC",checkNullReturnBlank(bsonFilter._2.get("SIC")));
			renewalSummaryDoc.append("agents",bsonFilter._2.get("agents"));
			renewalSummaryDoc.append("contacts",bsonFilter._2.get("contacts"));
			
			renewalSummaryDoc.append("start-date",bsonFilter._2.get("start-date"));
			renewalSummaryDoc.append("end-date",checkNullReturnBlank(bsonFilter._2.get("end-date")));
			renewalSummaryDoc.append("exchangeIndicator",checkNullReturnBlank(bsonFilter._2.get(IConstants.EXCH_IND).equals("OF") ? "Off" : "On"));
			renewalSummaryDoc.append("groupFDocID", bsonFilter._2.get("groupID"));
			renewalSummaryDoc.append("brokerFDocID", bsonFilter._2.get("groupID"));
			
			renewalSummaryDoc.append("associationCode", bsonFilter._2.get("associationCode"));
			renewalSummaryDoc.append("associationName", bsonFilter._2.get("associationName"));
			
			int count = 0;
			if (bsonFilter._2.get(IConstants.EMPLOYEE) != null)
				count = ((BasicDBList) bsonFilter._2.get(IConstants.EMPLOYEE)).size();
			renewalSummaryDoc.append("employeeCount", count);
			
			//"RAW",sourceDb
			MongoCollection<Document> collchecks = MongoConnector.getInstance().getCollectionDetail("RAW","Renewals_SGRS_GroupInfo", IConstants.RDM_DB);
			Document documentGroupInfo = collchecks.find(new Document(IConstants.GUID,checkNullReturnBlank(bsonFilter._2.get("GUID")))).first();
			
			renewalSummaryDoc.append("currentMonthlyPremium",Double.parseDouble(checkNullReturnZero(documentGroupInfo.get("current_premium"))));
			renewalSummaryDoc.append("monthlyPremium",Double.parseDouble(checkNullReturnZero(documentGroupInfo.get("renewal_premium"))));
			renewalSummaryDoc.append("groupName",checkNullReturnBlank(documentGroupInfo.get("Group_Name")));
			renewalSummaryDoc.append("size",1);
			renewalSummaryDoc.append("groupStatus",0);
			addGrpDelta(renewalSummaryDoc);
			
			
			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,sourceColl[1], IConstants.UDM_DB);
			Document documentRenewal = collcheck.find(new Document("ID", renewalSummaryDoc.getString("ID"))
					.append("source", "SGRS_RENEWALS")
					.append("status", "un-processed")
					.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE)).first();
			
			renewalSummaryDoc.append("renewalSummary",documentRenewal.get("Benefits"));
			
			//RenewalDetails Collection
			renewalDetailsDoc.append("_id",bsonFilter._2.get("_id"));
			renewalDetailsDoc.append("ID",checkNullReturnBlank(bsonFilter._2.get("ID")));
			renewalDetailsDoc.append("type",checkNullReturnBlank(documentGroupInfo.get("type")));
			renewalDetailsDoc.append("contactName",checkNullReturnBlank(documentGroupInfo.get("Group_Name")));
			
			renewalDetailsDoc.append("billingEntity",checkNullReturnBlank(bsonFilter._2.get("ID")));
			renewalDetailsDoc.append("effectiveDate",bsonFilter._2.get("effectiveDate"));
			renewalDetailsDoc.append("renewalDate",bsonFilter._2.get("renewalDate"));
			
			renewalDetailsDoc.append("underwriterID",documentGroupInfo.get("rating_area"));
			renewalDetailsDoc.append("exchangeIndicator",checkNullReturnBlank(bsonFilter._2.get(IConstants.EXCH_IND).equals("OF") ? "Off" : "On"));
			renewalDetailsDoc.append("size",count);
			renewalDetailsDoc.append("relationship",documentGroupInfo.get("relationship"));
			renewalDetailsDoc.append("groupStatus",0);
			renewalDetailsDoc.append("SIC",checkNullReturnBlank(bsonFilter._2.get("SIC")));
			renewalDetailsDoc.append("agents",bsonFilter._2.get("agents"));
			renewalDetailsDoc.append("contacts",bsonFilter._2.get("contacts"));
			renewalDetailsDoc.append("start-date",documentGroupInfo.get("start-date"));
			renewalDetailsDoc.append("end-date",documentGroupInfo.get("end-date"));
			renewalDetailsDoc.append("source-path", checkNullReturnBlank(bsonFilter._2.get("source-path")));
			renewalDetailsDoc.append("source", checkNullReturnBlank(bsonFilter._2.get("source")));
			renewalDetailsDoc.append("Version", checkNullReturnBlank(bsonFilter._2.get("Version")));
			renewalDetailsDoc.append("status", checkNullReturnBlank(bsonFilter._2.get("status")));
			renewalDetailsDoc.append("groupFDocID", checkNullReturnBlank(bsonFilter._2.get("groupID")));
			renewalDetailsDoc.append("brokerFDocID", checkNullReturnBlank(bsonFilter._2.get("groupID")));
			renewalDetailsDoc.append("Data_Quality_Check", checkNullReturnBlank(bsonFilter._2.get("Data_Quality_Check")));
			//Group
			Object benefitsObject = MongoConnector.getInstance().getRenewalDocumentSDS(renewalDetailsDoc, sourceDb, sourceColl[1],
					IConstants.UDM_DB);
			List<Document> benefitsList = (ArrayList<Document>) benefitsObject;
			benefitsObject = null;
			List<Document> updatedBenefitsList = new ArrayList<>();
			for (Document benefitDocument : benefitsList) {
				Document updatedBenefitDocument = new Document();
				addToDocument(groupSummaryBenefits, benefitDocument, "sgrsGroupSummaryBenefits", updatedBenefitDocument);
				updatedBenefitsList.add(updatedBenefitDocument);

			}
			renewalDetailsDoc.append("Benefits", listItBenefits(updatedBenefitsList));
			
			
			docDetailsList.add(renewalDetailsDoc);
			
			//Employees
			List<Document> subDocs = null;
			subDocs = getDetailDocs(bsonFilter, sourceDb, sourceColl, processInput);
			for (Document d : subDocs)
				docDetailsList.add(d);
			
			
			MongoConnector.getInstance().removePrevious(targetDb, targetCollection, "RenewalDetails",
					IConstants.SDSREN_DB, renewalSummaryDoc,IConstants.SGRS_RENEWALS);

			docSummaryList.add(renewalSummaryDoc);
			MongoConnector.getInstance().insertData(docSummaryList, targetDb, targetCollection, IConstants.SDSREN_DB);
			
			MongoConnector.getInstance().insertData(docDetailsList, targetDb, "RenewalDetails",IConstants.SDSREN_DB);
			
			MongoConnector.getInstance().updateStatus(sourceDb, sourceColl[0], bsonFilter, IConstants.UDM_DB);
			
			MongoConnector.getInstance().updateStatus(sourceDb, sourceColl[1], bsonFilter, IConstants.UDM_DB);
			
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		
		return null;
	}

	@Override
	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection,
			Tuple2<Object, BSONObject> bsonFilter, ProcessFieldNames procFieldNames, String targetDb,
			String targetCollection, String targetDetailCollection, String sourceDbTDM) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection) {
		// TODO Auto-generated method stub
		return null;
	}
	
	private String checkNullReturnBlank(Object strOriginalValue){
		if(strOriginalValue != null){
			return strOriginalValue.toString();
		}		
		return "";
	}
	
	private String checkNullReturnZero(Object strOriginalValue){
		if(strOriginalValue != null){
			return strOriginalValue.toString();
		}		
		return "0";
	}
	
	public void addGrpDelta(Document benefitDocument) {
		Double currMonPrem =0.0, diff=0.0 ;
		Double monPrem =0.0, delta =0.0;
		try{
			currMonPrem = benefitDocument.getDouble(IConstants.CURR_MON_PREMIUM);
			monPrem = benefitDocument.getDouble(IConstants.MON_PREM);
			diff = monPrem-currMonPrem;
			
			if(diff != 0.0 && currMonPrem != 0.0){
				delta = (diff/currMonPrem)*100;
			}
			benefitDocument.append("Delta", delta);
			benefitDocument.append("Difference", diff);
		
		}catch(Exception e){
			logger.error("Exception:  " + e);
		}
		
	}
	
	@SuppressWarnings("unchecked")
	private List<Document> getDetailDocs(Tuple2<Object, BSONObject> bson, String sourceDb, String[] sourceColl,
			ProcessInput processInput) {
		List<Document> subDocs = new ArrayList<>();
		ProcessFieldNames groupEmployeeDetail = null;
		Document doc = new Document();
		doc.putAll(bson._2.toMap());
		try {
			groupEmployeeDetail = FieldNamesProperties.getInstance().getPropertyContext("sgrsGroupEmployeeDetail");
			BasicDBList empDocList = (BasicDBList) doc.get(IConstants.EMPLOYEE);
			for (Object emp : empDocList) {
				
				Document empDoc = new Document();
				Document tempDoc1 = new Document();

				tempDoc1.putAll(((BasicDBObject) emp).toMap());
				addToDocument(groupEmployeeDetail, tempDoc1, "sgrsGroupEmployeeDetail", empDoc);
				
				Object empBenefits = getBenefits((Document) tempDoc1, sourceDb, sourceColl[1], IConstants.EMPLOYEE,
						doc.get("ID"), bson, sourceColl[0], processInput);
				empDoc.append(IConstants.BENEFITS, empBenefits);
				
				empDoc.append(IConstants.TYPE, "EMP");
				
				//Adding Renewal Date to Employee Level to avoid getting latest record
				System.out.println("bson before group renewal dt fetch:::::::"+bson._2);
				if (bson._2.containsField("renewalDate"))
					empDoc.append("renewalDate",bson._2.get("renewalDate"));
				
				if (bson._2.containsField(IConstants.GROUP_ID))
					empDoc.append(IConstants.GROUP_ID, bson._2.get(IConstants.GROUP_ID));
				
				empDoc.append("agents", bson._2.get("agents"));
				
				empDoc.append("contacts", bson._2.get("contacts"));
				
				empDoc.append("start-date", bson._2.get("start-date"));
				
				empDoc.append("end-date", bson._2.get("end-date"));
				
				empDoc.append("source-path", checkNullReturnBlank(bson._2.get("source-path")));
				empDoc.append("source", checkNullReturnBlank(bson._2.get("source")));
				empDoc.append("Version", checkNullReturnBlank(bson._2.get("Version")));
				empDoc.append("status", checkNullReturnBlank(bson._2.get("status")));
				empDoc.append("Data_Quality_Check", checkNullReturnBlank(bson._2.get("Data_Quality_Check")));

				Document dependDoc = new Document();
				List<Document> relatedDependentDoc = new ArrayList<>();
				relatedDependentDoc.add(dependDoc);
				empDoc.append(IConstants.DEPENDENT, relatedDependentDoc);
				subDocs.add(empDoc);
			}
		
		
		
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return subDocs;
		
	}
	
	private Document appendContacts(String targetDb,String agentTaxID,String taxIdType){
		Document individualAgentList = new Document();
		MongoCollection<Document> collcheck = null;
		Document agent = null;
		try{
			collcheck = MongoConnector.getInstance()
					.getCollectionDetail("enrollmentDB","brokerinfo", "APP");
			/*BasicDBList orList = new BasicDBList();
			orList.add(new Document("encryptedTaxId", agentTaxID));
			orList.add(new Document("starBrokerTin", agentTaxID));
			orList.add(new Document("agentTaxId", agentTaxID));
			orList.add(new Document("agentId", agentTaxID));
			orList.add(new Document("legacyAgentCode",agentTaxID));*/
			
			agent = (Document) collcheck.find(new Document("brokerIdentifier",agentTaxID)).first();
			
		
			if (agent != null && agent.getString("encryptedTin") != null) {				
				individualAgentList.append("taxID",agent.getString("encryptedTin"));
				individualAgentList.append("name", agent.getString("agentOrAgencyName"));
			}else{
					individualAgentList.append("name", "");
			}
			individualAgentList.append("agentID", agentTaxID);
			individualAgentList.append("taxIDType", taxIdType);
			individualAgentList.append("product", "default");
			
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}finally{
			collcheck = null;
			agent = null;
		}
		
		return individualAgentList;

	}
	
	private void addToDocument(ProcessFieldNames processFieldNames, Document bsonFilter, String mappingName,
			Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

		}

	}
	
	@SuppressWarnings("unchecked")
	private Object getBenefits(Document d, String sourceDb, String sourceColl, String type, Object object,
			Tuple2<Object, BSONObject> bson, String sourceColl2, ProcessInput processInput) {
		try {

			if (type.equals(IConstants.EMPLOYEE)) {
				Document query = new Document();
				Document query1 = new Document();
				Document query2 = new Document();
				Document query22 = new Document();
				Document query3 = new Document();
				query.append("$match",
						new Document("ID", object).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE));
				query1.append("$unwind", "$EmployeeRenewal");
				query2.append("$match", new Document().append("EmployeeRenewal.ID", d.get("subscriberID")));
				query3.append("$project", new Document().append(IConstants.RENEWAL_DETAILS, "$EmployeeRenewal.Benefits")
						.append("_id", 0));

				MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
						sourceColl, IConstants.UDM_DB);
				List<Document> l = new ArrayList<>();
				l.add(query);
				l.add(query1);
				l.add(query2);
				l.add(query3);

				// List pipeline;
				// Class resultClass;
				AggregateIterable<Document> ddd = collcheck.aggregate(l);
				if (ddd.first() != null) {
					Document doc = ddd.first();

					if (!doc.containsKey(IConstants.RENEWAL_DETAILS))
						return null;
					List<Document> renDetails = (List<Document>) doc.get(IConstants.RENEWAL_DETAILS);

					ProcessFieldNames groupDetailPremium = null;
					groupDetailPremium = FieldNamesProperties.getInstance().getPropertyContext("groupDetailPremium");
					List<Document> benefits = new ArrayList<>();
					for (Document renDoc : renDetails) {
						
						ArrayList<Document> renProdList = (ArrayList<Document>) renDoc.get("renewalProducts");
						Document tempDoc = renProdList.get(0);
												
						Document premiumDoc = new Document();
						List<Document> premiumDocList = new ArrayList<>();
						Document benefitDoc = new Document();
						addToDocument(groupDetailPremium, tempDoc, "groupDetailPremium", premiumDoc);
						benefitDoc.append(IConstants.BENEFITTYPE, "renewalProducts");
						benefitDoc.append("enrollmentType", renDoc.get("enrollmentType"));
						premiumDocList.add(premiumDoc);
						benefitDoc.append("premium", premiumDocList);
						benefitDoc.append("currentContractPlanCode", renDoc.get("currentContractPlanCode"));
						benefitDoc.append("currentContractPlanName", renDoc.get("Current_Prod_Name"));
						benefitDoc.append("renewalContractPlanName", renDoc.get("renewalContractPlanName"));

						try {
							MongoCollection<Document> collcheck0 = MongoConnector.getInstance()
									.getCollectionDetail(sourceDb, sourceColl, IConstants.UDM_DB);
							query.append("$match", new Document("GUID", bson._2.get("GUID"))
									.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE));
							query1.append("$unwind", "$Benefits");
							query2.append("$match", new Document().append("Benefits.currentContractPlanCode",
									renDoc.get("currentContractPlanCode")));
							query3.append("$project",
									new Document().append(IConstants.RENEWAL_DETAILS, "$Benefits").append("_id", 0));
							List<Document> l2 = new ArrayList<>();
							l2.add(query);
							l2.add(query1);
							l2.add(query2);
							l2.add(query3);
							AggregateIterable<Document> ddd0 = collcheck0.aggregate(l2);
							if (ddd0.first() != null) {
								Document doc0 = ddd0.first();
								if (!doc0.containsKey(IConstants.RENEWAL_DETAILS))
									return null;
								Document tempDoc0 = (Document) doc0.get(IConstants.RENEWAL_DETAILS);
								String productType = tempDoc0.get("productType").toString();
								//String productSubType = tempDoc0.get("productSubType").toString();
								renDoc.append("productType", productType);
								renDoc.append("enrollmentType", benefitDoc.get("enrollmentType"));
								benefitDoc.append("productType", productType);
								benefitDoc.append("currentContractPlanName", tempDoc0.get("currentContractPlanName"));
								//benefitDoc.append("enrollmentType", tempDoc0.get("enrollmentType"));
								renDoc.append("currentContractPlanName", tempDoc0.get("currentContractPlanName"));
								//renDoc.append("productSubType", productSubType);
								List<Document> renewalProd = (List<Document>) tempDoc0.get(IConstants.RENEWAL_PRODUCTS);
								if (renewalProd != null && renewalProd.size() > 0)
									benefitDoc.append("renewalContractPlanCode",
											renewalProd.get(0).get(IConstants.CONTRACT_PLAN_CODE));
								else
									benefitDoc.append("renewalContractPlanCode", "");
							}

						} catch (Exception e) {
							logger.error(IConstants.ERROR_PREPEND, e);
						}
						renDoc.append(IConstants.BENEFITTYPE, IConstants.CURRENTPRODUCTS);
						renDoc.remove("renewalProducts");
						benefits.add(renDoc);
						benefits.add(benefitDoc);

					}

					return benefits;

				}

			} else if (type.equals(IConstants.DEPENDENT)) {
				Document query = new Document();
				Document query1 = new Document();
				Document query2 = new Document();
				Document query3 = new Document();
				Document query4 = new Document();
				query.append("$match",
						new Document("ID", object).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE));
				query1.append("$unwind", "$EmployeeRenewal");
				query2.append("$unwind", "$EmployeeRenewal.DependentRenewal");

				query3.append("$match",
						new Document().append("EmployeeRenewal.DependentRenewal.ID", d.get("memberID")));// change
																											// ?
				query4.append("$project",
						new Document().append(IConstants.RENEWAL_DETAILS, "$EmployeeRenewal.DependentRenewal.Benefits")
								.append("_id", 0));

				MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
						sourceColl, IConstants.UDM_DB);

				List<Document> l = new ArrayList<>();
				l.add(query);
				l.add(query1);
				l.add(query2);
				l.add(query3);
				l.add(query4);

				AggregateIterable<Document> ddd = collcheck.aggregate(l);
				if (ddd.first() != null) {
					Document doc = ddd.first();
					List<Document> renDetails = (List<Document>) doc.get(IConstants.RENEWAL_DETAILS);
					ProcessFieldNames groupDetailPremium = null;
					groupDetailPremium = FieldNamesProperties.getInstance().getPropertyContext("groupDetailPremium");
					List<Document> benefits = new ArrayList<>();
					ArrayList<Document> renProdList = null;
					List<Document> premiumDocList = null;
					for (Document renDoc : renDetails) {
						renProdList = (ArrayList<Document>) renDoc.get("renewalProducts");
						Document tempDoc = renProdList.get(0);
						Document premiumDoc = new Document();
						premiumDocList = new ArrayList<>();
						Document benefitDoc = new Document();
						addToDocument(groupDetailPremium, tempDoc, "groupDetailPremium", premiumDoc);
						benefitDoc.append("contractPlanCode", tempDoc.getString("contractPlanCode"));
						benefitDoc.append(IConstants.BENEFITTYPE, "renewalProducts");
						premiumDocList.add(premiumDoc);
						benefitDoc.append("premium", premiumDocList);
						benefitDoc.append("currentContractPlanCode", renDoc.get("currentContractPlanCode"));
						benefitDoc.append("currentContractPlanName", renDoc.get("currentContractPlanName"));
						renDoc.append(IConstants.BENEFITTYPE, IConstants.CURRENTPRODUCTS);
						renDoc.remove("renewalProducts");
						benefits.add(renDoc);
					}
					return benefits;
				}

			}
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return null;
	}
	
	public List<Document> listItBenefits(List<Document> updatedBenefitsList){
		List<Document> newSortedList = new ArrayList<>();
		Document sortedList = null;
		Document sortedList1 = null;
		List<Document> premList = null;
		Document prem = null;
		Document documentRen = null;
		ArrayList<Document> documentRenList = null;
		
		for (Document renDoc : updatedBenefitsList) {
			sortedList = new Document();
			sortedList1 = new Document();			
			sortedList.append("productType",renDoc.get("productType"));
			sortedList.append("renewalDate",renDoc.get("renewalDate"));
			sortedList.append("currentContractPlanCode",renDoc.get("currentContractPlanCode"));
			sortedList.append("currentContractPlanName",renDoc.get("currentContractPlanName"));
			sortedList.append("currentMonthlyPremium",renDoc.get("currentMonthlyPremium"));
			sortedList.append("currentRatingMethod",renDoc.get("currentRatingMethod"));
			sortedList.append("benefitType","currentProducts");
				
			documentRenList = (ArrayList<Document>)renDoc.get("renewalProducts");
			documentRen = documentRenList.get(0);
			sortedList1.append("renewalContractPlanCode",documentRen.get("contractPlanCode"));
			sortedList1.append("productType",documentRen.get("productType"));
			sortedList1.append("enrollmentType",documentRen.get("enrollmentType"));
			
			premList = new ArrayList<>();
			prem = new Document();
			prem.append("monthlyPremium",documentRen.get("monthlyPremium"));
			prem.append("ratingMethod","MEMBER");
			premList.add(prem);
			sortedList1.append("premium", premList);
			
			sortedList1.append("currentContractPlanCode",renDoc.get("currentContractPlanCode"));
			sortedList1.append("currentContractPlanName",renDoc.get("currentContractPlanName"));
			sortedList1.append("renewalContractPlanName",documentRen.get("renewalContractPlanName"));
			sortedList1.append("benefitType","renewalProducts");
		
			newSortedList.add(sortedList);
			newSortedList.add(sortedList1);
		}
		return newSortedList;
	}
}
