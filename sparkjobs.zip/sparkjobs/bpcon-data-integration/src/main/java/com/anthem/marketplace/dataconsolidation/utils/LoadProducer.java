package com.anthem.marketplace.dataconsolidation.utils;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.JavaSparkContext;
//import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Dataset;
//import org.apache.spark.sql.Row;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SQLContext;
import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

/*
 * This class used for refresh of load the lookup_prod collection in the TDM Layer with new records
 * ,from the feed file [Dump.dat] present in the Hadoop file system 'apps' folder. 
 */

public class LoadProducer {

	private Dataset df;

	private Map<String, Producer> producers = new HashMap<String, Producer>();

	static final Logger logger = LoggerFactory.getLogger(LoadProducer.class);
	public static ArrayList<String> neglectList = new ArrayList<String>();

	public void loadLookupProd(String sourcePath,String sourceCollection,String sourceDB) throws IOException, URISyntaxException {

		SystemProperties.initializeProperties("eas");
		String hadoopFileSystem = SystemProperties.getProperty(IConstants.HADOOP_FILESYSTEM);
		

		if (hadoopFileSystem.equals(IConstants.STRING_TRUE)) {

			Configuration conf;
			FileSystem fs;
			FileStatus[] status;
		try {
			
			conf = new Configuration();
			conf.set("fs.hdfs.impl", org.apache.hadoop.hdfs.DistributedFileSystem.class.getName());
			String hadoopUri = SystemProperties.getProperty(IConstants.HADOOP_URI);
			fs = FileSystem.get(new URI(hadoopUri), conf);
			
			status = fs.listStatus(new Path(sourcePath));
			
				if (null != status[0] && status[0].isFile()	&& status[0].getPath().getName().equalsIgnoreCase("Dump.dat")) {

					JavaSparkContext scTransform = SparkContextSingleton.getInstance().getSparkContext();

					SQLContext sqlContext = new SQLContext(scTransform);

					df = sqlContext.read().format("com.databricks.spark.csv").option("header", "true")
							.option("delimiter", "|").load(status[0].getPath().toString());

				}
		}catch (Exception e) {
			logger.debug("File not found in the hadoop directory");
		} finally {
			conf = null;
			fs = null;
			status = null;
			
		}
		

		}

		else {

			File dir;
			File[] files;

			try {
				dir = new File(sourcePath);
				files = dir.listFiles();
				if (files.length == 0) {
				logger.info("The directory : "+  sourcePath  +" is empty");
				} else {
					List<File> preFiles = new ArrayList<>();

					for (File inputFile : files) {
						if (inputFile.isFile()) {

							if (inputFile.getName().equalsIgnoreCase("Dump.dat")) {
								preFiles.add(inputFile);
							} else {
							logger.info("The file name present in the 'apps' folder is  : " + inputFile
								+ " File name should be Dump.dat ");
							}
						}
					}
					if (preFiles.size() >= 1) {
						for (File aFile : preFiles) {
							if (aFile.isFile()) {

								JavaSparkContext scTransform = SparkContextSingleton.getInstance().getSparkContext();

								SQLContext sqlContext = new SQLContext(scTransform);

								df = sqlContext.read().format("com.databricks.spark.csv")
										.option("header", IConstants.STRING_TRUE).option("delimiter", "|")
										.load(sourcePath + "/" + aFile.getName().toString());
							}
						}
					}
					else {
							logger.info("The file 'Dump.dat' is not present in the apps folder ");
						}
				}
			} catch (Exception e) {

			} finally {
				dir = null;
				files = null;
			}
		}
		
if (null != df) 
	{
		MongoClient mongoClient = MongoConnector.getInstance().getMongoClient(IConstants.TDM_DB);

		MongoDatabase targetDB = mongoClient.getDatabase(sourceDB);
		MongoCollection<Document> targetCollection = targetDB.getCollection(sourceCollection);
		
		/* Here removing all the documents from the lookup_prod collection in TDM layer , which is already present */
		targetCollection.deleteMany(new Document());
		
		Dataset colRenamedDF = df.toDF("agentTaxId", "starBrokerTin", "encryptedTaxId", "suffix", "firstName",
				"middleName", "lastName", "agencyName", "agentId", "legacyAgentCode", "wgsAgentCode", "serviceLoc");

		Encoder<Producer> summaryEncoder = Encoders.bean(Producer.class);

		List<Producer> tempProducers = colRenamedDF.as(summaryEncoder).collectAsList();
		ArrayList<Document> docs = new ArrayList<Document>();

		java.util.Date date = new java.util.Date();
		String currentDate = new Timestamp(date.getTime()).toString();

		for (Producer tempProducer : tempProducers) {

			Document doc = new Document();
			doc.append("agentTaxId", tempProducer.getAgentTaxId().trim());
			doc.append("starBrokerTin", tempProducer.getStarBrokerTin().trim());
			doc.append("encryptedTaxId", tempProducer.getEncryptedTaxId().trim());
			doc.append("firstName", tempProducer.getFirstName());
			doc.append("middleName", tempProducer.getMiddleName());
			doc.append("lastName", tempProducer.getLastName());
			doc.append("agencyName", tempProducer.getAgencyName());
			if (!StringUtils.isBlank(tempProducer.getAgentId())
					&& !tempProducer.getAgentId().trim().equalsIgnoreCase("NULL")) {
				doc.append("agentId", tempProducer.getAgentId().trim());
			} else {
				doc.append("agentId", tempProducer.getAgentId());
			}
			doc.append("legacyAgentCode", tempProducer.getLegacyAgentCode());
			doc.append(IConstants.START_DATE_FIELD, currentDate);
			doc.append("_class", "com.anthem.marketplace.dataconsolidation.utils.LoadProducer");
			
		/* Adding the constructed document into the Document Array List */		
			docs.add(doc);

			if (docs.size() >= 10) {
				targetCollection.insertMany(docs);
				docs.clear();
			}

		}
		if (!docs.isEmpty()) {
			targetCollection.insertMany(docs);
			docs.clear();
		}
		System.gc();
	}
else
{
	logger.info("The Dataframe is empty ");
}
}

	public Map<String, Producer> getProducers() {
		return producers;
	}

}

/*
 * ProcessFieldNames procFieldNames = null;
 * 
 * try { procFieldNames =
 * FieldNamesProperties.getInstance().getPropertyContext(IConstants.
 * LOOKUP_PROD); } catch (ClassNotFoundException | NoSuchMethodException
 * | SecurityException | IllegalAccessException |
 * IllegalArgumentException | InvocationTargetException e) {
 * logger.error("Exception:  " + e); } Document docmapp = new
 * Document(); neglectList.add(""); neglectList.add(null);
 * 
 * for (String fieldNames :
 * procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
 * if
 * (!neglectList.contains(ReadMappingXmlSingleton.getInstance().getRead(
 * ) .getAttributeValueOfField(IConstants.LOOKUP_PROD, fieldNames,
 * IConstants.VALUE))) { docmapp.append(fieldNames,
 * ReadMappingXmlSingleton.getInstance().getRead().
 * getAttributeValueOfField(IConstants.LOOKUP_PROD, fieldNames,
 * IConstants.VALUE)); } }
 */
