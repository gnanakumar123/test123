package com.anthem.marketplace.dataconsolidation.model;

import java.io.Serializable;
import java.util.Date;

public class SpouseDetails implements Serializable {
    
	private String spouseFirstName;
	private String spouseLastName;
    private String spouseUwLevel;
    private Date spouseDateOfBirth;
    
	public String getSpouseFirstName() {
		return spouseFirstName;
	}
	public void setSpouseFirstName(String spouseFirstName) {
		this.spouseFirstName = spouseFirstName;
	}
	public String getSpouseLastName() {
		return spouseLastName;
	}
	public void setSpouseLastName(String spouseLastName) {
		this.spouseLastName = spouseLastName;
	}
	public String getSpouseUwLevel() {
		return spouseUwLevel;
	}
	public void setSpouseUwLevel(String spouseUwLevel) {
		this.spouseUwLevel = spouseUwLevel;
	}
	public Date getSpouseDateOfBirth() {
		return spouseDateOfBirth;
	}
	public void setSpouseDateOfBirth(Date spouseDateOfBirth) {
		this.spouseDateOfBirth = spouseDateOfBirth;
	}
}