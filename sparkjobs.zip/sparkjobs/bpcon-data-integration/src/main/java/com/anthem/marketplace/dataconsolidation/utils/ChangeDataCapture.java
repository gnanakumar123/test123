package com.anthem.marketplace.dataconsolidation.utils;

import java.sql.Timestamp;
import java.util.List;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/*
 * This class Checks for source db existence in mongoDB
 */

public class ChangeDataCapture {
	
	static final Logger logger = LoggerFactory.getLogger(ChangeDataCapture.class);
	/*
	 * This method checks for sourceDB.sorceCollection existence in mongoDB 
	 * @param sourceDB stores source database name
	 * @param sourceCollection stores source Collection name
	 * @param currentDate stores current Name 
	 * @param guid stores GUID created for source database 
	 * @return boolean value as db exists or not
	 * @exception NoSuchMethodException, ClassNotFoundException, InvocationTargetException, IllegalAccessException, IllegalArgumentException, IOException
	 */
	public boolean implementCdc(String sourceDB, String sourceCollection, Document doc, List<Document> docList,
			List<Document> failedList,String dbType) {

		java.util.Date date = new java.util.Date();
		String currentDate = new Timestamp(date.getTime()).toString();
		try {
			return MongoConnector.getInstance().updateCdc(sourceDB, sourceCollection, currentDate, doc, docList,failedList, dbType);
		} catch (Exception e) {
			logger.error("Error{}", e);
			return false;
		}
		// else return false if nothing found

	}
	public void implementWSGRSCdc(String sourceDB, String sourceCollection, Document doc, List<Document> docList,
			List<Document> failedList,String dbType) {

		java.util.Date date = new java.util.Date();
		String currentDate = new Timestamp(date.getTime()).toString();
		try {
			 MongoConnector.getInstance().updateWSGRSCdc(sourceDB, sourceCollection, currentDate, doc, docList,
					failedList, dbType);
		} catch (Exception e) {
			logger.error("Error{}", e);
			
		}
		// else return false if nothing found

	}

	/**
	 * BPP-8945 - SGRS Renewal Changes
	 * @param sourceDB
	 * @param sourceCollection
	 * @param doc
	 * @param docList
	 * @param failedList
	 * @param dbType
	 */
	public void implementSGRSCdc(String sourceDB, String sourceCollection, Document doc, List<Document> docList,
			List<Document> failedList,String dbType) {

		java.util.Date date = new java.util.Date();
		String currentDate = new Timestamp(date.getTime()).toString();
		try {
			 MongoConnector.getInstance().updateSGRSCdc(sourceDB, sourceCollection, currentDate, doc, docList,failedList, dbType);
		} catch (Exception e) {
			logger.error("Error{}", e);		
		}
	}
	
	

	public boolean implementCdc(String sourceDb, String sourceCollection, Document doc, List<Document> iterableDoc,
			List<Document> failedList, Boolean flag,String dbType) {

		java.util.Date date = new java.util.Date();
		String currentDate = new Timestamp(date.getTime()).toString();

		try {
			return MongoConnector.getInstance().updateCdc(sourceDb, sourceCollection, currentDate, doc, iterableDoc,failedList, flag, dbType);
		} catch (Exception e) {
			logger.error("Error{}", e);
			return false;
		}
	}
}