package com.anthem.marketplace.dataconsolidation.filesutils;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.bson.BSONObject;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.utils.ChangeDataCapture;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.BasicDBList;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

import scala.Tuple2;

/*
* This class implements UtilityInterface and Serializable and performs Ingestion, Transformation of AnthemO65 
 * and AnthemU65 renewals input files
* @author : MongoDB Team
* @version : 1.0
* @Date : June 2016
* It returns nothing.;
*/
public class FACETS implements UtilityInterface, Serializable {
	private static final long serialVersionUID = 1L;
	static final Logger logger = LoggerFactory.getLogger(FACETS.class);
	public static ArrayList<String> neglectList = new ArrayList<String>();
	public List<String> fieldsList;

	/*
	 * This method creates GUID
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param delimeted stores delimited character
	 * 
	 * @param readFileContent stores input file data
	 * 
	 * @param guidvalue stores guid values retrieve from properties file
	 * 
	 * @param type stores type of file
	 * 
	 * @return String GUID
	 */
	public String createGuid(String sourceCollection, String delimeted, Row readFileContent, String guidvalue,
			String type) {

		String guid = "";
		String errorFieldName = "";
		try {
			for (String item : guidvalue.split(IConstants.SPLIT_COMMA)) {
				int index = Integer.parseInt(ReadMappingXmlSingleton.getInstance().getRead().getIndex(type, item));
				guid += readFileContent.getString(index).trim().replace(IConstants.INVERTED_COMMA, IConstants.BLANK); // BPP-24173 CR-FACETS Renewals : while constructing the guid ,replaced the double quotes with blank 
				}
			if (type.equals("facets_renewal_Anthem_U65"))
				guid = guid.concat("IND");
			else
				guid = guid.concat("MED");
			guid = guid.concat("SUBSCR");

			// catch Exceptions and add respective errorCode and its description
		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM,
					IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM,
					IConstants.RDM_DB);
		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM,
					IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM,
					IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM,
					IConstants.RDM_DB);
		}
		return guid;
	}

	/*
	 * This method checks mandatory fields for file for data Quality check
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param delimeted stores delimited character
	 * 
	 * @param readFileContent stores input file data
	 * 
	 * @param type stores type of file
	 * 
	 * @return boolean value based on data Quality check passed.
	 */
	public boolean createFlag(String delimeted, String sourceCollection, Row readFileContent, String type) {

		boolean flag = false;
		String errorFieldName = "";
		try {
			// determine which files are mandatory from mapping.xml based on
			// type supplied
			Map<String, String> mandatoryFields = ReadMappingXmlSingleton.getInstance().getRead()
					.getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);
			// set GUID for csv file
			for (String item : mandatoryFields.keySet()) {
				errorFieldName = item;
				// check if mandatoryFields available in input content file
				flag = readFileContent.getString(Integer.parseInt(item)) == null
						|| ("".equals(readFileContent.getString(Integer.parseInt(item))));
				if (flag)
					break;
			}
			// if false then set error as null value found for mandatory fields.
			if (flag) {
				Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
						IConstants.DATA_QUALITY_ERROR_CHECK, readFileContent.toString(), errorFieldName,
						IConstants.FACETS_ANTHEM, IConstants.RDM_DB);
			}

		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM,
					IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM,
					IConstants.RDM_DB);
		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM,
					IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM,
					IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM,
					IConstants.RDM_DB);
		}
		return flag;
	}

	/*
	 * This method adds fileName and its respective value to a document and
	 * returns it.
	 * 
	 * @param processInput stores input properties related parameters
	 * 
	 * @param sourcePath stores source path of input file
	 * 
	 * @param guid stores GUID
	 * 
	 * @param flag stores value retrieve from data Quality check method
	 * 
	 * @param readFileContent stores Row of a input file
	 * 
	 * @return Document
	 */
	public Document appendRaw(ProcessInput processInput, String sourcePath, String guid, boolean flag,
			Row readFileContent) {

		String type = processInput.getType();
		String sourceDB = processInput.getSourceDB();
		String sourceCollection = processInput.getSourceCollection();
		boolean checkFlag = false;
		ProcessFieldNames procFieldNames;
		String value;
		Document doc = new Document();
		String errorFieldName = "";
		try {
			procFieldNames = FieldNamesProperties.getInstance().getPropertyContext(type);
			doc.append(IConstants.GUID, guid);

			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
				errorFieldName = fieldNames;
				// get dataType from mapping.xml for specified field.
				String dataType = ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(type,
						fieldNames, IConstants.DATATYPE);
				value = readFileContent
						.getString(Integer
								.parseInt(ReadMappingXmlSingleton.getInstance().getRead().getIndex(type, fieldNames)))
						.trim().replace(IConstants.INVERTED_COMMA, IConstants.BLANK);
				// change dataType of fields and convert zonal fields to zonal
				// decimal number
				checkFlag = Utility.applyZone(sourceCollection, fieldNames, value.trim(), doc, dataType,
						readFileContent, IConstants.FACETS_ANTHEM);
				if (checkFlag)
					flag = true;
			}

			if(sourcePath.contains("AnthemU65")){
				Utility.insertMetadata(doc, sourceDB, sourceCollection, guid, sourcePath, IConstants.FACETS_U65, flag,
					true, IConstants.RDM_DB);
			}else{
				Utility.insertMetadata(doc, sourceDB, sourceCollection, guid, sourcePath, IConstants.FACETS_O65, flag,
						true, IConstants.RDM_DB);
			}

			// catch Exceptions and add respective errorCode and its description
		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM, IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM, IConstants.RDM_DB);
		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM, IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.RAW_DATA,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM,
					IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.FACETS_ANTHEM, IConstants.RDM_DB);
		}
		return doc;
	}

	/*
	 * This method performs transformation on AnthemO65 and AnthemU65 Raw data.
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source collection name
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param targetCollection stores target collection name
	 * 
	 * @param appendedCollection stores collection name whose data to be
	 * appended as embedded doc. i.t summary to detail
	 * 
	 * @return transformed Document
	 */
	public Document ingestTDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String transColl, String appendedCollection) {

		Document metaDoc = new Document();
		boolean flag = false;
		String guid = "";
		ProcessFieldNames procFieldNames = null;
		String sourcePath = "";
		ProcessFieldNames clientFieldNames = null;
		neglectList.add("");
		neglectList.add(null);
		//MongoConnector objMongoConnector= MongoConnector.getInstance();
		try {
			clientFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.FACETS_ANTHEM.concat(transColl));
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e) {
			logger.error("Exception: " + e);
		}
		for (String fieldNames : clientFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
			if (!neglectList.contains(
					bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
							IConstants.FACETS_ANTHEM.concat(transColl), fieldNames, IConstants.VALUE))))
				metaDoc.append(fieldNames,
						bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
								IConstants.FACETS_ANTHEM.concat(transColl), fieldNames, IConstants.VALUE)));

		}

		if (bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString().contains("AnthemU65")) {
			metaDoc.append("type", "IND");
			metaDoc.append("relationship", "SUBSCR");

		} else {
			metaDoc.append("type", "MED");
			metaDoc.append("relationship", "SUBSCR");
		}

		if (transColl.contains("Renewals_tdm_Renewal")) {

			fieldsList = new ArrayList<String>();
			Document doc = new Document();
			try {
					procFieldNames = FieldNamesProperties.getInstance()
							.getPropertyContext(IConstants.FACETS_ANTHEM_REN_DET);
			} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
					| IllegalArgumentException | InvocationTargetException e) {
				logger.error("Exception:  " + e);
			}
			if(bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString().contains("AnthemU65")){
				for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
					if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(IConstants.FACETS_ANTHEM_REN_DET.concat("_modified"), fieldNames, IConstants.VALUE))))
						doc.append(fieldNames, bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
								.getAttributeValueOfField(IConstants.FACETS_ANTHEM_REN_DET.concat("_modified"), fieldNames, IConstants.VALUE)));
					if( (bsonFilter._2.get("DepName1") != null && !(bsonFilter._2.get("DepName1").toString().isEmpty())) ||
							(bsonFilter._2.get("DepName2") != null && !(bsonFilter._2.get("DepName2").toString().isEmpty())) ||
							(bsonFilter._2.get("DepName3") != null && !(bsonFilter._2.get("DepName3").toString().isEmpty())) ||
							(bsonFilter._2.get("DepName4") != null && !(bsonFilter._2.get("DepName4").toString().isEmpty()))){
						metaDoc.append("renewalDependentsCovered", "Yes");
					}else{
						metaDoc.append("renewalDependentsCovered", "No");
					}
				}
			}else{
				for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
					if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(IConstants.FACETS_ANTHEM_REN_DET, fieldNames, IConstants.VALUE))))
						doc.append(fieldNames, bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
								.getAttributeValueOfField(IConstants.FACETS_ANTHEM_REN_DET, fieldNames, IConstants.VALUE)));
				}
			}

			metaDoc.append(IConstants.RENEWAL_DETAILS, doc);
			
			if(bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString().contains("AnthemU65")){
				List<Document> renewalProducts = getGrpRenewalProductsU65(sourceCollection, doc, metaDoc);
				doc.append("renewalProducts", renewalProducts);
			}else{
				List<Document> renewalProducts = getGrpRenewalProducts(sourceCollection, doc, metaDoc);
				doc.append("renewalProducts", renewalProducts);
			}
			List<Document> benefitList = new ArrayList<>();
			benefitList.add(doc);
			metaDoc.append(IConstants.BENEFITS, benefitList);
		}

		else {
			int year = Calendar.getInstance().get(Calendar.YEAR);
			for (String coll : appendedCollection.split(IConstants.SPLIT_COMMA)) {
				Document doc = new Document();
				try {
					procFieldNames = FieldNamesProperties.getInstance()
							.getPropertyContext(IConstants.FACETS_ANTHEM.concat(coll));
				} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
						| IllegalArgumentException | InvocationTargetException e) {
					logger.error("Exception:  " + e);
				}

				if (coll.equals(IConstants.CLIENT_CONTACTS)) {
					BasicDBList contactList = new BasicDBList();
					Document d = new Document();

					for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
						if (fieldNames.equals("addressType")) {
							d.append(fieldNames, IConstants.DEFAULT);
						} else if (!neglectList.contains(bsonFilter._2
								.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
										IConstants.FACETS_ANTHEM.concat(coll), fieldNames, IConstants.VALUE))))
							d.append(fieldNames,
									bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
											.getAttributeValueOfField(IConstants.FACETS_ANTHEM.concat(coll), fieldNames,
													IConstants.VALUE)));
					}
					contactList.add(d);
					metaDoc.append(coll, contactList);

				} else if (coll.equals(IConstants.CLIENT_AGENT)) {

					String producerTIN = null;
					String agentName = null;
					List<Document> agentDocList = new ArrayList<Document>();
					
					try {
						// / BPP-3799-Adding Producer Tin Encrypted Number in
						// TDM
						producerTIN = bsonFilter._2().get("AgentNumber").toString();
						agentName = bsonFilter._2().get("AgentName").toString();
						if (producerTIN != null && producerTIN.length() > 0) {
							producerTIN = producerTIN.substring(3,producerTIN.length());
							agentDocList.add(MongoConnector.getInstance().appendContacts(targetDb,producerTIN,"Writing"));
							
						}else{
							doc.append("taxID", "UNKNOWN");
							if(agentName != null && agentName.length() > 0){
								doc.append("name", agentName);
							}else{
								doc.append("name", "NULL");
							}
							agentDocList.add(doc);
					  }
						//logger.info("---mogolookup agentid ---"+bsonFilter._2().get("SubId"));
					} catch (Exception e) {
						logger.info("---exception---"+bsonFilter._2().get("SubId"));
						logger.error("Exception:  " + e);
					}

					for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
						if (fieldNames.equals(IConstants.PRODUCT) || fieldNames.equals(IConstants.TAX_ID_TYPE)
								|| fieldNames.equals("addressType")) {
							// doc.append(fieldNames, IConstants.DEFAULT);
							doc.append(fieldNames, IConstants.WRITING);
						} else if (fieldNames.equals("renewalPeriod"))
							doc.append(fieldNames, year);
						else if (!neglectList.contains(bsonFilter._2
								.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
										IConstants.FACETS_ANTHEM.concat(coll), fieldNames, IConstants.VALUE))))
							doc.append(fieldNames,
									bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
											.getAttributeValueOfField(IConstants.FACETS_ANTHEM.concat(coll), fieldNames,
													IConstants.VALUE)));
					}
					
					//Method 'populateTinIfNotExist'wil populate the Paid and Parent tin from Writing tin, inside that method call the method populateIsVisibleFlag
					//agentDocList = (objMongoConnector.populateTinIfNotExist(agentDocList,metaDoc.get("ID").toString()));
					metaDoc.append(coll, agentDocList);

				} else {

					for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

						if (fieldNames.equals(IConstants.PRODUCT) || fieldNames.equals(IConstants.TAX_ID_TYPE)
								|| fieldNames.equals("addressType")) {
							doc.append(fieldNames, IConstants.DEFAULT);
						} else if (fieldNames.equals("renewalPeriod"))
							doc.append(fieldNames, year);
						else if (!neglectList.contains(bsonFilter._2
								.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
										IConstants.FACETS_ANTHEM.concat(coll), fieldNames, IConstants.VALUE))))
							doc.append(fieldNames,
									bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
											.getAttributeValueOfField(IConstants.FACETS_ANTHEM.concat(coll), fieldNames,
													IConstants.VALUE)));
					}
					metaDoc.append(coll, doc);
				}

			}
		}

		sourcePath = bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString();
		// insert metaData
		guid = metaDoc.get(IConstants.GUID).toString();
		if(sourcePath.contains("AnthemU65")){
			Utility.insertMetadata(metaDoc, targetDb, transColl, guid, sourcePath, IConstants.FACETS_U65, flag, true,
				IConstants.TDM_DB);
		}else{
			Utility.insertMetadata(metaDoc, targetDb, transColl, guid, sourcePath, IConstants.FACETS_O65, flag, true,
					IConstants.TDM_DB);
		}
		if (metaDoc.getString(IConstants.REN_ID) != null)
			return metaDoc;

		else
			return null;
	}
	/* TODO : This method id not being used anywhere double check it and remove this method of needed*/
	public List<Document> getRenewalProducts(String sourceCollection, Document outerDoc) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}
			double monPrem = 0.0;
			if (doc.containsKey("renewalMonthlyPremium")) {
				monPrem = doc.getDouble("renewalMonthlyPremium");
				doc.remove("renewalMonthlyPremium");
			}
			doc.append(IConstants.MON_PREM, monPrem);
			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	public List<Document> getGrpRenewalProducts(String sourceCollection, Document outerDoc, Document summaryDoc) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}
			double monPrem = 0.0, currMonPrem = 0.0;
			if (doc.containsKey("renewalMonthlyPremium")) {
				monPrem = doc.getDouble("renewalMonthlyPremium");
				doc.remove("renewalMonthlyPremium");
			}
			if (outerDoc.containsKey(IConstants.CURR_MON_PREMIUM)) {
				currMonPrem = outerDoc.getDouble(IConstants.CURR_MON_PREMIUM);
				outerDoc.remove(IConstants.CURR_MON_PREMIUM);
			}
			summaryDoc.append(IConstants.CURR_MON_PREMIUM, currMonPrem);
			summaryDoc.append(IConstants.MON_PREM, monPrem);
			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	public List<Document> getGrpRenewalProductsU65(String sourceCollection, Document outerDoc, Document summaryDoc) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}
			double monPrem = 0.0, currMonPrem = 0.0;
			if (doc.containsKey("renewalMonthlyPremium")) {
				monPrem = doc.getDouble("renewalMonthlyPremium");
				doc.remove("renewalMonthlyPremium");
			}
			if (outerDoc.containsKey(IConstants.CURR_MON_PREMIUM)) {
				currMonPrem = outerDoc.getDouble(IConstants.CURR_MON_PREMIUM);
				//outerDoc.remove(IConstants.CURR_MON_PREMIUM);
			}
			summaryDoc.append(IConstants.CURR_MON_PREMIUM, currMonPrem);
			summaryDoc.append(IConstants.MON_PREM, monPrem);
			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}
	/*
	 * This method performs unified transformation on AnthemO65 and U65
	 * transformed data.
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source collection name
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param targetCollection stores target collection name
	 * 
	 * @param targetDetailCollection stores collection name whose data is
	 * appended as embedded doc. i.t summary to detail
	 * 
	 * @return transformed Document
	 */
	@SuppressWarnings("unchecked")
	public Document ingestUDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection) {

		Document metaDoc = new Document();
		try {
			metaDoc.putAll(bsonFilter._2.toMap());

			metaDoc.remove(IConstants.ID);
		} catch (Exception e) {
			logger.error("Exception:  " + e);
		}
		return metaDoc;
	}

	/*
	 * this method inserts data into mongoDB for given specifications
	 * 
	 * @processInput stores input related parameters
	 * 
	 * @sourcePath stores file location path
	 * 
	 * @guidvalue stores GUID
	 * 
	 * @priority stores priority of process
	 * 
	 * @strType stores type of input file.
	 * 
	 * @return nothing
	 */
	@Override
	public void ingestRDMprocess(ProcessInput processInput, String sourcePath, String guidvalue, String strType) {

		List<Document> docList = new ArrayList<>();
		List<Document> failedList = new ArrayList<>();
		String sourceCollection = processInput.getSourceCollection();
		String delimeted = processInput.getDelimeted();
		String delimeter = processInput.getDelimeter();
		String type = processInput.getType();
		String sourceDB = processInput.getSourceDB();
		String failedCollection = processInput.getFailedCollection();
		
		JavaSparkContext scIngest = SparkContextSingleton.getInstance().getSparkContext();
		JavaPairRDD<String, String> fileContent = scIngest.wholeTextFiles(sourcePath);
		/* Start CR-FACETS Renewals BPP-24173 */
		JavaRDD<String> filePartition = fileContent.flatMap(new com.anthem.marketplace.dataconsolidation.utils.CustomCsvReader());
		//JavaRDD<String> filePartition = scIngest.textFile(sourcePath, 12);
		/* End CR-FACETS Renewals BPP-24173 */
		filePartition.count();
		// Regular expression to escape "," in the data of csv field
		String regex = IConstants.RETAIN_COMMA;
		JavaRDD<Row> readFile = filePartition.map(record -> RowFactory.create((Object[]) record.split(regex, -1)));
		readFile = readFile.mapPartitionsWithIndex((index, rowIterator) -> {
			// Remove the header line
			if (index == 0 && rowIterator.hasNext()) {
				rowIterator.next();
				return rowIterator;
			} else
				return rowIterator;
		} , false);
		readFile.foreachPartition(partitionIterator -> {

			ProcessInput process = new ProcessInput(sourceDB, sourceCollection, type, delimeter, delimeted,
					failedCollection);
			partitionIterator.forEachRemaining(readFileContent -> {

				String guid = this.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
				boolean flag = this.createFlag(delimeted, sourceCollection, readFileContent, type);
				Document doc = this.appendRaw(process, sourcePath, guid, flag, readFileContent);
				ChangeDataCapture cdc = new ChangeDataCapture();
				cdc.implementCdc(sourceDB, sourceCollection, doc, docList, failedList, IConstants.RDM_DB);
				if(docList.size() >= 500){
					MongoConnector.getInstance().insertData(docList, sourceDB, sourceCollection, IConstants.RDM_DB);
					MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
					docList.clear();
					failedList.clear();
				}
			});
			MongoConnector.getInstance().insertData(docList, sourceDB, sourceCollection, IConstants.RDM_DB);
			MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
		});

	}

	@Override
	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection,
			Tuple2<Object, BSONObject> bsonFilter, ProcessFieldNames procFieldNames, String targetDb,
			String targetCollection, String targetDetailCollection, String sourceDbTDM) {
		return null;
	}

	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection) {
		return null;
	}

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection, ProcessInput processInput) {
		ProcessFieldNames memberSummary = null;
		ProcessFieldNames memberDetail = null;
		ProcessFieldNames memberSummaryBenefits = null;
		ProcessFieldNames memberSummaryBenefitsF = null;
		try {
			memberSummary = FieldNamesProperties.getInstance().getPropertyContext("memberSummary");
			memberDetail = FieldNamesProperties.getInstance().getPropertyContext("memberDetail");
			memberSummaryBenefits = FieldNamesProperties.getInstance().getPropertyContext("memberSummaryBenefits");
			memberSummaryBenefitsF = FieldNamesProperties.getInstance().getPropertyContext("memberSummaryBenefitsModified");
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e1) {
			logger.error(IConstants.ERROR_PREPEND, e1);
		}

		String[] sourceColl = sourceCollection;
		List<Document> docDetailList = new ArrayList<>();
		List<Document> docSummaryList = new ArrayList<>();

		Document doc = new Document();
		Document summaryDoc = new Document();
		
		try {
			addToDocument(memberDetail, bsonFilter, "memberDetail", doc);
			for (String metaData : IConstants.getMetadata())
				doc.append(metaData, bsonFilter._2.get(metaData));
			
			if (bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString().contains("AnthemU65")) {
				
				doc.append(IConstants.RENEWAL_DETAILS, getRenewalDocumentSDSDetailModified(bsonFilter,
						sourceDb, sourceColl[1], IConstants.UDM_DB));
				doc.append(IConstants.FULLNAME, (bsonFilter._2.get(IConstants.LASTNAME).toString() + ", "
						+ bsonFilter._2.get(IConstants.FIRSTNAME).toString()).toUpperCase());
				doc.append("exchangeIndicator", "No");
				doc.append("ratingArea", "");
			}else{
				doc.append("exchangeIndicator", "No");
				doc.append("ratingArea", "");
				doc.append(IConstants.RENEWAL_DETAILS, MongoConnector.getInstance().getRenewalDocumentSDSDetail(bsonFilter,
						sourceDb, sourceColl[1], IConstants.UDM_DB));
			}

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}

		addToDocument(memberSummary, bsonFilter, "memberSummary", summaryDoc);
		if (bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString().contains("AnthemO65")) {
			summaryDoc.append(IConstants.FULLNAME, (bsonFilter._2.get(IConstants.LASTNAME).toString() + ", "
					+ bsonFilter._2.get(IConstants.FIRSTNAME).toString()).toUpperCase());

		}
		if(bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString().contains("AnthemU65")){
			summaryDoc.append(IConstants.FULLNAME, (bsonFilter._2.get(IConstants.LASTNAME).toString() + ", "
					+ bsonFilter._2.get(IConstants.FIRSTNAME).toString()).toUpperCase());
		}
			
		for (String metaData : IConstants.getMetadata()) {
			summaryDoc.append(metaData, bsonFilter._2.get(metaData));
		}
		Object benefitsObject = null;
		if (bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString().contains("AnthemO65")) {
			benefitsObject = MongoConnector.getInstance().getRenewalDocumentSDS(bsonFilter, sourceDb, sourceColl[1],
					IConstants.UDM_DB, IConstants.RENEWAL_DETAILS);
		}else{
			benefitsObject = getRenewalDocumentSDS(bsonFilter, sourceDb, sourceColl[1],IConstants.UDM_DB, IConstants.RENEWAL_DETAILS);
		}
		 
		@SuppressWarnings("unchecked")
		List<Document> benefitsList = (ArrayList<Document>) benefitsObject;
		List<Document> updatedBenefitsList = new ArrayList<>();
		for (Document benefitDocument : benefitsList) {
			Document updatedBenefitDocument = new Document();

			if (bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString().contains("AnthemO65")) {
				updatedBenefitDocument.append("currentContractPlanCode", "");
				/*addToDocument_O65(memberSummaryBenefits, benefitDocument, "memberSummaryBenefits",
						updatedBenefitDocument);*/
				addToDocument_O65(memberSummaryBenefits, benefitDocument, "memberSummaryBenefitsFacets",
						updatedBenefitDocument);
			} else {
				addToDocument(memberSummaryBenefitsF, benefitDocument, "memberSummaryBenefitsFacets", updatedBenefitDocument);
				
				String productType = "";
				if(updatedBenefitDocument.get("productType") != null && !(updatedBenefitDocument.get("productType").toString().isEmpty())){
					if(updatedBenefitDocument.get("productType").toString().equalsIgnoreCase("D")){
						productType = "DEN";
					}else if(updatedBenefitDocument.get("productType").toString().equalsIgnoreCase("M")){
						productType = "MED";
					}else if(updatedBenefitDocument.get("productType").toString().equalsIgnoreCase("L")){
						productType = "LFE";
					}
				}
				updatedBenefitDocument.append("productType", productType);
				ArrayList<Document> renProdList = (ArrayList<Document>) updatedBenefitDocument.get("renewalProducts");
				for(Document d : renProdList){
					d.put("contractPlanCode", d.get("renewalContractCode"));
					d.remove("renewalContractCode");
					String rproductType = "";
					if(d.get("productType") != null && !(d.get("productType").toString().isEmpty())){
						if(d.get("productType").toString().equalsIgnoreCase("D")){
							rproductType = "DEN";
						}else if(d.get("productType").toString().equalsIgnoreCase("M")){
							rproductType = "MED";
						}else if(d.get("productType").toString().equalsIgnoreCase("L")){
							rproductType = "LFE";
						}
					}
					d.append("productType", rproductType);
				}
			}
			updatedBenefitsList.add(updatedBenefitDocument);

		}
		summaryDoc.append("renewalSummary", updatedBenefitsList);
		putCalFields(summaryDoc, sourceDb, sourceColl[1], IConstants.UDM_DB,doc);
		addGrpDelta(summaryDoc);
		summaryDoc.append(IConstants.PLAN, IConstants.MED);
		
		MongoConnector.getInstance().addBrokerAgentAgencyInfo(targetDb,summaryDoc);
		
		docSummaryList.add(summaryDoc);
		docDetailList.add(doc);
		try {

			MongoConnector.getInstance().removePreviousDocuments(targetDb, targetCollection, targetDetailCollection,
					IConstants.SDSREN_DB, summaryDoc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		MongoConnector.getInstance().insertData(docDetailList, targetDb, targetDetailCollection, IConstants.SDSREN_DB);
		MongoConnector.getInstance().insertData(docSummaryList, targetDb, targetCollection, IConstants.SDSREN_DB);
		MongoConnector.getInstance().updateStatusF(sourceDb, sourceColl[0], bsonFilter, IConstants.UDM_DB);
		MongoConnector.getInstance().updateStatusF(sourceDb, sourceColl[1], bsonFilter, IConstants.UDM_DB);
		return null;
	}

	private void addToDocument_O65(ProcessFieldNames processFieldNames, Document bsonFilter, String mappingName,
			Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))
				if ("ProductType".equalsIgnoreCase(fieldNames)
						&& "M".equalsIgnoreCase(bsonFilter
								.get(ReadMappingXmlSingleton.getInstance().getRead()
										.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))
								.toString())) {
					document.append(fieldNames, "MSUP");
				} else if ("renewalProducts".equalsIgnoreCase(fieldNames)) {
					List<Document> renewalProducts = processRenewalProducts(
							bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
									.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)),
							bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
									.getAttributeValueOfField(mappingName, "currentContractPlanName", IConstants.VALUE))
									.toString());
					document.append(fieldNames, renewalProducts);
				} else
					document.append(fieldNames, bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

		}
	}

	private void addToDocument(ProcessFieldNames processFieldNames, Tuple2<Object, BSONObject> bsonFilter,
			String mappingName, Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

		}

	}

	private void addToDocument(ProcessFieldNames processFieldNames, Document bsonFilter, String mappingName,
			Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

		}

	}

	private List<Document> processRenewalProducts(Object object, String planName) {
		List<Document> modifiedDocuments = new ArrayList<>();
		for (Document d : (List<Document>) object) {
			if (d.containsKey("productType") && "M".equalsIgnoreCase(d.get("productType").toString())) {
				d.replace("productType", "M", "MSUP");
			}

			d.append("contractPlanCode", "");
			d.append("renewalContractPlanName", planName);
			modifiedDocuments.add(d);
		}

		return modifiedDocuments;
	}

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceColl, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String sourceDbTDM) {
		return null;
	}
	
	public Object getRenewalDocumentSDSDetailModified(Tuple2<Object, BSONObject> bsonFilter, String sourceDb, 
								String sourceColl,String dbType) {
		try {
			ProcessFieldNames memberDetailPremium = null;
			memberDetailPremium = FieldNamesProperties.getInstance().getPropertyContext("memberDetailPremium");
			List<Document> benefits = new ArrayList<>();
			
			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
					sourceColl, dbType);
			FindIterable<Document> docs =  collcheck.find(new Document("ID", bsonFilter._2.get("ID").toString()).append("end-date", IConstants.MAX_DATE).append("status", "un-processed"));
			//Document docRen = (Document) collcheck.find(new Document("GUID", bsonFilter._2.get("GUID").toString())).first();
			for(Document docRen : docs){
				@SuppressWarnings("unchecked")
				List<Document> renDetails =  (List<Document>) docRen.get(IConstants.RENEWAL_DETAILS);
										
					for(Document renDoc : renDetails){
						@SuppressWarnings("unchecked")
						ArrayList<Document> renProdList = (ArrayList<Document>) renDoc.get("renewalProducts");
						Document tempDoc= renProdList.get(0);							
						Document premiumDoc = new Document();
						List<Document> premiumDocList = new ArrayList<>();
						Document benefitDoc = new Document();
						Document currBenefitDoc = new Document();
						addToDocument(memberDetailPremium, tempDoc, "memberDetailPremium", premiumDoc);
						premiumDoc.append("monthlyPremium", renDoc.get("renewalMonthlyPremium"));
						premiumDoc.remove("renewalSubsidy");
						premiumDoc.append("renewalSubsidy", "No");
						premiumDoc.remove("currentMonthlyPremium");
						premiumDoc.append("currentMonthlyPremium", renDoc.get("currentMonthlyPremium"));
						premiumDoc.remove("renewalPremiumwithoutSubsidy");
						premiumDoc.append("renewalPremiumwithoutSubsidy", renDoc.get("renewalPremiumwithoutSubsidy"));
						benefitDoc.append("contractPlanCode", tempDoc.getString("renewalContractCode"));
						benefitDoc.append(IConstants.BENEFITTYPE, "renewalProducts");
						premiumDocList.add(premiumDoc);
						benefitDoc.append("premium", premiumDocList);
						String productType = "";
						if(renDoc.get("productType") != null && !(renDoc.get("productType").toString().isEmpty())){
							if(renDoc.get("productType").toString().equalsIgnoreCase("D")){
								productType = "DEN";
							}else if(renDoc.get("productType").toString().equalsIgnoreCase("M")){
								productType = "MED";
							}else if(renDoc.get("productType").toString().equalsIgnoreCase("L")){
								productType = "LFE";
							}
							
						}
						benefitDoc.append("currentContractPlanCode",renDoc.get("currentContractPlanCode"));
						benefitDoc.append("currentContractPlanName",renDoc.get("currentContractPlanName"));
						
						benefitDoc.append("renewalContractPlanCode",renDoc.get("renewalContractCode"));
						benefitDoc.append("contractPlanCode",renDoc.get("renewalContractCode"));
						benefitDoc.append("renewalContractPlanName",renDoc.get("renewalContractPlanName"));
						//benefitDoc.append("productType",renDoc.get("productType"));
						benefitDoc.append("productType",productType);
						//benefitDoc.append("renewalSubsidy",0.0);
						benefitDoc.append("renewalSubsidy","No");
						
						currBenefitDoc.append("currentContractPlanCode",renDoc.get("currentContractPlanCode"));
						currBenefitDoc.append("currentContractPlanName",renDoc.get("currentContractPlanName"));
						//currBenefitDoc.append("renewalContractPlanCode",renDoc.get("renewalContractCode"));
						currBenefitDoc.append("currentTotalPremium",renDoc.get("currentTotalPremium"));
						//currBenefitDoc.append("currentSubsidy",renDoc.get("currentSubsidy"));
						currBenefitDoc.append("currentSubsidy","No");
						currBenefitDoc.append("currentPremiumwithoutSubsidy",renDoc.get("currentPremiumwithoutSubsidy"));
						//currBenefitDoc.append("productType",renDoc.get("productType"));
						currBenefitDoc.append("productType",productType);
						//currBenefitDoc.append("currentMonthlyPremium",renDoc.get("renewalMonthlyPremium"));
						currBenefitDoc.append("currentMonthlyPremium",renDoc.get("currentMonthlyPremium"));
						currBenefitDoc.append(IConstants.BENEFITTYPE, IConstants.CURRENTPRODUCTS);
						
						if(currBenefitDoc.containsKey(IConstants.CURR_CONT_PLAN_CODE))
							benefits.add(currBenefitDoc);
						if(benefitDoc.containsKey(IConstants.CURR_CONT_PLAN_CODE))
							benefits.add(benefitDoc);
						}

					}
					
					return benefits;
				
			
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			}
		return null;

	} 
	public void putCalFields(Document summaryDoc, String sourceDb, String sourceColl, String udmDb, Document doc) {

		double currPrem = 0.00, monPrem = 0.00;
		double dif =0.0;
		//Document d=null;
		try {
			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, sourceColl,
					udmDb);
			/*d = collcheck.find(new Document("ID", summaryDoc.getString("ID")).append(IConstants.END_DATE_FIELD,
					IConstants.MAX_DATE)).first();*/
			if(summaryDoc.getString("source").equalsIgnoreCase("FACETS(O65)")){
				/* BPP-31929 Start for FACETS O65 to get latest current and monthly premium values,appended status  as "un-processed" */
				Document d = collcheck.find(new Document("ID", summaryDoc.getString("ID"))
						.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.STATUS_FIELD , IConstants.UNPROCESSED)).first();
				/* BPP-31929 End for FACETS O65 to get latest current and monthly premium values,appended status  as "un-processed" */
				if (d.containsKey(IConstants.CURR_MON_PREMIUM))
					currPrem = d.getDouble(IConstants.CURR_MON_PREMIUM);
				if (d.containsKey(IConstants.MON_PREM))
					monPrem = d.getDouble(IConstants.MON_PREM);
				if (d.containsKey("Delta") && d.getString("Delta") != null && !(d.getString("Delta").isEmpty())) {
					String diff = d.getString("Delta");
					diff = diff.replaceAll("%", "");
					dif = Double.parseDouble(diff);
					summaryDoc.append("Delta", dif);
				}
				if(d.containsKey("renewalDependentsCovered") && d.getString("renewalDependentsCovered").equalsIgnoreCase("Yes")){
					doc.append("dependentsCovered", "Yes");
				}else{
					doc.append("dependentsCovered", "No");
				}
				summaryDoc.append(IConstants.CURR_MON_PREMIUM, currPrem);
				summaryDoc.append(IConstants.MON_PREM, monPrem);
			}else{
				FindIterable<Document> docs =  collcheck.find(new Document("ID",summaryDoc.getString("ID")).append("end-date", IConstants.MAX_DATE).append("status", "un-processed"));
				String dependentsCovered = "";
				for(Document d : docs){
					if (d.containsKey(IConstants.CURR_MON_PREMIUM))
						currPrem += d.getDouble(IConstants.CURR_MON_PREMIUM);
					if (d.containsKey(IConstants.MON_PREM))
						monPrem += d.getDouble(IConstants.MON_PREM);
					if(d.containsKey("Delta") && d.getString("Delta") != null && !(d.getString("Delta").isEmpty())){
						String diff = d.getString("Delta");
						diff = diff.replaceAll("%", "");
						dif += Double.parseDouble(diff);
					}
					if(d.containsKey("renewalDependentsCovered") && d.getString("renewalDependentsCovered").equalsIgnoreCase("Yes")){
						dependentsCovered = "Yes";
					}
				}
				if(!dependentsCovered.isEmpty() && dependentsCovered.equalsIgnoreCase("Yes")){
					doc.append("dependentsCovered", "Yes");
				}else{
					doc.append("dependentsCovered", "No");
				}
				summaryDoc.append(IConstants.CURR_MON_PREMIUM, currPrem);
				summaryDoc.append(IConstants.MON_PREM, monPrem);
				summaryDoc.append("Delta", dif);
			}
			
			
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		

	}
	public void addGrpDelta(Document benefitDocument) {

		double currMonPrem =0.0, diff=0.0 ;
		double monPrem =0.0, delta =0.0;
		try{
		currMonPrem = benefitDocument.getDouble(IConstants.CURR_MON_PREMIUM);
		monPrem = benefitDocument.getDouble(IConstants.MON_PREM);
		diff = monPrem-currMonPrem;
		//BPP-23123-Renewals Dashboard - Question mark (junk character) 
		//displayed for "Change" field value-UI
		if(diff != 0.0 && currMonPrem != 0.0){
			delta = (diff/currMonPrem)*100;
		}
//		diff = Math.round(diff*100)/100;
//		delta = Math.round(delta*100)/100;
		
		}catch(Exception e)
		{
			logger.error("Exception:  " + e);
		}
		if(benefitDocument.getDouble("Delta") == null || benefitDocument.get("Delta").toString().isEmpty()){
			benefitDocument.remove("Delta");
			benefitDocument.append("Delta", delta);
		}
		//benefitDocument.append("Delta", delta);
		benefitDocument.append("Difference", diff);
	}
	
	@SuppressWarnings("unchecked")
	public Object getRenewalDocumentSDS(Tuple2<Object, BSONObject> bsonFilter, String sourceDb, String sourceColl,String dbType,String returnField) {
		try {
			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,sourceColl, dbType);
			
				//Document docRen = (Document) collcheck.find(new Document("GUID", bsonFilter._2.get("GUID").toString())).first();
				//List<Document> renDetails =  (List<Document>) docRen.get(returnField);
				
				List<Document> renDetails =  new ArrayList<Document>();
				FindIterable<Document> docs =  collcheck.find(new Document("ID",bsonFilter._2.get("ID").toString()).append("end-date", IConstants.MAX_DATE).append("status", "un-processed"));
				for(Document docRen : docs){
					List<Document> details =  (List<Document>) docRen.get(IConstants.RENEWAL_DETAILS);
					renDetails.addAll(details);
				}
				return renDetails;
			
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			}
		return null;

	} 
}
