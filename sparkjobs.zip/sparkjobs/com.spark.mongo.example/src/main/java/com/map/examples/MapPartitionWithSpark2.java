package com.map.examples;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.MapPartitionsFunction;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class MapPartitionWithSpark2 implements Serializable {

	public static void main(String[] args) {

		SparkSession spark = SparkSession.builder().master("local").appName("MongoSparkConnectorIntro")
				.config("spark.mongodb.input.uri", "mongodb://127.0.0.1/test.test")
				.config("spark.mongodb.output.uri", "mongodb://127.0.0.1/test.test").getOrCreate();

		// Create a Java Spark Context from a Spark Session
		JavaSparkContext jsc = new JavaSparkContext(spark.sparkContext());

		Dataset<Row> inputfileDf = spark.read().format("csv") //
				.option("multiline", true) //
				.option("sep", ";") //
				.option("quote", "^") //
				.option("dateFormat", "M/d/y") //
				.option("inferSchema", false) //
				.load("src/main/resources/group.txt");

		Dataset<String> mappedData = inputfileDf.mapPartitions(new MapPartitionsFunction<Row, String>() {
			@Override
			public Iterator<String> call(Iterator<Row> it) {
				List<String> ls = new ArrayList<>();

				System.out.println("MapPartitionsFunction - call() method is invoked");
				while (it.hasNext()) {
					ls.add(it.next().toString());
				}
				return ls.iterator();
			}
		}, Encoders.javaSerialization(String.class)

		);

		mappedData.show(false);
		
		

	}

}
