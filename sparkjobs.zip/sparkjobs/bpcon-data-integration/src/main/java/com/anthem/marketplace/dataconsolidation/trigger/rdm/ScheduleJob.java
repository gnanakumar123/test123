package com.anthem.marketplace.dataconsolidation.trigger.rdm;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;

import org.quartz.DisallowConcurrentExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.execution.Start;
import com.anthem.marketplace.dataconsolidation.job.processor.IngestRDM;
import com.anthem.marketplace.dataconsolidation.job.processor.IngestSDS;
import com.anthem.marketplace.dataconsolidation.job.processor.IngestTDM;
import com.anthem.marketplace.dataconsolidation.job.processor.IngestUDM;
import com.anthem.marketplace.dataconsolidation.utils.GuidProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.ProcessGuid;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.Utility;

/*
 * This class Schedules execution of an application after certain interval
 */
@DisallowConcurrentExecution
public class ScheduleJob implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static final Logger logger = LoggerFactory.getLogger(ScheduleJob.class);

	/*
	 * It is called by a Scheduler class object This method calls Ingestion
	 * class based on job
	 * 
	 * @param context stores job details
	 * 
	 * @return nothing
	 * 
	 * @exception JobExecutionException
	 */
	public void execute(String type) throws Exception {

		ProcessGuid procGuid = null;
		try {
			procGuid = GuidProperties.getInstance().getPropertyContext(type);
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			
		}

		ProcessInput processInput = Start.inputProperties.get(type);
		logger.info("---processInput.getArraySourcePath()---" + processInput.getArraySourcePath()); 
		for (String strTemp : processInput.getArraySourcePath()) {
			String fileAbsPath = strTemp;
			String guid = procGuid.getGuid();
			String failedCollection = processInput.getFailedCollection();
			String strType = IConstants.STR_TYPE_PATH + processInput.getFileType();

			IngestRDM irdObj = new IngestRDM();

			irdObj.ingest(processInput, fileAbsPath, guid, strType);

			Utility.setIngestion(type);

			if (Utility.runTransformation(type)) {
				
				IngestTDM transform = new IngestTDM();

				transform.readAndTransform(processInput, strType, failedCollection,ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(IConstants.SOURCE_PATH_FIELD, fileAbsPath, IConstants.VALUE));

				Utility.setTransformation(type);

				String UDMtargetDetailCollection = processInput.getUDMTargetDetailCollection();
				IngestUDM udm = new IngestUDM();
				udm.readAndUDMTransform(processInput, UDMtargetDetailCollection, strType,
						ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(IConstants.SOURCE_PATH_FIELD, fileAbsPath, IConstants.VALUE));

				String sdstargetDetailCollection = processInput.getSDSTargetDetailCollection();

				String sdsStatement = processInput.getSDSCommissionStatement();

				IngestSDS sds = new IngestSDS();

				sds.readAndSDSTransform(processInput, sdstargetDetailCollection, strType, sdsStatement,
						ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(IConstants.SOURCE_PATH_FIELD, fileAbsPath, IConstants.VALUE));

				//Utility.restoreHashMap(type);

			}
		}
	}

		
}