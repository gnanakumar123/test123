package com.anthem.marketplace.dataconsolidation.model;

import java.io.Serializable;
import java.util.List;

public class VARenewal implements Serializable {

	Contract contract;
	PolicyHolderData policyHolderData;
	PolicyHolderDetails policyHolderDetails;
	SpouseDetails spouseDetails;
	List<DependentDetails> dependentDetails;
	AgentInfo agentInfo;
	AgencyInfo agencyInfo;
	public Contract getContract() {
		return contract;
	}
	public void setContract(Contract contract) {
		this.contract = contract;
	}
	public PolicyHolderData getPolicyHolderData() {
		return policyHolderData;
	}
	public void setPolicyHolderData(PolicyHolderData policyHolderData) {
		this.policyHolderData = policyHolderData;
	}
	public PolicyHolderDetails getPolicyHolderDetails() {
		return policyHolderDetails;
	}
	public void setPolicyHolderDetails(PolicyHolderDetails policyHolderDetails) {
		this.policyHolderDetails = policyHolderDetails;
	}
	public SpouseDetails getSpouseDetails() {
		return spouseDetails;
	}
	public void setSpouseDetails(SpouseDetails spouseDetails) {
		this.spouseDetails = spouseDetails;
	}
	public List<DependentDetails> getDependentDetails() {
		return dependentDetails;
	}
	public void setDependentDetails(List<DependentDetails> dependentDetails) {
		this.dependentDetails = dependentDetails;
	}
	public AgentInfo getAgentInfo() {
		return agentInfo;
	}
	public void setAgentInfo(AgentInfo agentInfo) {
		this.agentInfo = agentInfo;
	}
	public AgencyInfo getAgencyInfo() {
		return agencyInfo;
	}
	public void setAgencyInfo(AgencyInfo agencyInfo) {
		this.agencyInfo = agencyInfo;
	}
}
