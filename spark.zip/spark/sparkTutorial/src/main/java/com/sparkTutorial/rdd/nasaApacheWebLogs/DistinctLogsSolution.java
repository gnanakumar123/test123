package com.sparkTutorial.rdd.nasaApacheWebLogs;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class DistinctLogsSolution {

    public static void main(String[] args) throws Exception {

        SparkConf conf = new SparkConf().setAppName("distinctLogs").setMaster("local[*]");

        JavaSparkContext sc = new JavaSparkContext(conf);

        JavaRDD<String> julyFirstLogs = sc.textFile("in/nasa_19950701.tsv");

        JavaRDD<String> cleanLogLines = julyFirstLogs.filter(line -> isNotHeader(line));

        JavaRDD<String> hostNames = cleanLogLines.map(line -> line.split("-")[0]);
        JavaRDD<String> distinctHosts = hostNames.distinct();
        

        distinctHosts.saveAsTextFile("out/distinct_hosts.csv");
    }

    private static boolean isNotHeader(String line) {
        return !(line.startsWith("host") && line.contains("bytes"));
    }
}
