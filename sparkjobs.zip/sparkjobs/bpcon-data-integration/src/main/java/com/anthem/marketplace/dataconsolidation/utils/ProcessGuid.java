package com.anthem.marketplace.dataconsolidation.utils;

/*
 * Class file for GUID  
 */

public class ProcessGuid {
	
	private String type;
	private String guid;

	public ProcessGuid(){
		super();
	}
	
	public ProcessGuid(String type){
		this.type = type;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}	

	

	@Override
	public String toString() {
		return "{type=" + this.type + ", guid=" + this.guid + "}";
	}

	public String getGuid() {
		return guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}
}