package com.anthem.marketplace.dataconsolidation.utils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CDCProperties {

	static final Logger logger = LoggerFactory.getLogger(CDCProperties.class);
	private static HashMap<String, String> hashMapproperty;
	private static CDCProperties instance;

	private CDCProperties() throws IOException, NoSuchMethodException, ClassNotFoundException,
			InvocationTargetException, IllegalAccessException {
		hashMapproperty = readProp("cdc.properties");
	}

	public ProcessCDC getPropertyContext(String collection) throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		ProcessCDC process = new ProcessCDC();

		for (String key : hashMapproperty.keySet()) {
			String[] keys = key.split(IConstants.SPLIT_DOT);
			if (keys[0].equals(collection)) {

				Class<?> cls = Class.forName("com.anthem.marketplace.dataconsolidation.utils.ProcessCDC");
				String tempPropertyValue = hashMapproperty.get(key);
				Method method = cls.getDeclaredMethod("set" + keys[1], String.class);
				method.invoke(process, tempPropertyValue);
			}
		}
		return process;

	}

	public static synchronized CDCProperties getInstance() {
		if (instance == null) {
			try {
				instance = new CDCProperties();

			} catch (Exception e) {
				logger.error("Error{}", e);
			}
		}
		return instance;

	}

	private HashMap<String, String> readProp(String configpath) throws IOException, NoSuchMethodException,
			ClassNotFoundException, InvocationTargetException, IllegalAccessException {
		Properties prop = new Properties();
		prop.load(CDCProperties.class.getResourceAsStream("/" + configpath));
		Enumeration<?> propertyNames = prop.propertyNames();
		HashMap<String, String> propertyHashMap = new HashMap<>();
		while (propertyNames.hasMoreElements()) {
			String key = (String) propertyNames.nextElement();
			String Value = prop.getProperty(key);
			propertyHashMap.put(key, Value);
		}
		return propertyHashMap;
	}

}
