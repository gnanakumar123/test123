package com.anthem.marketplace.dataconsolidation.utils;

/*
 * Class file for CDC.properties
 */

public class ProcessCDC {

	private String collection;
	private String performCDC;
	
	public ProcessCDC() {
		super();
	}
	
	public ProcessCDC(String collection){
		this.collection = collection;
	}
	
	public String getCollection() {
		return collection;
	}
	public void setCollection(String collection) {
		this.collection = collection;
	}
	public String getPerformCDC() {
		return performCDC;
	}
	public void setPerformCDC(String performCDC) {
		this.performCDC = performCDC;
	}
	
	
}
