package com.anthem.marketplace.dataconsolidation.model;

import java.io.Serializable;
import java.util.Date;

public class DependentDetails implements Serializable {

	private String dependentFirstName;
	private String dependentLastName;
    private String dependentUwLevel;
    private Date dependentDateOfBirth;
    
	public String getDependentFirstName() {
		return dependentFirstName;
	}
	public void setDependentFirstName(String dependentFirstName) {
		this.dependentFirstName = dependentFirstName;
	}
	public String getDependentLastName() {
		return dependentLastName;
	}
	public void setDependentLastName(String dependentLastName) {
		this.dependentLastName = dependentLastName;
	}
	public String getDependentUwLevel() {
		return dependentUwLevel;
	}
	public void setDependentUwLevel(String dependentUwLevel) {
		this.dependentUwLevel = dependentUwLevel;
	}
	public Date getDependentDateOfBirth() {
		return dependentDateOfBirth;
	}
	public void setDependentDateOfBirth(Date dependentDateOfBirth) {
		this.dependentDateOfBirth = dependentDateOfBirth;
	}
}
