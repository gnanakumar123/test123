package com.anthem.marketplace.dataconsolidation.utils;

/*
 * This class creats singleton class for ReadMappingXml  
 */

public class ReadMappingXmlSingleton {
	
	private ReadMappingXml read;

	   //create an object of SingleObject
	   private static ReadMappingXmlSingleton instance;

	   //make the constructor private so that this class cannot be
	   //instantiated
	   private ReadMappingXmlSingleton(){		   
		   read = new ReadMappingXml();		   
	   }

	   //Get the only object available
	   public ReadMappingXml getRead() {
			return read;
		}

	// Get the only object available
	public static synchronized ReadMappingXmlSingleton getInstance() {
		if (null == instance) {
			instance = new ReadMappingXmlSingleton();
		}
		return instance;
	}
}
