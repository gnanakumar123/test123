package com.anthem.marketplace.dataconsolidation.filesutils;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.bson.BSONObject;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.utils.ChangeDataCapture;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.FixedFileMetaDataProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFixedFileMetaData;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.BasicDBList;
import com.mongodb.client.MongoCollection;

import scala.Tuple2;

/*
 * This class implements UtilityInterface and Serializable and performs Ingestion, Transformation of NORTHEAST renewals input files
 * @author : MongoDB Team
 * @version : 1.0
 * @Date : June 2016
 * It returns nothing.
 */
public class ISG_NONACA_NE implements UtilityInterface, Serializable {

	private static final long serialVersionUID = 1L;
	static final Logger logger = LoggerFactory.getLogger(ISG_NONACA_NE.class);
	public static ArrayList<String> neglectList = new ArrayList<String>();
	public List<String> fieldsList;

	/*
	 * This method creates GUID
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param delimeted stores delimited character
	 * 
	 * @param readFileContent stores input file data
	 * 
	 * @param guidvalue stores guid values retrieve from properties file
	 * 
	 * @param type stores type of file
	 * 
	 * @return String GUID
	 */
	public String createGuid(String sourceCollection, String delimeted, Row readFileContent, String guidvalue,
			String type) {  		
		String guid = "";
		String errorFieldName = "";
		
		try {
			List<ProcessFixedFileMetaData> guidPosition = new ArrayList<>();

			for (String item : guidvalue.split(IConstants.SPLIT_COMMA)) {
				errorFieldName = item;
				guidPosition.add(FixedFileMetaDataProperties.getInstance().getPropertyContext(item, type));		//guid values using meta file with position
			}

			for (ProcessFixedFileMetaData item : guidPosition) {
				guid += (readFileContent.toString().substring(Integer.parseInt(item.getStart()),
						Integer.parseInt(item.getEnd()) + 1)).trim();
			}
			guid = guid.concat("IND").concat("SUBSCR");			//guid
		}
		// catch Exceptions and add respective errorCode and its description
		catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.GUID_ERROR_METHOD, "Exception:  "+ e,
					readFileContent.toString(), errorFieldName, IConstants.RENEWALS_ISG_NONACA_NE,IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  "+ e, readFileContent.toString(), errorFieldName, IConstants.RENEWALS_ISG_NONACA_NE,IConstants.RDM_DB);

		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.GUID_ERROR_METHOD, "Exception:  "+ e,
					readFileContent.toString(), errorFieldName, IConstants.RENEWALS_ISG_NONACA_NE,IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  "+ e, readFileContent.toString(), errorFieldName, IConstants.RENEWALS_ISG_NONACA_NE,IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  "+ e, readFileContent.toString(), errorFieldName, IConstants.RENEWALS_ISG_NONACA_NE,IConstants.RDM_DB);
		}

		return guid;
	}

	/*
	 * This method checks mandatory fields for file for data Quality check
	 * @param sourceCollection stores collection name
	 * @param delimeted stores delimited character
	 * @param readFileContent stores input file data
	 * @param type stores type of file
	 * @return boolean value based on data Quality check passed.
	 */
	public boolean createFlag(String delimeted, String sourceCollection, Row readFileContent, String type) {
		boolean flag = false;
		ProcessFixedFileMetaData metadata;
		String errorFieldName = "";
		try {
			// determine which files are mandatory from mapping.xml based on
			// type supplied
			Map<String, String> mandatoryFields = ReadMappingXmlSingleton.getInstance().getRead()
					.getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);
			for (String item : mandatoryFields.values()) {
				errorFieldName = item;
				metadata = FixedFileMetaDataProperties.getInstance().getPropertyContext(item, type);
				// check if mandatoryFields available in input content file
				flag = (readFileContent.toString()
						.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()))
						.trim() == null)
						|| readFileContent.toString()
								.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()))
								.trim().isEmpty();

				if (flag)
					break;
			}
			// if false then set error as null value found for mandatory fields.
			if (flag) {
				Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
						IConstants.DATA_QUALITY_ERROR_CHECK, readFileContent.toString(), errorFieldName, IConstants.RENEWALS_ISG_NONACA_NE,IConstants.RDM_DB);
			}
		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  "+ e,readFileContent.toString(),errorFieldName,IConstants.RENEWALS_ISG_NONACA_NE,IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  "+ e,readFileContent.toString(),errorFieldName,IConstants.RENEWALS_ISG_NONACA_NE,IConstants.RDM_DB);

		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  "+ e,readFileContent.toString(),errorFieldName,IConstants.RENEWALS_ISG_NONACA_NE,IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  "+ e,readFileContent.toString(),errorFieldName,IConstants.RENEWALS_ISG_NONACA_NE,IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  "+ e,readFileContent.toString(),errorFieldName,IConstants.RENEWALS_ISG_NONACA_NE,IConstants.RDM_DB);
		}
		return flag;
	}

	/*
	 * This method adds fileName and its respective value to a document and returns it.
	 * @param processInput stores input properties related parameters
	 * 
	 * @param sourcePath stores source path of input file
	 * 
	 * @param guid stores GUID
	 * 
	 * @param flag stores value retrieve from data Quality check method
	 * 
	 * @param readFileContent stores Row of a input file
	 * 
	 * @return Document
	 */
	public Document appendRaw(ProcessInput processInput, String sourcePath, String guid, boolean flag,
			Row readFileContent) {

		String type = processInput.getType();	//Renewals_ISG_NONACA

		String sourceDB = processInput.getSourceDB();	//bpconadsDB
		String sourceCollection = processInput.getSourceCollection();	//Renewals_ISG_NONACA
		String value;
		ProcessFixedFileMetaData metadata;
		ProcessFieldNames procFieldNames;
		boolean checkFlag = false;
		String errorFieldName = "";

		Document doc = new Document();
		try {
			procFieldNames = FieldNamesProperties.getInstance().getPropertyContext(type);		//getting field Name (hcid,firstName,middleName,lastName,careOf,Address,city,state,zipCode,medContractCode,medContractType,medCurrentPlanEffDate,ratingLevel,medOldRate,medNewRate,phone,medAnniversaryMonth,email,medBrokerWritingTin,medBrokerPaidTin,medBrokerParentTin,medSlsChnlID,denContractCode,denContractType,denCurrentPlanEffDate,denOldRate,denNewRate,denAnniversaryMonth,denBrokerWritingTin,denBrokerPaidTin,denBrokerParentTin,denSlsChnlID)
			doc.append(IConstants.GUID, guid);

			// for each filedNames
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				errorFieldName = fieldNames;
				// get dataType for each fieldName for given collectionName
				String dataType = ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(type,
						fieldNames, IConstants.DATATYPE);  //mapping.xml

				metadata = FixedFileMetaDataProperties.getInstance().getPropertyContext(fieldNames, type);
				// Getting the value of each field from the feed file by passing the start Postion and & end Postion 
				// Ex. facets_renewal_NE.brkrTin.start=691 ; facets_renewal_NE.brkrTin.end=699 and Value is : '001464640'
				value = readFileContent.toString()
						.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()) + 1)
						.trim();		
				// if empty value then append it as it is to document
				if (value.isEmpty())
					doc.append(fieldNames, value);		//eg, hcid,value

				// else change its dataType as specified and convert zonal
				// fields to zonal decimal number
				else {
					checkFlag = Utility.applyZone(sourceCollection, fieldNames, value.trim(), doc, dataType,
							readFileContent, IConstants.ISG_NONACA);		//check for  value against datatype
				}

			}
	/* Start BPP-24163 : ISGNONACA NE*/
	if ((null != doc.getDouble("medOldRate"))){
	/* End BPP-24163 : ISGNONACA NE*/	
			if ((doc.getString(IConstants.MEDBROKERWRITINGTIN).trim().equals("")
					|| doc.getString(IConstants.MEDBROKERWRITINGTIN).trim().equals(null))
					&& (doc.getString("denBrokerWritingTin").trim().equals("")
							|| doc.getString("denBrokerWritingTin").trim().equals(null)))
				doc.append(IConstants.MEDBROKERWRITINGTIN, "0");

			doc.replace("medOldRate", doc.getDouble("medOldRate") / 100);		//business logic
			doc.replace("medNewRate", doc.getDouble("medNewRate") / 100);
			doc.replace("denOldRate", doc.getDouble("denOldRate") / 100);
			doc.replace("denNewRate", doc.getDouble("denNewRate") / 100);
			
			}
			// insert metaData
			Utility.insertMetadata(doc, sourceDB, sourceCollection, guid, sourcePath, "ACES", flag,true,IConstants.RDM_DB);

			// catch Exceptions and add respective errorCode and its description
		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.RENEWALS_ISG_NONACA_NE, IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.RENEWALS_ISG_NONACA_NE, IConstants.RDM_DB);
		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.RENEWALS_ISG_NONACA_NE, IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.RAW_DATA,
					"Exception:  "+ e, readFileContent.toString(), errorFieldName, IConstants.RENEWALS_ISG_NONACA_NE,IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.RENEWALS_ISG_NONACA_NE, IConstants.RDM_DB);
		}

		return doc;
	}

	/*
	 * This method selects attributes to decide fields to be selected from NORTHEAST Raw data.
	 * 
	 * @param fieldNames stores field names
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param collName stores collection name
	 * 
	 * @return attribute name
	 */
	public String selectFields(String fieldNames, Tuple2<Object, BSONObject> bsonFilter, String collName) {
		
//fieldName= GUID,ID,type,relationship,clientReference,renewalMonth,renewalPeriod,renewalDate,estimatedLetterMailDate,currentMonthlyPremium,currentTotalPremium,currentPremiumwithoutSubsidy,currentPremiumwithSubsidy,currentRatingArea,currentSubsidy,renewalMonthlyPremium,renewalTotalPremium,renewalPremium,renewalPremiumwithoutSubsidy,renewalPremiumwithSubsidy,renewalRatingArea,renewalSubsidy,effectiveDate,renewalOptions,underwritingLevel,parentTIN,payeeTIN,writingTIN,exchangeIndicator,language,letterCode,letterCodeFlag,dentalEligibleEmployees,visGuaranteeMonths,denGuaranteeMonths,denPriorCoverage,saveAndGenerateFlag,renewalPacketToken,medicalFactorFlag,lifeFlag,enableGviFlag,MBUType,groupChangeInd,memberChangeInd,dentalSubscriberCnt,visionSubscriberCnt,targetDntlElgibleLivesCnt,targetVisElgibleLivesCnt,currDntlElgibleLivesCnt,currVisElgibleLivesCnt,dentalPriorCoverage
//(fieldName, bsonFilter, Renewals_tdm_Renewal)
		if (ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField(IConstants.RENEWALS_ISG_NONACA_NE.concat(collName), fieldNames, IConstants.PROD_TYPE) //Renewals_ISG_NONACA.Renewals_tdm_Renewal
				.equals(IConstants.STRING_FALSE))
			return IConstants.VALUE;
		/* Start BPP-24163 : ISGNONACA NE*/	
		else if (( null != bsonFilter._2.get("plcyTypeCd") )
				&& (bsonFilter._2.get("plcyTypeCd").toString().trim().equals("M")))
			return IConstants.MEDICAL; 
		
		else if ((null != bsonFilter._2.get("plcyTypeCd"))
				&& (bsonFilter._2.get("plcyTypeCd").toString().trim().equals("D")))
			return IConstants.DENTAL; 
			/* End BPP-24163 : ISGNONACA NE*/
		
		else if ((bsonFilter._2.get(IConstants.MEDBROKERWRITINGTIN) == null)
				|| (bsonFilter._2.get(IConstants.MEDBROKERWRITINGTIN).toString().trim().equals("")))
			return IConstants.DENTAL;
		else
			return IConstants.MEDICAL;
	}

	public String selectMultiFields(String fieldNames, Tuple2<Object, BSONObject> bsonFilter, String collName,
			String sourceCollection) {
		List<String> selectFieldsList = new ArrayList<String>();
		if (ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField(sourceCollection.concat(collName), fieldNames, IConstants.PROD_TYPE)
				.equals("false")) {
			return IConstants.VALUE;
	     }
		 else {

			if (!((bsonFilter._2.get(IConstants.MEDBROKERWRITINGTIN) == null)
					|| (bsonFilter._2.get(IConstants.MEDBROKERWRITINGTIN).toString().trim().equals("")))) {
				selectFieldsList.add(IConstants.MEDICAL);
			}
			if (!((bsonFilter._2.get(IConstants.DENBROKERWRITINGTIN) == null)
					|| (bsonFilter._2.get(IConstants.DENBROKERWRITINGTIN).toString().trim().equals("")))) {
				selectFieldsList.add(IConstants.DENTAL);
			}
			/* Start BPP-24163 : ISGNONACA NE*/	
			if (null != (bsonFilter._2.get("plcyTypeCd") )
					&& (bsonFilter._2.get("plcyTypeCd").toString().trim().equals("M")))
				selectFieldsList.add(IConstants.MEDICAL);
			
			if (null != (bsonFilter._2.get("plcyTypeCd"))
					&& (bsonFilter._2.get("plcyTypeCd").toString().trim().equals("D")))
				selectFieldsList.add(IConstants.DENTAL); 
			 /* End BPP-24163 : ISGNONACA NE*/
		}
		if (selectFieldsList.size() > 0)
			fieldsList = selectFieldsList;
		return "Multi";
	}

	/*
	 * This method performs transformation on NORTHEAST Raw data.
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source collection name
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param targetCollection stores target collection name
	 * 
	 * @param appendedCollection stores collection name whose data to be
	 * appended as embedded doc. i.t summary to detail
	 * 
	 * @return transformed Document
	 */
	public Document ingestTDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String transColl, String appendedCollection) {
		//For loop 1: (bpconadsDB , Renewals_ISG_NONACA, bsonFilter, bpconadsDB,Renewals_tdm_Renewal,  )
		// for loop 2: (bpconadsDB , Renewals_ISG_NONACA, bsonFilter, bpconadsDB,Renewals_tdm_Client,appendedCollection={renewals,agents,contacts})
		Document metaDoc = new Document();
		boolean flag = false;
		String guid = "";
		ProcessFieldNames procFieldNames = null;
		String sourcePath = "";
		ProcessFieldNames clientFieldNames = null;
		neglectList.add("");
		neglectList.add(null);
		try {
			clientFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.RENEWALS_ISG_NONACA_NE.concat(transColl).toString());  //Renewals_RENEWALS_ISG_NONACA_NERenewals_tdm_Renewal
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e1) {
			logger.error(IConstants.ERROR_PREPEND, e1);

		}

		for (String fieldNames : clientFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) 
		{
		//Renewals_ISG_NONACARenewals_tdm_Renewal.ArrayFieldName filedName= GUID,ID,type,relationship,clientReference,renewalMonth,renewalPeriod,renewalDate,estimatedLetterMailDate,currentMonthlyPremium,currentTotalPremium,currentPremiumwithoutSubsidy,currentPremiumwithSubsidy,currentRatingArea,currentSubsidy,renewalMonthlyPremium,renewalTotalPremium,renewalPremium,renewalPremiumwithoutSubsidy,renewalPremiumwithSubsidy,renewalRatingArea,renewalSubsidy,effectiveDate,renewalOptions,underwritingLevel,parentTIN,payeeTIN,writingTIN,exchangeIndicator,language,letterCode,letterCodeFlag,dentalEligibleEmployees,visGuaranteeMonths,denGuaranteeMonths,denPriorCoverage,saveAndGenerateFlag,renewalPacketToken,medicalFactorFlag,lifeFlag,enableGviFlag,MBUType,groupChangeInd,memberChangeInd,dentalSubscriberCnt,visionSubscriberCnt,targetDntlElgibleLivesCnt,targetVisElgibleLivesCnt,currDntlElgibleLivesCnt,currVisElgibleLivesCnt,dentalPriorCoverage
		String selectFieldAttribute = selectFields(fieldNames, bsonFilter, transColl); // (fieldName, bsonFilter, Renewals_tdm_Renewal)
			
				if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
							IConstants.RENEWALS_ISG_NONACA_NE.concat(transColl), fieldNames, selectFieldAttribute))))
						{
							/* Start BPP-24163 : ISGNONACA NE : Encrypting the 'brkrTin' and appending it as 'taxID' in 'Renewals_tdm_Renewal' collection   */ 
							if (null != (fieldNames) && fieldNames.equals(IConstants.BRKRTIN)) 
							{
								String taxID = encryptTaxId(bsonFilter._2.get(IConstants.BRKRTIN).toString(), targetDb);
								metaDoc.append(IConstants.TAX_ID, taxID);
							}/* End BPP-24163 : ISGNONACA NE*/ 
						else {
							metaDoc.append(fieldNames,
							bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
									IConstants.RENEWALS_ISG_NONACA_NE.concat(transColl), fieldNames, selectFieldAttribute)));
							}
						}
			metaDoc.append("type", "IND");
			metaDoc.append("relationship", "SUBSCR");
		} /*End of clientFieldNames for loop*/
		List<Document> innerDocList = new ArrayList<Document>();
		if (transColl.contains("Renewals_tdm_Renewal")) {
			fieldsList = new ArrayList<String>();
			try {
				procFieldNames = FieldNamesProperties.getInstance().getPropertyContext(IConstants.ISG_NONACA_NE_REN_DET);
			} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
					| IllegalArgumentException | InvocationTargetException e) {
				logger.error(IConstants.ERROR_PREPEND, e);

			}
			do {
				Document doc = new Document();

				String product = "";
				for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
					String selectFieldAttribute = selectFields(fieldNames, bsonFilter, IConstants.RENEWAL_DETAILS);

					if (!selectFieldAttribute.equals(IConstants.VALUE)) {
						if (fieldsList.size() == 0)
							selectMultiFields(fieldNames, bsonFilter, IConstants.RENEWAL_DETAILS, sourceCollection);

						if (fieldsList.size() > 0) {
							selectFieldAttribute = fieldsList.get(0);
							product = selectFieldAttribute.toUpperCase();
						}

					}

					if (!neglectList.contains(
							bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
									IConstants.ISG_NONACA_NE_REN_DET, fieldNames, selectFieldAttribute))))
					{
						/* Start BPP-24163 : ISGNONACA NE : Encrypting the 'brkrTin' and appending it as 'taxID' in 'Benefits' document under 'Renewals_tdm_Renewal' collection   */ 
						if (null != (fieldNames) && fieldNames.equals(IConstants.BRKRTIN)) 
						{
							String taxID = encryptTaxId(bsonFilter._2.get(IConstants.BRKRTIN).toString(), targetDb);
							doc.append(IConstants.TAX_ID, taxID);

						} /* End BPP-24163  */ 
						else 
						 {
							doc.append(fieldNames,bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(IConstants.ISG_NONACA_NE_REN_DET, fieldNames, selectFieldAttribute)));
						  }
					   }
				}/*End of for loop "procFieldNames"*/
				if (product.equals("PD"))
					product = "VIS";

				if (product.length() > 2)
					product = product.substring(0, 3);
				doc.append(IConstants.PRODUCT, product);
				List<Document> renewalProducts = getGrpRenewalProducts(sourceCollection, doc, bsonFilter._2(), metaDoc);
				doc.append("renewalProducts", renewalProducts);
				if (fieldsList.size() > 0)
					fieldsList.remove(0);

				innerDocList.add(doc);
			} while (fieldsList.size() > 0);
			metaDoc.append(IConstants.BENEFITS, innerDocList);
		}/* end of for 'if' Renewals_tdm_Renewal */

		else {
			int year = Calendar.getInstance().get(Calendar.YEAR);
			for (String coll : appendedCollection.split(IConstants.SPLIT_COMMA)) {
				Document doc = new Document();
				try {
					procFieldNames = FieldNamesProperties.getInstance()
							.getPropertyContext(IConstants.RENEWALS_ISG_NONACA_NE.concat(coll));
				} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
						| IllegalArgumentException | InvocationTargetException e) {
					logger.error(IConstants.ERROR_PREPEND, e);

				}
				BasicDBList docList = new BasicDBList();
				BasicDBList contDocList = new BasicDBList();
				if (coll.toString().equals(IConstants.CLIENT_AGENT)) {
					String[] arr = { "medical", "dental" };

					for (String taxid : arr) {
						String[] types = { "Writing", "Paid", "Parent" };
						for (String type : types) {
							Document addrDoc = new Document();
							for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
								if (ReadMappingXmlSingleton.getInstance().getRead()
										.getAttributeValueOfField(IConstants.RENEWALS_ISG_NONACA_NE.concat(coll), fieldNames,
												IConstants.PROD_TYPE)
										.equals(IConstants.STRING_TRUE)) {
									if (fieldNames.equals(IConstants.PRODUCT)) {

										String product = taxid.toUpperCase();

										if (product.length() > 2)
											product = product.substring(0, 3);
										addrDoc.append(fieldNames, product);
									} else if (fieldNames.equals("taxID")) {

										addrDoc.append(fieldNames,
												bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
														.getAttributeValueOfField(sourceCollection + "taxID",
																taxid + type, IConstants.VALUE)));

									}

									else if (!neglectList.contains(bsonFilter._2.get(
											ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
													IConstants.RENEWALS_ISG_NONACA_NE.concat(coll), fieldNames, taxid))))
										addrDoc.append(fieldNames,
												bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
														.getAttributeValueOfField(IConstants.RENEWALS_ISG_NONACA_NE.concat(coll),
																fieldNames, taxid)));
								}

								else if (fieldNames.equals(IConstants.TAX_ID_TYPE)) {
									addrDoc.append(fieldNames, type);
								} else if (!neglectList.contains(bsonFilter._2
										.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
												IConstants.RENEWALS_ISG_NONACA_NE.concat(coll), fieldNames, IConstants.VALUE))))

									addrDoc.append(fieldNames,
											bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
													.getAttributeValueOfField(IConstants.RENEWALS_ISG_NONACA_NE.concat(coll),
															fieldNames, IConstants.VALUE)));

							}
							addrDoc.append("agentID", addrDoc.get("taxID"));
							if (!((addrDoc.get("taxID") == null) || (addrDoc.get("taxID").equals("")))){
								// updated for BPP -8989 agent name
								populateEncytedFields(addrDoc, addrDoc.get("agentID").toString(), targetDb);
								docList.add(addrDoc);
							}
						}
					}

					metaDoc.append(coll, docList);

				} else if (coll.toString().equals(IConstants.CLIENT_CONTACTS)) {
					Document d = new Document();
					for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

						String selectFieldAttribute = selectFields(fieldNames, bsonFilter, coll);
						if (fieldNames.equals("addressType")) {
							d.append(fieldNames, IConstants.DEFAULT);
						} else if (fieldNames.equals("renewalPeriod"))
							d.append(fieldNames, year);
						else if (!neglectList.contains(bsonFilter._2
								.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
										IConstants.RENEWALS_ISG_NONACA_NE.concat(coll), fieldNames, selectFieldAttribute))))
							d.append(fieldNames,
									bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
											.getAttributeValueOfField(IConstants.RENEWALS_ISG_NONACA_NE.concat(coll), fieldNames,
													selectFieldAttribute)));

					}
					contDocList.add(d);
					metaDoc.append(coll, contDocList);
				}else if (coll.toString().equals(IConstants.AGENT)) {
					
					ArrayList<String> productarray=new ArrayList<String>();
					if(null != (bsonFilter._2.get("plcyTypeCd")) && bsonFilter._2.get("plcyTypeCd").equals("M"))
					{
						productarray.add("medical");
					}else
					{
						productarray.add("dental");
					}
					
					String[] types = { "Writing", "Paid", "Parent" };
									
					for (String taxid : productarray) {
						
						for (String type : types) 
						{
							Document addrDoc = new Document();
							for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) 
							{
								if (ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(IConstants.RENEWALS_ISG_NONACA_NE.concat(coll), fieldNames,IConstants.PROD_TYPE)
										.equals(IConstants.STRING_TRUE)) 
								{
									if (fieldNames.equals(IConstants.PRODUCT)) 
									{
										String product = taxid.toUpperCase();
										
											if (product.length() > 2)
											product = product.substring(0, 3);
											addrDoc.append(fieldNames, product);
											
									} else if (fieldNames.equals("taxID")) 
									{
										addrDoc.append(fieldNames,bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(sourceCollection + "taxID",
																taxid + type, IConstants.VALUE)));
									}
									else if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(IConstants.RENEWALS_ISG_NONACA_NE.concat(coll),fieldNames, taxid))))
										{
											addrDoc.append(fieldNames,bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(IConstants.RENEWALS_ISG_NONACA_NE.concat(coll), fieldNames, taxid)));
										}
								}
								
								 else if (null != (fieldNames) && fieldNames.equals("taxID")) 
									{
										
										/* Start BPP-24163 : ISGNONACA NE : Encrypting the 'brkrTin' and appending it as 'taxID' in 'agents' document under 'Renewals_tdm_Client' collection   */ 
										String taxID = encryptTaxId(bsonFilter._2.get(IConstants.BRKRTIN).toString(), targetDb);
										addrDoc.append(fieldNames,taxID);
										/* End BPP-24163 : ISGNONACA NE*/
									}
								
								else if (null != (fieldNames) && fieldNames.equals(IConstants.TAX_ID_TYPE)) 
								{
									addrDoc.append(fieldNames, type);
								} else if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(IConstants.RENEWALS_ISG_NONACA_NE.concat(coll), fieldNames, IConstants.VALUE))))
								{
									addrDoc.append(fieldNames,bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(IConstants.RENEWALS_ISG_NONACA_NE.concat(coll),fieldNames, IConstants.VALUE)));
								}
							}/*End of 'forLoop' : procFieldNames*/
							addrDoc.append("agentID", addrDoc.get("taxID"));
							  if (!((null == addrDoc.get("taxID") || addrDoc.get("taxID").equals("")))){
								// updated for BPP -8989 agent name
								populateEncytedFields(addrDoc, addrDoc.get("agentID").toString(), targetDb);
								docList.add(addrDoc);
							}
						}
					}
					metaDoc.append("agents", docList);
				}/*End of  'if' coll : agent [IConstants.AGENT] */
				/**/
				else {
					for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
						String selectFieldAttribute = selectFields(fieldNames, bsonFilter, coll);
						if (fieldNames.equals("addressType")) {
							doc.append(fieldNames, IConstants.DEFAULT);
						} else if (fieldNames.equals("renewalPeriod"))
							doc.append(fieldNames, year);
						else if (!neglectList.contains(bsonFilter._2
								.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
										IConstants.RENEWALS_ISG_NONACA_NE.concat(coll), fieldNames, selectFieldAttribute))))
							doc.append(fieldNames,
									bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
											.getAttributeValueOfField(IConstants.RENEWALS_ISG_NONACA_NE.concat(coll), fieldNames,
													selectFieldAttribute)));
					}
					metaDoc.append(coll, doc);
				}
			}
		}

		sourcePath = bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString();

		guid = metaDoc.get(IConstants.GUID).toString();
		// insert metaData
		Utility.insertMetadata(metaDoc, targetDb, transColl, guid, sourcePath, "ACES", flag, true,
				IConstants.TDM_DB);

		if (metaDoc.getString(IConstants.REN_ID) != null)
			return metaDoc;

		else
			return null;
	}
	
	// Added for BPP -8989 agent name
	private void populateEncytedFields(Document doc, String key, String targetDb) {
		try {
			
			if (key != null && key.length() > 0) {
				MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail("enrollmentDB","brokerinfo", "APP");
				
				Document docRen = (Document) collcheck.find(new Document("encryptedTin",key)).first();
				
					if(docRen != null && docRen.getString("agentOrAgencyName") != null && !(docRen.getString("agentOrAgencyName").equalsIgnoreCase("NULL"))){
							doc.append("name", docRen.getString("agentOrAgencyName"));
					}
					else{
							doc.append("name", "");
					}
			}
			
			
		} catch (Exception e) {
			logger.error(key + "Can't fetch from DumpFiles");
		}

	}
	
		/* Start BPP-24163 : ISGNONACA NE 
		 * encryptTaxId() is used to encrypt the 'Tin' which is present in feed file, if it was not encrypted */
	private String encryptTaxId(String key, String targetDb) {
		String encryptedTaxId="";
		try {
			if (key != null && key.length() > 0) {
				MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(targetDb,"lookup_prod", IConstants.TDM_DB);
							
				Document encryren = (Document) collcheck.find(new Document("encryptedTaxId",key)).first();
				/* Checking whether 'Tin'/'Taxid' is encrypted */	
				if (null != encryren)
				{
					return key;
				}
				else {
					/*By passing the 'Taxid'/'Tin' to 'lookup_prod' collection and fetching the respective encryptedTaxid*/
					Document docRen = (Document) collcheck.find(new Document("agentTaxId",key)).first();
					if(null != docRen && docRen.getString("encryptedTaxId") != null && !(docRen.getString("encryptedTaxId").equalsIgnoreCase("NULL"))){
							encryptedTaxId = docRen.getString("encryptedTaxId");
					}
				}
			}
			
		} catch (Exception e) {
			logger.error("EncryptedTaxid is not present for this '"+key+"' in the 'lookup_prod' collection");
		}
		return encryptedTaxId;

	}
	/* End BPP-24163 : ISGNONACA NE*/

	public List<Document> getRenewalProducts(String sourceCollection, Document outerDoc, BSONObject bsonObject) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}
			double monPrem = 0.0, currMonPrem = 0.0;
			try {
				if ((bsonObject.get("medOldRate") != null) && bsonObject.containsKey("medOldRate")) {
					currMonPrem += (Double) bsonObject.get("medOldRate");
					doc.remove("renewalMonthlyPremium");
				}
				if ((bsonObject.get("denOldRate") != null) && bsonObject.containsKey("denOldRate")) {
					currMonPrem += (Double) bsonObject.get("denOldRate");

				}
				if (bsonObject.get("medNewRate") != null && bsonObject.containsKey("medNewRate")) {
					monPrem += (Double) bsonObject.get("medNewRate");

				}
				if (bsonObject.get("denNewRate") != null && bsonObject.containsKey("denNewRate")) {
					monPrem += (Double) bsonObject.get("denNewRate");

				}
			} catch (Exception e) {
				logger.error(IConstants.ERROR_PREPEND, e);
			}
			doc.append(IConstants.MON_PREM, monPrem);
			if (outerDoc.containsKey(IConstants.CURR_MON_PREMIUM))
				outerDoc.remove(IConstants.CURR_MON_PREMIUM);
			outerDoc.append(IConstants.CURR_MON_PREMIUM, currMonPrem);
			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	

	public List<Document> getGrpRenewalProducts(String sourceCollection, Document outerDoc, BSONObject bsonObject, Document metaDoc)
	{
		List<Document> renewalProducts  = new ArrayList<>(); 
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}
			double monPrem = 0.0, currMonPrem = 0.0;
			try {
				if ((bsonObject.get("medOldRate") != null) && bsonObject.containsKey("medOldRate")) {
					currMonPrem += (Double) bsonObject.get("medOldRate");
					doc.remove("renewalMonthlyPremium");
				}
				if ((bsonObject.get("denOldRate") != null) && bsonObject.containsKey("denOldRate")) {
					currMonPrem += (Double) bsonObject.get("denOldRate");

				}
				if (bsonObject.get("medNewRate") != null && bsonObject.containsKey("medNewRate")) {
					monPrem += (Double) bsonObject.get("medNewRate");

				}
				if (bsonObject.get("denNewRate") != null && bsonObject.containsKey("denNewRate")) {
					monPrem += (Double) bsonObject.get("denNewRate");

				}
				/* Start BPP-24163 : ISGNONACA NE*/
				if ( null != (bsonObject.get("oldRate")) &&  bsonObject.containsKey("oldRate")) {
					currMonPrem += (Double) bsonObject.get("oldRate");
					doc.remove("renewalMonthlyPremium");
				}
				if ( null != (bsonObject.get("newRate")) && bsonObject.containsKey("newRate")) {
					monPrem += (Double) bsonObject.get("newRate");
				}
					/* End BPP-24163 : ISGNONACA NE*/
			} catch (Exception e) {
				logger.error(IConstants.ERROR_PREPEND, e);
			}
			if (metaDoc.containsKey(IConstants.MON_PREM))
				metaDoc.remove(IConstants.MON_PREM);
			metaDoc.append(IConstants.MON_PREM, monPrem);
			if (metaDoc.containsKey(IConstants.CURR_MON_PREMIUM))
				metaDoc.remove(IConstants.CURR_MON_PREMIUM);
			metaDoc.append(IConstants.CURR_MON_PREMIUM, currMonPrem);
			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	public List<Document> getRenewalProducts(String sourceCollection, Document outerDoc) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}
			double monPrem = 0.0;
			if (doc.containsKey("renewalMonthlyPremium")) {
				monPrem = doc.getDouble("renewalMonthlyPremium");
				doc.remove("renewalMonthlyPremium");
			}
			doc.append(IConstants.MON_PREM, monPrem);

			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	/*
	 * This method performs unified transformation on ASCS transformed data.
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source collection name
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param targetCollection stores target collection name
	 * 
	 * @param targetDetailCollection stores collection name whose data is
	 * appended as embedded doc. i.t summary to detail
	 * 
	 * @return transformed Document
	 */
	@SuppressWarnings("unchecked")
	public Document ingestUDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection) {

		Document metaDoc = new Document();
		try {
			metaDoc.putAll(bsonFilter._2.toMap());

			metaDoc.remove(IConstants.ID);
		} catch (Exception e) {
			logger.error("Exception:  " + e);
		}
		return metaDoc;
	}

	/*
	 * this method inserts data into mongoDB for given specifications
	 * 
	 * @processInput stores input related parameters
	 * 
	 * @sourcePath stores file location path
	 * 
	 * @guidvalue stores GUID
	 * 
	 * @priority stores priority of process
	 * 
	 * @strType stores type of input file.
	 * 
	 * @return nothing
	 */
	@Override
	public void ingestRDMprocess(ProcessInput processInput, String sourcePath, String guidvalue, String strType) { //(procesInput,/apps/Renewals/ISG_NONACA/NE,  
		List<Document> docList = new ArrayList<>();
		List<Document> failedList = new ArrayList<>();

		String sourceCollection = processInput.getSourceCollection();		//Renewals_ISG_NONACA
		String delimeted = processInput.getDelimeted();			//false
		String delimeter = processInput.getDelimeter();		//\\|
		String type = processInput.getType();			//ISG_NONACA 
		String sourceDB = processInput.getSourceDB();	//bpconadsDB
		String failedCollection = processInput.getFailedCollection();		//REN_ISG_NE_DQ_Reject
		String parentCollection = processInput.getParentCollection();
		JavaSparkContext scIngest = SparkContextSingleton.getInstance().getSparkContext();		// sparkcontext vm argumetns
		JavaRDD<String> filePartition = scIngest.textFile(sourcePath, 12); 
		filePartition.count();
		/*Start ISGNONACA NE :  Filtering the, first two rows and Footer from the feed file, since it contains the ColumnNames for ISG NONACA North East */
		if (null!=sourcePath && sourcePath.contains("ANTHEMNE_NE"))
		{
		String header1=filePartition.first();
		filePartition=filePartition.filter(line-> !(line.equals(header1)));
		String header2=filePartition.first();
		filePartition=filePartition.filter(line-> !(line.equals(header2)));
		String footer=filePartition.top(1).get(0);
		filePartition=filePartition.filter(line -> !(line.equals(footer) && line.startsWith("9999")));
		}
		/*End ISGNONACA NE */
		JavaRDD<Row> readFile = filePartition.map(record -> RowFactory.create((Object[]) record.split(delimeter, -1)));		//check this filepartition
		readFile.foreachPartition(partitionIterator -> {

			ProcessInput process = new ProcessInput(sourceDB, sourceCollection, type, delimeter, delimeted,
					failedCollection, parentCollection);
		
			partitionIterator.forEachRemaining(readFileContent -> {
				String guid = this.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);	
				boolean flag = this.createFlag(delimeted, sourceCollection, readFileContent, type);		//validating with mapping.xml
				Document doc = this.appendRaw(process, sourcePath, guid, flag, readFileContent);	
				ChangeDataCapture cdc = new ChangeDataCapture();
				cdc.implementCdc(sourceDB, sourceCollection, doc, docList, failedList, IConstants.RDM_DB);		//(bpconadsDB,Renewals_ISG_NONACA,doc,docList,failedList,RDM)
				
				if(docList.size() >= 500){
					MongoConnector.getInstance().insertData(docList, sourceDB, sourceCollection, IConstants.RDM_DB);
					MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
					docList.clear();
					failedList.clear();
				}

			});
			MongoConnector.getInstance().insertData(docList, sourceDB, sourceCollection, IConstants.RDM_DB);	//inserting docLIST
			MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
		});

	}

	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection,
			Tuple2<Object, BSONObject> bsonFilter, ProcessFieldNames procFieldNames, String targetDb,
			String targetCollection, String targetDetailCollection, String sourceDbTDM) {
		return null;
	}

	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection) {
		return null;
	}

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection, ProcessInput processInput) {
		ProcessFieldNames memberSummary = null;
		ProcessFieldNames memberDetail = null;
		ProcessFieldNames memberSummaryBenefits = null;
		try {
			memberSummary = FieldNamesProperties.getInstance().getPropertyContext("memberSummary");
			memberDetail = FieldNamesProperties.getInstance().getPropertyContext("memberDetail");
			memberSummaryBenefits= FieldNamesProperties.getInstance().getPropertyContext("memberSummaryBenefits"+IConstants.MODIFIED);
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e1) {
			logger.error(IConstants.ERROR_PREPEND, e1);
		}
		String[] sourceColl = sourceCollection;
		List<Document> docDetailList = new ArrayList<>();
		List<Document> docSummaryList = new ArrayList<>();

		Document doc = new Document();
		Document summaryDoc = new Document();

		try {
			addToDocument(memberDetail, bsonFilter, "memberDetail", doc);
			doc.append("exchangeIndicator", "No");
			doc.append("ratingArea", "");
			for (String metaData : IConstants.getMetadata())
				doc.append(metaData, bsonFilter._2.get(metaData));
			if (doc.get(IConstants.MIDDLENAME) == null) {
				doc.append("middleName", "");
			}
			doc.append("groupName", (doc.get(IConstants.LASTNAME) + ", " + doc.get(IConstants.FIRSTNAME) + " "
					+ doc.get(IConstants.MIDDLENAME)).toUpperCase());
			/*doc.append(IConstants.RENEWAL_DETAILS, MongoConnector.getInstance().getRenewalDocumentSDSDetail(bsonFilter,
					sourceDb, sourceColl[1], IConstants.UDM_DB));
			doc.append(IConstants.RENEWAL_DETAILS, MongoConnector.getInstance().getRenewalDocumentSDSDetailModified(bsonFilter,
					sourceDb, sourceColl[1], IConstants.UDM_DB));*/
			doc.append(IConstants.RENEWAL_DETAILS, getRenewalDocumentSDSDetailModified(bsonFilter,
						sourceDb, sourceColl[1], IConstants.UDM_DB));
			//docDetailList.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		addToDocument(memberSummary, bsonFilter, "memberSummary", summaryDoc);
		for (String metaData : IConstants.getMetadata())
			summaryDoc.append(metaData, bsonFilter._2.get(metaData));

		Object benefitsObject = MongoConnector.getInstance().getRenewalDocumentSDS(bsonFilter, sourceDb, sourceColl[1],
				IConstants.UDM_DB, IConstants.RENEWAL_DETAILS);
		@SuppressWarnings("unchecked")
		List<Document> benefitsList = (ArrayList<Document>) benefitsObject;
		List<Document> updatedBenefitsList = new ArrayList<>();
		String dependent = "";
		for (Document benefitDocument : benefitsList) {
			Document updatedBenefitDocument = new Document();
			//addToDocument(memberSummaryBenefits, benefitDocument, "memberSummaryBenefits", updatedBenefitDocument);
			//updated for BPP-8989/8900
		
			/*BPP-24845 - ISG Non ACA - Dependents Covered Logic*/
			
			if(benefitDocument.getString("ratingTier") != null && benefitDocument.getString("ratingTier").length() >0)
				{ dependent = benefitDocument.getString("ratingTier"); }
			/*BPP-24845 - ISG Non ACA - Dependents Covered Logic*/
			
			addToDocument(memberSummaryBenefits, benefitDocument, "memberSummaryBenefitsModified", updatedBenefitDocument);
				/* Start BPP-24163 : ISGNONACA NE*/
			if (!( null != bsonFilter._2.get("plcyTypeCd"))){
			updatedBenefitDocument.remove("currentContractPlanName");
			updatedBenefitDocument.put("currentContractPlanName", "");
			}
				/* End BPP-24163 : ISGNONACA NE*/
			@SuppressWarnings("unchecked")
			ArrayList<Document> renProdList = (ArrayList<Document>) updatedBenefitDocument.get("renewalProducts");
			for(Document d : renProdList){
				d.put("contractPlanCode", d.get("renewalContractCode"));
				d.remove("renewalContractCode");
				d.put("productType", updatedBenefitDocument.get("productType"));
					/* Start BPP-24163 : ISGNONACA NE*/
				if (( null != bsonFilter._2.get("plcyTypeCd"))){
				d.put("renewalContractPlanName",  d.get("renewalContractPlanName"));
				}
				else{
					d.put("renewalContractPlanName",  "");
				}
					/* End BPP-24163 : ISGNONACA NE*/
			}
			updatedBenefitsList.add(updatedBenefitDocument);
		}
		
		/*Document depedentDoc = new Document();
		if(dependent.equalsIgnoreCase("P") || dependent.equalsIgnoreCase("Q") || dependent.equalsIgnoreCase("R")){
			depedentDoc.append("dependentsCovered","Family");
		}else if(dependent.equalsIgnoreCase("M") || dependent.equalsIgnoreCase("N") || dependent.equalsIgnoreCase("E")){
			depedentDoc.append("dependentsCovered","Children");
		}else if(dependent.equalsIgnoreCase("C") || dependent.equalsIgnoreCase("D")){
			depedentDoc.append("dependentsCovered","Spouse");
		}else if(dependent.equalsIgnoreCase("A") || dependent.equalsIgnoreCase("B")){
			depedentDoc.append("dependentsCovered","No");
		}
		if(depedentDoc.get("dependentsCovered") != null && depedentDoc.getString("dependentsCovered").trim().length() > 0){
			doc.append("Dependents", depedentDoc);
		}*/
		
		/*Start : 24545 Dependents covered Issue &  BPP-24163 : ISGNONACA NE */
		 if((null != dependent && StringUtils.isNumeric(dependent) && Integer.parseInt(dependent) == 1 )){
			doc.append("dependentsCovered","No");
		 }
		 else if((null != dependent && StringUtils.isNumeric(dependent) && Integer.parseInt(dependent) > 1 )){
			doc.append("dependentsCovered","Yes");
		}
		else{
			doc.append("dependentsCovered","-");
		}
		/*End : 24545 Dependents covered Issue &  BPP-24163 : ISGNONACA NE */
		docDetailList.add(doc);
		putCalFields(summaryDoc, sourceDb, sourceColl[1], IConstants.UDM_DB);
		MongoConnector.getInstance().addGrpDelta(summaryDoc);
		summaryDoc.append("renewalSummary", updatedBenefitsList);
		summaryDoc.append(IConstants.PLAN, IConstants.MED);
		if (summaryDoc.get(IConstants.MIDDLENAME) == null) {
			summaryDoc.append("middleName", "");
		}
		// Added for BPP-8989
		summaryDoc.append("groupName", (summaryDoc.get(IConstants.LASTNAME) + ", "
				+ summaryDoc.get(IConstants.FIRSTNAME) + " " + summaryDoc.get(IConstants.MIDDLENAME)).toUpperCase());

		docSummaryList.add(summaryDoc);
		
		try {

			MongoConnector.getInstance().removePreviousDocuments(targetDb, targetCollection, targetDetailCollection,
					IConstants.SDSREN_DB, summaryDoc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}

		MongoConnector.getInstance().insertData(docDetailList, targetDb, targetDetailCollection, IConstants.SDSREN_DB);
		MongoConnector.getInstance().insertData(docSummaryList, targetDb, targetCollection, IConstants.SDSREN_DB);
		MongoConnector.getInstance().updateStatus(sourceDb, sourceColl[0], bsonFilter, IConstants.UDM_DB);
		return null;
	}

	private void addToDocument(ProcessFieldNames processFieldNames, Tuple2<Object, BSONObject> bsonFilter,
			String mappingName, Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

		}

	}

	private void addToDocument(ProcessFieldNames processFieldNames, Document bsonFilter, String mappingName,
			Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

		}

	}

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceColl, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String sourceDbTDM) {
		return null;
	}
	
	public Object getRenewalDocumentSDSDetailModified(Tuple2<Object, BSONObject> bsonFilter, String sourceDb, String sourceColl,String dbType) {
		try {
			
			ProcessFieldNames memberDetailPremium = null;
			memberDetailPremium = FieldNamesProperties.getInstance().getPropertyContext("memberDetailPremium");
			List<Document> benefits = new ArrayList<>();
			
			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
					sourceColl, dbType);
			
				 // Document docRen = (Document) collcheck.find(new Document("GUID", bsonFilter._2.get("GUID").toString())).first();
				/* BPP-31606 : Start : ISG NON ACA [Northeast] Renewal Details */	
				Document docRen = (Document) collcheck.find(new Document(IConstants.GUID, bsonFilter._2.get("GUID").toString()).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)).first();
				/* BPP-31606 : End : ISG NON ACA [Northeast] Renewal Details */

				List<Document> renDetails =  (List<Document>) docRen.get(IConstants.RENEWAL_DETAILS);
										
					for(Document renDoc : renDetails){
						ArrayList<Document> renProdList = (ArrayList<Document>) renDoc.get("renewalProducts");
						Document tempDoc= renProdList.get(0);							
						Document premiumDoc = new Document();
						List<Document> premiumDocList = new ArrayList<>();
						Document benefitDoc = new Document();
						Document currBenefitDoc = new Document();
						addToDocument(memberDetailPremium, tempDoc, "memberDetailPremium", premiumDoc);
						premiumDoc.append("monthlyPremium", renDoc.get("renewalMonthlyPremium"));
						premiumDoc.remove("renewalSubsidy");
						premiumDoc.append("renewalSubsidy", "No");
						premiumDoc.remove("currentMonthlyPremium");
						premiumDoc.append("currentMonthlyPremium", renDoc.get("currentMonthlyPremium"));
						premiumDoc.remove("renewalPremiumwithoutSubsidy");
						premiumDoc.append("renewalPremiumwithoutSubsidy", renDoc.get("renewalPremiumwithoutSubsidy"));
						benefitDoc.append("contractPlanCode", tempDoc.getString("renewalContractCode"));
						benefitDoc.append(IConstants.BENEFITTYPE, "renewalProducts");
						premiumDocList.add(premiumDoc);
						benefitDoc.append("premium", premiumDocList);
						benefitDoc.append("currentContractPlanCode",renDoc.get("currentContractPlanCode"));
						benefitDoc.append("currentContractPlanName",renDoc.get("currentContractPlanName"));
						// udpated for BPP-8990
						benefitDoc.append("renewalContractPlanCode",renDoc.get("renewalContractCode"));
						benefitDoc.append("contractPlanCode",renDoc.get("renewalContractCode"));
						benefitDoc.append("renewalContractPlanName",renDoc.get("renewalContractPlanName"));
						benefitDoc.append("productType",renDoc.get("product"));
						//benefitDoc.append("renewalSubsidy",0.0);
						benefitDoc.append("renewalSubsidy","No");
						
						currBenefitDoc.append("currentContractPlanCode",renDoc.get("currentContractPlanCode"));
						currBenefitDoc.append("currentContractPlanName",renDoc.get("currentContractPlanName"));
						//currBenefitDoc.append("renewalContractPlanCode",renDoc.get("renewalContractCode"));
						currBenefitDoc.append("currentTotalPremium",renDoc.get("currentTotalPremium"));
						//currBenefitDoc.append("currentSubsidy",renDoc.get("currentSubsidy"));
						currBenefitDoc.append("currentSubsidy","No");
						currBenefitDoc.append("currentPremiumwithoutSubsidy",renDoc.get("currentPremiumwithoutSubsidy"));
						currBenefitDoc.append("productType",renDoc.get("product"));
						//currBenefitDoc.append("currentMonthlyPremium",renDoc.get("renewalMonthlyPremium"));
						currBenefitDoc.append("currentMonthlyPremium",renDoc.get("currentMonthlyPremium"));
						currBenefitDoc.append(IConstants.BENEFITTYPE, IConstants.CURRENTPRODUCTS);
						
						if(currBenefitDoc.containsKey(IConstants.CURR_CONT_PLAN_CODE))
							benefits.add(currBenefitDoc);
						if(benefitDoc.containsKey(IConstants.CURR_CONT_PLAN_CODE))
							benefits.add(benefitDoc);
						
					}
					
					return benefits;
				
			
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			}
		return null;

	} 
	public void putCalFields(Document summaryDoc, String sourceDb, String sourceColl, String udmDb) {

		double currPrem = 0.00, monPrem = 0.00;
		Document d=null;
		try {
			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, sourceColl,
					udmDb);
			d = collcheck.find(new Document("ID", summaryDoc.getString("ID")).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED).append(IConstants.END_DATE_FIELD,
					IConstants.MAX_DATE)).first(); /* BPP-31928 : Not getting latest record , added Un-processed status */
			if (d.containsKey(IConstants.CURR_MON_PREMIUM))
				currPrem = d.getDouble(IConstants.CURR_MON_PREMIUM);
			if (d.containsKey(IConstants.MON_PREM))
				monPrem = d.getDouble(IConstants.MON_PREM);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		summaryDoc.append(IConstants.CURR_MON_PREMIUM, currPrem);
		summaryDoc.append(IConstants.MON_PREM, monPrem);

	}

}
