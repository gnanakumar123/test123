package com.anthem.marketplace.dataconsolidation.utils;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReadMappingXml implements Serializable {
	
	public HashMap<String,String> readMappingXml=new HashMap<>();
	public HashMap<String,HashMap<String,String>> fieldList=new HashMap<>();
	
	public ReadMappingXml() {
		fieldList=XmlToHashMap.loadXmlHashMapMandatoryFields();
		readMappingXml=XmlToHashMap.loadXmlHashMap();
	}

	private static final long serialVersionUID = 1L;
	
	static final Logger logger = LoggerFactory.getLogger(ReadMappingXml.class);

	public Map<String, String> getMandatoryFields(String collectionName, String attribute) {
		if(this.fieldList.get(collectionName+attribute)!=null)
		return this.fieldList.get(collectionName+attribute);
		return null;
	}



	public String getIndex(String collectionName, String fieldName) {
		return this.readMappingXml.get(collectionName+fieldName+"index");
	}

	

	public String getAttributeValueOfField(String collectionName, String fieldName, String attributeName) {
		return this.readMappingXml.get(collectionName+fieldName+attributeName);
		
	}

	

	public  String getValue(String fieldName, String fieldValue) {
		return this.readMappingXml.get(fieldName+fieldValue+"value");
	}

	

}