package com.mongospark.examples;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.mongodb.spark.MongoSpark;

public final class MongoSparkSave_DelimitedFile {

	public static void main(final String[] args) throws InterruptedException {

		// Create a single Spark Session with reference to Mongo Db -
		// Database.Collection
		// Specify Spark MASTER URL to process to remove machine
		// SparkSession spark = SparkSession.builder().master("spark://10.137.56.226:7077").
		SparkSession spark = SparkSession.builder().master("local").appName("MongoSparkConnectorIntro")
				.config("spark.mongodb.input.uri", "mongodb://127.0.0.1/test.test")
				.config("spark.mongodb.output.uri", "mongodb://127.0.0.1/test.test")
				.config("spark.ui.port", "7077")
				.getOrCreate();

		// Create a Java Spark Context from a Spark Session
		JavaSparkContext jsc = new JavaSparkContext(spark.sparkContext());

		// Define a schema for a file
		StructType schema = DataTypes.createStructType(
				new StructField[] { DataTypes.createStructField("seqNumber", DataTypes.StringType, true),
						DataTypes.createStructField("groupId", DataTypes.StringType, true),
						DataTypes.createStructField("firstName", DataTypes.StringType, true),
						DataTypes.createStructField("lastName", DataTypes.StringType, true),
						DataTypes.createStructField("premium", DataTypes.DoubleType, true),
						DataTypes.createStructField("renewalDate", DataTypes.DateType, true),
						DataTypes.createStructField("source", DataTypes.StringType, true)

				});

		// Create a dataframe from a text file using Spark Session
		// Map the fields in the file against the above custom Schema ( data
		// types for each field )
		Dataset<Row> df = spark.read().format("csv") //
				.schema(schema).option("header", "true") //
				.option("multiline", true) //
				.option("sep", ";") //
				.option("quote", "^") //
				.option("dateFormat", "M/d/y") //
				.option("inferSchema", false) //
				.load("src/main/resources/group.txt");

		System.out.println("Printing dataframe content:");
		df.show(false);

		// dropping a column and remove duplicates from a file
		Dataset<Row> filteredDf = df.drop("seqNumber").dropDuplicates();
		filteredDf.show(false);

		// Write to MongoDB in a distributed processing
		MongoSpark.write(filteredDf).option("collection", "test").mode("append").save();

		jsc.close();

	}

}
