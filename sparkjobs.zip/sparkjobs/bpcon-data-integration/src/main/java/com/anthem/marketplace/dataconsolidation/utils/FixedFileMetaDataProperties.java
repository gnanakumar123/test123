package com.anthem.marketplace.dataconsolidation.utils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FixedFileMetaDataProperties {
	
	static final  Logger logger = LoggerFactory.getLogger(FixedFileMetaDataProperties.class);
	private static FixedFileMetaDataProperties instance;
	private static HashMap<String,String> hashMapproperty;
	private FixedFileMetaDataProperties() throws IOException, NoSuchMethodException, ClassNotFoundException,
			InvocationTargetException, IllegalAccessException {

		hashMapproperty = readProp("fixedFileMetaData.properties");

	}

	public ProcessFixedFileMetaData getPropertyContext(String fieldName, String type)
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {

		ProcessFixedFileMetaData process = new ProcessFixedFileMetaData();
		process.setstart(hashMapproperty.get(type+"."+fieldName+IConstants.START));
		process.setend(hashMapproperty.get(type+"."+fieldName+IConstants.END));
		return process;
	
	}

	public static synchronized FixedFileMetaDataProperties getInstance() {
		if (instance == null) {
			try {
				instance = new FixedFileMetaDataProperties();

			} catch (Exception e) {
				logger.error("Error{}", e);
			}
		}
		return instance;
	}

	private HashMap<String, String> readProp(String configpath)
			throws IOException, NoSuchMethodException, ClassNotFoundException,

			InvocationTargetException, IllegalAccessException {
		Properties prop = new Properties();
		
		prop.load(FixedFileMetaDataProperties.class.getResourceAsStream("/" + configpath));
		Enumeration<?> propertyNames = prop.propertyNames();
		HashMap<String,String> propertyHashMap=new HashMap<>();
		while (propertyNames.hasMoreElements()) {
			String key = (String) propertyNames.nextElement();
			
			
			
				
				
				String Value = prop.getProperty(key);
				propertyHashMap.put(key, Value);
				
			}
		
		return propertyHashMap;
	}

}
