package com.anthem.marketplace.dataconsolidation.filesutils;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.bson.BSONObject;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.model.VARenewal;
import com.anthem.marketplace.dataconsolidation.utils.ChangeDataCapture;
import com.anthem.marketplace.dataconsolidation.utils.ChipsUtils;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.BasicDBList;

import scala.Tuple2;

/*
 * This class implements UtilityInterface and Serializable and performs Ingestion, Transformation of CHIPS renewals input files
 * @author : MongoDB Team
 * @version : 1.0
 * @Date : June 2016
 * It returns nothing.
 */
public class CHIPS implements UtilityInterface, Serializable {

	private static final long serialVersionUID = 1L;
	static final Logger logger = LoggerFactory.getLogger(CHIPS.class);
	public static ArrayList<String> neglectList = new ArrayList<String>();
	public List<String> fieldsList;
	public static final String keys = "contract,policyHolderDetails,policyHolderData,agencyInfo,agentInfo,spouseDetails,dependentDetails";

	/*
	 * This method creates GUID
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param delimeted stores delimited character
	 * 
	 * @param readFileContent stores input file data
	 * 
	 * @param guidvalue stores guid values retrieve from properties file
	 * 
	 * @param type stores type of file
	 * 
	 * @return String GUID
	 */
	public String createGuid(String sourceCollection, String delimeted, Row readFileContent, String guidvalue,
			String type) {  		
		StringBuffer guid = new StringBuffer();
		String errorFieldName = "";
		Document doc = new Document();
		try {
  			doc = ChipsUtils.getInstance().getVADocument(readFileContent);
			for (String item : guidvalue.split(IConstants.SPLIT_COMMA)) {
				errorFieldName = item;
				for(String key: keys.split(IConstants.SPLIT_COMMA)) {
					String value =  ChipsUtils.getInstance().getValue(doc,key,item);
					if(value != null && !value.isEmpty()) {
						guid.append(value);
						break;
					}
				}
			}
			guid = guid.append("IND").append("SUBSCR");			
		}
		catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.GUID_ERROR_METHOD, "Exception:  "+ e,
					readFileContent.toString(), errorFieldName, IConstants.CHIPS,IConstants.RDM_DB);
		}catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  "+ e, readFileContent.toString(), errorFieldName, IConstants.CHIPS,IConstants.RDM_DB);
		}

		return guid.toString();
	}

	/*
	 * This method checks mandatory fields for file for data Quality check
	 * @param sourceCollection stores collection name
	 * @param delimeted stores delimited character
	 * @param readFileContent stores input file data
	 * @param type stores type of file
	 * @return boolean value based on data Quality check passed.
	 */
	public boolean createFlag(String delimeted, String sourceCollection, Row readFileContent, String type) {
		boolean mandatoryFieldNotExists = true;
		String errorFieldName = "";
		Document doc = new Document();
		try {
			 
			 doc = ChipsUtils.getInstance().getVADocument(readFileContent);
			 Map<String, String> mandatoryFields = ReadMappingXmlSingleton.getInstance().getRead()
						.getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);
			 
			 for (String item : mandatoryFields.values()) {
					errorFieldName = item;
					mandatoryFieldNotExists = true; 
					for(String key: keys.split(IConstants.SPLIT_COMMA)) {
						String value =  ChipsUtils.getInstance().getValue(doc,key,item);
						if(value != null && !value.isEmpty()) {
							mandatoryFieldNotExists = false;
							break;
						}
					}
				  if(mandatoryFieldNotExists)
					break;
				}
			
			// if false then set error as null value found for mandatory fields.
			if (mandatoryFieldNotExists) {
				Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
						IConstants.DATA_QUALITY_ERROR_CHECK, readFileContent.toString(), errorFieldName, IConstants.CHIPS,IConstants.RDM_DB);
			}
		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  "+ e,readFileContent.toString(),errorFieldName,IConstants.CHIPS,IConstants.RDM_DB);
		}catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  "+ e,readFileContent.toString(),errorFieldName,IConstants.CHIPS,IConstants.RDM_DB);
		}
		return mandatoryFieldNotExists;
	}

	/*
	 * This method adds fileName and its respective value to a document and returns it.
	 * @param processInput stores input properties related parameters
	 * 
	 * @param sourcePath stores source path of input file
	 * 
	 * @param guid stores GUID
	 * 
	 * @param flag stores value retrieve from data Quality check method
	 * 
	 * @param readFileContent stores Row of a input file
	 * 
	 * @return Document
	 */
	public Document appendRaw(ProcessInput processInput, String sourcePath, String guid, boolean flag,
			Row readFileContent) {

		String type = processInput.getType();	
		String sourceDB = processInput.getSourceDB();	
		String sourceCollection = processInput.getSourceCollection();	
		String errorFieldName = "";
		Document doc = new Document();
		ProcessFieldNames procFieldNames;
		
		try {
			 procFieldNames = FieldNamesProperties.getInstance().getPropertyContext(type);	
			 doc = ChipsUtils.getInstance().getVADocument(readFileContent);
			
			 for (String fieldName : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
					errorFieldName = fieldName;
					
				String dataType = ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(type,
						fieldName, IConstants.DATATYPE);
				
				if(dataType.contains("Date")) {
					for(String key: keys.split(IConstants.SPLIT_COMMA)) {
						Object object = doc.get(key);
						if(object instanceof Document) {
							Document innerDoc = (Document) object;
							if(innerDoc != null && innerDoc.get(fieldName) != null) {
								Utility.applyZone(sourceCollection, fieldName, innerDoc.get(fieldName).toString(), innerDoc, dataType,
										readFileContent, IConstants.CHIPS);
								doc.append(key, innerDoc);
								break;
							}
						}else if(object instanceof List<?>) {
							List<Document> innerDocList = (List<Document>) object;
							for(int i=0; i<innerDocList.size(); i++) {
								Document innerDoc = innerDocList.get(i);
								if(innerDoc != null && innerDoc.get(fieldName) != null) {
									Utility.applyZone(sourceCollection, fieldName, innerDoc.get(fieldName).toString(), innerDoc, dataType,
											readFileContent, IConstants.CHIPS);
									innerDocList.set(i,innerDoc);
								}
							}
							doc.append(key, innerDocList);
						}
					}
				}
			 }

			 doc.append("GUID", guid);
		
			Utility.insertMetadata(doc, sourceDB, sourceCollection, guid, sourcePath, "CHIPS", flag,true,IConstants.RDM_DB);

			// catch Exceptions and add respective errorCode and its description
		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.CHIPS, IConstants.RDM_DB);
		}catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.CHIPS, IConstants.RDM_DB);
		}

		return doc;
	}

	
	/*
	 * This method performs transformation on CHIPS Raw data.
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source collection name
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param targetCollection stores target collection name
	 * 
	 * @param appendedCollection stores collection name whose data to be
	 * appended as embedded doc. i.t summary to detail
	 * 
	 * @return transformed Document
	 */
	public Document ingestTDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String transColl, String appendedCollection) {

		Document metaDoc = new Document();
		boolean flag = false;
		String guid = "";
		ProcessFieldNames procFieldNames = null;
		String sourcePath = "";
		ProcessFieldNames clientFieldNames = null;
		neglectList.add("");
		neglectList.add(null);
		try {
			clientFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.CHIPS.concat(transColl).toString());  
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e1) {
			logger.error(IConstants.ERROR_PREPEND, e1);

		}
		//adding outer doc elements
		metaDoc.append("GUID",  bsonFilter._2.get("GUID"));
		ChipsUtils.getInstance().addToDocument(clientFieldNames, bsonFilter,"contract",IConstants.CHIPS.concat(transColl),metaDoc);
		metaDoc.append("type", "IND");
		metaDoc.append("relationship", "SUBSCR");
		
		if (transColl.contains("Renewals_tdm_Renewal")) {
			List<Document> benefitDocList = new ArrayList<Document>(); 
			fieldsList = new ArrayList<String>();
			try {
				procFieldNames = FieldNamesProperties.getInstance().getPropertyContext(IConstants.CHIPSBENEFITS);
			} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
					| IllegalArgumentException | InvocationTargetException e) {
				logger.error(IConstants.ERROR_PREPEND, e);

			}
			benefitDocList = ChipsUtils.getInstance().createRenewalBenefits(procFieldNames,bsonFilter,sourceCollection,metaDoc,targetDb);
			metaDoc.append(IConstants.BENEFITS, benefitDocList);
		}
		else {
			//adding firstname, dateOfBirth elements for Client
			ChipsUtils.getInstance().addToDocument(clientFieldNames, bsonFilter,IConstants.POLICYHOLDERDETAILS, IConstants.CHIPS.concat(transColl),metaDoc);
			for (String coll : appendedCollection.split(IConstants.SPLIT_COMMA)) {
				try {
					procFieldNames = FieldNamesProperties.getInstance()
							.getPropertyContext(IConstants.CHIPS.concat(coll));
				} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
						| IllegalArgumentException | InvocationTargetException e) {
					logger.error(IConstants.ERROR_PREPEND, e);

				}
				if (coll.toString().equals(IConstants.CLIENT_AGENT)) {
					BasicDBList agentsDocList = ChipsUtils.getInstance().createAgentsList(procFieldNames,bsonFilter,coll,targetDb);
					metaDoc.append(coll, agentsDocList);
				} else if (coll.toString().equals(IConstants.CLIENT_CONTACTS)) {
					BasicDBList contDocList = new BasicDBList();
					Document contactDoc = ChipsUtils.getInstance().createContactDoc(procFieldNames,bsonFilter,coll);
					contDocList.add(contactDoc);
					metaDoc.append(coll, contDocList);
				}else {		
					Document renewalsDoc = ChipsUtils.getInstance().createRenewalsDoc(procFieldNames);
					metaDoc.append(coll, renewalsDoc);
				}
			}
			List<BSONObject> memberDocList = ChipsUtils.getInstance().createMemberDocList(bsonFilter);
			metaDoc.append("Dependents", memberDocList);
			if(memberDocList.size() > 0){
				metaDoc.append("dependentsCovered", "Yes");
			}else{
				metaDoc.append("dependentsCovered", "No");
			}
		}

		sourcePath = bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString();

		guid = metaDoc.get(IConstants.GUID).toString();
		// insert metaData
		Utility.insertMetadata(metaDoc, targetDb, transColl, guid, sourcePath, "CHIPS", flag, true,
				IConstants.TDM_DB);

		if (metaDoc.getString(IConstants.REN_ID) != null)
			return metaDoc;

		else
			return null;
	}
	
	/*
	 * This method performs unified transformation on ASCS transformed data.
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source collection name
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param targetCollection stores target collection name
	 * 
	 * @param targetDetailCollection stores collection name whose data is
	 * appended as embedded doc. i.t summary to detail
	 * 
	 * @return transformed Document
	 */
	@SuppressWarnings("unchecked")
	public Document ingestUDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection) {

		Document metaDoc = new Document();
		try {
			metaDoc.putAll(bsonFilter._2.toMap());

			metaDoc.remove(IConstants.ID);
		} catch (Exception e) {
			logger.error("Exception:  " + e);
		}
		return metaDoc;
	}

	/*
	 * this method inserts data into mongoDB for given specifications
	 * 
	 * @processInput stores input related parameters
	 * 
	 * @sourcePath stores file location path
	 * 
	 * @guidvalue stores GUID
	 * 
	 * @priority stores priority of process
	 * 
	 * @strType stores type of input file.
	 * 
	 * @return nothing
	 */
	@Override
	public void ingestRDMprocess(ProcessInput processInput, String sourcePath, String guidvalue, String strType) {  
		List<Document> docList = new ArrayList<>();
		List<Document> failedList = new ArrayList<>();

		String sourceCollection = processInput.getSourceCollection();		
		String delimeted = processInput.getDelimeted();			
		String delimeter = processInput.getDelimeter();		
		String type = processInput.getType();			
		String sourceDB = processInput.getSourceDB();	
		String failedCollection = processInput.getFailedCollection();		
		JavaSparkContext scIngest = SparkContextSingleton.getInstance().getSparkContext();	
		JavaRDD<List<VARenewal>> fileContent = scIngest.wholeTextFiles(sourcePath).map(new com.anthem.marketplace.dataconsolidation.utils.CustomRDDConverter());
		JavaRDD<Row> readFile = fileContent.flatMap(vaRenewalList->vaRenewalList.iterator()).map(record -> RowFactory.create((VARenewal) record));
		readFile = readFile.repartition(6);
		readFile.foreachPartition(partitionIterator -> {
			
			ProcessInput process = new ProcessInput(sourceDB, sourceCollection, type, delimeter, delimeted,
					failedCollection);
			
			partitionIterator.forEachRemaining(readAgency -> {
				
				String guid = this.createGuid(sourceCollection, delimeted, readAgency, guidvalue, type);
				boolean flag = this.createFlag(delimeted, sourceCollection, readAgency, type);
				Document doc = this.appendRaw(process, sourcePath, guid, flag, readAgency);
				ChangeDataCapture cdc = new ChangeDataCapture();
				cdc.implementCdc(sourceDB, sourceCollection, doc, docList, failedList, IConstants.RDM_DB);
				if(docList.size() >= 500){
					MongoConnector.getInstance().insertData(docList, sourceDB, sourceCollection, IConstants.RDM_DB);
					MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
					docList.clear();
					failedList.clear();
				}
			});
			MongoConnector.getInstance().insertData(docList, sourceDB, sourceCollection, IConstants.RDM_DB);
			MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
		});
	}

	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection,
			Tuple2<Object, BSONObject> bsonFilter, ProcessFieldNames procFieldNames, String targetDb,
			String targetCollection, String targetDetailCollection, String sourceDbTDM) {
		return null;
	}

	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection) {
		return null;
	}

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection, ProcessInput processInput) {
		ProcessFieldNames memberSummary = null;
		ProcessFieldNames memberDetail = null;
		ProcessFieldNames memberSummaryBenefits = null;
		try {
			memberSummary = FieldNamesProperties.getInstance().getPropertyContext("memberSummary");
			memberDetail = FieldNamesProperties.getInstance().getPropertyContext("memberDetail");
			memberSummaryBenefits= FieldNamesProperties.getInstance().getPropertyContext("memberSummaryBenefits"+IConstants.MODIFIED);
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e1) {
			logger.error(IConstants.ERROR_PREPEND, e1);
		}
		String[] sourceColl = sourceCollection;
		List<Document> docDetailList = new ArrayList<>();
		List<Document> docSummaryList = new ArrayList<>();

		//RenewalDetails Document Creation
		try {
			Document detailDoc = ChipsUtils.getInstance().createDetailDocument(memberDetail,bsonFilter,sourceDb,sourceCollection);
			docDetailList.add(detailDoc);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		// Renewal Summary Document Creation
		Document summaryDoc = ChipsUtils.getInstance().createSummaryDocument(memberSummary,memberSummaryBenefits,bsonFilter,sourceDb,sourceCollection);
		docSummaryList.add(summaryDoc);
		try {
			MongoConnector.getInstance().removePreviousDocuments(targetDb, targetCollection, targetDetailCollection,
					IConstants.SDSREN_DB, summaryDoc);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		MongoConnector.getInstance().insertData(docDetailList, targetDb, targetDetailCollection, IConstants.SDSREN_DB);
		MongoConnector.getInstance().insertData(docSummaryList, targetDb, targetCollection, IConstants.SDSREN_DB);
		MongoConnector.getInstance().updateStatus(sourceDb, sourceColl[0], bsonFilter, IConstants.UDM_DB);
		return null;
	}

	

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceColl, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String sourceDbTDM) {
		return null;
	}
	
}
