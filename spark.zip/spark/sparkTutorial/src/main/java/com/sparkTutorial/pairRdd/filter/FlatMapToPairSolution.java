package com.sparkTutorial.pairRdd.filter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFlatMapFunction;

import scala.Tuple2;

public class FlatMapToPairSolution {

    public static void main(String[] args) throws Exception {

        SparkConf conf = new SparkConf().setAppName("flatMapToPair").setMaster("local");

        JavaSparkContext sc = new JavaSparkContext(conf);

        JavaRDD<String> airportsRDD = sc.parallelize(Arrays.asList("Hello World", "Welcome to Spark"));

        JavaPairRDD<String, Integer> airportPairRDD = airportsRDD.flatMapToPair(getAirportNameAndCountryNamePair());

        airportPairRDD.saveAsTextFile("out/word_length_count_flat_map_pair_rdd.text");
    }

    private static PairFlatMapFunction<String, String, Integer> getAirportNameAndCountryNamePair() {
        return (PairFlatMapFunction<String, String, Integer>) line -> {
        	List<Tuple2<String, Integer>> wordLengths = new ArrayList<>();
        	
        	String[] words = line.split(" ");
        	for (String string : words) {
        		wordLengths.add(new Tuple2<>(string, string.length()));	
			}
        	
        	return wordLengths.iterator();
        };
    }
}
