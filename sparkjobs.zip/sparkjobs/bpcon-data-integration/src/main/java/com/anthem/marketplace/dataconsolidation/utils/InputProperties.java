package com.anthem.marketplace.dataconsolidation.utils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * This class reads ingest and transform related parameters from properties file and returns them.  
 */

public class InputProperties {
	static final Logger logger = LoggerFactory.getLogger(InputProperties.class);
	private HashMap<String,ProcessInput> processList=new HashMap<>();
	private static InputProperties instance;

	private InputProperties() throws IOException, NoSuchMethodException, ClassNotFoundException,
			InvocationTargetException, IllegalAccessException {

		processList = readProp("input.properties");

	}

	private ProcessInput getProcess(String type) {
		ProcessInput process = null;
		
		if (processList.get(type)==null) {
			process = new ProcessInput(type);
			this.processList.put(type, process);
		} else
			process = processList.get(type);
		return process;
	}

	public HashMap<String,ProcessInput> getPropertyContext() {
		return processList;
	}

	public static synchronized InputProperties getInstance()  {
		if (null == instance) {
			try {
				instance = new InputProperties();
			} catch (NoSuchMethodException | ClassNotFoundException | InvocationTargetException | IllegalAccessException
					| IOException e) {

				logger.error(IConstants.ERROR_PREPEND+e);
			}
		}
		return instance;
	}

	private HashMap<String,ProcessInput> readProp(String configpath) throws IOException, NoSuchMethodException,
			ClassNotFoundException, InvocationTargetException, IllegalAccessException {
		Properties prop = new Properties();
		prop.load(InputProperties.class.getResourceAsStream("/" + configpath));
		Enumeration<?> propertyNames = prop.propertyNames();
		while (propertyNames.hasMoreElements()) {
			String key = (String) propertyNames.nextElement();
			String[] keys = key.split("\\.");
			if (keys.length == 2) {
				ProcessInput process = getProcess(keys[0]);
				Class<?> cls = Class.forName("com.anthem.marketplace.dataconsolidation.utils.ProcessInput");
				String tempPropertyValue = prop.getProperty(key);

				if (key.contains("Array")) {
					Method method = cls.getDeclaredMethod("set" + keys[1], new Class[] { String[].class });
					method.invoke(process, new Object[] { tempPropertyValue.split(",") });
				} else {
					Method method = cls.getDeclaredMethod("set" + keys[1], String.class);
					method.invoke(process, tempPropertyValue);
				}
			}
		}
		return processList;
	}


}