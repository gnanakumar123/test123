package com.bean;

public class Agent {

	private String agentId;
	private String writingAgentTin;
	private String writingAgentName;
	private String paidAgentTin;
	private String paidAgentName;
	private String generalAgentTin;
	private String generalAgentName;

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public String getWritingAgentTin() {
		return writingAgentTin;
	}

	public void setWritingAgentTin(String writingAgentTin) {
		this.writingAgentTin = writingAgentTin;
	}

	public String getWritingAgentName() {
		return writingAgentName;
	}

	public void setWritingAgentName(String writingAgentName) {
		this.writingAgentName = writingAgentName;
	}

	public String getPaidAgentTin() {
		return paidAgentTin;
	}

	public void setPaidAgentTin(String paidAgentTin) {
		this.paidAgentTin = paidAgentTin;
	}

	public String getPaidAgentName() {
		return paidAgentName;
	}

	public void setPaidAgentName(String paidAgentName) {
		this.paidAgentName = paidAgentName;
	}

	public String getGeneralAgentTin() {
		return generalAgentTin;
	}

	public void setGeneralAgentTin(String generalAgentTin) {
		this.generalAgentTin = generalAgentTin;
	}

	public String getGeneralAgentName() {
		return generalAgentName;
	}

	public void setGeneralAgentName(String generalAgentName) {
		this.generalAgentName = generalAgentName;
	}
}
