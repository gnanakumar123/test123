package com.anthem.marketplace.dataconsolidation.utils;

import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.bson.BSONObject;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.WriteConcern;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.DistinctIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
import com.mongodb.client.model.Sorts;

import scala.Tuple2;

/*
* This class contains update, insert and check mongo database values 
 */

public class MongoConnector implements Serializable {

	/* Start[BPP-37713] : Audit tracking Constants */
	private static final String SDS = "SDS";
	private static final String TABLE_BROKER_CLIENT_INFO = "BrokerclinetInfo";
	
	private static final String CLIENT_ID = "clientId";
	private static final String TAX_ID = "taxID";
	private static final String TAX_ID_TYPE = "taxIDType";
	private static final String AGENT_ID = "agentID";
	private static final String NAME = "name";
	private static final String PRODUCT = "product";
	private static final String IS_VISIBLE = "isVisible";
	
	private static final String Y = "Y";
	private static final String N = "N";
	//private static final String YES = "Yes";
	private static final String NO = "No";
	private static final String NULL = "NULL";
	
	private static final String WRITING = "Writing";
	private static final String PARENT = "Parent";
	private static final String PAID = "Paid";
	
	private static final String WRITING_TIN = "writingTin";
	private static final String APPOINTMENT = "writingappointment";
	private static final String RTS = "rts";
	private static final String OWNERSHIP = "writingownership";
	
	private static final String PAID_TIN = "paidTin";
	private static final String PAID_TINAPPOINTMENT = "paidtinappointment";
	
	private static final String PARENT_TIN = "parentTin";
	private static final String PARENT_TINAPPOINTMENT = "parenttinappointment";
	/* End[BPP-37713] : Audit tracking Constants */
	
	private static final long serialVersionUID = 1L;
	static final Logger logger = LoggerFactory.getLogger(MongoConnector.class);
	public static ArrayList<String> neglectList = new ArrayList<String>();
	HashMap<String,String> planNames = new HashMap<String,String>(); /* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
	
	// create an object of SingleObject
	private static MongoConnector instance;
	static HashMap<String,ProcessConnector> connectorList;
	static HashMap<String,MongoClient> mongoClientList=new HashMap<>();
	// make the constructor private so that this class cannot be
	// instantiated
	private MongoConnector() throws NoSuchMethodException, ClassNotFoundException, InvocationTargetException,
			IllegalAccessException, IOException {
		setMongoClient();
	}

	
	
	public void removePrevious(String sourceDB, String summCollection, String detCollection, String type, Document d,String strSource) {

		MongoCollection<Document> sCollcheck = MongoConnector.getInstance().getCollectionDetail(sourceDB,
				summCollection, type); // RenewalSummary collection
		MongoCollection<Document> dCollcheck = MongoConnector.getInstance().getCollectionDetail(sourceDB, detCollection,
				type); // RenewalDetails Collection

		long count = 0, dCount = 0, empdCount = 0;
		String billingEntity = null;
		String groupID = null;
		if (d.containsKey("ID")) {
			billingEntity = d.get("ID").toString(); // In RenewalSummary the 'ID' is having billingEntity value
			groupID = d.getString("groupID");
			
			count = sCollcheck.count(new Document("ID", billingEntity).append("renewalDate", d.get("renewalDate")).append("source",strSource));
			dCount = dCollcheck.count(new Document("billingEntity", billingEntity).append("renewalDate", d.get("renewalDate")).append("source",strSource)); 
			empdCount = dCollcheck.count(new Document("groupID", groupID).append("type", "EMP").append("source",strSource));

		}
		if (count > 0) {
			/* RenewalSummary Collection records are deleted by passing billingEntity  */
			sCollcheck.deleteMany(new Document("ID", billingEntity).append("renewalDate", d.get("renewalDate")).append("source",strSource)); 
		} 
		if (dCount > 0) {
			/* RenewalDetails GroupLevel Records are deleted by passing billingEntity */
			dCollcheck.deleteMany(new Document("billingEntity", billingEntity).append("renewalDate", d.get("renewalDate")).append("source",strSource));

		}
		if (empdCount > 0) {
			/* RenewalDetails EmpLevel Records are deleted by passing groupID */
			dCollcheck.deleteMany(new Document("groupID", groupID).append("type", "EMP").append("source",strSource)); 
		}

	}


public void removePreviousDocuments(String sourceDB, String summCollection, String detCollection, String type, Document d){
	
	MongoCollection<Document> sCollcheck = 
			MongoConnector.getInstance().
			getCollectionDetail(sourceDB, summCollection,type);
	MongoCollection<Document> dCollcheck = 
			MongoConnector.getInstance().
			getCollectionDetail(sourceDB, detCollection,type);
	
		long count=0;
		String key = null;
		if(d.containsKey("ID"))
		{
			key =d.get("ID").toString();
			count = sCollcheck.count(new Document("ID", key));
			//dCount = dCollcheck.count(new Document("groupID", key));
		}
		if(count>0)
		{
//			System.out.println("Docs Deleted : "+count);
			sCollcheck.deleteMany(new Document("ID", key));
			dCollcheck.deleteMany(new Document("ID", key));
		}
		/*if(dCount>0){
			dCollcheck.deleteMany(new Document("billingEntity", key));
			dCollcheck.deleteMany(new Document("groupID", key));
			dCollcheck.deleteMany(new Document("ID", key));
		}*/
		
	}
	private void setMongoClient() {
		connectorList=InputConnectors.getInstance().getConnectorList();
		for(String key:connectorList.keySet()){
			MongoClient mongoClient;
		List<ServerAddress> processConnectors = InputConnectors.getInstance().getMongoPropertyContext(key);
		boolean authFlag = InputConnectors.getInstance().checkAuthenticationFlag(key);
		boolean sslFlag = InputConnectors.getInstance().checkSSLFlag(key); /*BPP-38521 : Implement Mongodb SSL Feature to Data Load Project */
		if (authFlag) {	
			List<MongoCredential> credentialList = InputConnectors.getInstance().getMongoCredentials(key);
			/*BPP-38521 : Implement Mongodb SSL Feature to Data Load Project */
			if(sslFlag){
				MongoClientOptions options = new MongoClientOptions.Builder().sslEnabled(true).build(); 
			/*BPP-38521 : Implement Mongodb SSL Feature to Data Load Project */
				mongoClient = new MongoClient(processConnectors, credentialList,options);
			}else{
				mongoClient = new MongoClient(processConnectors, credentialList);
			}
		} else
			mongoClient = new MongoClient(processConnectors);
		mongoClient.setWriteConcern(WriteConcern.W1);
		mongoClientList.put(key, mongoClient);
		}
	}

	// Get the only object available
	public MongoClient getMongoClient(String type) {
		return mongoClientList.get(type);
	}

	// Get the only object available
	public static synchronized MongoConnector getInstance() {
		if (null == instance) {
			try {
				instance = new MongoConnector();

			} catch (Exception e) {
				logger.error("Error{}", e);
			}

		}
		return instance;
	}

	/*
	 * This method returns collection of database.
	 * 
	 * @param dbName stores database name
	 * 
	 * @param collectionName stores collection name
	 * 
	 * @return specified collection of database
	 */
	public MongoCollection<Document> getCollectionDetail(String dbName, String collectionName,String dbType) {
		MongoDatabase database = MongoConnector.getInstance().getMongoClient(dbType).getDatabase(dbName);
		return database.getCollection(collectionName);
	}

	/*
	 * This method Checks specified collection exists in dataBase
	 * 
	 * @param sourceDB stores database name
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @return boolean value for collection existence
	 */
	public boolean checkCollection(String sourceDB, String sourceCollection,String dbType) {
		boolean col = false;
		MongoIterable<String> collection = MongoConnector.getInstance().getMongoClient(dbType).getDatabase(sourceDB).listCollectionNames();
		for (String s : collection) {
			if (s.equalsIgnoreCase(sourceCollection))
				col = true;
		}
		return col;
	}

	/*
	 * This overidden method checks for document for specified guid in mongo
	 * database and compares it with @param doc without metadata. If the
	 * document is same it updates the timestamp of document to latest. else it
	 * creates another version of document and makes it the latest.
	 * 
	 * @param sourceDB stores database name
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param currentDate stores recent timeStamp
	 * 
	 * @param docList is java list for storing passed documents
	 * 
	 * @param failedList is java list for storing failed documents
	 * 
	 * @return boolean value depending on process
	 */
	
	//@SuppressWarnings("unchecked")
	public boolean updateCdc(String sourceDB, String sourceCollection, String currentDate, Document doc,
			List<Document> docList, List<Document> failedList,String dbType) {

		try {
			String guid = doc.get(IConstants.GUID).toString();
			MongoCollection<Document> collcheck;
			//BasicDBList dbDoc = null;
			BasicDBObject newDocument = new BasicDBObject();
			BasicDBObject searchQuery = new BasicDBObject().append(IConstants.GUID, guid)
					.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE);
			FindIterable<Document> iterable;
			Document docnew;

			String[] metadata = new String[7];

			for (int i = 0; i < IConstants.getMetadata().length; i++)
				metadata[i] = doc.getString(IConstants.getMetadata()[i]);
			collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDB, sourceCollection,dbType);

			iterable = collcheck
					.find(new Document(IConstants.GUID, guid).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE));
			docnew = iterable.first();

			// remove auto-generated objectId and metaData fields from document
			// for other fields comparison.
			if (docnew != null) {
				docnew.remove(IConstants.ID);
				for (int i = 0; i < IConstants.getMetadata().length; i++) {
					doc.remove(IConstants.getMetadata()[i]);
					doc.append(IConstants.getMetadata()[i], docnew.get(IConstants.getMetadata()[i]));
				}
			}

			// if same document found then update timeStamp of document
			if (docnew != null && docnew.equals(doc)) {
				newDocument.append("$set", new BasicDBObject().append(IConstants.START_DATE_FIELD, currentDate));
				collcheck.updateOne(searchQuery, newDocument);

			}

			// else add metaData to new document, embed detail_reference docs,
			// set end_date to max date and add document to java list
			else {
				for (int i = 0; i < IConstants.getMetadata().length; i++) {
					doc.remove(IConstants.getMetadata()[i]);
					doc.append(IConstants.getMetadata()[i], metadata[i]);
				}
				newDocument.append("$set", new BasicDBObject().append(IConstants.END_DATE_FIELD, currentDate));
				collcheck.updateOne(searchQuery, newDocument);
				Utility.addToList(doc, docList, failedList);
			}
		} catch (Exception e) {
			logger.error("Exception:  "+ e);
		}
		return true;
	}
	
	public void updateWSGRSCdc(String sourceDB, String sourceCollection, String currentDate, Document doc,
			List<Document> docList, List<Document> failedList,String dbType) {

		try {

			String groupID = doc.get(IConstants.GROUP_ID1).toString();
			String sourcePath = doc.get(IConstants.SOURCE_PATH_FIELD).toString();
			MongoCollection<Document> collcheck;
			BasicDBObject newDocument = new BasicDBObject();
			BasicDBObject searchQuery = new BasicDBObject().append(IConstants.GROUP_ID1, groupID)
					.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.SOURCE_PATH_FIELD, new BasicDBObject().append("$ne", sourcePath));
			FindIterable<Document> iterable;
			Document docnew;

			String[] metadata = new String[7];

			for (int i = 0; i < IConstants.getMetadata().length; i++)
				metadata[i] = doc.getString(IConstants.getMetadata()[i]);
			collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDB, sourceCollection,dbType);

			iterable = collcheck
					.find(new Document(IConstants.GROUP_ID1, groupID).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.SOURCE_PATH_FIELD, new Document("$ne", sourcePath)));
			docnew = iterable.first();

			if (docnew != null ) {
//				System.out.println("Updated");
				newDocument.append("$set", new BasicDBObject().append(IConstants.END_DATE_FIELD, currentDate));
				try{
					collcheck.updateMany(searchQuery, newDocument);
				}catch(Exception e)
				{
					collcheck.updateMany(searchQuery, newDocument);
				}

			}

				for (int i = 0; i < IConstants.getMetadata().length; i++) {
					doc.remove(IConstants.getMetadata()[i]);
					doc.append(IConstants.getMetadata()[i], metadata[i]);
				}

				Utility.addToList(doc, docList, failedList);

		} catch (Exception e) {
			logger.error("Exception:  "+ e);
		}
		return ;
	}

	/**
	 * BPP-8945 - SGRS Renewals changes
	 * @param sourceDB
	 * @param sourceCollection
	 * @param currentDate
	 * @param doc
	 * @param docList
	 * @param failedList
	 * @param dbType
	 */
	public void updateSGRSCdc(String sourceDB, String sourceCollection, String currentDate, Document doc,
			List<Document> docList, List<Document> failedList,String dbType) {

		try {

			String groupID = doc.get(IConstants.GROUP_ID1).toString();
			String sourcePath = doc.get(IConstants.SOURCE_PATH_FIELD).toString();
			MongoCollection<Document> collcheck;
			BasicDBObject newDocument = new BasicDBObject();
			BasicDBObject searchQuery = new BasicDBObject().append(IConstants.GROUP_ID1, groupID)
					.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.SOURCE_PATH_FIELD, new BasicDBObject().append("$ne", sourcePath));
			FindIterable<Document> iterable;
			Document docnew;

			collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDB, sourceCollection,dbType);

			iterable = collcheck.find(searchQuery);
			docnew = iterable.first();

			if (docnew != null ) {
				newDocument.append("$set", new BasicDBObject().append(IConstants.END_DATE_FIELD, currentDate));
				collcheck.updateMany(searchQuery, newDocument);		
			}
			Utility.addToList(doc, docList, failedList);
		} catch (Exception e) {
			logger.error("Exception:  "+ e);
		}
	}

	/*
	 * This method inserts data in mongoDB dataBase
	 * 
	 * @param docList stores list of documents to insert
	 * 
	 * @param sourceDB stores database name
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @return boolean value depending on insertion process.
	 */
	public boolean insertData(List<Document> docList, String sourceDB, String sourceCollection,String dbType) {
		MongoDatabase database;
		MongoCollection<Document> coll;
		try {
			database = MongoConnector.getInstance().getMongoClient(dbType).getDatabase(sourceDB);
			coll = database.getCollection(sourceCollection);

			if (!docList.isEmpty()) {
				coll.insertMany(docList);
				return true;
			}
		} catch (Exception e) {
			logger.error("Exception:  "+ e);
		} finally {
			database = null;
			coll = null;
		}
		return false;
	}

	/*
	 * This method updates status field of documents to processed once they are
	 * transformed
	 * 
	 * @param sourceDB stores database name
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param bsonFilter stores data to be processed
	 * 
	 * @return boolean value depending on update Status process.
	 */
	public boolean updateStatus(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,String dbType) {
		MongoDatabase database = MongoConnector.getInstance().getMongoClient(dbType).getDatabase(sourceDb);
		database.getCollection(sourceCollection).updateOne(new Document(IConstants.ID, bsonFilter._1),
				new Document("$set", new Document(IConstants.STATUS_FIELD, IConstants.PROCESSED)));
		return true;
	}
	
	public boolean updateStatusF(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,String dbType) {
		MongoDatabase database = MongoConnector.getInstance().getMongoClient(dbType).getDatabase(sourceDb);
		database.getCollection(sourceCollection).updateMany(new Document(IConstants.ID, bsonFilter._1).append("end-date", IConstants.MAX_DATE),
				new Document("$set", new Document(IConstants.STATUS_FIELD, IConstants.PROCESSED)));
		return true;
	}

	/*
	 * This method returns version of document for specified guid from
	 * sourceDb.sourceCollection
	 * 
	 * @param sourceDB stores database name
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param guid stores GUID
	 * 
	 * @return version String
	 */
	public String getVersion(String sourceDb, String sourceCollection, String guid,String dbType) {
		String version = "";

		if (checkCollection(sourceDb, sourceCollection,dbType)) {
			MongoDatabase database = MongoConnector.getInstance().getMongoClient(dbType).getDatabase(sourceDb);
			MongoCollection<Document> collection = database.getCollection(sourceCollection);

			FindIterable<Document> iterable = collection
					.find(new Document(IConstants.GUID, guid).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE));

			if (iterable.first() != null)
				version = iterable.first().getString("Version");

		}

		return version;

	}
	
	public Document getDocument(String key, String value, String sourceDb, String sourceCollection,String dbType) {
		Document doc;
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
				sourceCollection,dbType);
		doc = collcheck.find(new Document(key, value).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)
				.append(IConstants.END_DATE_FIELD,IConstants.MAX_DATE)).first(); /* BPP-31928 : Not getting latest record , added Un-processed status */
		return doc;
	}
	
	public FindIterable<Document> getAllRenewalDocument(String joinField, String groupID, String sourceDb,
			String appendedCollection,String dbType) {
		FindIterable<Document> iterable;
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
				appendedCollection,dbType);
		iterable = collcheck
				.find(new Document(joinField, groupID).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)
						.append(IConstants.END_DATE_FIELD,IConstants.MAX_DATE));
		return iterable;
	}
	/* Start WSGRS change BPP-23129 */
	public FindIterable<Document> getAllNonLifeRenewalDocumentWithSubscriberID(String groupId, String subId, String sourceDb,
			String appendedCollection,String dbType) {
		FindIterable<Document> iterable;
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,appendedCollection,dbType);
		//Member_ID = Subscriber_ID
		Document eqMemberID = new Document("$eq",subId);
		Document doc=new Document(IConstants.MEMBER_ID,eqMemberID).append(IConstants.GROUP_ID1,groupId).append(IConstants.STATUS_FIELD,
				IConstants.UNPROCESSED).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE);
		iterable = collcheck.find(doc);
		
		return iterable;
	}
	
	public DistinctIterable<String> getDistinctLifeBenefits(String groupID, String sourceDb,
			String appendedCollection,String dbType) {
		DistinctIterable<String> iterable;
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
				appendedCollection,dbType);
		iterable = collcheck
				.distinct(IConstants.PRODUCT_ID1,new Document(IConstants.GROUP_ID1, groupID).append(IConstants.CURRENT_PROD_TYPE, IConstants.LFE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)
						.append(IConstants.END_DATE_FIELD,IConstants.MAX_DATE),String.class);
		return iterable;
	}
			
	public FindIterable<Document> getAllLifeRenewalDocumentWithSubscriberID(String groupId, String subId, String sourceDb,
			String appendedCollection,String dbType) {
		FindIterable<Document> iterable;
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
				appendedCollection,dbType);
	
		String[] lifeProductTypes = { "LTD", "STD", "401", "402", "403", "401SUPLF", "402SUPAD", "VLFE",
				"VDEP", "BLTD", "BSTD", "VADD", "VLTD", "VSTD" };
		BasicDBList lifeProductList = new BasicDBList();
		lifeProductList.addAll(Arrays.asList(lifeProductTypes));
		DBObject lifeProducts = new BasicDBObject("$in", lifeProductList);
		
		//is Life Products check
		Document lifeDoc=new Document(IConstants.PROD_ID2, lifeProducts).append(IConstants.GROUP_ID1, groupId).append(IConstants.SUBSCRIBER_ID, subId).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)
				.append(IConstants.END_DATE_FIELD,IConstants.MAX_DATE);
		
		
		iterable = collcheck.find(lifeDoc);
		return iterable;
	}


	public double getLifeMonthlyPrem(String sourceDb, String coll, String rdmDb, String grpID,String product) {


		double total= 0.00;
		try{
		Document query1 = new Document();
		Document query2 = new Document();
		
		query1.append("$match",new Document(IConstants.GROUP_ID1,grpID).append(IConstants.PROD_ID1, product).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE)); /* BPP-31928 : Not getting latest record , added Un-processed status */
		query2.append("$group", new Document().append(IConstants.ID, "$"+IConstants.PROD_ID1)
				.append(IConstants.TOTAL, new Document("$sum","$"+IConstants.RENEWAL_MON_PREM)));
		
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, coll,
				IConstants.RDM_DB);
		List<Document> queryList = new ArrayList<>();
		queryList.add(query1);
		queryList.add(query2);
				
		AggregateIterable<Document> resultDoc = collcheck.aggregate(queryList);
		if(resultDoc.first()!=null)
		{
			total=resultDoc.first().getDouble("total");
//			total = Math.round(total*100)/100;
		}
		}catch(Exception e)
		{
			logger.error("Exception:  " + e);
		}
		return total;
		
	}

	public double getLifeSubscriberCurrentMonthlyPrem(String sourceDb, String coll, String rdmDb, String grpID,String product,String subID) {


		double total= 0.00;
		try{
		Document query1 = new Document();
		Document query2 = new Document();
		
		query1.append("$match",new Document(IConstants.GROUP_ID1,grpID).append(IConstants.PROD_ID1, product).append(IConstants.SUBSCRIBER_ID, subID).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE)); /* BPP-31928 : Not getting latest record , added Un-processed status */
		query2.append("$group", new Document().append(IConstants.ID, "$"+IConstants.SUBSCRIBER_ID)
				.append(IConstants.TOTAL, new Document("$sum","$"+IConstants.CURR_MON_PREM)));
		
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, coll,
				IConstants.RDM_DB);
		List<Document> queryList = new ArrayList<>();
		queryList.add(query1);
		queryList.add(query2);
				
		AggregateIterable<Document> resultDoc = collcheck.aggregate(queryList);
		if(resultDoc.first()!=null)
		{
			total=resultDoc.first().getDouble("total");
//			total = Math.round(total*100)/100;
		}
		}catch(Exception e)
		{
			logger.error("Exception:  " + e);
		}
		return total;
		
	}
	
	public double getLifeSubscriberMonthlyPrem(String sourceDb, String coll, String rdmDb, String grpID,String product,String subID) {


		double total= 0.00;
		try{
		Document query1 = new Document();
		Document query2 = new Document();
		
		query1.append("$match",new Document(IConstants.GROUP_ID1,grpID).append(IConstants.PROD_ID1, product).append(IConstants.SUBSCRIBER_ID, subID).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE)); /* BPP-31928 : Not getting latest record , added Un-processed status */
		query2.append("$group", new Document().append(IConstants.ID, "$"+IConstants.SUBSCRIBER_ID)
				.append(IConstants.TOTAL, new Document("$sum","$"+IConstants.RENEWAL_MON_PREM)));
		
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, coll,
				IConstants.RDM_DB);
		List<Document> queryList = new ArrayList<>();
		queryList.add(query1);
		queryList.add(query2);
				
		AggregateIterable<Document> resultDoc = collcheck.aggregate(queryList);
		if(resultDoc.first()!=null)
		{
			total=resultDoc.first().getDouble("total");
//			total = Math.round(total*100)/100;
		}
		}catch(Exception e)
		{
			logger.error("Exception:  " + e);
		}
		return total;
		
	}
	
	/* End WSGRS change BPP-23129 */ 
	public FindIterable<Document> getAllRenewalDocument(String field, String value, String field2, String value2,
			String sourceDb, String appendedCollection, String dbType) {
		FindIterable<Document> iterable;
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
				appendedCollection, dbType);

		iterable = collcheck.find(new Document(field, value).append(field2, value2).append(IConstants.STATUS_FIELD,
				IConstants.UNPROCESSED).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE));
		return iterable;
	}

	public FindIterable<Document> getMemberDocument(String field, String value, String field2, String value2, String field3, String value3
			,String sourceDb, String appendedCollection, String dbType) {
		FindIterable<Document> iterable;
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
				appendedCollection, dbType);
		Document doc = new Document("$ne", value2);
		iterable = collcheck.find(
				new Document(field, value).append(field2, doc).append(field3, value3).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)
				.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE));
		return iterable;
	}

	/*
	 * This overidden method checks for document for specified guid in mongo
	 * database and compares it with @param doc without metadata. If the
	 * document is same it updates the timestamp of document to latest. else it
	 * creates another version of document and makes it the latest.
	 * 
	 * @param sourceDB stores database name
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param currentDate stores recent timeStamp
	 * 
	 * @param docList is java list for storing passed documents
	 * 
	 * @param failedList is java list for storing failed documents
	 * 
	 * @param guidDoc is a GUID for detail document
	 * 
	 * @return boolean value depending on process
	 */
	//@SuppressWarnings("unchecked")
	public boolean updateCdc(String sourceDB, String sourceCollection, String currentDate, Document doc,
			List<Document> docList, List<Document> failedList, boolean flag,String dbType) {
		try {
			String guid = doc.get(IConstants.GUID).toString();
			MongoCollection<Document> collcheck;
			BasicDBObject newDocument = new BasicDBObject();
			BasicDBObject searchQuery = new BasicDBObject().append(IConstants.GUID, guid)
					.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE);
			FindIterable<Document> iterable;
			Document docnew;

			String[] metadata = new String[7];

			for (int i = 0; i < IConstants.getMetadata().length; i++)
				metadata[i] = doc.getString(IConstants.getMetadata()[i]);
			collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDB, sourceCollection, dbType);

			iterable = collcheck
					.find(new Document(IConstants.GUID, guid).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE));
			docnew = iterable.first();

			// remove auto-generated objectId and metaData fields from document
			// for other fields comparison.
			if (docnew != null) {
				docnew.remove(IConstants.ID);
				for (int i = 0; i < IConstants.getMetadata().length; i++) {
					doc.remove(IConstants.getMetadata()[i]);
					doc.append(IConstants.getMetadata()[i], docnew.get(IConstants.getMetadata()[i]));
				}
			}

			// if same document found then update timeStamp of document
			if (docnew != null && docnew.equals(doc)) {
				newDocument.append("$set", new BasicDBObject().append(IConstants.START_DATE_FIELD, currentDate).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED));
				collcheck.updateOne(searchQuery, newDocument);

			}

			// else add metaData to new document, embed detail_reference docs,
			// set end_date to max date and add document to java list
			else {
				for (int i = 0; i < IConstants.getMetadata().length; i++) {
					doc.remove(IConstants.getMetadata()[i]);
					doc.append(IConstants.getMetadata()[i], metadata[i]);
				}

				/*if (dbDoc != null) {
					doc.append(IConstants.DETAIL_REFERENCE, dbDoc);
				}*/
				newDocument.append("$set", new BasicDBObject().append(IConstants.END_DATE_FIELD, currentDate));
				collcheck.updateOne(searchQuery, newDocument);
				Utility.addToList(doc, docList, failedList);
			}
		} catch (Exception e) {
			logger.error("Exception:  "+ e);

		}
		return true;
	}

	/*
	 * This method inserts error code and error description into
	 * sourceDB.sourceCollection
	 * 
	 * @param sourceDB stores database name
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param errorCode stores error code integer
	 * 
	 * @param errorDescription stores error description String
	 * 
	 * @return nothing
	 */
	public void createErrorLog(String sourceDB, String sourceCollection, String errorCode, String errorDescription,
			String data,String dbType,String method,String message,String fieldName,String type) {
		sourceCollection=dbType+"_"+sourceCollection;
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDB,
				sourceCollection, dbType);
		Document doc = new Document();

		doc.append(IConstants.ERROR_CODE, errorCode);
		doc.append(IConstants.ERROR_DESCRIPTION, errorDescription);		
		doc.append("Process", method);
		doc.append("Exception", message);
		doc.append("Field-Name", fieldName);
		doc.append("Source", type);
		doc.append(IConstants.DATA, data);
		doc.append(IConstants.DATE, new Date());
		collcheck.insertOne(doc);
	}

	public void createErrorLog(String sourceDB, String sourceCollection, String errorCode, String errorDescription,
			String data,String dbType,String method,String message) {
		sourceCollection=dbType+"_"+sourceCollection;
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDB,
				sourceCollection, dbType);
		Document doc = new Document();

		doc.append(IConstants.ERROR_CODE, errorCode);
		doc.append(IConstants.ERROR_DESCRIPTION, errorDescription);		
		doc.append("Process", method);
		doc.append("Exception", message);		
		doc.append(IConstants.DATA, data);
		doc.append(IConstants.DATE, new Date());
		collcheck.insertOne(doc);
	}
	
	public void replaceSummaryDocument(String targetDb, String collection, Document metaDoc,String dbType) {
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(targetDb, collection, dbType);
		try {
			collcheck.insertOne(metaDoc);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			
		}
		

	}
	//For WSGRS RENEWALS
	@SuppressWarnings("unchecked")
		public Object getRenewalDocumentSDS(Document doc, String sourceDb, String sourceColl,String dbType) {
				try {
					MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
							sourceColl, dbType);
			Document d = collcheck
					.find(new Document("ID", doc.getString("ID")).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)
							.append("renewalDate", doc.get("renewalDate")))
					.first();
					
						List<Document> renDetails = (List<Document>) d.get(IConstants.RENEWAL_DETAILS);
						return renDetails;
					
				} catch (Exception e) {
					logger.error(IConstants.ERROR_PREPEND, e);
					}
				return null;

			} 
		
	//For WSGRS RENEWALS
		@SuppressWarnings("unchecked")
		public Object getRenewalDocumentSDSDetail(Document doc, String sourceDb, String sourceColl,String dbType,String targetDb)/* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */ {
				try {
					ProcessFieldNames groupDetailPremium = null;
					groupDetailPremium = FieldNamesProperties.getInstance().getPropertyContext("groupDetailPremium");
					List<Document> benefits = new ArrayList<>();
					
					MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
							sourceColl, dbType);
			Document d = collcheck
					.find(new Document("ID", doc.getString("ID")).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)
							.append("renewalDate", doc.get("renewalDate")))
					.first();
					
						List<Document> renDetails = (List<Document>) d.get(IConstants.RENEWAL_DETAILS);
//						System.out.println("1125MConn :"+renDetails.size());
						for(Document renDoc : renDetails){
							
							ArrayList<Document> renProdList = (ArrayList<Document>) renDoc.get("renewalProducts");
							Document tempDoc= renProdList.get(0);	
							Document premiumDoc = new Document();
							List<Document> premiumDocList = new ArrayList<>();
							Document benefitDoc = new Document();
							addToDocument(groupDetailPremium, tempDoc, "groupDetailPremium", premiumDoc);
							benefitDoc.append("productType", renDoc.get("productType"));
							benefitDoc.append("renewalContractPlanCode", tempDoc.getString("contractPlanCode"));
							benefitDoc.append("renewalContractPlanName", getPlanName(tempDoc.getString("contractPlanCode")
									,targetDb,IConstants.SDSREN_DB));/* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
							benefitDoc.append(IConstants.BENEFITTYPE, "renewalProducts");
							premiumDocList.add(premiumDoc);
							benefitDoc.append("premium", premiumDocList);							
							benefitDoc.append("currentContractPlanCode",renDoc.get("currentContractPlanCode"));
							benefitDoc.append("currentContractPlanName",renDoc.get("currentContractPlanName"));						
							renDoc.append(IConstants.BENEFITTYPE, IConstants.CURRENTPRODUCTS);
							renDoc.remove("renewalProducts");							
							benefits.add(renDoc);
							benefits.add(benefitDoc);
							
						}
						
						return benefits;
					
				} catch (Exception e) {
					logger.error(IConstants.ERROR_PREPEND, e);
					}
				return null;

			}
		
		
		private void addToDocument(ProcessFieldNames processFieldNames, Document bsonFilter, String mappingName,
				Document document) {
			neglectList.add("");
			neglectList.add(null);
			for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!neglectList.contains(bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

					document.append(fieldNames, bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

			}

		}
			
			//For other renewal sources
		@SuppressWarnings("unchecked")
			public Object getRenewalDocumentSDS(Tuple2<Object, BSONObject> bsonFilter, String sourceDb, String sourceColl,String dbType,String returnField) {
				try {
					MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
							sourceColl, dbType);
					
					//Document docRen = (Document) collcheck.find(new Document("GUID", bsonFilter._2.get("GUID").toString())).first();
					/* BPP-31929 Start for FACETS O65 and FACETS GBD Renewal Summary  && BPP-31606 : ISG NON ACA Renewal Summary */
					Document docRen = (Document) collcheck.find(new Document(IConstants.GUID, bsonFilter._2.get("GUID").toString()).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)).first();	
					/* BPP-31929 End for FACETS O65 and FACETS GBD Renewal Summary && BPP-31606 : ISG NON ACA Renewal Summary */  
						List<Document> renDetails =  (List<Document>) docRen.get(returnField);
						return renDetails;
					
				} catch (Exception e) {
					logger.error(IConstants.ERROR_PREPEND, e);
					}
				return null;

			} 
		
	
		//For other renewal sources
		@SuppressWarnings("unchecked")
			public Object getRenewalDocumentSDSDetail(Tuple2<Object, BSONObject> bsonFilter, String sourceDb, String sourceColl,String dbType) {
				try {
					
					ProcessFieldNames memberDetailPremium = null;
					memberDetailPremium = FieldNamesProperties.getInstance().getPropertyContext("memberDetailPremium");
					List<Document> benefits = new ArrayList<>();
					
					MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
							sourceColl, dbType);
					
					//Document docRen = (Document) collcheck.find(new Document("GUID", bsonFilter._2.get("GUID").toString())).first();
					/* BPP-31929 Start for FACETS O65 and FACETS GBD RenewalDetails */
					Document docRen = (Document) collcheck.find(new Document(IConstants.GUID, bsonFilter._2.get("GUID").toString()).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)).first();	
					/* BPP-31929 End for FACETS O65 and FACETS GBD RenewalDetails */
						List<Document> renDetails =  (List<Document>) docRen.get(IConstants.RENEWAL_DETAILS);
												
							for(Document renDoc : renDetails){
								ArrayList<Document> renProdList = (ArrayList<Document>) renDoc.get("renewalProducts");
								Document tempDoc= renProdList.get(0);							
								Document premiumDoc = new Document();
								List<Document> premiumDocList = new ArrayList<>();
								Document benefitDoc = new Document();
								addToDocument(memberDetailPremium, tempDoc, "memberDetailPremium", premiumDoc);
								benefitDoc.append("contractPlanCode", tempDoc.getString("contractPlanCode"));
								benefitDoc.append(IConstants.BENEFITTYPE, "renewalProducts");
								premiumDocList.add(premiumDoc);
								benefitDoc.append("premium", premiumDocList);
								benefitDoc.append("currentContractPlanCode",renDoc.get("currentContractPlanCode"));
								benefitDoc.append("currentContractPlanName",renDoc.get("currentContractPlanName"));
								renDoc.append(IConstants.BENEFITTYPE, IConstants.CURRENTPRODUCTS);
								renDoc.remove("renewalProducts");
								benefits.add(renDoc);
								benefits.add(benefitDoc);
								
							}
							
							return benefits;
						
					
				} catch (Exception e) {
					logger.error(IConstants.ERROR_PREPEND, e);
					}
				return null;

			} 

		//For other renewal sources
				@SuppressWarnings("unchecked")
					public Object getRenewalDocumentSDSDetailModified(Tuple2<Object, BSONObject> bsonFilter, String sourceDb, String sourceColl,String dbType) {
						try {
							
							ProcessFieldNames memberDetailPremium = null;
							memberDetailPremium = FieldNamesProperties.getInstance().getPropertyContext("memberDetailPremium");
							List<Document> benefits = new ArrayList<>();
							
							MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
									sourceColl, dbType);
							
			Document docRen = (Document) collcheck.find(new Document("GUID", bsonFilter._2.get("GUID").toString())
					.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)).first(); /* BPP-31928 : Not getting latest record , added Un-processed status */
								List<Document> renDetails =  (List<Document>) docRen.get(IConstants.RENEWAL_DETAILS);
														
									for(Document renDoc : renDetails){
										ArrayList<Document> renProdList = (ArrayList<Document>) renDoc.get("renewalProducts");
										Document tempDoc= renProdList.get(0);							
										Document premiumDoc = new Document();
										List<Document> premiumDocList = new ArrayList<>();
										Document benefitDoc = new Document();
										Document currBenefitDoc = new Document();
										addToDocument(memberDetailPremium, tempDoc, "memberDetailPremium", premiumDoc);
										premiumDoc.append("monthlyPremium", renDoc.get("renewalMonthlyPremium"));
										benefitDoc.append("contractPlanCode", renDoc.getString("renewalContractPlanCode"));
										/* Start BPP-22918 added 'renewalLetterCode' only for renewal plan in 'Benefits' document in 'RenewalDetails' Collection for ISG ACA Individual */
										benefitDoc.append("renewalLetterCode",renDoc.get("renewalLetterCode"));
										/* End BPP-22918 Letter codes */
										if(renDoc.containsKey("renewalSubsidy")){
											if(renDoc.get("renewalSubsidy").toString().equals("0.0") || renDoc.get("renewalSubsidy") == null 
													|| renDoc.get("renewalSubsidy").toString().isEmpty()){
												premiumDoc.append("renewalSubsidy","No");
											}else{
												premiumDoc.append("renewalSubsidy",renDoc.get("renewalSubsidy"));
											}
										}else{
											premiumDoc.append("renewalSubsidy","No");
										}
										
										benefitDoc.append(IConstants.BENEFITTYPE, "renewalProducts");
										premiumDocList.add(premiumDoc);
										benefitDoc.append("premium", premiumDocList);
										benefitDoc.append("currentContractPlanCode",renDoc.get("currentContractPlanCode"));
										benefitDoc.append("currentContractPlanName",renDoc.get("currentContractPlanName"));
										benefitDoc.append("renewalContractPlanCode",renDoc.get("renewalContractPlanCode"));
										benefitDoc.append("renewalContractPlanName",renDoc.get("renewalContractPlanName"));
                                        /* Start BPP-22918 added 'renewalLetterCode' only for renewal plan in 'Benefits' document in 'RenewalDetails' Collection for ISG ACA Individual */
										benefitDoc.append("renewalLetterCode",renDoc.get("renewalLetterCode"));
										/* End BPP-22918 Letter codes */
										benefitDoc.append("productType",renDoc.get("product"));
										//benefitDoc.append("renewalSubsidy",0.0);
										if(renDoc.get("renewalSubsidy").toString().equals("0.0") || renDoc.get("renewalSubsidy") == null 
												|| renDoc.get("renewalSubsidy").toString().isEmpty()){
											benefitDoc.append("renewalSubsidy","No");
										}else{
											benefitDoc.append("renewalSubsidy",renDoc.get("renewalSubsidy"));
										}
										
										currBenefitDoc.append("currentContractPlanCode",renDoc.get("currentContractPlanCode"));
										currBenefitDoc.append("currentContractPlanName",renDoc.get("currentContractPlanName"));
										currBenefitDoc.append("currentTotalPremium",renDoc.get("currentTotalPremium"));
										//currBenefitDoc.append("currentSubsidy",renDoc.get("currentSubsidy"));
										if(renDoc.get("currentSubsidy").toString().equals("0.0") || renDoc.get("currentSubsidy") == null 
												|| renDoc.get("renewalSubsidy").toString().isEmpty()){
											currBenefitDoc.append("currentSubsidy","No");
										}else{
											currBenefitDoc.append("currentSubsidy",renDoc.get("currentSubsidy"));
										}
										currBenefitDoc.append("currentPremiumwithoutSubsidy",renDoc.get("currentPremiumwithoutSubsidy"));
										currBenefitDoc.append("productType",renDoc.get("product"));
										//currBenefitDoc.append("currentMonthlyPremium",renDoc.get("renewalMonthlyPremium"));
										currBenefitDoc.append("currentMonthlyPremium",renDoc.get("currentTotalPremium"));
										currBenefitDoc.append(IConstants.BENEFITTYPE, IConstants.CURRENTPRODUCTS);
										
										if(currBenefitDoc.containsKey(IConstants.CURR_CONT_PLAN_CODE) &&
												currBenefitDoc.get(IConstants.CURR_CONT_PLAN_CODE)!= null &&
												!currBenefitDoc.get(IConstants.CURR_CONT_PLAN_CODE).toString().equals(""))
											benefits.add(currBenefitDoc);
										if(benefitDoc.containsKey(IConstants.CURR_CONT_PLAN_CODE) &&
												benefitDoc.get(IConstants.CURR_CONT_PLAN_CODE)!= null &&
												!benefitDoc.get(IConstants.CURR_CONT_PLAN_CODE).toString().equals(""))
											benefits.add(benefitDoc);
										
									}
									
									return benefits;
								
							
						} catch (Exception e) {
							logger.error(IConstants.ERROR_PREPEND, e);
							}
						return null;

					} 

		
		
		
	public void updateAllStatus(String sourceDb, String sourceCollection, String sourcePath,String dbType) {
		SystemProperties.initializeProperties("eas");
		String flag = SystemProperties.getProperty("HadoopFileSystem");
		if("true".equals(flag))
			sourcePath = SystemProperties.getProperty("HadoopUri")+sourcePath;
		MongoDatabase database =  MongoConnector.getInstance().getMongoClient(dbType).getDatabase(sourceDb);
		database.getCollection(sourceCollection).updateMany(
				new Document(IConstants.SOURCE_PATH_FIELD, new Document("$regex", "^"+sourcePath))
						.append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED),
				new Document("$set", new Document(IConstants.STATUS_FIELD, IConstants.PROCESSED)));

	}

	public void updateAllDetailStatus(String sourceDb, String appendedCollection, String sourcePath,String dbType) {
		SystemProperties.initializeProperties("eas");
		String flag = SystemProperties.getProperty("HadoopFileSystem");
		if("true".equals(flag))
			sourcePath = SystemProperties.getProperty("HadoopUri")+sourcePath;
		MongoDatabase database = MongoConnector.getInstance().getMongoClient(dbType).getDatabase(sourceDb);
		database.getCollection(appendedCollection).updateMany(
				new Document(IConstants.SOURCE_PATH_FIELD, new Document("$regex", "^"+sourcePath))
						.append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED),
				new Document("$set", new Document(IConstants.STATUS_FIELD, IConstants.PROCESSED)));

	}

	public void updateAllTDMStatus(String sourceDB, String sourceCollection, String sourcePath,String dbType) {

		try {
			
			MongoConnector.getInstance().updateAllStatus(sourceDB, sourceCollection, sourcePath,dbType);

		} catch (Exception e) {
			logger.error("No Detail Documents in Transformation" + e);
		} finally {
		}

	}

	public double getCurMonthlyPrem(String sourceDb, String coll, String rdmDb, String grpID, String prodID) {


		double total= 0;
		try{
		Document query1 = new Document();
		Document query2 = new Document();
		
		query1.append("$match",new Document(IConstants.GROUP_ID1,grpID).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE)
				.append(IConstants.PROD_ID1, prodID));
		query2.append("$group", new Document().append(IConstants.ID, "$"+IConstants.PROD_ID1)
				.append(IConstants.TOTAL, new Document("$sum","$"+IConstants.CURR_MON_PREM)));
		
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, coll,
				IConstants.RDM_DB);
		List<Document> l = new ArrayList<>();
		l.add(query1);
		l.add(query2);
				
		AggregateIterable<Document> ddd = collcheck.aggregate(l);
		if(ddd.first()!=null)
		{
			total=ddd.first().getDouble("total");
			total = Math.round(total*100)/100;
		}
		}catch(Exception e)
		{
			logger.error("Exception:  " + e);
		}
		return total;
		
	}


	public double getCurMonthlyPrem(String sourceDb, String coll, String rdmDb, String grpID) {


		double total= 0.00;
		try{
		Document query1 = new Document();
		Document query2 = new Document();
		
		query1.append("$match",new Document(IConstants.GROUP_ID1,grpID).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE)); /* BPP-31928 : Not getting latest record , added Un-processed status */ 
		query2.append("$group", new Document().append(IConstants.ID, "$"+IConstants.GROUP_ID1)
				.append(IConstants.TOTAL, new Document("$sum","$"+IConstants.CURR_MON_PREM)));
		
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, coll,
				IConstants.RDM_DB);
		List<Document> l = new ArrayList<>();
		l.add(query1);
		l.add(query2);
				
		AggregateIterable<Document> ddd = collcheck.aggregate(l);
		if(ddd.first()!=null)
		{
			total=ddd.first().getDouble("total");
//			total = Math.round(total*100)/100;
		}
		}catch(Exception e)
		{
			logger.error("Exception:  " + e);
		}
		return total;
		
	}

	public double getMonthlyPrem(String sourceDb, String coll, String rdmDb, String grpID) {


		double total= 0.0;
		try{
		Document query1 = new Document();
		Document query2 = new Document();
		
		query1.append("$match",new Document(IConstants.GROUP_ID1,grpID).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE)); /* BPP-31928 : Not getting latest record , added Un-processed status */
//		.append(IConstants.RENEWAL_MON_PREM, new Document("ne",""))
		query2.append("$group", new Document().append(IConstants.ID, "$"+IConstants.GROUP_ID1)
				.append(IConstants.TOTAL, new Document("$sum","$"+IConstants.RENEWAL_MON_PREM)));
		
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, coll,
				IConstants.RDM_DB);
		List<Document> l = new ArrayList<>();
		l.add(query1);
		l.add(query2);
				
		AggregateIterable<Document> ddd = collcheck.aggregate(l);
		if(ddd.first()!=null)
		{
			total=ddd.first().getDouble("total");
//			total = Math.round(total*100)/100;
//			System.out.println("1646 : "+total);
		}
		}catch(Exception e)
		{
			logger.error("Exception:  " + e);
		}
		return total;
		
	}

	
	public void addGrpDelta(Document benefitDocument) {

		double currMonPrem =0.0, diff=0.0 ;
		double monPrem =0.0, delta =0.0;
		try{
		currMonPrem = benefitDocument.getDouble(IConstants.CURR_MON_PREMIUM);
		monPrem = benefitDocument.getDouble(IConstants.MON_PREM);
		diff = monPrem-currMonPrem;
		delta = (diff/currMonPrem)*100;
//		diff = Math.round(diff*100)/100;
//		delta = Math.round(delta*100)/100;
		
		}catch(Exception e)
		{
			logger.error("Exception:  " + e);
		}
		benefitDocument.append("Delta", delta);
		benefitDocument.append("Difference", diff);
	}

	public void putCalFields(Document summaryDoc, String sourceDb, String sourceColl, String udmDb) {

		double currPrem = 0.00, monPrem = 0.00;
		Document d=null;
		try {
			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, sourceColl,
					udmDb);
			d = collcheck.find(new Document("ID", summaryDoc.getString("groupID")).append(IConstants.END_DATE_FIELD,
					IConstants.MAX_DATE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)).first();
			if (d.containsKey(IConstants.CURR_MON_PREMIUM))
				currPrem = d.getDouble(IConstants.CURR_MON_PREMIUM);
			if (d.containsKey(IConstants.MON_PREM))
				monPrem = d.getDouble(IConstants.MON_PREM);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		summaryDoc.append(IConstants.CURR_MON_PREMIUM, currPrem);
		summaryDoc.append(IConstants.MON_PREM, monPrem);

	}
	
	public FindIterable<Document> getMemberDocument(String field, String value,
			String sourceDb, String appendedCollection, String dbType) {
		FindIterable<Document> iterable;
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
				appendedCollection, dbType);
		//Document doc = new Document("$eq", value2);
		iterable = collcheck.find(
				new Document(field, value).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)
				.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE));
		return iterable;
	}
	
	public FindIterable<Document> getMemberDocument(String field, String value,String field1,
			String value2,String sourceDb, String appendedCollection, String dbType) {
		FindIterable<Document> iterable;
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
				appendedCollection, dbType);
		//Document doc = new Document("$eq", value2);
		iterable = collcheck.find(
				new Document(field, value).append(field1, value2).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)
				.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE));
		return iterable;
	}
	/* Start BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
	public FindIterable<Document> getPlanName(String field, String value, String sourceDb,
			String appendedCollection, String dbType){
		FindIterable<Document> iterable;
		
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
				appendedCollection, dbType);
		iterable = collcheck.find(new Document(field, value));
		return iterable;
	}
	
	private String getPlanName(String planCode,String sourceDb,String dbType){
		String strPlanName ="";		
		
		if(planNames.get(planCode) != null){
			return planNames.get(planCode);
		}
		
		FindIterable<Document> objPlanName = MongoConnector.getInstance().
				getPlanName("contractID", planCode, sourceDb, "RenewalPlanDetails", IConstants.SDSREN_DB);
		
		for(Document objPlan:objPlanName){
			strPlanName = objPlan.getString("productMKTName");
			planNames.put(planCode, strPlanName);
			return strPlanName;
		}		
		return strPlanName;
	}
	/*End BPP-34308 : Renewal Service performance degradation issues (Data fix)  */

	/* Start [BPP-37713] : Audit tracking Changes  */
	public List<Document> populateTinIfNotExist(List<Document> agentDocList,String clientID){
		
	    Document writingSubDocument = new Document(); 
		Document paidSubDocument = new Document(); 
		Document parentSubDocument = new Document();
		
		String client_Id = null;
		
		if (StringUtils.isNotBlank(clientID))
		{
			 client_Id = clientID;
		}
		
		HashMap<String, String> agentsmap = new HashMap<>(); 
		  
		   
		   if(agentDocList.size() >= 1)
		   {
			   for(Document agentDoc: agentDocList)
			   {	
				   if (StringUtils.isNotBlank(agentDoc.getString(TAX_ID_TYPE)) && StringUtils.isNotBlank(agentDoc.getString(TAX_ID)))
						   {
					   			 agentsmap.put(agentDoc.getString(TAX_ID_TYPE), agentDoc.getString(TAX_ID));
						   }
			   }
		   }
		   
		if (agentsmap.size() == 1)
		{
			 	/*AgentDocList Contains only WritingSubDocument*/
				if (agentsmap.containsKey(IConstants.WRITING) )
				{
		        	 writingSubDocument = agentDocList.get(0);
					
					/* Pass the WritingSubDocument and Populate PaidSubDocument and ParentSubDocument */
					agentDocList = populatePaidnParentfrmWriting(writingSubDocument);
					
					/* Performs Null Check on SubDocument's TaxIdType & TaxId ,segregates and adds to the agentDocList */
					//agentDocList = performNullCheckAndSegregatesSubdocuments(agentDocList); 
					
					agentDocList = populateIsVisibleFlagforWrtPadPrt (agentDocList,client_Id,SDS);

					return agentDocList;
				}
			    //AgentDocList Contains only PaidSubDocument
				else if (agentsmap.containsKey(IConstants.PAID))
				{
				   logger.info("Client ID [" +clientID+ "] doesn't contain the WritingTin and Contains only ["+agentsmap.get(TAX_ID_TYPE)+"] Paid Tin[" + agentsmap.get(TAX_ID) + "]");
				} 
				  
				else //AgentDocList Contains only ParentSubDocument
				{
					logger.info("Client ID [" +clientID+ "] doesn't contain the WritingTin and Contains only ["+agentsmap.get(TAX_ID_TYPE)+"]  ParentTin :[" + agentsmap.get(TAX_ID) + "]");
				}
		}		
		 else if (agentsmap.size() == 2)
		{
			 
			 for (Document agentSubDocument : agentDocList)
				{
						if ( isNotNull(agentSubDocument) && StringUtils.isNotBlank(agentSubDocument.getString(TAX_ID_TYPE)) && StringUtils.isNotBlank(agentSubDocument.getString(TAX_ID)) )
						{
							if (agentSubDocument.getString(TAX_ID_TYPE).equalsIgnoreCase(IConstants.WRITING))
							{
								writingSubDocument = getSubDocument(IConstants.WRITING, agentSubDocument);
							}
							else if (agentSubDocument.getString(TAX_ID_TYPE).equalsIgnoreCase(IConstants.PAID))
							{
								paidSubDocument = getSubDocument(IConstants.PAID, agentSubDocument);
							}
							else if (agentSubDocument.getString(TAX_ID_TYPE).equalsIgnoreCase(IConstants.PARENT))
							{
								parentSubDocument = getSubDocument(IConstants.PARENT, agentSubDocument);
							}
							
						}
						
						
				}
			 
			 
			 if (isNotNull(writingSubDocument) && isNotNull(paidSubDocument)  && agentsmap.containsKey(IConstants.WRITING) && agentsmap.containsKey(IConstants.PAID))
				 		{
			 				parentSubDocument = populateParentSubDocument(paidSubDocument);
			 				
			 				addSubDocumentsToAgentDocList(agentDocList, writingSubDocument, paidSubDocument, parentSubDocument);
				 			
			 				agentDocList = performNullCheckAndSegregatesSubdocuments(agentDocList);
				 			
				 			agentDocList = populateIsVisibleFlagforWrtPadPrt (agentDocList,client_Id,SDS);
							
							return agentDocList;
				 			
				 		}
				 		else if (isNotNull(writingSubDocument) && isNotNull(parentSubDocument) && agentsmap.containsKey(IConstants.WRITING) && agentsmap.containsKey(IConstants.PARENT))
						{
				 			paidSubDocument = populatePaidSubDocument(parentSubDocument);
				 			
				 			addSubDocumentsToAgentDocList(agentDocList, writingSubDocument, paidSubDocument, parentSubDocument);
				 			
				 			agentDocList = performNullCheckAndSegregatesSubdocuments(agentDocList);
				 			
				 			agentDocList = populateIsVisibleFlagforWrtPadPrt (agentDocList,client_Id,SDS);
							
							return agentDocList;
				 			
						}
				 		else 
				 		{
				 			logger.info("Client ID [" +client_Id+ "] doesn't contain the WritingTin");
				 		}
		 }
	
		else if (agentDocList.size() == 3 && agentsmap.size() == 3)
		{
			
			agentDocList = performNullCheckAndSegregatesSubdocuments(agentDocList);
			
			agentDocList = populateIsVisibleFlagforWrtPadPrt (agentDocList,client_Id,SDS);
		
			return agentDocList;
		
		}else
		{
			logger.info("agentDocListSize is more than Three.....");
		}
		return agentDocList;
		
}

	/**
	 * This Method gets the agentDocList and Populate value to the IsVisibleFlag field by hitting the "BrokerClientInfo" Collection by passing ClientID 
     * adds new field IsVisibleFlag to writingSubDocuments,paidSubDocument,ParentSubDocument present in the agentDocList 
	 * @param agentDocList
	 * @param clientId
	 * @param targetDb
	 */
	@SuppressWarnings("unused")
	public List<Document> populateIsVisibleFlagforWrtPadPrt(List<Document> agentsDocList, String clientId, String targetDb) {
		try {
			String appointment = null;
			String ownership = null;
			String rts = null;
			
			String paidTinAppointment= null;
			String parentTinAppointment = null;
			
			String writingIsVisibleFlag = "Y";
			String paidIsVisibleFlag = "Y";
			String parentIsVisibleFlag = "Y";
			
			
			Document writingDoc = null; 
			Document paidDoc = null;
			Document parentDoc = null;
			
			/*  Fetching the segregating Writing,Paid and Parent subDocument and that same document we are adding the  isVisibleFlag  */
			for (Document agentSubDocument : agentsDocList)
			{
					if ( isNotNull(agentSubDocument) && StringUtils.isNotBlank(agentSubDocument.getString(TAX_ID_TYPE)) && StringUtils.isNotBlank(agentSubDocument.getString(TAX_ID)) )
					{
						if (agentSubDocument.getString(TAX_ID_TYPE).equalsIgnoreCase(IConstants.WRITING))
						{
							writingDoc = getSubDocument(IConstants.WRITING, agentSubDocument);
						}
						else if (agentSubDocument.getString(TAX_ID_TYPE).equalsIgnoreCase(IConstants.PAID))
						{
							paidDoc = getSubDocument(IConstants.PAID, agentSubDocument);
						}
						else if (agentSubDocument.getString(TAX_ID_TYPE).equalsIgnoreCase(IConstants.PARENT))
						{
							parentDoc = getSubDocument(IConstants.PARENT, agentSubDocument);
						}
					}
			}
			
			
			if (StringUtils.isNotBlank(clientId)) 
				{
					
					MongoCollection<Document> brokerInfoCollection = MongoConnector.getInstance().getCollectionDetail(targetDb,TABLE_BROKER_CLIENT_INFO, IConstants.SDSREN_DB);
					
					BasicDBList andList = new BasicDBList();
					andList.add( new Document(CLIENT_ID,clientId) );
					//andList.add( new Document(APPOINTMENT,writingTin) );
					//andList.add( new Document(PAID_TIN,paidTin) );
					//andList.add( new Document(PARENT_TIN,parentTin) );
					
					//List<Document>  listbrokerdocuments = (List<Document>) brokerInfoCollection.find(new Document("$and", andList));
					FindIterable<Document> listbrokerdocuments = brokerInfoCollection.find(new Document("$and", andList));
					
					/*BasicDBObject query = new BasicDBObject();
					query.put("dateAdded", new BasicDBObject("$gte", fromDate));
					query.put("dateAdded", new BasicDBObject("$lte", toDate));
					collection.find(query).sort(new BasicDBObject("dateAdded", -1));*/
					
					
					for(Document brokerdocument : listbrokerdocuments )
					{
						
						//Date UpdatedDate = brokerdocument.getDate(UPDATEDDATE);
						//Boolean isLatestDoc = true;
						
						if (brokerdocument.getString(WRITING_TIN).equals(writingDoc.getString(TAX_ID)))
						{
							if( StringUtils.isNotBlank(brokerdocument.getString(APPOINTMENT))  && !(brokerdocument.getString(APPOINTMENT).equalsIgnoreCase(NULL)) )
							{
								appointment = brokerdocument.getString(APPOINTMENT);
							}
							if(StringUtils.isNotBlank(brokerdocument.getString(OWNERSHIP))  && !(brokerdocument.getString(OWNERSHIP).equalsIgnoreCase(NULL)))
							{
								ownership = brokerdocument.getString(OWNERSHIP);
							}
							if(StringUtils.isNotBlank(brokerdocument.getString(RTS))  && !(brokerdocument.getString(RTS).equalsIgnoreCase(NULL)))
							{
								rts = brokerdocument.getString(RTS);
							}
						}
						if(brokerdocument.getString(PAID_TIN).equals(paidDoc.getString(TAX_ID)) && StringUtils.isNotBlank(brokerdocument.getString(PAID_TINAPPOINTMENT))  &&   !(brokerdocument.getString(PAID_TINAPPOINTMENT).equalsIgnoreCase(NULL)))
						{
							paidTinAppointment = brokerdocument.getString(PAID_TINAPPOINTMENT);
						}						
						if((brokerdocument.getString(PARENT_TIN).equals(paidDoc.getString(TAX_ID))  && StringUtils.isNotBlank(brokerdocument.getString(PARENT_TINAPPOINTMENT)) &&  !(brokerdocument.getString(PARENT_TINAPPOINTMENT).equalsIgnoreCase(NULL))))
						{
							parentTinAppointment = brokerdocument.getString(PARENT_TINAPPOINTMENT);
						}
					}
				
			   if (StringUtils.isNotBlank(appointment) && StringUtils.isNotBlank(ownership) && StringUtils.isNotBlank(rts))
			   {
					if(appointment.equalsIgnoreCase(NO)|| ownership.equalsIgnoreCase(NO) || rts.equalsIgnoreCase(NO))
					
					{
						writingIsVisibleFlag= N;
					}
				
			   }
			   writingDoc.append(IS_VISIBLE,writingIsVisibleFlag);
				
				if (StringUtils.isNotBlank(paidTinAppointment) && paidTinAppointment.equalsIgnoreCase(NO) )
				{
							paidIsVisibleFlag= N;
				}
				paidDoc.append(IS_VISIBLE,paidIsVisibleFlag);
				
				if (StringUtils.isNotBlank(parentTinAppointment) && parentTinAppointment.equalsIgnoreCase(NO) )
				{
						parentIsVisibleFlag= N;
				}
				parentDoc.append(IS_VISIBLE,parentIsVisibleFlag);
				
				addSubDocumentsToAgentDocList(agentsDocList, writingDoc, paidDoc, parentDoc);
				
			}
		}
		catch (Exception e) {
			logger.error("Client ID :"+clientId + "Exception in populateIsVisibleFlagforWrtPadPrt " + e);
		}
		return agentsDocList;
	}
/**
* @param writingSubDocument
* @param agentDoc
* @return
*/
/* This method gets the agentsDocList and checks respective AgentTaxIdType and TaxID values are not null, then replace the respectiveAgentSubDocument into agentsDocList again.
* Ex. Method gets agentsDocList and checks the AgentType:"Writing" and WritingTaxid is not null, then assign that agentsubDocument as writingSubDocument, like wise or Paid and Parent also*/
private List<Document> performNullCheckAndSegregatesSubdocuments(List<Document> agentsDocList) 
{
	Document writingSubDocument = new Document(); 
	Document paidSubDocument = new Document(); 
	Document parentSubDocument = new Document();
	
	for (Document agentSubDocument : agentsDocList)
	{
			if ( isNotNull(agentSubDocument) && StringUtils.isNotBlank(agentSubDocument.getString(TAX_ID_TYPE)) && StringUtils.isNotBlank(agentSubDocument.getString(TAX_ID)) )
			{
				
				if (agentSubDocument.getString(TAX_ID_TYPE).equalsIgnoreCase(IConstants.WRITING))
				{
					writingSubDocument = getSubDocument(IConstants.WRITING, agentSubDocument);
				}
				else if (agentSubDocument.getString(TAX_ID_TYPE).equalsIgnoreCase(IConstants.PAID))
				{
					paidSubDocument = getSubDocument(IConstants.PAID, agentSubDocument);
				}
				else if (agentSubDocument.getString(TAX_ID_TYPE).equalsIgnoreCase(IConstants.PARENT))
				{
					parentSubDocument = getSubDocument(IConstants.PARENT, agentSubDocument);
				}
				
			}
	}
	
	/*Now the Validated Writing, Paid and Parent subDocuments where passed to add into the AgentDocList */
	agentsDocList = addSubDocumentsToAgentDocList (agentsDocList,writingSubDocument,paidSubDocument,parentSubDocument);
	
	return agentsDocList;
}

/**
* @param AgentType
* @param agentSubDocument
* @return
*/
private Document getSubDocument(String agentType, Document agentSubDocument) {
	
	Document subDocument = new Document();
	
	if (agentSubDocument.getString(TAX_ID_TYPE).equalsIgnoreCase(agentType))
	{
		subDocument = agentSubDocument; 
		logger.info("The" +agentSubDocument.getString(TAX_ID_TYPE) +"TaxID is : "+ agentSubDocument.getString(TAX_ID));
	}
	return subDocument;
}

/**
* @param agentDocList
* @param writingSubDocument
* @param paidSubDocument
* @param parentSubDocument
*/
private List<Document> addSubDocumentsToAgentDocList(List<Document> agentDocList, Document writingSubDocument,Document paidSubDocument, Document parentSubDocument) {
		
	agentDocList.clear();
	
	try
	{
		agentDocList.add(0, writingSubDocument);
		agentDocList.add(1, paidSubDocument);
		agentDocList.add(2, parentSubDocument);
		
		/*agentDocList.set(0, writingSubDocument);
		agentDocList.set(1, paidSubDocument);
		agentDocList.set(2, parentSubDocument);*/
	}
	catch (Exception e) {
		logger.error("Error{}", e);
	}
	return agentDocList;
}

	/**
	 * @param writingSubDocument
	 * @return agentDocList
	 **/
	/* Populate the Paid Tin using the Writing Tin and  Parent Tin using the Paid Tin */
	private List<Document> populatePaidnParentfrmWriting(Document writingSubDocument) {
		
		List<Document> agentDocList = new ArrayList<Document>();
		
		Document paidSubDocument = new Document();
		Document parentSubDocument = new Document();
		
		paidSubDocument = populatePaidSubDocument(writingSubDocument);
		parentSubDocument = populateParentSubDocument(paidSubDocument);
		
		addSubDocumentsToAgentDocList(agentDocList, writingSubDocument, paidSubDocument, parentSubDocument);
		
		return agentDocList;
		
	}

	/**
	 * @param subDocument
	 * @return paidSubDocument
	 */
	private Document populatePaidSubDocument(Document subDocument) {
		Document paidSubDocument;
		
		paidSubDocument = new Document();
		paidSubDocument.append(TAX_ID,subDocument.getOrDefault(TAX_ID,"").toString());
		paidSubDocument.append(NAME,subDocument.getOrDefault(NAME,"").toString());
		paidSubDocument.append(AGENT_ID,subDocument.getOrDefault(AGENT_ID,"").toString());
		paidSubDocument.append(TAX_ID_TYPE,PAID);	
		paidSubDocument.append(PRODUCT,PAID);	
		//paidSubDocument.append("product",writingSubDocument.getOrDefault("product","Medical").toString());
		return paidSubDocument;
		
		//Document subDocument;
		//subDocument.append(TAX_ID_TYPE,PAID);
		//subDocument.append(PRODUCT,PAID);
		//return subDocument;
	}
	
	/**
	 * @param subDocument
	 * @return parentSubDocument
	 */
	private Document populateParentSubDocument(Document subDocument) {
		Document parentSubDocument;
		parentSubDocument = new Document();
		parentSubDocument.append(TAX_ID,subDocument.getOrDefault(TAX_ID,"").toString());
		parentSubDocument.append(NAME,subDocument.getOrDefault(NAME,"").toString());
		parentSubDocument.append(AGENT_ID,subDocument.getOrDefault(AGENT_ID,"").toString());
		parentSubDocument.append(TAX_ID_TYPE,PARENT);	
		parentSubDocument.append(PRODUCT,PARENT);	
		//parentSubDocument.append("product",paidSubDocument.getOrDefault("product","Medical").toString());
		return parentSubDocument;
	}
	
	/**
	 * Pass the Value & HashMap, this method will return the Key from the HashMap, 
	 * @param harshMap
	 * @param value
	 * @return key
	 */
	public static Object getKeyFromValue(Map<String,String> harshMap, Object value) {
	    for (Object key : harshMap.keySet()) {
	      if (harshMap.get(key).equals(value)) {
	        return key;
	      }
	    }
	    return null;
	  }
	
	public boolean isNotNull(Object myObj)
	{
	  return (null != myObj);
	}
	
	public boolean isNull(Object myObj)
	{
	  return (null == myObj);
	}
	
	/* End[BPP-37713] : Audit tracking Changes */
	
	public Document appendContacts(String targetDb,String agentTaxID,String taxIdType){
		Document individualAgentList = new Document();
		MongoCollection<Document> collcheck = null;
		Document agent = null;
		try{
			collcheck = MongoConnector.getInstance()
					.getCollectionDetail("enrollmentDB","brokerinfo", "APP");
			BasicDBList orList = new BasicDBList();
			orList.add(new Document("encryptedTin", agentTaxID));
			orList.add(new Document("brokerIdentifier", agentTaxID));
			/*orList.add(new Document("agentTaxId", agentTaxID));
			orList.add(new Document("agentId", agentTaxID));
			orList.add(new Document("legacyAgentCode",agentTaxID));*/
			
			agent = (Document) collcheck.find(new Document("$or", orList)).first();
			
			if (agent != null && agent.getString("encryptedTin") != null) {				
				individualAgentList.append("taxID",agent.getString("encryptedTin"));
				individualAgentList.append("agentID", agentTaxID);
				individualAgentList.append("taxIDType", taxIdType);
				individualAgentList.append("product", taxIdType);
				individualAgentList.append("name", agent.getString("agentOrAgencyName"));
			}else {
				individualAgentList.append("taxID",agentTaxID);
				individualAgentList.append("agentID", agentTaxID);
				individualAgentList.append("taxIDType", taxIdType);
				individualAgentList.append("product", taxIdType);
				individualAgentList.append("name", "");
			}
			
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}finally{
			collcheck = null;
			agent = null;
		}
		
		return individualAgentList;

	}
	
	public BasicDBObject appendDBContacts(String targetDb,String agentTaxID,String taxIdType){
		BasicDBObject individualAgentList = new BasicDBObject();
		MongoCollection<Document> collcheck = null;
		Document agent = null;
		try{
			collcheck = MongoConnector.getInstance()
					.getCollectionDetail("enrollmentDB","brokerinfo", "APP");
			BasicDBList orList = new BasicDBList();
			orList.add(new Document("encryptedTin", agentTaxID));
			orList.add(new Document("brokerIdentifier", agentTaxID));
			/*orList.add(new Document("agentTaxId", agentTaxID));
			orList.add(new Document("agentId", agentTaxID));
			orList.add(new Document("legacyAgentCode",agentTaxID));*/
			
			agent = (Document) collcheck.find(new Document("$or", orList)).first();
			
		
			if (agent != null && agent.getString("encryptedTin") != null) {				
				individualAgentList.append("taxID",agent.getString("encryptedTin"));
				individualAgentList.append("agentID", agentTaxID);
				individualAgentList.append("taxIDType", taxIdType);
				individualAgentList.append("product", taxIdType);
				individualAgentList.append("name", agent.getString("agentOrAgencyName"));
			}else {
				individualAgentList.append("taxID",agentTaxID);
				individualAgentList.append("agentID", agentTaxID);
				individualAgentList.append("taxIDType", taxIdType);
				individualAgentList.append("product", taxIdType);
				individualAgentList.append("name", "");
			}
			
			
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}finally{
			collcheck = null;
			agent = null;
		}
		
		return individualAgentList;

	}
	
	@SuppressWarnings("unchecked")
	public void addBrokerAgentAgencyInfo(String targetDb,Document summaryDoc){
		MongoCollection<Document> collcheck = null;
		Document brokerAgentAgencyInfo = null;
		String strPaidTin = null;
		String strParentTin = null;
		String strWritingTin = null;
		List<BasicDBObject> agentDocList = new ArrayList<BasicDBObject>();
		boolean bPaid = false;
		boolean bParent = false;
		boolean bWriting = false;
		
		try{
			collcheck = MongoConnector.getInstance()
				.getCollectionDetail(targetDb, "BrokerClientInfo", IConstants.SDSREN_DB);
			
			brokerAgentAgencyInfo = (Document) collcheck.find(new Document("clientId", summaryDoc.getString("ID"))).sort(Sorts.descending("updatedDate")).first();
						
			if(brokerAgentAgencyInfo != null){
				strPaidTin = brokerAgentAgencyInfo.getString("paidTin").trim();
				strParentTin = brokerAgentAgencyInfo.getString("parentTin").trim();
				strWritingTin = brokerAgentAgencyInfo.getString("writingTin").trim();
				
				if(summaryDoc.get("agents") != null){
								
					agentDocList = (ArrayList<BasicDBObject >) summaryDoc.get("agents");
				
					for(BasicDBObject agentDoc:agentDocList){
						if(agentDoc.getString("taxIDType") != null &&
								agentDoc.getString("taxIDType").equalsIgnoreCase("Parent")){
							bParent = true;
						}else if(agentDoc.getString("taxIDType") != null &&
								agentDoc.getString("taxIDType").equalsIgnoreCase("Paid")){
							bPaid = true;
							
						}else if(agentDoc.getString("taxIDType") != null &&
								agentDoc.getString("taxIDType").equalsIgnoreCase("Writing")){
							bWriting = true;
						}				
					}
				}
				
				if(!bParent && strParentTin.length() >0){
					agentDocList.add(appendDBContacts(IConstants.TDM_DB,strParentTin,"Parent"));
				}else if(!bPaid && strPaidTin.length() >0){
					agentDocList.add(appendDBContacts(IConstants.TDM_DB,strPaidTin,"Paid"));
				}else if(!bWriting && strWritingTin.length() >0){
					agentDocList.add(appendDBContacts(IConstants.TDM_DB,strWritingTin,"Writing"));
				}				
				summaryDoc.put("agents", agentDocList);
				
			}	
		}catch(Exception e){
			logger.error(IConstants.ERROR_PREPEND, e);
		}finally{
			collcheck = null;
			brokerAgentAgencyInfo = null;
			agentDocList = null;
		}
	}
}



