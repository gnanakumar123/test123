package com.anthem.marketplace.dataconsolidation.filesutils;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.bson.BSONObject;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.utils.ChangeDataCapture;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.FixedFileMetaDataProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFixedFileMetaData;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

import scala.Tuple2;

/*
 * This class implements UtilityInterface and Serializable and performs Ingestion, Transformation of ISG 
 * renewals input files
 * @author : MongoDB Team
 * @version : 1.0
 * @Date : June 2016
 * It returns nothing.
 */
public class ISG_ACA implements UtilityInterface, Serializable {

	private static final long serialVersionUID = 1L;
	static final Logger logger = LoggerFactory.getLogger(ISG_ACA.class);
	public static ArrayList<String> neglectList = new ArrayList<String>();
	public List<String> fieldsList;

	/*
	 * This method creates GUID
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param delimeted stores delimited character
	 * 
	 * @param readFileContent stores input file data
	 * 
	 * @param guidvalue stores guid values retrieve from properties file
	 * 
	 * @param type stores type of file
	 * 
	 * @return String GUID
	 */
	public String createGuid(String sourceCollection, String delimeted, Row readFileContent, String guidvalue,
			String type) {
		String guid = "";
		String errorFieldName = "";
		try {
			List<ProcessFixedFileMetaData> guidPosition = new ArrayList<>();

			for (String item : guidvalue.split(IConstants.SPLIT_COMMA)) {
				errorFieldName = item;
				guidPosition.add(FixedFileMetaDataProperties.getInstance().getPropertyContext(item, type));
			}

			for (ProcessFixedFileMetaData item : guidPosition) {
				guid += (readFileContent.toString().substring(Integer.parseInt(item.getStart()),
						Integer.parseInt(item.getEnd()) + 1)).trim();
			}
			if (sourceCollection.equals("Renewals_ISG_Renewal_ACA_sub"))
				guid = guid.concat("SUBSCR");
			else
				guid = guid.concat("DPNDT");
			guid = guid.concat("IND").concat("01/01/2017").concat("All");
		}
		// catch Exceptions and add respective errorCode and its description
		catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_REN,
					IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_REN,
					IConstants.RDM_DB);

		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_REN,
					IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_REN,
					IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_REN,
					IConstants.RDM_DB);
		}

		return guid;
	}

	/*
	 * This method checks mandatory fields for file for data Quality check
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param delimeted stores delimited character
	 * 
	 * @param readFileContent stores input file data
	 * 
	 * @param type stores type of file
	 * 
	 * @return boolean value based on data Quality check passed.
	 */
	public boolean createFlag(String delimeted, String sourceCollection, Row readFileContent, String type) {
		boolean flag = false;
		ProcessFixedFileMetaData metadata;
		String errorFieldName = "";
		try {
			// determine which files are mandatory from mapping.xml based on
			// type supplied
			Map<String, String> mandatoryFields = ReadMappingXmlSingleton.getInstance().getRead()
					.getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);
			for (String item : mandatoryFields.values()) {
				errorFieldName = item;
				metadata = FixedFileMetaDataProperties.getInstance().getPropertyContext(item, type);
				// check if mandatoryFields available in input content file
				flag = (readFileContent.toString()
						.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()))
						.trim() == null)
						|| readFileContent.toString()
								.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()))
								.trim().isEmpty();

				if (flag)
					break;
			}
			// if false then set error as null value found for mandatory fields.
			if (flag) {
				Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
						IConstants.DATA_QUALITY_ERROR_CHECK, readFileContent.toString(), errorFieldName,
						IConstants.ISG_REN, IConstants.RDM_DB);
			}
		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_REN,
					IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_REN,
					IConstants.RDM_DB);

		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_REN,
					IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_REN,
					IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_REN,
					IConstants.RDM_DB);
		}
		return flag;
	}

	/*
	 * This method adds fileName and its respective value to a document and
	 * returns it.
	 * 
	 * @param processInput stores input properties related parameters
	 * 
	 * @param sourcePath stores source path of input file
	 * 
	 * @param guid stores GUID
	 * 
	 * @param flag stores value retrieve from data Quality check method
	 * 
	 * @param readFileContent stores Row of a input file
	 * 
	 * @return Document
	 */
	public Document appendRaw(ProcessInput processInput, String sourcePath, String guid, boolean flag,
			Row readFileContent) {

		String type = processInput.getType();
		String sourceDB = processInput.getSourceDB();
		String sourceCollection = processInput.getSourceCollection();
		String value;
		ProcessFixedFileMetaData metadata;
		ProcessFieldNames procFieldNames;
		boolean checkFlag = false;
		String errorFieldName = "";

		Document doc = new Document();
		try {
			procFieldNames = FieldNamesProperties.getInstance().getPropertyContext(type);
			doc.append(IConstants.GUID, guid);

			// for each filedNames
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
				errorFieldName = fieldNames;
				// get dataType for each fieldName for given collectionName
				String dataType = ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(type,
						fieldNames, IConstants.DATATYPE);
				
				if(fieldNames.equalsIgnoreCase("CUR_DEN_PROD_TYPE") || 
						fieldNames.equalsIgnoreCase("CUR_MED_PLAN_TYPE") ||
						fieldNames.equalsIgnoreCase("RNWL_MED_PLAN_TYPE") ||
						fieldNames.equalsIgnoreCase("MED_SUG_PLAN") ||
						fieldNames.equalsIgnoreCase("CUR_UNSBZD_DEN_PLAN_PRMM") ||
						fieldNames.equalsIgnoreCase("CUR_DEN_PLAN_SBSDY") ||
						fieldNames.equalsIgnoreCase("RNWL_UNSBZD_DEN_PLAN_PRMM") || 
						fieldNames.equalsIgnoreCase("RNWL_DEN_PLAN_SBSDY")){

					metadata = FixedFileMetaDataProperties.getInstance().getPropertyContext(fieldNames, type);
					
					if(readFileContent.toString().trim().length() > (Integer.parseInt(metadata.getStart())) ){
						value = readFileContent.toString()
								.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd())).trim();
					}else{
						if (dataType.equalsIgnoreCase("String")){
							value = "";
						}else{
							value="0.0";
						}
					}
				}else{

				metadata = FixedFileMetaDataProperties.getInstance().getPropertyContext(fieldNames, type);
				value = readFileContent.toString()
						.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()) + 1).trim();
				}
				checkFlag = Utility.applyZone(sourceCollection, fieldNames, value.trim(), doc, dataType,
						readFileContent, IConstants.ISG_REN);
				if (checkFlag)
					flag = true;
			}

			// insert metaData
			//Utility.insertMetadata(doc, sourceDB, sourceCollection, guid, sourcePath, IConstants.ISG_REN, flag, true, IConstants.RDM_DB);
			Utility.insertMetadata(doc, sourceDB, sourceCollection, guid, sourcePath, IConstants.ISG_ACA, flag, true, IConstants.RDM_DB);
			// for sub phone
			doc.replace("SUB_PHONE", null);
			// catch Exceptions and add respective errorCode and its description
		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.ISG_REN, IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.ISG_REN, IConstants.RDM_DB);
		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.ISG_REN, IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.RAW_DATA,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_REN,
					IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.ISG_REN, IConstants.RDM_DB);
		}

		return doc;
	}

	/*
	 * This method selects attributes to decide fields to be selected from BCC
	 * or BCBSGA Raw data.
	 * 
	 * @param fieldNames stores field names
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param collName stores collection name
	 * 
	 * @return attribute name
	 */
	public String selectFields(String fieldNames, Tuple2<Object, BSONObject> bsonFilter, String collName,
			String sourceCollection) {
		if (ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField(sourceCollection.concat(collName), fieldNames, IConstants.PROD_TYPE)
				.equals("false")) {
			return IConstants.VALUE;

		} else if (((bsonFilter._2.get(IConstants.MEDWRITINGTINENC) != null)
				&& (!bsonFilter._2.get(IConstants.MEDWRITINGTINENC).toString().trim().equalsIgnoreCase("")))
				|| ((bsonFilter._2.get(IConstants.MEDPARENTTINENC) != null)
						&& (!bsonFilter._2.get(IConstants.MEDPARENTTINENC).toString().trim().equalsIgnoreCase("")))
				|| ((bsonFilter._2.get(IConstants.MEDPAIDTINENC) != null)
						&& (!bsonFilter._2.get(IConstants.MEDPAIDTINENC).toString().trim().equalsIgnoreCase("")))) {
			return IConstants.MEDICAL;
		} else if (((bsonFilter._2.get(IConstants.DENWRITINGTINENC) != null)
				&& (!bsonFilter._2.get(IConstants.DENWRITINGTINENC).toString().trim().equalsIgnoreCase("")))
				|| ((bsonFilter._2.get(IConstants.DENPARENTTINENC) != null)
						&& (!bsonFilter._2.get(IConstants.DENPARENTTINENC).toString().trim().equalsIgnoreCase("")))
				|| ((bsonFilter._2.get(IConstants.DENPAIDTINENC) != null)
						&& (!bsonFilter._2.get(IConstants.DENPAIDTINENC).toString().trim().equalsIgnoreCase("")))) {
			return IConstants.DENTAL;
		} else
			return "pd";
	}

	public String selectFields(String fieldNames, Document bsonFilter, String collName, String sourceCollection) {
		if (ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField(sourceCollection.concat(collName), fieldNames, IConstants.PROD_TYPE)
				.equals("false")) {
			return IConstants.VALUE;

		} else if (((bsonFilter.get(IConstants.MEDWRITINGTINENC) != null)
				&& (!bsonFilter.get(IConstants.MEDWRITINGTINENC).toString().trim().equalsIgnoreCase("")))
				|| ((bsonFilter.get(IConstants.MEDPARENTTINENC) != null)
						&& (!bsonFilter.get(IConstants.MEDPARENTTINENC).toString().trim().equalsIgnoreCase("")))
				|| ((bsonFilter.get(IConstants.MEDPAIDTINENC) != null)
						&& (!bsonFilter.get(IConstants.MEDPAIDTINENC).toString().trim().equalsIgnoreCase("")))) {
			return IConstants.MEDICAL;
		} else if (((bsonFilter.get(IConstants.DENWRITINGTINENC) != null)
				&& (!bsonFilter.get(IConstants.DENWRITINGTINENC).toString().trim().equalsIgnoreCase("")))
				|| ((bsonFilter.get(IConstants.DENPARENTTINENC) != null)
						&& (!bsonFilter.get(IConstants.DENPARENTTINENC).toString().trim().equalsIgnoreCase("")))
				|| ((bsonFilter.get(IConstants.DENPAIDTINENC) != null)
						&& (!bsonFilter.get(IConstants.DENPAIDTINENC).toString().trim().equalsIgnoreCase("")))) {
			return IConstants.DENTAL;
		} else
			return "pd";
	}

	public String selectMultiFields(String fieldNames, Tuple2<Object, BSONObject> bsonFilter, String collName,
			String sourceCollection) {
		List<String> selectFieldsList = new ArrayList<String>();
		if (ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField(sourceCollection.concat(collName), fieldNames, IConstants.PROD_TYPE)
				.equals("false")) {
			return IConstants.VALUE;
		} else {

			if (((bsonFilter._2.get(IConstants.MEDWRITINGTIN) != null)
					|| (bsonFilter._2.get(IConstants.MEDWRITINGTINENC) != null))) {
				selectFieldsList.add(IConstants.MEDICAL);
			}
			if (((bsonFilter._2.get(IConstants.DENWRITINGTIN) != null)
					|| (bsonFilter._2.get(IConstants.DENWRITINGTINENC) != null))) {
				selectFieldsList.add(IConstants.DENTAL);
			}
			if ((bsonFilter._2.get(IConstants.PDWRITINGTIN) != null)
					|| (bsonFilter._2.get(IConstants.VISWRITINGTINENC) != null))/* BPP-34001 ISGACA Vision Renewals */ {
				// to be implemented...
				selectFieldsList.add("pd");
			}
		}
		if (selectFieldsList.size() > 0)
			fieldsList = selectFieldsList;
		return "Multi";
	}

	public String selectMultiFields(String fieldNames, Document bsonFilter, String collName, String sourceCollection) {
		List<String> selectFieldsList = new ArrayList<String>();
		if (ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField(sourceCollection.concat(collName), fieldNames, IConstants.PROD_TYPE)
				.equals("false")) {
			return IConstants.VALUE;
		} else {

			if (((bsonFilter.get(IConstants.MEDWRITINGTIN) != null)
					|| (bsonFilter.get(IConstants.MEDWRITINGTINENC) != null))) {
				selectFieldsList.add(IConstants.MEDICAL);
			}
			if (((bsonFilter.get(IConstants.DENWRITINGTIN) != null)
					|| (bsonFilter.get(IConstants.DENWRITINGTINENC) != null))) {
				selectFieldsList.add(IConstants.DENTAL);
			}
			if ((bsonFilter.get(IConstants.PDWRITINGTIN) != null)
					|| (bsonFilter.get(IConstants.VISWRITINGTINENC) != null))/* BPP-34001 ISGACA Vision Renewals */ {
				// to be implemented...
				selectFieldsList.add("pd");
			}
		}
		if (selectFieldsList.size() > 0)
			fieldsList = selectFieldsList;
		return "Multi";
	}

	/*
	 * This method performs transformation on ISG Renewals Raw data.
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source collection name
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param transColl stores target collection name
	 * 
	 * @param appendedCollection stores collection name whose data to be
	 * appended as embedded doc. i.t summary to detail
	 * 
	 * @return transformed Document
	 */
	public Document ingestTDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String transColl, String appendedCollection) {

		sourceCollection = sourceCollection.split(IConstants.SPLIT_COMMA)[0];
		Document metaDoc = new Document();
		boolean flag = false;
		String guid = "";
		ProcessFieldNames procFieldNames = null;
		ProcessFieldNames procFieldNamesContacts = null;
		ProcessFieldNames procFieldNamesAgent = null;
		ProcessFieldNames procFieldNamesRen = null;
		String sourcePath = "";
		ProcessFieldNames clientFieldNames = null;
		neglectList.add("");
		neglectList.add(null);
		try {
			clientFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_REN.concat(transColl).toString());

		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e) {
			logger.error("Exception:  " + e);
		}
		for (String fieldNames : clientFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
			String selectFieldAttribute = selectFields(fieldNames, bsonFilter, transColl, sourceCollection);

			if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(sourceCollection.concat(transColl), fieldNames, selectFieldAttribute))))
				metaDoc.append(fieldNames,
						bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
								sourceCollection.concat(transColl), fieldNames, selectFieldAttribute)));
		

			if (sourceCollection.equals("Renewals_ISG_Renewal_ACA_sub")) {
				metaDoc.append("type", "IND");
				metaDoc.append("relationship", "SUBSCR");
			} else {
				metaDoc.append("type", "IND");
				metaDoc.append("relationship", "DPNDT");
			}
		}
		List<Document> innerDocList = new ArrayList<Document>();
		if (transColl.contains("Renewals_tdm_Renewal")) {

			fieldsList = new ArrayList<String>();
			try {
				procFieldNames = FieldNamesProperties.getInstance()
						.getPropertyContext(IConstants.ISG_REN.concat("Benefits"));

			} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
					| IllegalArgumentException | InvocationTargetException e) {
				logger.error("Exception:  " + e);
			}
			do {
				Document doc = new Document();
				for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
					String selectFieldAttribute = selectFields(fieldNames, bsonFilter, IConstants.RENEWAL_DETAILS,
							sourceCollection);

					if (!selectFieldAttribute.equals(IConstants.VALUE)) {
						if (fieldsList.size() == 0)
							selectMultiFields(fieldNames, bsonFilter, IConstants.RENEWAL_DETAILS, sourceCollection);

						if (fieldsList.size() > 0) {
							selectFieldAttribute = fieldsList.get(0);
						}

					}

					if (!neglectList.contains(
							bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
									sourceCollection.concat("Benefits"), fieldNames, selectFieldAttribute))))
						doc.append(fieldNames,
								bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
										.getAttributeValueOfField(sourceCollection.concat("Benefits"), fieldNames,
												selectFieldAttribute)));
					else
						doc.append(fieldNames, "");
				}
				String product = fieldsList.get(0).toUpperCase();

				if (product.equals("PD"))
					product = "VIS";

				if (product.length() > 2)
					product = product.substring(0, 3);
				doc.append(IConstants.PRODUCT, product);
				List<Document> renewalProducts = getRenewalProducts(sourceCollection, doc, bsonFilter._2());
				doc.append("renewalProducts", renewalProducts);
				fieldsList.remove(0);
				innerDocList.add(doc);

			} while (fieldsList.size() > 0);
			metaDoc.append(IConstants.BENEFITS, innerDocList);
			
			try {
				String subID = bsonFilter._2.get("HCID").toString();
				List<String> rejectMemId = new ArrayList<String>();
				rejectMemId.add("010");
				rejectMemId.add("020");
				FindIterable<Document> iterable;
				MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
						appendedCollection, IConstants.RDM_DB);
				iterable = collcheck
						.find(new Document(IConstants.HCID, subID).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append("MBR_CODE", new Document("$nin", rejectMemId)) /* BPP-31928 : Not getting latest record , added Un-processed status */

				);
				//String dependentsCoverd = "";
				List<Document> memberDocList = new ArrayList<Document>();
				for (Document d : iterable) {
					Document docum = new Document();
					docum.append("ID", subID);

					docum.append(IConstants.BENEFITS, getBenefits(sourceCollection, bsonFilter, procFieldNames, d));

					memberDocList.add(docum);
				}
				metaDoc.append("Dependents", memberDocList);
				if(memberDocList.size() > 0){
					metaDoc.append("dependentsCovered", "Yes");
				}else{
					metaDoc.append("dependentsCovered", "No");
				}

			} catch (Exception e) {
				logger.error(IConstants.ERROR_PREPEND, e);
			}
			List<Document> renewalProducts = getRenewalProducts(sourceCollection, metaDoc, bsonFilter._2());
			metaDoc.append("renewalProducts", renewalProducts);
			
		}

		else {
			
			BasicDBList docList = new BasicDBList();
			Document doc = new Document();
			int year = Calendar.getInstance().get(Calendar.YEAR);
			try {
				procFieldNamesContacts = FieldNamesProperties.getInstance()
						.getPropertyContext(IConstants.ISG_REN.concat(IConstants.CLIENT_CONTACTS));
				procFieldNamesAgent = FieldNamesProperties.getInstance()
						.getPropertyContext(IConstants.ISG_REN.concat(IConstants.CLIENT_AGENT));
				procFieldNamesRen = FieldNamesProperties.getInstance()
						.getPropertyContext(IConstants.ISG_REN.concat(IConstants.CLIENT_RENEWAL));
			} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
					| IllegalArgumentException | InvocationTargetException e) {
				logger.error("Exception:  " + e);
			}

			String[] addr = { "home", "mailing" };
			docList = appendCollections(addr, IConstants.ADDR_TYPE, "addressType", "stateName", procFieldNamesContacts,
					IConstants.CLIENT_CONTACTS, bsonFilter, sourceCollection, sourceDb);
			metaDoc.append(IConstants.CLIENT_CONTACTS, docList);
			docList = new BasicDBList();
			String[] product = { IConstants.MEDICAL, IConstants.DENTAL, "vis" }; /* BPP-34001 ISGACA Vision Renewals */
			docList = appendCollections(product, IConstants.PROD_TYPE, IConstants.PRODUCT, "agentID",
					procFieldNamesAgent, IConstants.CLIENT_AGENT, bsonFilter, sourceCollection, sourceDb, true, targetDb);
			metaDoc.append(IConstants.CLIENT_AGENT, docList);
			docList = new BasicDBList();
			for (String fieldNames : procFieldNamesRen.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
				String selectFieldAttribute = selectFields(fieldNames, bsonFilter, IConstants.CLIENT_RENEWAL,
						sourceCollection);
				if (fieldNames.equals("renewalPeriod"))
					doc.append(fieldNames, year);
				else if (!neglectList.contains(
						bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
								sourceCollection.concat(IConstants.CLIENT_RENEWAL), fieldNames, selectFieldAttribute))))
					doc.append(fieldNames,
							bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
									sourceCollection.concat(IConstants.CLIENT_RENEWAL), fieldNames,
									selectFieldAttribute)));

			}
			metaDoc.append(IConstants.CLIENT_RENEWAL, doc);

			try {
				String subID = bsonFilter._2.get("HCID").toString();
				List<String> rejectMemId = new ArrayList<String>();
				rejectMemId.add("010");
				rejectMemId.add("020");
				FindIterable<Document> iterable;
				MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
						appendedCollection, IConstants.RDM_DB);
				iterable = collcheck.find(
						new Document(IConstants.HCID, subID).append("MBR_CODE", new Document("$nin", rejectMemId)).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)
						.append(IConstants.END_DATE_FIELD,IConstants.MAX_DATE)); /* BPP-31928 : Not getting latest record , added Un-processed status */
				List<Document> memberDocList = new ArrayList<Document>();
				//String dependentsCoverd = "";
				for (Document d : iterable) {
					docList = appendCollections(addr, IConstants.ADDR_TYPE, "addressType", "stateName",
							procFieldNamesContacts, IConstants.CLIENT_CONTACTS, d, appendedCollection, sourceDb);
					d.append(IConstants.CLIENT_CONTACTS, docList);
					memberDocList.add(d);
				}
				metaDoc.append("Dependents", memberDocList);
				if(memberDocList.size() > 0){
					metaDoc.append("dependentsCovered", "Yes");
				}else{
					metaDoc.append("dependentsCovered", "No");
				}
				

			} catch (Exception e) {
				logger.error(IConstants.ERROR_PREPEND, e);
			}
			
		}

		sourcePath = bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString();
		guid = metaDoc.get(IConstants.GUID).toString();
		//Utility.insertMetadata(metaDoc, targetDb, transColl, guid, sourcePath, IConstants.ISG_REN, flag, true, IConstants.TDM_DB);
		Utility.insertMetadata(metaDoc, targetDb, transColl, guid, sourcePath, IConstants.ISG_ACA, flag, true, IConstants.TDM_DB);
		if (metaDoc.getString(IConstants.REN_ID) != null) {
			return metaDoc;

		} else
			return null;

	}

	public List<Document> getBenefits(String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			ProcessFieldNames procFieldNames) {
		List<Document> innerDocList = null;
		try {
			innerDocList = new ArrayList<Document>();
			do {
				Document doc = new Document();
				for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
					String selectFieldAttribute = selectFields(fieldNames, bsonFilter, IConstants.RENEWAL_DETAILS,
							sourceCollection);

					if (!selectFieldAttribute.equals(IConstants.VALUE)) {
						if (fieldsList.size() == 0)
							selectMultiFields(fieldNames, bsonFilter, IConstants.RENEWAL_DETAILS, sourceCollection);

						if (fieldsList.size() > 0) {
							selectFieldAttribute = fieldsList.get(0);
						}

					}

					if (!neglectList.contains(
							bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
									sourceCollection.concat("Benefits"), fieldNames, selectFieldAttribute))))
						doc.append(fieldNames,
								bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
										.getAttributeValueOfField(sourceCollection.concat("Benefits"), fieldNames,
												selectFieldAttribute)));
				}
				String product = fieldsList.get(0).toUpperCase();

				if (product.equals("PD"))
					product = "VIS";

				if (product.length() > 2)
					product = product.substring(0, 3);
				doc.append(IConstants.PRODUCT, product);
				fieldsList.remove(0);
				innerDocList.add(doc);

				List<Document> renewalProducts = getRenewalProducts(sourceCollection, doc);
				doc.append("renewalProducts", renewalProducts);
			} while (fieldsList.size() > 0);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return innerDocList;

	}

	public List<Document> getBenefits(String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			ProcessFieldNames procFieldNames, Document d) {
		List<Document> innerDocList = null;
		try {
			innerDocList = new ArrayList<Document>();
			do {
				Document doc = new Document();
				for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
					String selectFieldAttribute = selectFields(fieldNames, d, IConstants.RENEWAL_DETAILS,
							sourceCollection);

					if (!selectFieldAttribute.equals(IConstants.VALUE)) {
						if (fieldsList.size() == 0)
							selectMultiFields(fieldNames, d, IConstants.RENEWAL_DETAILS, sourceCollection);

						if (fieldsList.size() > 0) {
							selectFieldAttribute = fieldsList.get(0);
						}

					}

					if (!neglectList.contains(
							bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
									sourceCollection.concat("Benefits"), fieldNames, selectFieldAttribute))))
						doc.append(fieldNames,
								bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
										.getAttributeValueOfField(sourceCollection.concat("Benefits"), fieldNames,
												selectFieldAttribute)));
				}
				String product = fieldsList.get(0).toUpperCase();

				if (product.equals("PD"))
					product = "VIS";

				if (product.length() > 2)
					product = product.substring(0, 3);
				doc.append(IConstants.PRODUCT, product);
				fieldsList.remove(0);
				innerDocList.add(doc);

				List<Document> renewalProducts = getRenewalProducts(sourceCollection, doc);
				doc.append("renewalProducts", renewalProducts);
			} while (fieldsList.size() > 0);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return innerDocList;

	}

	public List<Document> getRenewalProducts(String sourceCollection, Document outerDoc) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}

			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	public List<Document> getRenewalProducts(String sourceCollection, Document outerDoc, BSONObject bsonObject) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}

			double monPrem = 0.0, currMonPrem = 0.0;
			try {
				if (bsonObject.containsKey("MED_RNWL_RATE") && (bsonObject.get("MED_RNWL_RATE") != null)) {
					monPrem += (Double) bsonObject.get("MED_RNWL_RATE");
					doc.remove("renewalMonthlyPremium");
				}
				if (bsonObject.containsKey("DEN_RNWL_RATE") && (bsonObject.get("DEN_RNWL_RATE") != null)) {
					monPrem += (Double) bsonObject.get("DEN_RNWL_RATE");

				}
				if (bsonObject.containsKey("PD_RNWL_RATE") && (bsonObject.get("PD_RNWL_RATE") != null)) {
					monPrem += (Double) bsonObject.get("PD_RNWL_RATE");

				}

				if (bsonObject.containsKey("MED_PREMIUM") && (bsonObject.get("MED_PREMIUM") != null)) {
					currMonPrem += (Double) bsonObject.get("MED_PREMIUM");

				}
				if (bsonObject.containsKey("DEN_PREMIUM") && (bsonObject.get("DEN_PREMIUM") != null)) {
					currMonPrem += (Double) bsonObject.get("DEN_PREMIUM");

				}
				if (bsonObject.containsKey("PD_PREMIUM") && (bsonObject.get("PD_PREMIUM") != null)) {
					currMonPrem += (Double) bsonObject.get("PD_PREMIUM");

				}

			} catch (Exception e) {
				logger.error(IConstants.ERROR_PREPEND, e);
			}
			// doc.append(IConstants.MON_PREM, monPrem);
			if (outerDoc.containsKey(IConstants.CURR_MON_PREMIUM))
				outerDoc.remove(IConstants.CURR_MON_PREMIUM);
			outerDoc.append(IConstants.CURR_MON_PREMIUM, currMonPrem);
			outerDoc.append(IConstants.MON_PREM, monPrem);

			renewalProducts.add(doc);
			

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	public BasicDBList appendCollections(String[] arr, String prodAddr, String fieldType, String mandatoryField,
			ProcessFieldNames procFieldNames, String coll, Tuple2<Object, BSONObject> bsonFilter,
			String sourceCollection, String sourceDb) {
		BasicDBList docList = new BasicDBList();
		if (sourceCollection.equals("Renewals_ISG_Renewal_ACA_mem")) {
			Document subscriberDoc = MongoConnector.getInstance().getDocument("HCID",
					bsonFilter._2.get("HCID").toString(), sourceDb, "Renewals_ISG_Renewal_ACA_sub", IConstants.RDM_DB);

			for (String taxid : arr) {
				Document addrDoc = new Document();
				for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
					if (ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, prodAddr)
							.equals(IConstants.STRING_TRUE)) {
						if (fieldNames.equals(fieldType)) {
							addrDoc.append(fieldNames, taxid);
						} else if (!neglectList.contains(subscriberDoc.get(ReadMappingXmlSingleton.getInstance()
								.getRead().getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, taxid))))
							addrDoc.append(fieldNames, subscriberDoc.get(ReadMappingXmlSingleton.getInstance().getRead()
									.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, taxid)));
					} else if (fieldNames.equals(IConstants.TAX_ID_TYPE)) {
						addrDoc.append(fieldNames, "Writing");
					} else if (!neglectList.contains(subscriberDoc.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames,
									selectFields(fieldNames, bsonFilter, coll, sourceCollection)))))
						addrDoc.append(fieldNames,
								subscriberDoc.get(ReadMappingXmlSingleton.getInstance().getRead()
										.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames,
												selectFields(fieldNames, bsonFilter, coll, sourceCollection))));

				}
				// if (!addrDoc.get(mandatoryField).equals(""))
				docList.add(addrDoc);
			}

		} else {
			for (String taxid : arr) {
				Document addrDoc = new Document();
				for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
					if (ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, prodAddr)
							.equals(IConstants.STRING_TRUE)) {
						if (fieldNames.equals(fieldType)) {
							addrDoc.append(fieldNames, taxid);
						} else if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance()
								.getRead().getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, taxid))))
							addrDoc.append(fieldNames, bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
									.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, taxid)));
					} else if (fieldNames.equals(IConstants.TAX_ID_TYPE)) {
						addrDoc.append(fieldNames, "Writing");
					} else if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames,
									selectFields(fieldNames, bsonFilter, coll, sourceCollection)))))
						addrDoc.append(fieldNames,
								bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
										.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames,
												selectFields(fieldNames, bsonFilter, coll, sourceCollection))));
				}
				docList.add(addrDoc);
			}
		}
		return docList;
	}

	public BasicDBList appendCollections(String[] arr, String prodAddr, String fieldType, String mandatoryField,
			ProcessFieldNames procFieldNames, String coll, Document bsonFilter, String sourceCollection,
			String sourceDb) {
		BasicDBList docList = new BasicDBList();
		if (sourceCollection.equals("ISG_Renewal_ACA_mem")) {
			Document subscriberDoc = MongoConnector.getInstance().getDocument("HCID", bsonFilter.get("HCID").toString(),
					sourceDb, "ISG_Renewal_ACA_sub", IConstants.RDM_DB);

			for (String taxid : arr) {
				Document addrDoc = new Document();
				for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
					if (ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, prodAddr)
							.equals(IConstants.STRING_TRUE)) {
						if (fieldNames.equals(fieldType)) {
							addrDoc.append(fieldNames, taxid);
						} else if (!neglectList.contains(subscriberDoc.get(ReadMappingXmlSingleton.getInstance()
								.getRead().getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, taxid))))
							addrDoc.append(fieldNames, subscriberDoc.get(ReadMappingXmlSingleton.getInstance().getRead()
									.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, taxid)));
					} else if (fieldNames.equals(IConstants.TAX_ID_TYPE)) {
						addrDoc.append(fieldNames, "Writing");
					} else if (!neglectList.contains(subscriberDoc.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames,
									selectFields(fieldNames, bsonFilter, coll, sourceCollection)))))
						addrDoc.append(fieldNames,
								subscriberDoc.get(ReadMappingXmlSingleton.getInstance().getRead()
										.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames,
												selectFields(fieldNames, bsonFilter, coll, sourceCollection))));

				}
				docList.add(addrDoc);
			}

		} else {
			for (String taxid : arr) {
				Document addrDoc = new Document();
				for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
					if (ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, prodAddr)
							.equals(IConstants.STRING_TRUE)) {
						if (fieldNames.equals(fieldType)) {
							addrDoc.append(fieldNames, taxid);
						} else if (!neglectList.contains(bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
								.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, taxid))))
							addrDoc.append(fieldNames, bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
									.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, taxid)));
					} else if (fieldNames.equals(IConstants.TAX_ID_TYPE)) {
						addrDoc.append(fieldNames, "Writing");
					} else if (!neglectList.contains(bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames,
									selectFields(fieldNames, bsonFilter, coll, sourceCollection)))))
						addrDoc.append(fieldNames,
								bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
										sourceCollection.concat(coll), fieldNames,
										selectFields(fieldNames, bsonFilter, coll, sourceCollection))));

				}
				docList.add(addrDoc);
			}
		}
		return docList;
	}

	public BasicDBList appendCollections(String[] arr, String prodAddr, String fieldType, String mandatoryField,
			ProcessFieldNames procFieldNames, String coll, Tuple2<Object, BSONObject> bsonFilter,
			String sourceCollection, String sourceDb, boolean flag, String targetDb) {
		BasicDBList docList = new BasicDBList();
		if (sourceCollection.equals("Renewals_ISG_Renewal_ACA_mem")) {
			Document subscriberDoc = MongoConnector.getInstance().getDocument("HCID",
					bsonFilter._2.get("HCID").toString(), sourceDb, "Renewals_ISG_Renewal_ACA_sub", IConstants.RDM_DB);

			for (String taxid : arr) {

				Document addrDoc = new Document();

				for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
					if (ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, prodAddr)
							.equals(IConstants.STRING_TRUE)) {
						if (fieldNames.equals(fieldType)) {
							addrDoc.append(fieldNames, taxid);
						} else if (!neglectList.contains(subscriberDoc.get(ReadMappingXmlSingleton.getInstance()
								.getRead().getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, taxid))))
							addrDoc.append(fieldNames, subscriberDoc.get(ReadMappingXmlSingleton.getInstance().getRead()
									.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, taxid)));
					} else if (fieldNames.equals(IConstants.TAX_ID_TYPE)) {

						addrDoc.append(fieldNames, "Writing");
					} else if (!neglectList.contains(subscriberDoc.get(ReadMappingXmlSingleton.getInstance().getRead()
							.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames,
									selectFields(fieldNames, bsonFilter, coll, sourceCollection)))))
						addrDoc.append(fieldNames,
								subscriberDoc.get(ReadMappingXmlSingleton.getInstance().getRead()
										.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames,
												selectFields(fieldNames, bsonFilter, coll, sourceCollection))));

				}

				populateEncytedFields(addrDoc, addrDoc.get("agentID").toString(), targetDb);

				docList.add(addrDoc);
			}

		} else {
			for (String taxid : arr) {
				String[] types = { "Writing", "Paid", "Parent" };
				for (String type : types) {
					Document addrDoc = new Document();
					for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
						if (ReadMappingXmlSingleton.getInstance().getRead()
								.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames, prodAddr)
								.equals(IConstants.STRING_TRUE)) {

							if (fieldNames.equals("taxID")) {

								addrDoc.append(fieldNames,
										bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
												.getAttributeValueOfField(sourceCollection + "taxID", taxid + type,
														IConstants.VALUE)));

							} else {
								if (fieldNames.equals(fieldType)) {
									String product = taxid.toUpperCase();
									if (product.equals("PD"))
										product = "VIS";
									if (product.length() > 2)
										product = product.substring(0, 3);
									addrDoc.append(fieldNames, product);
								} else if (!neglectList.contains(bsonFilter._2
										.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
												sourceCollection.concat(coll), fieldNames, taxid))))
									addrDoc.append(fieldNames,
											bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
													.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames,
															taxid)));
							}

						} else if (fieldNames.equals(IConstants.TAX_ID_TYPE)) {
							addrDoc.append(fieldNames, type);
						} else if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance()
								.getRead().getAttributeValueOfField(sourceCollection.concat(coll), fieldNames,
										selectFields(fieldNames, bsonFilter, coll, sourceCollection)))))
							addrDoc.append(fieldNames,
									bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
											.getAttributeValueOfField(sourceCollection.concat(coll), fieldNames,
													selectFields(fieldNames, bsonFilter, coll, sourceCollection))));

					}

					addrDoc.append("agentID", addrDoc.get("taxID"));

					if (!((addrDoc.get("taxID").equals("") || (addrDoc.get("taxID") == null)))) {
						populateEncytedFields(addrDoc, addrDoc.get("agentID").toString(), targetDb);
						docList.add(addrDoc);
					}
				}
			}
		}
		return docList;
	}

	private void populateEncytedFields(Document doc, String key, String targetDb) {
		String producerTIN = null;
		try {
			
			producerTIN = key;
			if (producerTIN != null && producerTIN.length() > 0) {
				//logger.info("--key---",producerTIN);
			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail("enrollmentDB","brokerinfo", "APP");
			
			Document docRen = (Document) collcheck.find(new Document("encryptedTin",producerTIN)).first();
			
				if(docRen != null && docRen.getString("agentOrAgencyName") != null && !(docRen.getString("agentOrAgencyName").equalsIgnoreCase("NULL"))){
						doc.append("name", docRen.getString("agentOrAgencyName"));
				} else {
					doc.append("name", "");
				}
			}
			//logger.info("--after key---",producerTIN);
			
		} catch (Exception e) {
			logger.error(producerTIN + "Can't fetch from DumpFiles");
		}

	}

	/*
	 * This method performs unified transformation on ISG Renewals transformed
	 * data.
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source collection name
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param targetCollection stores target collection name
	 * 
	 * @param targetDetailCollection stores collection name whose data is
	 * appended as embedded doc. i.t summary to detail
	 * 
	 * @return transformed Document
	 */
	@SuppressWarnings("unchecked")
	public Document ingestUDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection) {

		Document metaDoc = new Document();
		try {
			metaDoc.putAll(bsonFilter._2.toMap());

			metaDoc.remove(IConstants.ID);
		} catch (Exception e) {
			logger.error("Exception:  " + e);
		}
		return metaDoc;
	}

	/*
	 * this method inserts data into mongoDB for given specifications
	 * 
	 * @processInput stores input related parameters
	 * 
	 * @sourcePath stores file location path
	 * 
	 * @guidvalue stores GUID
	 * 
	 * @priority stores priority of process
	 * 
	 * @strType stores type of input file.
	 * 
	 * @return nothing
	 */
	@Override
	public void ingestRDMprocess(ProcessInput processInput, String sourcePath, String guidvalue, String strType) {
		List<Document> docList = new ArrayList<>();
		List<Document> failedList = new ArrayList<>();

		String sourceCollection = processInput.getSourceCollection();
		String delimeted = processInput.getDelimeted();
		String delimeter = processInput.getDelimeter();
		String type = processInput.getType();
		String sourceDB = processInput.getSourceDB();
		String failedCollection = processInput.getFailedCollection();
		String parentCollection = processInput.getParentCollection();
		JavaSparkContext scIngest = SparkContextSingleton.getInstance().getSparkContext();
		JavaRDD<String> filePartition = scIngest.textFile(sourcePath, 4);
		filePartition.count();
		JavaRDD<Row> readFile = filePartition.map(record -> RowFactory.create((Object[]) record.split(delimeter, -1)));
		readFile.foreachPartition(partitionIterator -> {

			ProcessInput process = new ProcessInput(sourceDB, sourceCollection, type, delimeter, delimeted,
					failedCollection, parentCollection);
			partitionIterator.forEachRemaining(readFileContent -> {
				String guid = this.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
				boolean flag = this.createFlag(delimeted, sourceCollection, readFileContent, type);
				Document doc = this.appendRaw(process, sourcePath, guid, flag, readFileContent);
				ChangeDataCapture cdc = new ChangeDataCapture();
				cdc.implementCdc(sourceDB, sourceCollection, doc, docList, failedList, IConstants.RDM_DB);
				
				if(docList.size() >= 500){
					MongoConnector.getInstance().insertData(docList, sourceDB, sourceCollection, IConstants.RDM_DB);
					MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
					docList.clear();
					failedList.clear();
				}

			});
			MongoConnector.getInstance().insertData(docList, sourceDB, sourceCollection, IConstants.RDM_DB);
			MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
		});

	}

	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection,
			Tuple2<Object, BSONObject> bsonFilter, ProcessFieldNames procFieldNames, String targetDb,
			String targetCollection, String targetDetailCollection, String sourceDbTDM) {
		return null;
	}

	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection) {
		return null;
	}

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection, ProcessInput processInput) {
		ProcessFieldNames memberSummary = null;
		ProcessFieldNames memberDetail = null;
		ProcessFieldNames memberSummaryBenefits = null;
		ProcessFieldNames memberSummaryTDMRenewals = null;
		try {
			memberSummary = FieldNamesProperties.getInstance().getPropertyContext("memberSummary");
			memberDetail = FieldNamesProperties.getInstance()
					.getPropertyContext("memberDetail".concat(IConstants.MODIFIED));
			memberSummaryBenefits = FieldNamesProperties.getInstance()
					.getPropertyContext("memberSummaryBenefits" + IConstants.MODIFIED);
			memberSummaryTDMRenewals = FieldNamesProperties.getInstance()
					.getPropertyContext("memberSummaryTDMRenewals");

		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e1) {
			logger.error(IConstants.ERROR_PREPEND, e1);
		}

		String[] sourceColl = sourceCollection;
		List<Document> docDetailList = new ArrayList<>();
		List<Document> docSummaryList = new ArrayList<>();

		Document doc = new Document();
		Document summaryDoc = new Document();

		try {

			addToDocumentIncNull(memberDetail, bsonFilter, "memberDetail", doc);

			for (String metaData : IConstants.getMetadata())
				doc.append(metaData, bsonFilter._2.get(metaData));
			//For getting latest record into sds BPP-31927
			doc.append(IConstants.RENEWAL_DETAILS, MongoConnector.getInstance()
					.getRenewalDocumentSDSDetailModified(bsonFilter, sourceDb, sourceColl[1], IConstants.UDM_DB)); /* sourceColl[1] :  Renewals_udm_Renewal*/

			List<Document> subDocs = null;
			subDocs = getDetailDocs(bsonFilter, sourceDb, sourceColl);
			
			if(bsonFilter._2.get("dependentsCovered") != null ){
				doc.append("dependentsCovered", bsonFilter._2.get("dependentsCovered"));
			}
						
			if(doc.containsKey(IConstants.PLAN_SBSDY) && doc.get(IConstants.PLAN_SBSDY).toString().equals("0.0"))
				doc.append(IConstants.PLAN_SBSDY, "No");
			if(doc.containsKey(IConstants.RENEWAL_SUBSIDY) && doc.get(IConstants.RENEWAL_SUBSIDY).toString().equals("0.0"))
				doc.append(IConstants.RENEWAL_SUBSIDY, "No");
			if(doc.containsKey(IConstants.EXCHG_IND) && doc.get(IConstants.EXCHG_IND) != null && doc.get(IConstants.EXCHG_IND).toString().equals("PB"))
				doc.append(IConstants.EXCH_IND, "On");
			else
				doc.append(IConstants.EXCH_IND, "Off");
			if(doc.containsKey(IConstants.EXCHG_IND))
				doc.remove(IConstants.EXCHG_IND);
			
			docDetailList.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}

		// following code adds estimatedLetterMailDate, letterCode and
		// letterFlagCode to summary document.
		Document tdmRenewal = new Document();
		MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, sourceColl[1],
				IConstants.UDM_DB);
		tdmRenewal = collcheck.find(new Document("GUID", bsonFilter._2.get("GUID").toString()).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)).first(); /* BPP-31928 : Not getting latest record , added Un-processed status */

		addToDocument(memberSummary, bsonFilter, "memberSummary", summaryDoc);
		
		if(summaryDoc.containsKey("contacts")){
			ArrayList<BasicDBObject> contacts = (ArrayList<BasicDBObject>) summaryDoc.get("contacts");
			ArrayList<BasicDBObject> scontacts = new ArrayList<BasicDBObject> ();
			
			for(int i=0; i < contacts.size(); i ++){
				BasicDBObject obj = contacts.get(i);
				if(obj.containsKey("addressType")){
					if(obj.getString("addressType").equalsIgnoreCase("home")){
						scontacts.add(obj);
						summaryDoc.replace("contacts", scontacts);
					}
				}
			}
		}
		
		addToDocument(memberSummaryTDMRenewals, tdmRenewal, "memberSummaryTDMRenewals", summaryDoc);
		for (String metaData : IConstants.getMetadata())
			summaryDoc.append(metaData, bsonFilter._2.get(metaData));

		Object benefitsObject = MongoConnector.getInstance().getRenewalDocumentSDS(bsonFilter, sourceDb, sourceColl[1],
				IConstants.UDM_DB, IConstants.RENEWAL_DETAILS);
		@SuppressWarnings("unchecked")
		List<Document> benefitsList = (ArrayList<Document>) benefitsObject;
		List<Document> updatedBenefitsList = new ArrayList<>();
		double monthlyPrem = 0.0, currMonPrem = 0.0;
		for (Document benefitDocument : benefitsList) {
			Document updatedBenefitDocument = new Document();
			addToDocument(memberSummaryBenefits, benefitDocument, "memberSummaryBenefits", updatedBenefitDocument);
			if (updatedBenefitDocument.containsKey(IConstants.CURR_CONT_PLAN_CODE) && 
					updatedBenefitDocument.get(IConstants.CURR_CONT_PLAN_CODE) != null && 
					!(updatedBenefitDocument.get(IConstants.CURR_CONT_PLAN_CODE).toString().equals(""))){
				
				ArrayList<Document> renProdList = (ArrayList<Document>) updatedBenefitDocument.get("renewalProducts");
				for(Document d : renProdList){
					d.put("contractPlanCode", updatedBenefitDocument.get("currentContractPlanCode"));
					d.put("productType", updatedBenefitDocument.get("productType"));
					if( (d.containsKey("renewalSubsidy") && d.get("renewalSubsidy").toString().equals("0.0")) || d.get("renewalSubsidy")== null){
						d.remove("renewalSubsidy");
						d.put("renewalSubsidy", "No");
					}
				}
				updatedBenefitsList.add(updatedBenefitDocument);
			
			}
		}
		putCalFields(summaryDoc, sourceDb, sourceColl[1], IConstants.UDM_DB);
		/* Start BPP-24690 Delta Displayed for Subsidized Individual Products does not match the Renewal Packet */
		if ( null != tdmRenewal.getDouble("currentPremiumwithoutSubsidy") && null!= tdmRenewal.getDouble("renewalSubsidy")) // It contains 'currentPremiumwithSubsidy'
			{
					double currMonPremwithsubsidy =0.0, diff=0.0 ;
					double monPremwithsubsidy   =0.0, delta =0.0;
				try{
					currMonPremwithsubsidy = tdmRenewal.getDouble("currentPremiumwithoutSubsidy");
					monPremwithsubsidy = tdmRenewal.getDouble(IConstants.MON_PREM) + tdmRenewal.getDouble("renewalSubsidy");
			
					diff = monPremwithsubsidy-currMonPremwithsubsidy;
				
					//BPP-23123-Renewals Dashboard - Question mark (junk character) 
					//displayed for "Change" field value-UI
					if(diff != 0.0 && currMonPremwithsubsidy != 0.0)
					{
						delta = (diff/currMonPremwithsubsidy)*100;
					}
				
				}
				catch(Exception e)
				{
					logger.error("Exception:  " + e);
				}
				summaryDoc.append("Delta", delta);
				summaryDoc.append("Difference", diff);
			}
		/* End BPP-24690 Delta Displayed */
		else {
			MongoConnector.getInstance().addGrpDelta(summaryDoc);
		}
		// summaryDoc.append(IConstants.MON_PREM, monthlyPrem);
		// summaryDoc.append(IConstants.CURR_MON_PREMIUM, currMonPrem);
		summaryDoc.append("renewalSummary", updatedBenefitsList);
		summaryDoc.append(IConstants.PLAN, IConstants.MED);
		if (summaryDoc.get(IConstants.MIDDLENAME) == null) {
			summaryDoc.append("middleName", "");
		}
		summaryDoc.append("groupName", (summaryDoc.get(IConstants.LASTNAME) + ", "
				+ summaryDoc.get(IConstants.FIRSTNAME) + " " + summaryDoc.get(IConstants.MIDDLENAME)).toUpperCase());
		docSummaryList.add(summaryDoc);
		
		try {

			MongoConnector.getInstance().removePreviousDocuments(targetDb, targetCollection, targetDetailCollection,
					IConstants.SDSREN_DB, summaryDoc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
//docDetailList : [Document{{ID=297A78305, type=IND, relationship=SUBSCR, renewalDate=Mon Jan 01 10:30:00 IST 2018, firstName=NANCY, lastName=LUTES, dateofBirth=, age=, gender=, tobaccoUsage=, tobaccoWellness=, contacts=[ { "addressType" : "home" , "addressLine2" : "415 HARROW LN" , "cityName" : "PLATTEVILLE" , "stateCode" : "CO" , "stateName" : "CO" , "postalCode" : "80651"} , { "addressType" : "mailing" , "addressLine2" : "415 HARROW LN" , "cityName" : "PLATTEVILLE" , "stateCode" : "CO" , "stateName" : "CO" , "postalCode" : "80651"}], agents=[ { "taxID" : "HNJKJJQTRZ" , "taxIDType" : "Writing" , "product" : "MED" , "agentID" : "HNJKJJQTRZ"} , { "taxID" : "CLGNPQJMTY" , "taxIDType" : "Paid" , "product" : "MED" , "agentID" : "CLGNPQJMTY"} , { "taxID" : "CLGNPQJMTY" , "taxIDType" : "Parent" , "product" : "MED" , "agentID" : "CLGNPQJMTY"}], PLAN_SBSDY=490.11, MED_CUR_RATING_AREA=06, DEN_CUR_RATING_AREA=, PD_CUR_RATING_AREA=, MED_FUTURE_RATING_AREA=, DEN_FUTURE_RATING_AREA=, PD_FUTURE_RATING_AREA=, start-date=2018-05-15 17:08:59.947, end-date=9999-12-31 00:00:00:000, source-path=D:/372712/Employer Broker/FeedFiles/ISG_ACA/Subscriber/PRE_SUB_ISG_ACA_CO_20180131_1614.txt, source=ISG(ACA), Version=V1, status=un-processed, Data_Quality_Check=passed, Benefits=[Document{{currentContractPlanCode=1G0Q, currentContractPlanName=ANTHEM BRONZE PATHWAY X HMO 5800, currentTotalPremium=139.37, currentSubsidy=490.11, currentPremiumwithoutSubsidy=629.48, productType=MED, currentMonthlyPremium=139.37, benefitType=currentProducts}}, Document{{contractPlanCode=1G0Q, renewalLetterCode=RN, benefitType=renewalProducts, premium=[Document{{renewalSubsidy=490.11, monthlyPremium=289.54}}], currentContractPlanCode=1G0Q, currentContractPlanName=ANTHEM BRONZE PATHWAY X HMO 5800, renewalContractPlanCode=1G0Q, renewalContractPlanName=ANTHEM BRONZE PATHWAY X HMO 5800, productType=MED, renewalSubsidy=490.11}}], dependentsCovered=No, exchangeIndicator=On}}]
// docSummaryList : [Document{{ID=297A78305, renewalDate=Mon Jan 01 10:30:00 IST 2018, type=IND, effectiveDate=Fri Dec 01 10:30:00 IST 2017, firstName=NANCY, lastName=LUTES, agents=[ { "taxID" : "HNJKJJQTRZ" , "taxIDType" : "Writing" , "product" : "MED" , "agentID" : "HNJKJJQTRZ"} , { "taxID" : "CLGNPQJMTY" , "taxIDType" : "Paid" , "product" : "MED" , "agentID" : "CLGNPQJMTY"} , { "taxID" : "CLGNPQJMTY" , "taxIDType" : "Parent" , "product" : "MED" , "agentID" : "CLGNPQJMTY"}], contacts=[{ "addressType" : "home" , "addressLine2" : "415 HARROW LN" , "cityName" : "PLATTEVILLE" , "stateCode" : "CO" , "stateName" : "CO" , "postalCode" : "80651"}], start-date=2018-05-15 17:08:59.947, end-date=9999-12-31 00:00:00:000, source-path=D:/372712/Employer Broker/FeedFiles/ISG_ACA/Subscriber/PRE_SUB_ISG_ACA_CO_20180131_1614.txt, source=ISG(ACA), Version=V1, status=un-processed, Data_Quality_Check=passed, currentMonthlyPremium=139.37, monthlyPremium=289.54, Delta=107.74915692042764, Difference=150.17000000000002, renewalSummary=[Document{{productType=MED, renewalDate=Mon Jan 01 10:30:00 IST 2018, currentContractPlanCode=1G0Q, renewalLetterCode=RN, currentContractPlanName=ANTHEM BRONZE PATHWAY X HMO 5800, renewalProducts=[Document{{renewalSubsidy=490.11, renewalContractPlanName=ANTHEM BRONZE PATHWAY X HMO 5800, contractPlanCode=1G0Q, productType=MED}}], contractPlanCode=1G0Q}}], plan=MED, groupName=NANCY LUTES}}]
		MongoConnector.getInstance().insertData(docDetailList, targetDb, targetDetailCollection, IConstants.SDSREN_DB);
		MongoConnector.getInstance().insertData(docSummaryList, targetDb, targetCollection, IConstants.SDSREN_DB);
		MongoConnector.getInstance().updateStatus(sourceDb, sourceColl[0], bsonFilter, IConstants.UDM_DB);
		/*benefitsList = null;
		updatedBenefitsList = null;
		summaryDoc = null;
		docDetailList = null;
		docSummaryList = null;
		System.gc();*/
		return null;
	}

	@SuppressWarnings("unchecked")
	private List<Document> getDetailDocs(Tuple2<Object, BSONObject> bsonFilter, String sourceDb, String[] sourceColl) {

		ProcessFieldNames memberDependentDetail = null;
		List<Document> subDocs = new ArrayList<>();
		try {
			memberDependentDetail = FieldNamesProperties.getInstance().getPropertyContext("memberDependentDetail");
			BasicDBList dependents = (BasicDBList) bsonFilter._2.get("Dependents");

			for (Object o : dependents) {
				Document tempDoc1 = new Document();
				Document dependDoc = new Document();
				tempDoc1.putAll(((BasicDBObject) o).toMap());
				addToDocument(memberDependentDetail, tempDoc1, "memberDependentDetail", dependDoc);
				Object depBenefits = getBenefits((Document) tempDoc1, sourceDb, sourceColl[1], IConstants.DEPENDENT,
						bsonFilter._2.get("GUID"));
				dependDoc.append(IConstants.BENEFITS, depBenefits);
				dependDoc.append(IConstants.TYPE, IConstants.DEPENDENT);
				subDocs.add(dependDoc);
				tempDoc1 = null;
			}
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return subDocs;
	}

	@SuppressWarnings("unchecked")
	private Object getBenefits(Document d, String sourceDb, String sourceColl, String type, Object object) {
		try {
			Document query = new Document();
			Document query1 = new Document();
			Document query2 = new Document();
			Document query3 = new Document();
			query.append("$match", new Document("GUID", object).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)
					.append(IConstants.END_DATE_FIELD,IConstants.MAX_DATE)); /* BPP-31928 : Not getting latest record , added Un-processed status */
			query1.append("$unwind", "$Dependents");
			query2.append("$match", new Document().append("Dependents.ID", d.get("HCID")));
			query3.append("$project",
					new Document().append(IConstants.RENEWAL_DETAILS, "$Dependents.Benefits").append("_id", 0));

			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, sourceColl,
					IConstants.UDM_DB);
			List<Document> l = new ArrayList<>();
			l.add(query);
			l.add(query1);
			l.add(query2);
			l.add(query3);

			AggregateIterable<Document> ddd = collcheck.aggregate(l);
			if (ddd.first() != null)
				;
			{
				Document doc = ddd.first();
				List<Document> renDetails = (List<Document>) doc.get(IConstants.RENEWAL_DETAILS);
				ProcessFieldNames memberDetailPremium = null;
				memberDetailPremium = FieldNamesProperties.getInstance().getPropertyContext("memberDetailPremium");
				List<Document> benefits = new ArrayList<>();

				for (Document renDoc : renDetails) {
					ArrayList<Document> renProdList = (ArrayList<Document>) renDoc.get("renewalProducts");
					Document tempDoc = renProdList.get(0);
					Document premiumDoc = new Document();
					List<Document> premiumDocList = new ArrayList<>();
					Document benefitDoc = new Document();
					addToDocument(memberDetailPremium, tempDoc, "memberDetailPremium", premiumDoc);
					benefitDoc.append("contractPlanCode", tempDoc.getString("contractPlanCode"));
					benefitDoc.append(IConstants.BENEFITTYPE, "renewalProducts");
					premiumDocList.add(premiumDoc);
					benefitDoc.append("premium", premiumDocList);
					benefitDoc.append("currentContractPlanCode", renDoc.get("currentContractPlanCode"));
					benefitDoc.append("currentContractPlanName", renDoc.get("currentContractPlanName"));
					renDoc.append(IConstants.BENEFITTYPE, IConstants.CURRENTPRODUCTS);
					renDoc.remove("renewalProducts");
					benefits.add(renDoc);
					benefits.add(benefitDoc);

				}

				return benefits;
			}

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return null;
	}

	private void addToDocument(ProcessFieldNames processFieldNames, Tuple2<Object, BSONObject> bsonFilter,
			String mappingName, Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

		}

	}

	private void addToDocumentIncNull(ProcessFieldNames processFieldNames, Tuple2<Object, BSONObject> bsonFilter,
			String mappingName, Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

			else
				document.append(fieldNames, "");

		}

	}

	private void addToDocument(ProcessFieldNames processFieldNames, Document bsonFilter, String mappingName,
			Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

		}

	}

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceColl, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String sourceDbTDM) {
		return null;
	}
	
	public void putCalFields(Document summaryDoc, String sourceDb, String sourceColl, String udmDb) {

		double currPrem = 0.00, monPrem = 0.00;
		Document d=null;
		try {
			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, sourceColl,
					udmDb);
			d = collcheck.find(new Document("ID", summaryDoc.getString("ID")).append(IConstants.END_DATE_FIELD,
					IConstants.MAX_DATE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)).first(); /* BPP-31928 : Not getting latest record , added Un-processed status */
			if (d.containsKey(IConstants.CURR_MON_PREMIUM))
				currPrem = d.getDouble(IConstants.CURR_MON_PREMIUM);
			if (d.containsKey(IConstants.MON_PREM))
				monPrem = d.getDouble(IConstants.MON_PREM);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		summaryDoc.append(IConstants.CURR_MON_PREMIUM, currPrem);
		summaryDoc.append(IConstants.MON_PREM, monPrem);

	}
}
