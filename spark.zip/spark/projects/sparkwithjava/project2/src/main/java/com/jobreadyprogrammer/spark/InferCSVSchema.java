package com.jobreadyprogrammer.spark;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class InferCSVSchema {

	public void printSchema() {
		SparkSession spark = SparkSession.builder().appName("Complex CSV to Dataframe").master("local").getOrCreate();

		Dataset<Row> df = spark.read().format("csv") //
				.option("header", "true") //
				.option("multiline", true) //
				.option("sep", ";") //
				.option("quote", "^") //
				.option("dateFormat", "M/d/y") //
				.option("inferSchema", true) //
			//	.load("/home/ubuntu/sparkwithjava/project2/src/main/resources/amazonProducts.txt");
				.load("src/main/resources/amazonProducts.txt");

		System.out.println("Excerpt of the dataframe content:");
		// df.show(7);

		// show 7 records and all characters of each column
		df.show(7, false);

		// show 7 records and show only 10 characters of each column
		df.show(7, 10);

		System.out.println("Dataframe's schema:");
		df.printSchema();
	}

}
