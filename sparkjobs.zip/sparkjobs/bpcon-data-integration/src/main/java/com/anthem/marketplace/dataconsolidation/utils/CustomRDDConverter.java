package com.anthem.marketplace.dataconsolidation.utils;

import java.io.StringReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.spark.api.java.function.Function;

import com.anthem.marketplace.dataconsolidation.model.AgencyInfo;
import com.anthem.marketplace.dataconsolidation.model.AgentInfo;
import com.anthem.marketplace.dataconsolidation.model.Contract;
import com.anthem.marketplace.dataconsolidation.model.DependentDetails;
import com.anthem.marketplace.dataconsolidation.model.PolicyHolderData;
import com.anthem.marketplace.dataconsolidation.model.PolicyHolderDetails;
import com.anthem.marketplace.dataconsolidation.model.SpouseDetails;
import com.anthem.marketplace.dataconsolidation.model.VARenewal;
import com.esotericsoftware.minlog.Log;

import generated.AGENCY;
import generated.AGENCYINFO;
import generated.AGENT;
import generated.AGENTINFO;
import generated.CONTRACT;
import generated.CONTRACTSFORTHISAGENT;
import generated.DEPENDENTDETAILS;
import generated.POLICYHOLDERDATA;
import generated.POLICYHOLDERDETAILS;
import generated.SPOUSEDETAILS;
import generated.WPFILE;
import scala.Tuple2;

public class CustomRDDConverter implements Function<Tuple2<String, String>,  List<VARenewal>> {

	@Override
	public List<VARenewal> call(Tuple2<String, String> file) throws Exception {
		
		JAXBContext jaxbContext = JAXBContext.newInstance(WPFILE.class);
        Unmarshaller jaxbUnMarshaller = jaxbContext.createUnmarshaller();
        StringReader xmlReader = new StringReader(file._2);
		WPFILE list = (WPFILE)jaxbUnMarshaller.unmarshal(xmlReader);
		List<VARenewal> vaRenewalsList = new ArrayList<VARenewal>();
		for(AGENCY agency : list.getAGENCY()) {
			for(AGENT agents : agency.getAGENTSFORTHISAGENCY().getAGENT()) {
				for(CONTRACTSFORTHISAGENT contracts : agents.getCONTRACTSFORTHISAGENT()) {
					
					VARenewal vaRenewal = new VARenewal();
					//Adding contract
					Contract contract = getContract(contracts.getCONTRACT()); 
					
					//Adding Policy Holder Data
					PolicyHolderData policyHolderData = getPolicyHolderData(contracts.getPOLICYHOLDERDATA());
					
					//Adding Policy Holder Details
					PolicyHolderDetails policyHolderDetails = getPolicyHolderDetails(contracts.getENROLLMENTDETAILS().getPOLICYHOLDERDETAILS());
					
					//Adding Spouse Details
					List<DependentDetails> dependentDetails = getDependentDetails(contracts.getENROLLMENTDETAILS().getDEPENDENTDETAILS());
								
					//Adding Spouse Details
					SpouseDetails spouse = getSpouseDetails(contracts.getENROLLMENTDETAILS().getSPOUSEDETAILS());
										
					//Adding corresponding agent
					AgentInfo agent = getAgent(agents.getAGENTINFO());
					
					//Adding Agency Details
					AgencyInfo agencyInfo = getAgencyInfo(agency.getAGENCYINFO());
						
					vaRenewal.setAgencyInfo(agencyInfo);
					vaRenewal.setSpouseDetails(spouse);
					vaRenewal.setDependentDetails(dependentDetails);
					vaRenewal.setPolicyHolderDetails(policyHolderDetails);
					vaRenewal.setPolicyHolderData(policyHolderData);
					vaRenewal.setAgentInfo(agent);
					vaRenewal.setContract(contract);
					vaRenewalsList.add(vaRenewal);
				}
			}
		}
		return vaRenewalsList;
	}
	
	private AgencyInfo getAgencyInfo(AGENCYINFO agencyinfo) {
		// TODO Auto-generated method stub
		AgencyInfo agencyInfo = null;
		try {
			if(agencyinfo != null) {
				agencyInfo = new AgencyInfo();
				agencyInfo.setAgencyAddressLine1(agencyinfo.getAGENCYADDRESS().getAGENCYADDRESSLN1());
				agencyInfo.setAgencyAddressLine2(agencyinfo.getAGENCYADDRESS().getAGENCYADDRESSLN2());
				agencyInfo.setAgencyName(agencyinfo.getAGENCYNAME());
				agencyInfo.setAgencyNumber(agencyinfo.getAGENCYNUMBER());
				agencyInfo.setAgencyZip(agencyinfo.getAGENCYADDRESS().getAGENCYADDRESSCITYSTATEZIP().getAGENCYADDRESSZIP());
				agencyInfo.setAgencyState(agencyinfo.getAGENCYADDRESS().getAGENCYADDRESSCITYSTATEZIP().getAGENCYADDRESSSTATE());
				agencyInfo.setAgencyCity(agencyinfo.getAGENCYADDRESS().getAGENCYADDRESSCITYSTATEZIP().getAGENCYADDRESSCITY());
			}
		}catch(Exception e) {
			Log.error(e.getMessage());
		}	
		return agencyInfo;
	}

	private AgentInfo getAgent(AGENTINFO agentinfo) {
		// TODO Auto-generated method stub
		AgentInfo agent = null;
		try {
			if(agentinfo != null) {
				agent = new AgentInfo();
				agent.setFirstName(agentinfo.getAGENTNAME().getAGENTNAMEFIRST());
				agent.setLastName(agentinfo.getAGENTNAME().getAGENTNAMELAST());
				agent.setMiddleName(agentinfo.getAGENTNAME().getAGENTNAMEMI());
				agent.setAgentNumber(agentinfo.getAGENTNUMBER());
			}
		}catch(Exception e) {
			Log.error(e.getMessage());
		}	
		return agent;
	}

	private SpouseDetails getSpouseDetails(SPOUSEDETAILS spousedetails) throws ParseException {

		SpouseDetails spouse = null ;
		try {
			if(spousedetails != null) {
				spouse = new SpouseDetails();
				spouse.setSpouseFirstName(spousedetails.getSPOUSEFIRSTNAME());
				spouse.setSpouseLastName(spousedetails.getSPOUSELASTNAME());
				spouse.setSpouseUwLevel(spousedetails.getSPOUSEUWLEVEL());
				spouse.setSpouseDateOfBirth(convertDate(spousedetails.getSPOUSEDATEOFBIRTH()));
			}
		}catch(Exception e) {
			Log.error(e.getMessage());
		}	
		return spouse;
	}

	private List<DependentDetails> getDependentDetails(List<DEPENDENTDETAILS> dependentdetails){

		List<DependentDetails> dependentDetails = new ArrayList<DependentDetails>();
		try {
			if(dependentdetails != null) {
				for(DEPENDENTDETAILS dependents : dependentdetails) {
					DependentDetails dependent = new DependentDetails();
					dependent.setDependentFirstName(dependents.getDEPENDENTFIRSTNAME());
					dependent.setDependentLastName(dependents.getDEPENDENTLASTNAME());
					dependent.setDependentUwLevel(dependents.getDEPENDENTUWLEVEL());
					dependent.setDependentDateOfBirth(convertDate(dependents.getDEPENDENTDATEOFBIRTH()));
					dependentDetails.add(dependent);
				}
			}
		}catch(Exception e) {
			Log.error(e.getMessage());
		}	
		return dependentDetails;
	}

	private PolicyHolderDetails getPolicyHolderDetails(POLICYHOLDERDETAILS policyholderdetails) {

		PolicyHolderDetails policyHolderDetail = null;
		try {
			if(policyholderdetails != null) {
				policyHolderDetail = new PolicyHolderDetails();
				policyHolderDetail.setFirstName(policyholderdetails.getPOLICYHOLDERFIRSTNAME());
				policyHolderDetail.setLastName(policyholderdetails.getPOLICYHOLDERLASTNAME());
				policyHolderDetail.setUwLevel(policyholderdetails.getPOLICYHOLDERUWLEVEL());
				policyHolderDetail.setDateOfBirth(convertDate(policyholderdetails.getPOLICYHOLDERDATEOFBIRTH()));
			}
		}catch(Exception e) {
				Log.error(e.getMessage());
		}				
		return policyHolderDetail;
	}

	private PolicyHolderData getPolicyHolderData(POLICYHOLDERDATA policyholderdata) {

		PolicyHolderData policyHolderData = null;
		try {
			if(policyholderdata != null) {
				policyHolderData = new PolicyHolderData();
				policyHolderData.setAddressLine1(policyholderdata.getPOLICYHOLDERADDRESS().getPOLICYHOLDERADDRESSLN1());
				policyHolderData.setAddressLine2(policyholderdata.getPOLICYHOLDERADDRESS().getPOLICYHOLDERADDRESSLN2());
				policyHolderData.setAddressLine3(policyholderdata.getPOLICYHOLDERADDRESS().getPOLICYHOLDERADDRESSLN3());
				policyHolderData.setCity(policyholderdata.getPOLICYHOLDERADDRESS().getPOLICYHOLDERADDRESSCITYSTATEZIP().getPOLICYHOLDERADDRESSCITY());
				policyHolderData.setState(policyholderdata.getPOLICYHOLDERADDRESS().getPOLICYHOLDERADDRESSCITYSTATEZIP().getPOLICYHOLDERADDRESSSTATE());
				policyHolderData.setPhoneNumber(policyholderdata.getPOLICYHOLDERPHONENUMBER());
				String zipCode5 = policyholderdata.getPOLICYHOLDERADDRESS().getPOLICYHOLDERADDRESSCITYSTATEZIP().getPOLICYHOLDERADDRESSZIP().getPOLICYHOLDERADDRESSZIP5();
				String zipCode4 = policyholderdata.getPOLICYHOLDERADDRESS().getPOLICYHOLDERADDRESSCITYSTATEZIP().getPOLICYHOLDERADDRESSZIP().getPOLICYHOLDERADDRESSZIP4();
				if(zipCode5 != null && !zipCode5.isEmpty()) {
					if(zipCode4 != null && !zipCode4.isEmpty()) {
						policyHolderData.setZip(zipCode5+"-"+zipCode4);
					}
					else {
						policyHolderData.setZip(zipCode5);
					}
				}
			}
		}catch(Exception e) {
			Log.error(e.getMessage());
		}
		return policyHolderData;
	}

	private Contract getContract(CONTRACT contracts){

		Contract contract = null;
		try {
			if(contracts != null ) {
				contract = new Contract();
				contract.setContractId(contracts.getCONTRACTID());
				contract.setDeductible(convertDouble(contracts.getDEDUCTIBLE()));
				contract.setEffectiveDate(convertDate(contracts.getEFFECTIVEDATE()));
				contract.setHcid(contracts.getHCID());
				contract.setOldRate(convertDouble(contracts.getOLDRATE()));
				contract.setNewRate(convertDouble(contracts.getNEWRATE()));
				contract.setProduct(contracts.getPRODUCT());
			}
		}catch(Exception e) {
			Log.error(e.getMessage());
		}
		return contract;
	}

	private Double convertDouble(String value) {
		
		Double convertValue;
		
		if (value.equals(null) || value.trim().equals("") || value.equalsIgnoreCase("null") || value.trim().isEmpty()) {
			convertValue = null;
		} else {

			value = value.replaceAll(IConstants.COMMA, "").replaceAll("\\$", "");

			if (value.indexOf('-') == value.length() - 1)
				value = '-' + value.substring(0, value.length() - 1);
			convertValue = Double.parseDouble(value);
		}
		return convertValue;
	}
	
	private Date convertDate(XMLGregorianCalendar value) throws ParseException {
		
		if (value != null) {

			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String date = formatter.format(value.toGregorianCalendar().getTime());
			Date formattedDate = (Date) formatter.parse(date);
			return formattedDate;
		}
		else
			return null;
	}

}
