package com.anthem.marketplace.dataconsolidation.filesutils;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.bson.BSONObject;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.anthem.marketplace.dataconsolidation.utils.ChangeDataCapture;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.FixedFileMetaDataProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFixedFileMetaData;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.BasicDBList;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

import scala.Tuple2;

/*
 * This class implements UtilityInterface and Serializable and performs Ingestion, Transformation of BCC and 
 * BCBSGA renewals input files
 * @author : MongoDB Team
 * @version : 1.0
 * @Date : June 2016
 * It returns nothing.
 */
public class ISG_NONACA implements UtilityInterface, Serializable {

	private static final long serialVersionUID = 1L;
	static final Logger logger = LoggerFactory.getLogger(ISG_NONACA.class);
	public static ArrayList<String> neglectList = new ArrayList<String>();
	public List<String> fieldsList;
	HashMap<String,String> planNames = new HashMap<String,String>(); /* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */

	/*
	 * This method creates GUID
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param delimeted stores delimited character
	 * 
	 * @param readFileContent stores input file data
	 * 
	 * @param guidvalue stores guid values retrieve from properties file
	 * 
	 * @param type stores type of file
	 * 
	 * @return String GUID
	 */
	public String createGuid(String sourceCollection, String delimeted, Row readFileContent, String guidvalue,
			String type) {
		String guid = "";
		String errorFieldName = "";
		try {
			List<ProcessFixedFileMetaData> guidPosition = new ArrayList<>();

			for (String item : guidvalue.split(IConstants.SPLIT_COMMA)) {
				errorFieldName = item;
				guidPosition.add(FixedFileMetaDataProperties.getInstance().getPropertyContext(item, type));
			}

			for (ProcessFixedFileMetaData item : guidPosition) {
				guid += (readFileContent.toString().substring(Integer.parseInt(item.getStart()),
						Integer.parseInt(item.getEnd()) + 1)).trim();
			}
			guid = guid.concat("IND").concat("SUBSCR");
		}
		// catch Exceptions and add respective errorCode and its description
		catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA,
					IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA,
					IConstants.RDM_DB);

		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA,
					IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA,
					IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.GUID_ERROR_METHOD,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA,
					IConstants.RDM_DB);
		}

		return guid;
	}

	/*
	 * This method checks mandatory fields for file for data Quality check
	 * 
	 * @param sourceCollection stores collection name
	 * 
	 * @param delimeted stores delimited character
	 * 
	 * @param readFileContent stores input file data
	 * 
	 * @param type stores type of file
	 * 
	 * @return boolean value based on data Quality check passed.
	 */
	public boolean createFlag(String delimeted, String sourceCollection, Row readFileContent, String type) {
		boolean flag = false;
		ProcessFixedFileMetaData metadata;
		String errorFieldName = "";
		try {
			// determine which files are mandatory from mapping.xml based on
			// type supplied
			Map<String, String> mandatoryFields = ReadMappingXmlSingleton.getInstance().getRead()
					.getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);
			for (String item : mandatoryFields.values()) {
				errorFieldName = item;
				metadata = FixedFileMetaDataProperties.getInstance().getPropertyContext(item, type);
				// check if mandatoryFields available in input content file
				flag = (readFileContent.toString()
						.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()))
						.trim() == null)
						|| readFileContent.toString()
								.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()))
								.trim().isEmpty();

				if (flag)
					break;
			}
			// if false then set error as null value found for mandatory fields.
			if (flag) {
				Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
						IConstants.DATA_QUALITY_ERROR_CHECK, readFileContent.toString(), errorFieldName,
						IConstants.ISG_NONACA, IConstants.RDM_DB);
			}
		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA,
					IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA,
					IConstants.RDM_DB);

		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA,
					IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA,
					IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.DATA_QUALITY_CHECK,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA,
					IConstants.RDM_DB);
		}
		return flag;
	}

	/*
	 * This method adds fileName and its respective value to a document and
	 * returns it.
	 * 
	 * @param processInput stores input properties related parameters
	 * 
	 * @param sourcePath stores source path of input file
	 * 
	 * @param guid stores GUID
	 * 
	 * @param flag stores value retrieve from data Quality check method
	 * 
	 * @param readFileContent stores Row of a input file
	 * 
	 * @return Document
	 */
	public Document appendRaw(ProcessInput processInput, String sourcePath, String guid, boolean flag,
			Row readFileContent) {

		String type = processInput.getType();

		String sourceDB = processInput.getSourceDB();
		String sourceCollection = processInput.getSourceCollection();
		String value;
		ProcessFixedFileMetaData metadata;
		ProcessFieldNames procFieldNames;
		boolean checkFlag = false;
		String errorFieldName = "";

		Document doc = new Document();
		try {
			procFieldNames = FieldNamesProperties.getInstance().getPropertyContext(type);
			doc.append(IConstants.GUID, guid);

			// for each filedNames
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				errorFieldName = fieldNames;
				// get dataType for each fieldName for given collectionName
				String dataType = ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(type,
						fieldNames, IConstants.DATATYPE);

				metadata = FixedFileMetaDataProperties.getInstance().getPropertyContext(fieldNames, type);
				value = readFileContent.toString()
						.substring(Integer.parseInt(metadata.getStart()), Integer.parseInt(metadata.getEnd()) + 1)
						.trim();

				// if empty value then append it as it is to document
				if (value.isEmpty())
					doc.append(fieldNames, value);

				// else change its dataType as specified and convert zonal
				// fields to zonal decimal number
				else {
					checkFlag = Utility.applyZone(sourceCollection, fieldNames, value.trim(), doc, dataType,
							readFileContent, IConstants.ISG_NONACA);
				}

			}
			if ((doc.getString(IConstants.MEDBROKERWRITINGTIN).trim().equals("")
					|| doc.getString(IConstants.MEDBROKERWRITINGTIN).trim().equals(null))
					&& (doc.getString("denBrokerWritingTin").trim().equals("")
							|| doc.getString("denBrokerWritingTin").trim().equals(null)))
				doc.append(IConstants.MEDBROKERWRITINGTIN, "0");

			doc.replace("medOldRate", doc.getDouble("medOldRate") / 100);		//business logic
			doc.replace("medNewRate", doc.getDouble("medNewRate") / 100);
			doc.replace("denOldRate", doc.getDouble("denOldRate") / 100);
			doc.replace("denNewRate", doc.getDouble("denNewRate") / 100);

			// insert metaData
			Utility.insertMetadata(doc, sourceDB, sourceCollection, guid, sourcePath, IConstants.ISGNONACA, flag, true,
					IConstants.RDM_DB);

			// catch Exceptions and add respective errorCode and its description
		} catch (NullPointerException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NULL_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA, IConstants.RDM_DB);
		} catch (ArrayIndexOutOfBoundsException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.ARRAY_EEROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA, IConstants.RDM_DB);
		} catch (ClassCastException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.CAST_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA, IConstants.RDM_DB);
		} catch (NumberFormatException e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.NUMBER_CONVERSION_ERROR_CODE, IConstants.RAW_DATA,
					"Exception:  " + e, readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA,
					IConstants.RDM_DB);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			Utility.createErrorCodeDescription(IConstants.GENERIC_ERROR_CODE, IConstants.RAW_DATA, "Exception:  " + e,
					readFileContent.toString(), errorFieldName, IConstants.ISG_NONACA, IConstants.RDM_DB);
		}

		return doc;
	}

	/*
	 * This method selects attributes to decide fields to be selected from BCC
	 * or BCBSGA Raw data.
	 * 
	 * @param fieldNames stores field names
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param collName stores collection name
	 * 
	 * @return attribute name
	 */
	public String selectFields(String fieldNames, Tuple2<Object, BSONObject> bsonFilter, String collName) {

		if (ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField(IConstants.ISG_NONACA.concat(collName), fieldNames, IConstants.PROD_TYPE)
				.equals(IConstants.STRING_FALSE))
			return IConstants.VALUE;

		else if ((bsonFilter._2.get(IConstants.MEDBROKERWRITINGTIN) == null)
				|| (bsonFilter._2.get(IConstants.MEDBROKERWRITINGTIN).toString().trim().equals("")))
			return IConstants.DENTAL;
		else
			return IConstants.MEDICAL;
	}

	public String selectMultiFields(String fieldNames, Tuple2<Object, BSONObject> bsonFilter, String collName,
			String sourceCollection) {
		List<String> selectFieldsList = new ArrayList<String>();
		if (ReadMappingXmlSingleton.getInstance().getRead()
				.getAttributeValueOfField(sourceCollection.concat(collName), fieldNames, IConstants.PROD_TYPE)
				.equals("false")) {
			return IConstants.VALUE;
		} else {

			if (!((bsonFilter._2.get(IConstants.MEDBROKERWRITINGTIN) == null)
					|| (bsonFilter._2.get(IConstants.MEDBROKERWRITINGTIN).toString().trim().equals("")))) {
				selectFieldsList.add(IConstants.MEDICAL);
			}
			if (!((bsonFilter._2.get(IConstants.DENBROKERWRITINGTIN) == null)
					|| (bsonFilter._2.get(IConstants.DENBROKERWRITINGTIN).toString().trim().equals("")))) {
				selectFieldsList.add(IConstants.DENTAL);
			}
		}
		if (selectFieldsList.size() > 0)
			fieldsList = selectFieldsList;
		return "Multi";
	}

	/*
	 * This method performs transformation on BCC or BCBSGA Raw data.
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source collection name
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param targetCollection stores target collection name
	 * 
	 * @param appendedCollection stores collection name whose data to be
	 * appended as embedded doc. i.t summary to detail
	 * 
	 * @return transformed Document
	 */
	public Document ingestTDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String transColl, String appendedCollection) {

		Document metaDoc = new Document();
		boolean flag = false;
		String guid = "";
		ProcessFieldNames procFieldNames = null;
		String sourcePath = "";
		ProcessFieldNames clientFieldNames = null;
		neglectList.add("");
		neglectList.add(null);
		try {
			clientFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_NONACA.concat(transColl).toString());
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e1) {
			logger.error(IConstants.ERROR_PREPEND, e1);

		}

		for (String fieldNames : clientFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
			String selectFieldAttribute = selectFields(fieldNames, bsonFilter, transColl);
			if (!neglectList.contains(
					bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
							IConstants.ISG_NONACA.concat(transColl), fieldNames, selectFieldAttribute))))
				metaDoc.append(fieldNames,
						bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
								IConstants.ISG_NONACA.concat(transColl), fieldNames, selectFieldAttribute)));
			metaDoc.append("type", "IND");
			metaDoc.append("relationship", "SUBSCR");
		} /*End of clientFieldNames for loop*/
		List<Document> innerDocList = new ArrayList<Document>();
		if (transColl.contains("Renewals_tdm_Renewal")) {
			fieldsList = new ArrayList<String>();
			try {
				procFieldNames = FieldNamesProperties.getInstance().getPropertyContext(IConstants.ISG_NONACA_REN_DET);
			} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
					| IllegalArgumentException | InvocationTargetException e) {
				logger.error(IConstants.ERROR_PREPEND, e);

			}
			do {
				Document doc = new Document();

				String product = "";
				for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
					String selectFieldAttribute = selectFields(fieldNames, bsonFilter, IConstants.RENEWAL_DETAILS);

					if (!selectFieldAttribute.equals(IConstants.VALUE)) {
						if (fieldsList.size() == 0)
							selectMultiFields(fieldNames, bsonFilter, IConstants.RENEWAL_DETAILS, sourceCollection);

						if (fieldsList.size() > 0) {
							selectFieldAttribute = fieldsList.get(0);
							product = selectFieldAttribute.toUpperCase();
						}

					}

					if (!neglectList.contains(
							bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
									IConstants.ISG_NONACA_REN_DET, fieldNames, selectFieldAttribute))))
					   {						
							doc.append(fieldNames,bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(IConstants.ISG_NONACA_REN_DET, fieldNames, selectFieldAttribute)));
					   }
				}/*End of for loop "procFieldNames"*/
				if (product.equals("PD"))
					product = "VIS";

				if (product.length() > 2)
					product = product.substring(0, 3);
				doc.append(IConstants.PRODUCT, product);
				List<Document> renewalProducts = getGrpRenewalProducts(sourceCollection, doc, bsonFilter._2(), metaDoc);
				doc.append("renewalProducts", renewalProducts);
				if (fieldsList.size() > 0)
					fieldsList.remove(0);

				innerDocList.add(doc);
			} while (fieldsList.size() > 0);
			metaDoc.append(IConstants.BENEFITS, innerDocList);
		}/* end of for 'if' Renewals_tdm_Renewal */

		else {
			int year = Calendar.getInstance().get(Calendar.YEAR);
			for (String coll : appendedCollection.split(IConstants.SPLIT_COMMA)) {
				Document doc = new Document();
				try {
					procFieldNames = FieldNamesProperties.getInstance()
							.getPropertyContext(IConstants.ISG_NONACA.concat(coll));
				} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
						| IllegalArgumentException | InvocationTargetException e) {
					logger.error(IConstants.ERROR_PREPEND, e);

				}
				BasicDBList docList = new BasicDBList();
				BasicDBList contDocList = new BasicDBList();
				if (coll.toString().equals(IConstants.CLIENT_AGENT)) {
					String[] arr = { "medical", "dental" };

					for (String taxid : arr) {
						String[] types = { "Writing", "Paid", "Parent" };
						for (String type : types) {
							Document addrDoc = new Document();
							for (String fieldNames : procFieldNames.getArrayFieldNames()
									.split(IConstants.SPLIT_COMMA)) {
								if (ReadMappingXmlSingleton.getInstance().getRead()
										.getAttributeValueOfField(IConstants.ISG_NONACA.concat(coll), fieldNames,
												IConstants.PROD_TYPE)
										.equals(IConstants.STRING_TRUE)) {
									if (fieldNames.equals(IConstants.PRODUCT)) {

										String product = taxid.toUpperCase();

										if (product.length() > 2)
											product = product.substring(0, 3);
										addrDoc.append(fieldNames, product);
									} else if (fieldNames.equals("taxID")) {

										addrDoc.append(fieldNames,
												bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
														.getAttributeValueOfField(sourceCollection + "taxID",
																taxid + type, IConstants.VALUE)));

									}

									else if (!neglectList.contains(bsonFilter._2.get(
											ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
													IConstants.ISG_NONACA.concat(coll), fieldNames, taxid))))
										addrDoc.append(fieldNames,
												bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
														.getAttributeValueOfField(IConstants.ISG_NONACA.concat(coll),
																fieldNames, taxid)));
								}

								else if (fieldNames.equals(IConstants.TAX_ID_TYPE)) {
									addrDoc.append(fieldNames, type);
								} else if (!neglectList.contains(bsonFilter._2
										.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
												IConstants.ISG_NONACA.concat(coll), fieldNames, IConstants.VALUE))))

									addrDoc.append(fieldNames,
											bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
													.getAttributeValueOfField(IConstants.ISG_NONACA.concat(coll),
															fieldNames, IConstants.VALUE)));

							}
							addrDoc.append("agentID", addrDoc.get("taxID"));
							if (!((addrDoc.get("taxID") == null) || (addrDoc.get("taxID").equals("")))){
								// updated for BPP -8989 agent name
								populateEncytedFields(addrDoc, addrDoc.get("agentID").toString(), targetDb);
								docList.add(addrDoc);
							}
						}
					}

					metaDoc.append(coll, docList);

				} else if (coll.toString().equals(IConstants.CLIENT_CONTACTS)) {
					Document d = new Document();
					for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

						String selectFieldAttribute = selectFields(fieldNames, bsonFilter, coll);
						if (fieldNames.equals("addressType")) {
							d.append(fieldNames, IConstants.DEFAULT);
						} else if (fieldNames.equals("renewalPeriod"))
							d.append(fieldNames, year);
						else if (!neglectList.contains(bsonFilter._2
								.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
										IConstants.ISG_NONACA.concat(coll), fieldNames, selectFieldAttribute))))
							d.append(fieldNames,
									bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
											.getAttributeValueOfField(IConstants.ISG_NONACA.concat(coll), fieldNames,
													selectFieldAttribute)));

					}
					contDocList.add(d);
					metaDoc.append(coll, contDocList);
				} else {
					for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
						String selectFieldAttribute = selectFields(fieldNames, bsonFilter, coll);
						if (fieldNames.equals("addressType")) {
							doc.append(fieldNames, IConstants.DEFAULT);
						} else if (fieldNames.equals("renewalPeriod"))
							doc.append(fieldNames, year);
						else if (!neglectList.contains(bsonFilter._2
								.get(ReadMappingXmlSingleton.getInstance().getRead().getAttributeValueOfField(
										IConstants.ISG_NONACA.concat(coll), fieldNames, selectFieldAttribute))))
							doc.append(fieldNames,
									bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
											.getAttributeValueOfField(IConstants.ISG_NONACA.concat(coll), fieldNames,
													selectFieldAttribute)));
					}
					metaDoc.append(coll, doc);
				}
			}
		}

		sourcePath = bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString();

		guid = metaDoc.get(IConstants.GUID).toString();
		// insert metaData
		Utility.insertMetadata(metaDoc, targetDb, transColl, guid, sourcePath, IConstants.ISGNONACA, flag, true,
				IConstants.TDM_DB);

		if (metaDoc.getString(IConstants.REN_ID) != null)
			return metaDoc;

		else
			return null;
	}
	
	// Added for BPP -8989 agent name
	private void populateEncytedFields(Document doc, String key, String targetDb) {
		try {
			
			if (key != null && key.length() > 0) {
				MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail("enrollmentDB","brokerinfo", "APP");
				
				Document docRen = (Document) collcheck.find(new Document("encryptedTin",key)).first();
				
				if (docRen != null && docRen.getString("encryptedTin") != null) {				
					doc.append("name", docRen.getString("agentOrAgencyName"));
				}else{
					doc.append("name", "");
				}
			}
			
			
		} catch (Exception e) {
			logger.error(key + "Can't fetch from DumpFiles");
		}

	}

	public List<Document> getRenewalProducts(String sourceCollection, Document outerDoc, BSONObject bsonObject) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}
			double monPrem = 0.0, currMonPrem = 0.0;
			try {
				if ((bsonObject.get("medOldRate") != null) && bsonObject.containsKey("medOldRate")) {
					currMonPrem += (Double) bsonObject.get("medOldRate");
					doc.remove("renewalMonthlyPremium");
				}
				if ((bsonObject.get("denOldRate") != null) && bsonObject.containsKey("denOldRate")) {
					currMonPrem += (Double) bsonObject.get("denOldRate");

				}
				if (bsonObject.get("medNewRate") != null && bsonObject.containsKey("medNewRate")) {
					monPrem += (Double) bsonObject.get("medNewRate");

				}
				if (bsonObject.get("denNewRate") != null && bsonObject.containsKey("denNewRate")) {
					monPrem += (Double) bsonObject.get("denNewRate");

				}
			} catch (Exception e) {
				logger.error(IConstants.ERROR_PREPEND, e);
			}
			doc.append(IConstants.MON_PREM, monPrem);
			if (outerDoc.containsKey(IConstants.CURR_MON_PREMIUM))
				outerDoc.remove(IConstants.CURR_MON_PREMIUM);
			outerDoc.append(IConstants.CURR_MON_PREMIUM, currMonPrem);
			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	public List<Document> getGrpRenewalProducts(String sourceCollection, Document outerDoc, BSONObject bsonObject,
			Document metaDoc) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}
			double monPrem = 0.0, currMonPrem = 0.0;
			try {
				if ((bsonObject.get("medOldRate") != null) && bsonObject.containsKey("medOldRate")) {
					currMonPrem += (Double) bsonObject.get("medOldRate");
					doc.remove("renewalMonthlyPremium");
				}
				if ((bsonObject.get("denOldRate") != null) && bsonObject.containsKey("denOldRate")) {
					currMonPrem += (Double) bsonObject.get("denOldRate");

				}
				if (bsonObject.get("medNewRate") != null && bsonObject.containsKey("medNewRate")) {
					monPrem += (Double) bsonObject.get("medNewRate");

				}
				if (bsonObject.get("denNewRate") != null && bsonObject.containsKey("denNewRate")) {
					monPrem += (Double) bsonObject.get("denNewRate");

				}
			} catch (Exception e) {
				logger.error(IConstants.ERROR_PREPEND, e);
			}
			if (metaDoc.containsKey(IConstants.MON_PREM))
				metaDoc.remove(IConstants.MON_PREM);
			metaDoc.append(IConstants.MON_PREM, monPrem);
			if (metaDoc.containsKey(IConstants.CURR_MON_PREMIUM))
				metaDoc.remove(IConstants.CURR_MON_PREMIUM);
			metaDoc.append(IConstants.CURR_MON_PREMIUM, currMonPrem);
			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	public List<Document> getRenewalProducts(String sourceCollection, Document outerDoc) {
		List<Document> renewalProducts = new ArrayList<>();
		ProcessFieldNames procFieldNames = null;
		try {
			procFieldNames = FieldNamesProperties.getInstance()
					.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
			Document doc = new Document();
			for (String fieldNames : procFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

				if (!outerDoc.containsKey(fieldNames))
					continue;
				if (!neglectList.contains(outerDoc.get(fieldNames)))
					doc.append(fieldNames, outerDoc.get(fieldNames));

			}
			double monPrem = 0.0;
			if (doc.containsKey("renewalMonthlyPremium")) {
				monPrem = doc.getDouble("renewalMonthlyPremium");
				doc.remove("renewalMonthlyPremium");
			}
			doc.append(IConstants.MON_PREM, monPrem);

			renewalProducts.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		return renewalProducts;

	}

	/*
	 * This method performs unified transformation on ASCS transformed data.
	 * 
	 * @param sourceDb stores source database name
	 * 
	 * @param sourceCollection stores source collection name
	 * 
	 * @param bsonFilter stores data
	 * 
	 * @param targetDb stores target database name
	 * 
	 * @param targetCollection stores target collection name
	 * 
	 * @param targetDetailCollection stores collection name whose data is
	 * appended as embedded doc. i.t summary to detail
	 * 
	 * @return transformed Document
	 */
	@SuppressWarnings("unchecked")
	public Document ingestUDMProcess(String sourceDb, String sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection) {

		Document metaDoc = new Document();
		try {
			metaDoc.putAll(bsonFilter._2.toMap());

			metaDoc.remove(IConstants.ID);
		} catch (Exception e) {
			logger.error("Exception:  " + e);
		}
		return metaDoc;
	}

	/*
	 * this method inserts data into mongoDB for given specifications
	 * 
	 * @processInput stores input related parameters
	 * 
	 * @sourcePath stores file location path
	 * 
	 * @guidvalue stores GUID
	 * 
	 * @priority stores priority of process
	 * 
	 * @strType stores type of input file.
	 * 
	 * @return nothing
	 */
	@Override
	public void ingestRDMprocess(ProcessInput processInput, String sourcePath, String guidvalue, String strType) {
		List<Document> docList = new ArrayList<>();
		List<Document> failedList = new ArrayList<>();

		String sourceCollection = processInput.getSourceCollection();
		String delimeted = processInput.getDelimeted();
		String delimeter = processInput.getDelimeter();
		String type = processInput.getType();
		String sourceDB = processInput.getSourceDB();
		String failedCollection = processInput.getFailedCollection();
		String parentCollection = processInput.getParentCollection();
		JavaSparkContext scIngest = SparkContextSingleton.getInstance().getSparkContext();
		JavaRDD<String> filePartition = scIngest.textFile(sourcePath, 12);
		filePartition.count();
		JavaRDD<Row> readFile = filePartition.map(record -> RowFactory.create((Object[]) record.split(delimeter, -1)));
		readFile.foreachPartition(partitionIterator -> {

			ProcessInput process = new ProcessInput(sourceDB, sourceCollection, type, delimeter, delimeted,
					failedCollection, parentCollection);
			partitionIterator.forEachRemaining(readFileContent -> {
				String guid = this.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);	
				boolean flag = this.createFlag(delimeted, sourceCollection, readFileContent, type);		//validating with mapping.xml
				Document doc = this.appendRaw(process, sourcePath, guid, flag, readFileContent);	
				ChangeDataCapture cdc = new ChangeDataCapture();
				cdc.implementCdc(sourceDB, sourceCollection, doc, docList, failedList, IConstants.RDM_DB);		//(bpconadsDB,Renewals_ISG_NONACA,doc,docList,failedList,RDM)
				
				if(docList.size() >= 500){
					MongoConnector.getInstance().insertData(docList, sourceDB, sourceCollection, IConstants.RDM_DB);
					MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
					docList.clear();
					failedList.clear();
				}

			});
			MongoConnector.getInstance().insertData(docList, sourceDB, sourceCollection, IConstants.RDM_DB);
			MongoConnector.getInstance().insertData(failedList, sourceDB, failedCollection, IConstants.RDM_DB);
		});

	}

	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection,
			Tuple2<Object, BSONObject> bsonFilter, ProcessFieldNames procFieldNames, String targetDb,
			String targetCollection, String targetDetailCollection, String sourceDbTDM) {
		return null;
	}

	public List<Document> ingestSDSProcess(String sourceDb, String sourceCollection) {
		return null;
	}

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceCollection, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String targetDetailCollection, ProcessInput processInput) {
		ProcessFieldNames memberSummary = null;
		ProcessFieldNames memberDetail = null;
		ProcessFieldNames memberSummaryBenefits = null;
		try {
			memberSummary = FieldNamesProperties.getInstance().getPropertyContext("memberSummary");
			memberDetail = FieldNamesProperties.getInstance().getPropertyContext("memberDetail");
			memberSummaryBenefits = FieldNamesProperties.getInstance()
					.getPropertyContext("memberSummaryBenefits" + IConstants.MODIFIED);
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException e1) {
			logger.error(IConstants.ERROR_PREPEND, e1);
		}
		String[] sourceColl = sourceCollection;
		List<Document> docDetailList = new ArrayList<>();
		List<Document> docSummaryList = new ArrayList<>();

		Document doc = new Document();
		Document summaryDoc = new Document();

		try {
			addToDocument(memberDetail, bsonFilter, "memberDetail", doc);
			doc.append("exchangeIndicator", "No");
			doc.append("ratingArea", "");
			for (String metaData : IConstants.getMetadata())
				doc.append(metaData, bsonFilter._2.get(metaData));
			if (doc.get(IConstants.MIDDLENAME) == null) {
				doc.append("middleName", "");
			}
			doc.append("groupName", (doc.get(IConstants.LASTNAME) + ", " + doc.get(IConstants.FIRSTNAME) + " "
					+ doc.get(IConstants.MIDDLENAME)).toUpperCase());
			/*doc.append(IConstants.RENEWAL_DETAILS, MongoConnector.getInstance().getRenewalDocumentSDSDetail(bsonFilter,
					sourceDb, sourceColl[1], IConstants.UDM_DB));
			doc.append(IConstants.RENEWAL_DETAILS, MongoConnector.getInstance().getRenewalDocumentSDSDetailModified(bsonFilter,
					sourceDb, sourceColl[1], IConstants.UDM_DB));*/
			doc.append(IConstants.RENEWAL_DETAILS, getRenewalDocumentSDSDetailModified(bsonFilter,
						sourceDb, sourceColl[1], IConstants.UDM_DB,targetDb));  /* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
			//docDetailList.add(doc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		addToDocument(memberSummary, bsonFilter, "memberSummary", summaryDoc);
		for (String metaData : IConstants.getMetadata())
			summaryDoc.append(metaData, bsonFilter._2.get(metaData));

		Object benefitsObject = MongoConnector.getInstance().getRenewalDocumentSDS(bsonFilter, sourceDb, sourceColl[1],
				IConstants.UDM_DB, IConstants.RENEWAL_DETAILS);
		@SuppressWarnings("unchecked")
		List<Document> benefitsList = (ArrayList<Document>) benefitsObject;
		List<Document> updatedBenefitsList = new ArrayList<>();
		String dependent = "";
		String dependent_ratingTier = "";
		for (Document benefitDocument : benefitsList) {
			Document updatedBenefitDocument = new Document();
			//addToDocument(memberSummaryBenefits, benefitDocument, "memberSummaryBenefits", updatedBenefitDocument);
			//updated for BPP-8989/8900
			//dependent = benefitDocument.getString("ratingTier");
			/*BPP-24845 - ISG Non ACA - Dependents Covered Logic*/
			
			
			
			
			
			if (benefitDocument.getString("medContractType") != null && benefitDocument.getString("medContractType").length() >0){
				dependent = benefitDocument.getString("medContractType");
			}else if(benefitDocument.getString("denContractType") != null && benefitDocument.getString("denContractType").length() >0){
				dependent = benefitDocument.getString("denContractType");
			}else if(benefitDocument.getString("ratingTier") != null && benefitDocument.getString("ratingTier").length() >0){
				dependent_ratingTier = benefitDocument.getString("ratingTier");
			}
			
			addToDocument(memberSummaryBenefits, benefitDocument, "memberSummaryBenefitsModified", updatedBenefitDocument);
			updatedBenefitDocument.remove("currentContractPlanName");
			updatedBenefitDocument.put("currentContractPlanName", 
					getPlanName(updatedBenefitDocument.getString("currentContractPlanCode"),targetDb,targetDb)); /* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
			@SuppressWarnings("unchecked")
			ArrayList<Document> renProdList = (ArrayList<Document>) updatedBenefitDocument.get("renewalProducts");
			for(Document d : renProdList){
				d.put("contractPlanCode", d.get("renewalContractCode"));
				d.remove("renewalContractCode");
				d.put("productType", updatedBenefitDocument.get("productType"));
				//d.put("renewalContractPlanName", "");
				/* Start BPP-24163 : ISGNONACA NE*/
				if (( null != bsonFilter._2.get("plcyTypeCd"))){
				d.put("renewalContractPlanName",  getPlanName(d.getString("contractPlanCode"),targetDb,targetDb));
				}
				else{
					d.put("renewalContractPlanName",  getPlanName(d.getString("contractPlanCode"),targetDb,targetDb));
				}
					/* End BPP-24163 : ISGNONACA NE*/
			}
			updatedBenefitsList.add(updatedBenefitDocument);
		}
		
		/*Document depedentDoc = new Document();
		if(dependent.equalsIgnoreCase("P") || dependent.equalsIgnoreCase("Q") || dependent.equalsIgnoreCase("R")){
			depedentDoc.append("dependentsCovered","Family");
		}else if(dependent.equalsIgnoreCase("M") || dependent.equalsIgnoreCase("N") || dependent.equalsIgnoreCase("E")){
			depedentDoc.append("dependentsCovered","Children");
		}else if(dependent.equalsIgnoreCase("C") || dependent.equalsIgnoreCase("D")){
			depedentDoc.append("dependentsCovered","Spouse");
		}else if(dependent.equalsIgnoreCase("A") || dependent.equalsIgnoreCase("B")){
			depedentDoc.append("dependentsCovered","No");
		}
		if(depedentDoc.get("dependentsCovered") != null && depedentDoc.getString("dependentsCovered").trim().length() > 0){
			doc.append("Dependents", depedentDoc);
		}*/

		/*Start : 24845 Dependents covered Issue */
		if((null!= dependent && (dependent.equalsIgnoreCase("A") || dependent.equalsIgnoreCase("B") ))){
			doc.append("dependentsCovered","No");
		}
		else if(( null!= dependent && (dependent.equalsIgnoreCase("C") || dependent.equalsIgnoreCase("D") || dependent.equalsIgnoreCase("E") || dependent.equalsIgnoreCase("F")  || 
			dependent.equalsIgnoreCase("G") || dependent.equalsIgnoreCase("L") || dependent.equalsIgnoreCase("M") || dependent.equalsIgnoreCase("N")  ||
			dependent.equalsIgnoreCase("P") || dependent.equalsIgnoreCase("Q") || dependent.equalsIgnoreCase("R") || dependent.equalsIgnoreCase("S")  || 
			dependent.equalsIgnoreCase("U"))) ){
			doc.append("dependentsCovered","Yes");
		}
		else if(null!= dependent_ratingTier && dependent_ratingTier.equalsIgnoreCase("P")){
			doc.append("dependentsCovered","No");
		}else if (null!= dependent_ratingTier && StringUtils.isNumeric(dependent_ratingTier) && (Integer.parseInt(dependent_ratingTier) == 0 || Integer.parseInt(dependent_ratingTier) == 1))
		{
			doc.append("dependentsCovered","No");
		}
		else{
			//If the medContractType,denContractType and Rating Level is blank set "-" to dependent
			doc.append("dependentsCovered","-");
		}
		/*End : 24845 Dependents covered Issue */
		
		docDetailList.add(doc);
		putCalFields(summaryDoc, sourceDb, sourceColl[1], IConstants.UDM_DB);
		MongoConnector.getInstance().addGrpDelta(summaryDoc);
		summaryDoc.append("renewalSummary", updatedBenefitsList);
		summaryDoc.append(IConstants.PLAN, IConstants.MED);
		if (summaryDoc.get(IConstants.MIDDLENAME) == null) {
			summaryDoc.append("middleName", "");
		}
		// Added for BPP-8989
		summaryDoc.append("groupName", (summaryDoc.get(IConstants.LASTNAME) + ", "
				+ summaryDoc.get(IConstants.FIRSTNAME) + " " + summaryDoc.get(IConstants.MIDDLENAME)).toUpperCase());

		docSummaryList.add(summaryDoc);
		
		try {

			MongoConnector.getInstance().removePreviousDocuments(targetDb, targetCollection, targetDetailCollection,
					IConstants.SDSREN_DB, summaryDoc);

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}

		MongoConnector.getInstance().insertData(docDetailList, targetDb, targetDetailCollection, IConstants.SDSREN_DB);
		MongoConnector.getInstance().insertData(docSummaryList, targetDb, targetCollection, IConstants.SDSREN_DB);
		MongoConnector.getInstance().updateStatus(sourceDb, sourceColl[0], bsonFilter, IConstants.UDM_DB);
		return null;
	}

	private void addToDocument(ProcessFieldNames processFieldNames, Tuple2<Object, BSONObject> bsonFilter,
			String mappingName, Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter._2.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

		}

	}

	private void addToDocument(ProcessFieldNames processFieldNames, Document bsonFilter, String mappingName,
			Document document) {

		for (String fieldNames : processFieldNames.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {

			if (!neglectList.contains(bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
					.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE))))

				document.append(fieldNames, bsonFilter.get(ReadMappingXmlSingleton.getInstance().getRead()
						.getAttributeValueOfField(mappingName, fieldNames, IConstants.VALUE)));

		}

	}

	@Override
	public Document ingestSDSProcess(String sourceDb, String[] sourceColl, Tuple2<Object, BSONObject> bsonFilter,
			String targetDb, String targetCollection, String sourceDbTDM) {
		return null;
	}
	/* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
	public Object getRenewalDocumentSDSDetailModified(Tuple2<Object, BSONObject> bsonFilter, String sourceDb, String sourceColl,String dbType, String targetDb) {
		try {
			
			ProcessFieldNames memberDetailPremium = null;
			memberDetailPremium = FieldNamesProperties.getInstance().getPropertyContext("memberDetailPremium");
			List<Document> benefits = new ArrayList<>();
			
			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb,
					sourceColl, dbType);
			
				//Document docRen = (Document) collcheck.find(new Document("GUID", bsonFilter._2.get("GUID").toString())).first();
				/* BPP-31606 : Start : ISG NON ACA [BCC,BCBSGA] Renewal Details */	
				Document docRen = (Document) collcheck.find(new Document(IConstants.GUID, bsonFilter._2.get("GUID").toString()).append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)).first();
				/* BPP-31606 : End : ISG NON ACA Renewal Details */
			
				
				List<Document> renDetails =  (List<Document>) docRen.get(IConstants.RENEWAL_DETAILS);
										
					for(Document renDoc : renDetails){
						ArrayList<Document> renProdList = (ArrayList<Document>) renDoc.get("renewalProducts");
						Document tempDoc= renProdList.get(0);							
						Document premiumDoc = new Document();
						List<Document> premiumDocList = new ArrayList<>();
						Document benefitDoc = new Document();
						Document currBenefitDoc = new Document();
						addToDocument(memberDetailPremium, tempDoc, "memberDetailPremium", premiumDoc);
						premiumDoc.append("monthlyPremium", renDoc.get("renewalMonthlyPremium"));
						premiumDoc.remove("renewalSubsidy");
						premiumDoc.append("renewalSubsidy", "No");
						premiumDoc.remove("currentMonthlyPremium");
						premiumDoc.append("currentMonthlyPremium", renDoc.get("currentMonthlyPremium"));
						premiumDoc.remove("renewalPremiumwithoutSubsidy");
						premiumDoc.append("renewalPremiumwithoutSubsidy", renDoc.get("renewalPremiumwithoutSubsidy"));
						benefitDoc.append("contractPlanCode", tempDoc.getString("renewalContractCode"));
						benefitDoc.append(IConstants.BENEFITTYPE, "renewalProducts");
						premiumDocList.add(premiumDoc);
						benefitDoc.append("premium", premiumDocList);
						benefitDoc.append("currentContractPlanCode",renDoc.get("currentContractPlanCode"));
						benefitDoc.append("currentContractPlanName",
								getPlanName(renDoc.getString("currentContractPlanCode"),targetDb,targetDb)); /* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
						// udpated for BPP-8990
						benefitDoc.append("renewalContractPlanCode",renDoc.get("renewalContractCode"));
						benefitDoc.append("contractPlanCode",renDoc.get("renewalContractCode"));
						benefitDoc.append("renewalContractPlanName",
								getPlanName(renDoc.getString("renewalContractCode"),targetDb,targetDb)); /* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
						benefitDoc.append("productType",renDoc.get("product"));
						//benefitDoc.append("renewalSubsidy",0.0);
						benefitDoc.append("renewalSubsidy","No");
						
						currBenefitDoc.append("currentContractPlanCode",renDoc.get("currentContractPlanCode"));
						currBenefitDoc.append("currentContractPlanName",
								getPlanName(renDoc.getString("currentContractPlanCode"),targetDb,targetDb)); /* BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
						//currBenefitDoc.append("renewalContractPlanCode",renDoc.get("renewalContractCode"));
						currBenefitDoc.append("currentTotalPremium",renDoc.get("currentTotalPremium"));
						//currBenefitDoc.append("currentSubsidy",renDoc.get("currentSubsidy"));
						currBenefitDoc.append("currentSubsidy","No");
						currBenefitDoc.append("currentPremiumwithoutSubsidy",renDoc.get("currentPremiumwithoutSubsidy"));
						currBenefitDoc.append("productType",renDoc.get("product"));
						//currBenefitDoc.append("currentMonthlyPremium",renDoc.get("renewalMonthlyPremium"));
						currBenefitDoc.append("currentMonthlyPremium",renDoc.get("currentMonthlyPremium"));
						currBenefitDoc.append(IConstants.BENEFITTYPE, IConstants.CURRENTPRODUCTS);
						
						if(currBenefitDoc.containsKey(IConstants.CURR_CONT_PLAN_CODE))
							benefits.add(currBenefitDoc);
						if(benefitDoc.containsKey(IConstants.CURR_CONT_PLAN_CODE))
							benefits.add(benefitDoc);
						
					}
					
					return benefits;
				
			
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
			}
		return null;

	} 
	public void putCalFields(Document summaryDoc, String sourceDb, String sourceColl, String udmDb) {

		double currPrem = 0.00, monPrem = 0.00;
		Document d=null;
		try {
			MongoCollection<Document> collcheck = MongoConnector.getInstance().getCollectionDetail(sourceDb, sourceColl,
					udmDb);
			d = collcheck.find(new Document("ID", summaryDoc.getString("ID")).append(IConstants.END_DATE_FIELD,
					IConstants.MAX_DATE).append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)).first(); /* BPP-31928 : Not getting latest record , added Un-processed status */
			if (d.containsKey(IConstants.CURR_MON_PREMIUM))
				currPrem = d.getDouble(IConstants.CURR_MON_PREMIUM);
			if (d.containsKey(IConstants.MON_PREM))
				monPrem = d.getDouble(IConstants.MON_PREM);
		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		summaryDoc.append(IConstants.CURR_MON_PREMIUM, currPrem);
		summaryDoc.append(IConstants.MON_PREM, monPrem);

	}
	/* Start BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
	private String getPlanName(String planCode,String sourceDb,String dbType){
		String strPlanName ="";		
		
		if(planNames.get(planCode) != null){
			return planNames.get(planCode);
		}
		
		FindIterable<Document> objPlanName = MongoConnector.getInstance().
				getPlanName("CONTR_CDE", planCode, sourceDb, "RenewalISGNonACAPlanNames", IConstants.SDSREN_DB);
		
		for(Document objPlan:objPlanName){
			strPlanName = objPlan.getString("PLAN_NAME");
			planNames.put(planCode, strPlanName);
			return strPlanName;
		}		
		return strPlanName;
	}
	/* End BPP-34308 : Renewal Service performance degradation issues (Data fix)  */
}
