package com.anthem.marketplace.dataconsolidation.job.processor;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.bson.BSONObject;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.filesutils.UtilityInterface;
import com.anthem.marketplace.dataconsolidation.utils.CDCProperties;
import com.anthem.marketplace.dataconsolidation.utils.ChangeDataCapture;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.MongoConfiguration;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessCDC;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.MongoCommandException;
import com.mongodb.hadoop.MongoInputFormat;

/*
 * This class Starts Transformation Process
 */

public class IngestUDM implements Serializable {

	private static final long serialVersionUID = 1L;
	static final Logger logger = LoggerFactory.getLogger(IngestUDM.class);
	int targetCollIndex = 0;

	/*
	 * This method ingest data into sourceDB.sorceCollection on mongoDB
	 * 
	 * @param processInput stores input related parameters
	 * 
	 * @param targetDetailCollection stores
	 * 
	 * @param priority stores job priority
	 * 
	 * @param strType stores file type
	 * 
	 * @param source stores source value for each file
	 * 
	 * @return boolean value depending on UDM transformation process
	 */
	public boolean readAndUDMTransform(ProcessInput processInput, String targetDetailCollection, String strType,
			String sourcePath) {
		ProcessCDC proc = null;
		Configuration mongodbConfig;
		JavaPairRDD<Object, BSONObject> documents;
		try {

			String sourceDb = processInput.getUDMSourceDB();
			String sourceCollection = processInput.getUDMSourceCollection();
			final String[] sourceCollectionArray = sourceCollection.split(IConstants.SPLIT_COMMA);
			String targetDb = processInput.getUDMTargetDB();
			String targetCollection = processInput.getUDMTargetCollection();
			final String[] targetCollectionArray = targetCollection.split(IConstants.SPLIT_COMMA);
			String sourceField = processInput.getSourceField();

			long count = MongoConnector.getInstance()
						.getCollectionDetail(sourceDb, sourceCollection.split(IConstants.COMMA)[1], IConstants.TDM_DB)
						.count(new Document(IConstants.STATUS_FIELD, IConstants.UNPROCESSED)
								.append(IConstants.SOURCE_FIELD, sourceField));
				if (count > 0) {
					try {
						proc = CDCProperties.getInstance()
								.getPropertyContext(processInput.getFileType() + IConstants.UDM_DB);
					} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
							| IllegalArgumentException | InvocationTargetException e) {
						logger.error("Exception:  " + e);
					}
					Boolean performCDC = Boolean.parseBoolean(proc.getPerformCDC());

					JavaSparkContext scTransform = SparkContextSingleton.getInstance().getSparkContext();

					logger.debug("UDM Started for --> "
							+ strType.split(IConstants.SPLIT_DOT)[strType.split(IConstants.SPLIT_DOT).length - 1]);
					for (String sourceColl : sourceCollectionArray) {
						String targetColl = targetCollectionArray[targetCollIndex];
						/* Start : Performance Improvement Added inputQuery */  
						//String inputQuery="{'status':'un-processed','source':'"+sourceField+"','end-date':'"+IConstants.MAX_DATE+"'}";
						//mongodbConfig = new MongoConfiguration(sourceDb, sourceColl).setConfiguration(IConstants.TDM_DB, inputQuery);
						/* End : Performance Improvement Added inputQuery */
						mongodbConfig = new MongoConfiguration(sourceDb, sourceColl)
								.setConfiguration(IConstants.TDM_DB);
						documents = scTransform
								.newAPIHadoopRDD(mongodbConfig, MongoInputFormat.class, Object.class, BSONObject.class)
								.filter(bsonFilter -> {
									if (bsonFilter._2.get(IConstants.SOURCE_PATH_FIELD).toString().contains(sourcePath)
											&& bsonFilter._2.get(IConstants.STATUS_FIELD).toString()
													.contains(IConstants.UNPROCESSED)
											&& bsonFilter._2.get(IConstants.END_DATE_FIELD).toString()
													.contains(IConstants.MAX_DATE)) {
										UtilityInterface utilityInterface;
										List<Document> list = new ArrayList<>();
										List<Document> failedList = new ArrayList<>();
										Document metaDoc;
										try {

											utilityInterface = Utility.createObject(strType);
											metaDoc = utilityInterface.ingestUDMProcess(sourceDb, sourceColl,
													bsonFilter, targetDb, targetColl, targetDetailCollection);

											if (performCDC) {

												ChangeDataCapture cdc = new ChangeDataCapture();
												cdc.implementCdc(targetDb, targetColl, metaDoc, list, failedList, false,
														IConstants.UDM_DB);
												MongoConnector.getInstance().insertData(list, targetDb, targetColl,
														IConstants.UDM_DB);
											} else {
												MongoConnector.getInstance().replaceSummaryDocument(targetDb,
														targetColl, metaDoc, IConstants.UDM_DB);
											}

											return true;

										} catch (Exception e) {
											logger.error(IConstants.ERROR_PREPEND, e);
											return false;
										} finally {
											utilityInterface = null;
											list = null;
											failedList = null;
											metaDoc = null;
										}

									} else
										return false;
								});

						try {
							documents.count();
							MongoConnector.getInstance().updateAllTDMStatus(sourceDb, sourceColl, sourcePath,
									IConstants.TDM_DB);
							logger.debug("UDM Done for --> " + strType
									.split(IConstants.SPLIT_DOT)[strType.split(IConstants.SPLIT_DOT).length - 1]);
						} catch (MongoCommandException e) {
							logger.error("Mongo Exception Occured" + e);
							return false;
						}
						targetCollIndex++;
					}
				}
		} catch (Exception e) {
			logger.error("Exception:  " + e);
		} finally {
			proc = null;
			mongodbConfig = null;
			documents = null;
		}
		return true;
	}
}