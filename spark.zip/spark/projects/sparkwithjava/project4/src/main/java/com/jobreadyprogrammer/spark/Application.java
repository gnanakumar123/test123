package com.jobreadyprogrammer.spark;

public class Application {

	public static void main(String[] args) {

		MapReduceExample1 app2 = new MapReduceExample1();
		app2.start();

		MapCsvToDatasetHouseToDataframe app = new MapCsvToDatasetHouseToDataframe();
		app.start();

		// WordCount wc = new WordCount();
		// wc.start();

	}

}
