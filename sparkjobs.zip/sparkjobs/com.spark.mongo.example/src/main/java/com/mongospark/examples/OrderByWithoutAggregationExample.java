package com.mongospark.examples;

import java.io.Serializable;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

public class OrderByWithoutAggregationExample implements Serializable {

	public static void main(String[] args) {

		SparkSession spark = SparkSession.builder().master("local").appName("MongoSparkConnectorIntro")
				.config("spark.mongodb.input.uri", "mongodb://127.0.0.1/test.agent_lookup")
				.config("spark.mongodb.output.uri", "mongodb://127.0.0.1/test.agent_lookup").getOrCreate();

		// Create a Java Spark Context from a Spark Session
		JavaSparkContext jsc = new JavaSparkContext(spark.sparkContext());

		StructType groupBrokerSchema = DataTypes.createStructType(
				new StructField[] { DataTypes.createStructField("seqNumber", DataTypes.StringType, true),
						DataTypes.createStructField("groupId", DataTypes.StringType, true),
						DataTypes.createStructField("writingAgentTin", DataTypes.StringType, true),
						DataTypes.createStructField("writingAgentName", DataTypes.StringType, true),
						DataTypes.createStructField("paidAgentTin", DataTypes.StringType, true),
						DataTypes.createStructField("paidAgentName", DataTypes.StringType, true),
						DataTypes.createStructField("GeneralAgentTin", DataTypes.StringType, true),
						DataTypes.createStructField("GeneralAgentName", DataTypes.StringType, true)

				});

		Dataset<Row> groupBrokerDf = spark.read().format("csv") //
				.schema(groupBrokerSchema).option("header", "true") //
				.option("multiline", true) //
				.option("sep", ";") //
				.option("quote", "^") //
				.option("dateFormat", "M/d/y") //
				.option("inferSchema", true) //
				.load("src/main/resources/group_broker_2.txt");
		groupBrokerDf.show(false);

	
		Dataset<Row> groupedDf = groupBrokerDf.orderBy(groupBrokerDf.col("groupId"),groupBrokerDf.col("writingAgentTin"));
		groupedDf.show(false);

	}

}
