package com.anthem.marketplace.dataconsolidation.utils;

public final class ZonedDecimalParser {

	private ZonedDecimalParser() {
	}

    /**
     * Gets the decimal.
     *
     * @param i_str the i_str
     * @return the decimal
     */
    public static Long getDecimal(String str){
        long returnNumber = 0;
        int strLen;
        char lastChar;
        int lastNum;
        String firstStr;

        if (str == null || str.length()==0){
            return null;
        }else{
        	strLen = str.length();

        	lastChar = str.charAt(strLen-1);

        	lastNum = (int)lastChar;
    
        if (strLen > 1) {
        	firstStr = str.substring(0, strLen-1);     

          if(lastNum >=  48 && lastNum <= 57){
    
        	  returnNumber = Long.parseLong(str);
          }else if(lastNum == 123){    
        	  firstStr += Character.toString('0');    
                returnNumber = Long.parseLong(firstStr);
          }else if(lastNum == 125) {
        	  firstStr += Character.toString('0');
                returnNumber = -1 * Long.parseLong(firstStr);              
          }else if(lastNum >= 65 && lastNum <= 73){

        	  lastNum = lastNum - 16;
                char newChar = (char)lastNum;
                firstStr += Character.toString(newChar);
                returnNumber = Long.parseLong(firstStr);     
                
          }else if(lastNum >=  74 && lastNum <= 82){

        	  lastNum = lastNum - 25;
                char newChar = (char)lastNum;
                firstStr += Character.toString(newChar);
                returnNumber = -1 * Long.parseLong(firstStr);             

          }else{
              return 0L;
              }
          }
        return returnNumber;
        }
    }
   
   /**
    * Gets the decimal.
    *
    * @param i_str the i_str
    * @param precision the precision
    * @return the decimal
    */
   public static Double getDecimal(String str, int precision ){
          long inputStr = getDecimal(str);
          
          double divider = Math.pow(10, precision);
          return inputStr/divider;
   }
   
   /**
    * The main method.
    *
    * @param ar the arguments
    */

}
