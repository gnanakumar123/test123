package com.anthem.marketplace.dataconsolidation.utils;

/*
 * Class file for fieldNames  
 */

public class ProcessFieldNames {
	
	private String type;
	private String arrayFieldNames;

	public ProcessFieldNames(){
		super();
	}
	
	
	public ProcessFieldNames(String type){
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	
	public String getArrayFieldNames() {
		return arrayFieldNames;
	}

	public void setArrayFieldNames(String arrayFieldNames) {
		this.arrayFieldNames = arrayFieldNames;
	}
	
	
	@Override
	public String toString() {
		return "{type=" + this.type + ", isgArrayFieldNames=" + this.arrayFieldNames +"}";
	}


	

}