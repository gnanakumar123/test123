/**
 * 
 */
package com.sparkTutorial.sparkSql;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

/**
 * @author 238209
 *
 */
public class DynamicDatasetCreationExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Logger.getLogger("org").setLevel(Level.ERROR);
		SparkSession session = SparkSession.builder().appName("createDs").master("local[*]").getOrCreate();
		
		// Create an RDD
		JavaRDD<String> peopleRDD = session.sparkContext()
		  .textFile("in/people.txt", 1)
		  .toJavaRDD();
		
		// The schema is encoded in a string
		String schemaString = "name age";

		// Generate the schema based on the string of schema
		List<StructField> fields = new ArrayList<>();
		for (String fieldName : schemaString.split(" ")) {
		  StructField field = DataTypes.createStructField(fieldName, DataTypes.StringType, true);
		  fields.add(field);
		}
		StructType schema = DataTypes.createStructType(fields);
		
		// Create a RDD of Rows
		JavaRDD<Row> rowRDD = peopleRDD.map((Function<String, Row>) record -> {
			String[] recAttributes = record.split(" ");
			
			return RowFactory.create(recAttributes[0], recAttributes[1].trim());
		});
		
		// create dataframe
		Dataset<Row> peopleDF = session.createDataFrame(rowRDD, schema);
		peopleDF.show();
	}

}
