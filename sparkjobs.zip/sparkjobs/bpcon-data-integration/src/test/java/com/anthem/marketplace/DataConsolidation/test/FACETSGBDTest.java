/**
 * 
 */
package com.anthem.marketplace.DataConsolidation.test;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.lang.reflect.InvocationTargetException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.rdd.RDD;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.bson.BSONObject;
import org.bson.Document;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.filesutils.UtilityInterface;
import com.anthem.marketplace.dataconsolidation.filesutils.facets_GBD;
import com.anthem.marketplace.dataconsolidation.job.processor.IngestRDM;
import com.anthem.marketplace.dataconsolidation.utils.ChangeDataCapture;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.FixedFileMetaDataProperties;
import com.anthem.marketplace.dataconsolidation.utils.GetSysProperties;
import com.anthem.marketplace.dataconsolidation.utils.GuidProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.InputConnectors;
import com.anthem.marketplace.dataconsolidation.utils.InputProperties;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFixedFileMetaData;
import com.anthem.marketplace.dataconsolidation.utils.ProcessGuid;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXml;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SystemProperties;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.util.JSON;

import scala.Tuple2;
import scala.reflect.ClassTag;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "org.apache.hadoop.*", "javax.*", "com.sun.org.apache.*", "org.apache.log4j.*", "org.w3c.dom.*",
		"org.apache.xerces.*" })
@PrepareForTest({ facets_GBD.class, ReadMappingXmlSingleton.class, MongoConnector.class, FieldNamesProperties.class,
		FixedFileMetaDataProperties.class, ReadMappingXml.class, Utility.class, UtilityInterface.class,
		SparkContextSingleton.class })

public class FACETSGBDTest {

	@Mock
	ReadMappingXmlSingleton readMappingXmlSingletonMock;

	@Mock
	ReadMappingXml readMappingXmlMock;

	@Mock
	SparkContextSingleton sparkContextSingletonMock;

	@Mock
	JavaSparkContext javaSparkContextMock;

	@Mock
	JavaPairRDD javaPairRddMock;
	
	@Mock
	ChangeDataCapture changeDataCaptureMock;
	
	@Mock
	FieldNamesProperties fileNamesPropertiesMock;

	@Mock
	MongoConnector mongoConnectorMock;

	@Mock
	FixedFileMetaDataProperties fixedFileMetaDataPropertiesMock;

	@Mock
	GuidProperties guidPropertiesMock;

	@Mock
	GetSysProperties getSysPropertiesMock;

	@Mock
	InputConnectors inputConnectorsMock;

	@Mock
	InputProperties inputPropertiesMock;

	@Mock
	ProcessInput processInput;

	@Mock
	ProcessGuid processGuid;

	@Mock
	IngestRDM irdObj;

	@Mock
	UtilityInterface utilityInterface;

	@Mock
	SystemProperties systemProperties;

	@Mock
	BSONObject bsonObjectMock;

	@Mock
	Utility utilityMock;

	facets_GBD facets_GBD = (facets_GBD) Utility.createObject("com.anthem.marketplace.dataconsolidation.filesutils.facets_GBD");

	String sourceCollection = "FACETS GBD";

	String delimeted = " ";

	static final Logger logger = LoggerFactory.getLogger(IngestRDM.class);

	String jsonRaw = "{\r\n" + "    \"_id\" : ObjectId(\"5bd988629ec0071b146696c6\"),\r\n"
			+ "    \"GUID\" : \"000M55781000M557816/1/2018MINDSUBSCR\",\r\n" + "    \"SubId\" : \"000M55781\",\r\n"
			+ "    \"SubFirstName\" : \"Chris\",\r\n" + "    \"SubLastName\" : \"Dimitroff\",\r\n"
			+ "    \"Addr1\" : \"451 American Way North\",\r\n" + "    \"Addr2\" : \"Apt 2H\",\r\n"
			+ "    \"City\" : \"Carmel\",\r\n" + "    \"State\" : \"IN\",\r\n" + "    \"Zip\" : \"46032\",\r\n"
			+ "    \"SubPhone\" : \"317-748-1153\",\r\n" + "    \"SubDOB\" : \"1/27/1979\",\r\n"
			+ "    \"DepName1\" : \"\",\r\n" + "    \"DepName2\" : \"\",\r\n" + "    \"DepName3\" : \"\",\r\n"
			+ "    \"DepName4\" : \"\",\r\n" + "    \"CurrRate\" : 407.73,\r\n" + "    \"NewRate\" : 480.49,\r\n"
			+ "    \"Difference%\" : \"17.85%\",\r\n" + "    \"RatingLevel\" : 0.573,\r\n"
			+ "    \"PlanName\" : \"SmartSense 30%\",\r\n" + "    \"Deductible\" : \"1000\",\r\n"
			+ "    \"AgentName\" : \"EXACT INSURANCE INSURANCE GROUP INC\",\r\n"
			+ "    \"AgentNumber\" : \"INI719812\",\r\n"
			+ "    \"PlanEffDate\" : ISODate(\"2018-06-01T04:00:00.000Z\"),\r\n"
			+ "    \"AnnivMnth\" : ISODate(\"2018-06-01T04:00:00.000Z\"),\r\n" + "    \"ProductType\" : \"M\",\r\n"
			+ "    \"ProductString\" : \"INE000701000V200\",\r\n"
			+ "    \"start-date\" : \"2018-10-31 16:18:02.258\",\r\n"
			+ "    \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n"
			+ "    \"source-path\" : \"D:/372712/Employer Broker/FeedFile/apps/Renewals/GBD/RA_MEDICARE_ALL_IN_Annual_Triggers_November_20170915_1377.txt\",\r\n"
			+ "    \"source\" : \"FACETS GBD\",\r\n" + "    \"Version\" : \"V1\",\r\n"
			+ "    \"status\" : \"processed\",\r\n" + "    \"Data_Quality_Check\" : \"passed\"\r\n" + "}";

	Document convertDocument = (Document) Document.parse(jsonRaw);

	BSONObject bsonRawObject = (BSONObject) JSON.parse(convertDocument.toJson());

	String jsonTDMRenewal = "{\r\n" + "	    \"_id\" : ObjectId(\"5be949549ec00730101306df\"),\r\n"
			+ "	    \"GUID\" : \"000M55781000M557816/1/2019MINDSUBSCR\",\r\n" + "	    \"ID\" : \"000M55781\",\r\n"
			+ "	    \"renewalDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	    \"effectiveDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	    \"currentContractCode\" : \"INE000701000V200\",\r\n"
			+ "	    \"renewalContractCode\" : \"INE000701000V200\",\r\n" + "	    \"Delta\" : \"17.85%\",\r\n"
			+ "	    \"type\" : \"IND\",\r\n" + "	    \"relationship\" : \"SUBSCR\",\r\n"
			+ "	    \"renewalDependentsCovered\" : \"No\",\r\n" + "	    \"Benefits\" : [ \r\n" + "	        {\r\n"
			+ "	            \"effectiveDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	            \"renewalDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	            \"ratingTier\" : 0.573,\r\n" + "	            \"productType\" : \"M\",\r\n"
			+ "	            \"currentContractPlanCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"currentContractPlanName\" : \"SmartSense 30%\",\r\n"
			+ "	            \"currentMonthlyPremium\" : 500.73,\r\n"
			+ "	            \"currentTotalPremium\" : 500.73,\r\n"
			+ "	            \"renewalMonthlyPremium\" : 680.49,\r\n"
			+ "	            \"renewalTotalPremium\" : 680.49,\r\n"
			+ "	            \"renewalContractCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"renewalContractPlanCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"renewalContractPlanName\" : \"SmartSense 30%\",\r\n"
			+ "	            \"deductible\" : \"1000\",\r\n" + "	            \"renewalProducts\" : [ \r\n"
			+ "	                {\r\n" + "	                    \"productType\" : \"M\",\r\n"
			+ "	                    \"renewalContractCode\" : \"INE000701000V200\",\r\n"
			+ "	                    \"renewalContractPlanName\" : \"SmartSense 30%\"\r\n" + "	                }\r\n"
			+ "	            ]\r\n" + "	        }\r\n" + "	    ],\r\n" + "	    \"currentMonthlyPremium\" : 500.73,\r\n"
			+ "	    \"monthlyPremium\" : 680.49,\r\n" + "	    \"start-date\" : \"2018-11-12 15:05:16.397\",\r\n"
			+ "	    \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n"
			+ "	    \"source-path\" : \"D:/372712/Employer Broker/FeedFile/apps/Renewals/GBD/RA_MEDICARE_ALL_IN_Annual_Triggers_November_20170915_1377.txt\",\r\n"
			+ "	    \"source\" : \"FACETS GBD\",\r\n" + "	    \"Version\" : \"V1\",\r\n"
			+ "	    \"status\" : \"processed\",\r\n" + "	    \"Data_Quality_Check\" : \"passed\"\r\n" + "	}\r\n"
			+ "";

	Document conDocument = (Document) Document.parse(jsonTDMRenewal);

	BSONObject bsonTDMObject = (BSONObject) JSON.parse(conDocument.toJson());

	String jsonTDMBenefit = "{\r\n" + "	    \"_id\" : ObjectId(\"5be949549ec00730101306df\"),\r\n"
			+ "	    \"Benefits\" : [ \r\n" + "	        {\r\n"
			+ "	            \"effectiveDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	            \"renewalDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	            \"ratingTier\" : 0.573,\r\n" + "	            \"productType\" : \"M\",\r\n"
			+ "	            \"currentContractPlanCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"currentContractPlanName\" : \"SmartSense 30%\",\r\n"
			+ "	            \"currentMonthlyPremium\" : 500.73,\r\n"
			+ "	            \"currentTotalPremium\" : 500.73,\r\n"
			+ "	            \"renewalMonthlyPremium\" : 680.49,\r\n"
			+ "	            \"renewalTotalPremium\" : 680.49,\r\n"
			+ "	            \"renewalContractCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"renewalContractPlanCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"renewalContractPlanName\" : \"SmartSense 30%\",\r\n"
			+ "	            \"deductible\" : \"1000\",\r\n" + "	            \"renewalProducts\" : [ \r\n"
			+ "	                {\r\n" + "	                    \"productType\" : \"M\",\r\n"
			+ "	                    \"renewalContractCode\" : \"INE000701000V200\",\r\n"
			+ "	                    \"renewalContractPlanName\" : \"SmartSense 30%\"\r\n" + "	                }\r\n"
			+ "	            ]\r\n" + "	        }\r\n" + "	    ],\r\n" + "	    \"currentMonthlyPremium\" : 500.73,\r\n"
			+ "	    \"monthlyPremium\" : 680.49,\r\n" + "	    \"start-date\" : \"2018-11-12 15:05:16.397\",\r\n"
			+ "	    \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n"
			+ "	    \"source-path\" : \"D:/372712/Employer Broker/FeedFile/apps/Renewals/GBD/RA_MEDICARE_ALL_IN_Annual_Triggers_November_20170915_1377.txt\",\r\n"
			+ "	    \"source\" : \"FACETS GBD\",\r\n" + "	    \"Version\" : \"V1\",\r\n"
			+ "	    \"status\" : \"processed\",\r\n" + "	    \"Data_Quality_Check\" : \"passed\"\r\n" + "	}\r\n"
			+ "";

	Document benefitDocument = (Document) Document.parse(jsonTDMBenefit);

	BSONObject bsonTDMBenefitObject = (BSONObject) JSON.parse(benefitDocument.toJson());

	@Before
	public void setup() {

		/* ReadMappingXml Mock Singleton */

		PowerMockito.mockStatic(ReadMappingXmlSingleton.class);

		readMappingXmlSingletonMock = PowerMockito.mock(ReadMappingXmlSingleton.class);
		PowerMockito.when(ReadMappingXmlSingleton.getInstance()).thenReturn(readMappingXmlSingletonMock);

		readMappingXmlMock = PowerMockito.mock(ReadMappingXml.class);
		doReturn(readMappingXmlMock).when(readMappingXmlSingletonMock).getRead();

		/* SparkContextSingleton Mock Singleton */
		PowerMockito.mockStatic(SparkContextSingleton.class);

		sparkContextSingletonMock = PowerMockito.mock(SparkContextSingleton.class);
		PowerMockito.when(SparkContextSingleton.getInstance()).thenReturn(sparkContextSingletonMock);

		javaSparkContextMock = PowerMockito.mock(JavaSparkContext.class);
		doReturn(javaSparkContextMock).when(sparkContextSingletonMock).getSparkContext();

		/* MongoConnector Mock */
		PowerMockito.mockStatic(MongoConnector.class);
		mongoConnectorMock = PowerMockito.mock(MongoConnector.class);

		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);

		/* FieldNamesProperties Mock */
		PowerMockito.mockStatic(FieldNamesProperties.class);
		fileNamesPropertiesMock = PowerMockito.mock(FieldNamesProperties.class);

		PowerMockito.when(FieldNamesProperties.getInstance()).thenReturn(fileNamesPropertiesMock);

		/* FixedFileMetaDataProperties Mock */
		PowerMockito.mockStatic(FixedFileMetaDataProperties.class);
		fixedFileMetaDataPropertiesMock = PowerMockito.mock(FixedFileMetaDataProperties.class);
		PowerMockito.when(FixedFileMetaDataProperties.getInstance()).thenReturn(fixedFileMetaDataPropertiesMock);

		/* GuidProperties Mock */
		// PowerMockito.mockStatic(GuidProperties.class);
		guidPropertiesMock = PowerMockito.mock(GuidProperties.class);

		// PowerMockito.when(GuidProperties.getInstance()).thenReturn(guidPropertiesMock);

		/* GuidProperties Mock */
		// PowerMockito.mockStatic(GetSysProperties.class);
		getSysPropertiesMock = PowerMockito.mock(GetSysProperties.class);

		// PowerMockito.when(GetSysProperties.getInstance()).thenReturn(getSysPropertiesMock);

		/* InputConnectors Mock */
		// PowerMockito.mockStatic(InputConnectors.class);
		inputConnectorsMock = PowerMockito.mock(InputConnectors.class);

		// PowerMockito.when(InputConnectors.getInstance()).thenReturn(inputConnectorsMock);

		/* InputProperties Mock */
		// PowerMockito.mockStatic(InputProperties.class);
		inputPropertiesMock = PowerMockito.mock(InputProperties.class);

		// PowerMockito.when(InputProperties.getInstance()).thenReturn(inputPropertiesMock);

		/* Utility Mock */

		PowerMockito.mockStatic(Utility.class);
		utilityMock = PowerMockito.mock(Utility.class);

	}

	@Test
	public void createGuidFacetsGBDTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("1");
		processFixedFileMetaData.setend("9");
		processFixedFileMetaData.setType(null);
		
		ProcessFixedFileMetaData processFixedFileMetaData2 = new ProcessFixedFileMetaData();
		processFixedFileMetaData2.setstart("582");
		processFixedFileMetaData2.setend("591");
		processFixedFileMetaData2.setType(null);
		
		List<ProcessFixedFileMetaData> guidPosition = new ArrayList<>();
		guidPosition.add(processFixedFileMetaData);
		guidPosition.add(processFixedFileMetaData2);
		
		String sourceCollection = "Renewals_facets_GBD_Renewal";
		String delimeted = "true";
		Row readFileContent = RowFactory.create("130M55856 Joice           Johnston                            203 E Taylor St                                                                   Sims                IN 46986       7654532052           GRANT                F 60                                            203 E Taylor St                                                                   Sims                IN 46986       INSUPWP0          2000.8400          3069.8400 IN Plan A 92 Std.5 Year Band 11/01 Comm/Dis-MADIA                      House Account Invalid Broker                                 INIAAA344788    770470789E 770470789E M 20171101 M N              1 ");
		String guidvalue = "hcid,AgentTIN";
		String type = "facets_GBD";

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("hcid", type);
		doReturn(processFixedFileMetaData2).when(fixedFileMetaDataPropertiesMock).getPropertyContext("AgentTIN", type);
		
		String actual = facets_GBD.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);

		Assert.assertEquals("130M55856770470789EMEDSUBSCR", actual);
	}
	

	@SuppressWarnings("unchecked")
	@Test // (expected=NullPointerException.class)
	public void createGuidNullPointerExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("1");
		processFixedFileMetaData.setend("9");
		processFixedFileMetaData.setType(null);
		
		ProcessFixedFileMetaData processFixedFileMetaData2 = new ProcessFixedFileMetaData();
		processFixedFileMetaData2.setstart("582");
		processFixedFileMetaData2.setend("591");
		processFixedFileMetaData2.setType(null);
		
		List<ProcessFixedFileMetaData> guidPosition = new ArrayList<>();
		guidPosition.add(processFixedFileMetaData);
		guidPosition.add(processFixedFileMetaData2);
		
		String sourceCollection = "Renewals_facets_GBD_Renewal";
		String delimeted = "true";
		Row readFileContent = RowFactory.create("130M55856 Joice           Johnston                            203 E Taylor St                                                                   Sims                IN 46986       7654532052           GRANT                F 60                                            203 E Taylor St                                                                   Sims                IN 46986       INSUPWP0          2000.8400          3069.8400 IN Plan A 92 Std.5 Year Band 11/01 Comm/Dis-MADIA                      House Account Invalid Broker                                 INIAAA344788    770470789E 770470789E M 20171101 M N              1 ");
		String guidvalue = "hcid,AgentTIN";
		String type = "facets_GBD";

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("hcid", type);
		when(fixedFileMetaDataPropertiesMock.getPropertyContext("AgentTIN", type)).thenThrow(NullPointerException.class);
		
		facets_GBD.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}

	@SuppressWarnings("unchecked")
	@Test // (expected=ArrayIndexOutOfBoundsException.class)
	public void createGuidArrayIndexOutOfBoundsExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {


		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("1");
		processFixedFileMetaData.setend("9");
		processFixedFileMetaData.setType(null);
		
		ProcessFixedFileMetaData processFixedFileMetaData2 = new ProcessFixedFileMetaData();
		processFixedFileMetaData2.setstart("582");
		processFixedFileMetaData2.setend("591");
		processFixedFileMetaData2.setType(null);
		
		List<ProcessFixedFileMetaData> guidPosition = new ArrayList<>();
		guidPosition.add(processFixedFileMetaData);
		guidPosition.add(processFixedFileMetaData2);
		
		String sourceCollection = "Renewals_facets_GBD_Renewal";
		String delimeted = "true";
		Row readFileContent = RowFactory.create("130M55856 Joice           Johnston                            203 E Taylor St                                                                   Sims                IN 46986       7654532052           GRANT                F 60                                            203 E Taylor St                                                                   Sims                IN 46986       INSUPWP0          2000.8400          3069.8400 IN Plan A 92 Std.5 Year Band 11/01 Comm/Dis-MADIA                      House Account Invalid Broker                                 INIAAA344788    770470789E 770470789E M 20171101 M N              1 ");
		String guidvalue = "hcid,AgentTIN";
		String type = "facets_GBD";

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("hcid", type);
		when(fixedFileMetaDataPropertiesMock.getPropertyContext("AgentTIN", type)).thenThrow(ArrayIndexOutOfBoundsException.class);
		
		facets_GBD.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);

	}

	@SuppressWarnings("unchecked")
	@Test // (expected=ClassCastException.class)
	public void createGuidClassCastExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("1");
		processFixedFileMetaData.setend("9");
		processFixedFileMetaData.setType(null);
		
		ProcessFixedFileMetaData processFixedFileMetaData2 = new ProcessFixedFileMetaData();
		processFixedFileMetaData2.setstart("582");
		processFixedFileMetaData2.setend("591");
		processFixedFileMetaData2.setType(null);
		
		List<ProcessFixedFileMetaData> guidPosition = new ArrayList<>();
		guidPosition.add(processFixedFileMetaData);
		guidPosition.add(processFixedFileMetaData2);
		
		String sourceCollection = "Renewals_facets_GBD_Renewal";
		String delimeted = "true";
		Row readFileContent = RowFactory.create("130M55856 Joice           Johnston                            203 E Taylor St                                                                   Sims                IN 46986       7654532052           GRANT                F 60                                            203 E Taylor St                                                                   Sims                IN 46986       INSUPWP0          2000.8400          3069.8400 IN Plan A 92 Std.5 Year Band 11/01 Comm/Dis-MADIA                      House Account Invalid Broker                                 INIAAA344788    770470789E 770470789E M 20171101 M N              1 ");
		String guidvalue = "hcid,AgentTIN";
		String type = "facets_GBD";

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("hcid", type);
		when(fixedFileMetaDataPropertiesMock.getPropertyContext("AgentTIN", type)).thenThrow(ClassCastException.class);
		
		facets_GBD.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);

	}

	@SuppressWarnings("unchecked")
	@Test // (expected=NumberFormatException.class)
	public void createGuidNumberFormatExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("1");
		processFixedFileMetaData.setend("9");
		processFixedFileMetaData.setType(null);
		
		ProcessFixedFileMetaData processFixedFileMetaData2 = new ProcessFixedFileMetaData();
		processFixedFileMetaData2.setstart("582");
		processFixedFileMetaData2.setend("591");
		processFixedFileMetaData2.setType(null);
		
		List<ProcessFixedFileMetaData> guidPosition = new ArrayList<>();
		guidPosition.add(processFixedFileMetaData);
		guidPosition.add(processFixedFileMetaData2);
		
		String sourceCollection = "Renewals_facets_GBD_Renewal";
		String delimeted = "true";
		Row readFileContent = RowFactory.create("130M55856 Joice           Johnston                            203 E Taylor St                                                                   Sims                IN 46986       7654532052           GRANT                F 60                                            203 E Taylor St                                                                   Sims                IN 46986       INSUPWP0          2000.8400          3069.8400 IN Plan A 92 Std.5 Year Band 11/01 Comm/Dis-MADIA                      House Account Invalid Broker                                 INIAAA344788    770470789E 770470789E M 20171101 M N              1 ");
		String guidvalue = "hcid,AgentTIN";
		String type = "facets_GBD";

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("hcid", type);
		when(fixedFileMetaDataPropertiesMock.getPropertyContext("AgentTIN", type)).thenThrow(NumberFormatException.class);
		
		facets_GBD.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}

	@SuppressWarnings("unchecked")
	@Test // (expected=Exception.class)
	public void createGuidExceptionTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("1");
		processFixedFileMetaData.setend("9");
		processFixedFileMetaData.setType(null);
		
		ProcessFixedFileMetaData processFixedFileMetaData2 = new ProcessFixedFileMetaData();
		processFixedFileMetaData2.setstart("582");
		processFixedFileMetaData2.setend("591");
		processFixedFileMetaData2.setType(null);
		
		List<ProcessFixedFileMetaData> guidPosition = new ArrayList<>();
		guidPosition.add(processFixedFileMetaData);
		guidPosition.add(processFixedFileMetaData2);
		
		String sourceCollection = "Renewals_facets_GBD_Renewal";
		String delimeted = "true";
		Row readFileContent = RowFactory.create("130M55856 Joice           Johnston                            203 E Taylor St                                                                   Sims                IN 46986       7654532052           GRANT                F 60                                            203 E Taylor St                                                                   Sims                IN 46986       INSUPWP0          2000.8400          3069.8400 IN Plan A 92 Std.5 Year Band 11/01 Comm/Dis-MADIA                      House Account Invalid Broker                                 INIAAA344788    770470789E 770470789E M 20171101 M N              1 ");
		String guidvalue = "hcid,AgentTIN";
		String type = "facets_GBD";

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("hcid", type);
		when(fixedFileMetaDataPropertiesMock.getPropertyContext("AgentTIN", type)).thenThrow(Exception.class);
		
		facets_GBD.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
		
	}

	@Test
	public void createFlagTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String delimeted = "true";
		String sourceCollection = "Renewals_facets_GBD_Renewal";
		Row readFileContent = RowFactory.create("734M65193 Barbaric        Batterson                           PO Box 464                                                                        Monroe              IA 50170       5747733384           JASPER               F 72                                            PO Box 464                                                                        Monroe              IA 50170       INSUPWP0           200.5200           315.6700 IN Select Plan F 92 Std.1 Year Band 11/01 Att/Non Dis-MLSIF                                                                         22449GA00                  770470789E M 20171101 M N              1");
		String type = "facets_GBD";
		
		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("165");
		processFixedFileMetaData.setend("166");
		processFixedFileMetaData.setType(null);
		
		Map<String, String> mandatoryFields = new HashMap<String, String>();
		mandatoryFields.put("7", "state");
	
		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("state", type);
		
		boolean actual = facets_GBD.createFlag(delimeted, sourceCollection, readFileContent, type);

		Assert.assertEquals(false, actual);

	}

	@Test
	public void createFlagcreateErrorCodeDescriptionTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {


		String delimeted = "true";
		String sourceCollection = "Renewals_facets_GBD_Renewal";
		Row readFileContent = RowFactory.create("734M65193 Barbaric        Batterson                           PO Box 464                                                                        Monroe                 50170       5747733384           JASPER               F 72                                            PO Box 464                                                                        Monroe              IA 50170       INSUPWP0           200.5200           315.6700 IN Select Plan F 92 Std.1 Year Band 11/01 Att/Non Dis-MLSIF                                                                         22449GA00                  770470789E M 20171101 M N              1");
		String type = "facets_GBD";
		
		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("165");
		processFixedFileMetaData.setend("166");
		processFixedFileMetaData.setType(null);
		
		Map<String, String> mandatoryFields = new HashMap<String, String>();
		mandatoryFields.put("7", "state");
	
		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("state", type);
		
		boolean actual = facets_GBD.createFlag(delimeted, sourceCollection, readFileContent, type);

		Assert.assertEquals(true, actual);

	}


	@SuppressWarnings("unchecked")
	@Test
	public void createFlagNullPointerExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String delimeted = "true";
		String sourceCollection = "Renewals_facets_GBD_Renewal";
		Row readFileContent = RowFactory.create("734M65193 Barbaric        Batterson                           PO Box 464                                                                        Monroe              IA 50170       5747733384           JASPER               F 72                                            PO Box 464                                                                        Monroe              IA 50170       INSUPWP0           200.5200           315.6700 IN Select Plan F 92 Std.1 Year Band 11/01 Att/Non Dis-MLSIF                                                                         22449GA00                  770470789E M 20171101 M N              1");
		String type = "facets_GBD";
		
		Map<String, String> mandatoryFields = new HashMap<String, String>();
		mandatoryFields.put("7", "State");
	
		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);

		when(fixedFileMetaDataPropertiesMock.getPropertyContext("State", type)).thenThrow(NullPointerException.class);
		
		boolean actual = facets_GBD.createFlag(delimeted, sourceCollection, readFileContent, type);

		Assert.assertEquals(false, actual);

	}

	@Test
	public void createFlagArrayIndexOutOfBoundsExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String delimeted = "true";
		String sourceCollection = "Renewals_facets_GBD_Renewal";
		Row readFileContent = RowFactory.create("734M65193 Barbaric        Batterson                           PO Box 464                                                                        Monroe              IA 50170       5747733384           JASPER               F 72                                            PO Box 464                                                                        Monroe              IA 50170       INSUPWP0           200.5200           315.6700 IN Select Plan F 92 Std.1 Year Band 11/01 Att/Non Dis-MLSIF                                                                         22449GA00                  770470789E M 20171101 M N              1");
		String type = "facets_GBD";
		
		Map<String, String> mandatoryFields = new HashMap<String, String>();
		mandatoryFields.put("7", "State");
	
		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);

		when(fixedFileMetaDataPropertiesMock.getPropertyContext("State", type)).thenThrow(ArrayIndexOutOfBoundsException.class);
		
		boolean actual = facets_GBD.createFlag(delimeted, sourceCollection, readFileContent, type);

		Assert.assertEquals(false, actual);

	}

	@Test
	public void createFlagClassCastExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String delimeted = "true";
		String sourceCollection = "Renewals_facets_GBD_Renewal";
		Row readFileContent = RowFactory.create("734M65193 Barbaric        Batterson                           PO Box 464                                                                        Monroe              IA 50170       5747733384           JASPER               F 72                                            PO Box 464                                                                        Monroe              IA 50170       INSUPWP0           200.5200           315.6700 IN Select Plan F 92 Std.1 Year Band 11/01 Att/Non Dis-MLSIF                                                                         22449GA00                  770470789E M 20171101 M N              1");
		String type = "facets_GBD";
		
		Map<String, String> mandatoryFields = new HashMap<String, String>();
		mandatoryFields.put("7", "State");
	
		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);

		when(fixedFileMetaDataPropertiesMock.getPropertyContext("State", type)).thenThrow(ClassCastException.class);
		
		boolean actual = facets_GBD.createFlag(delimeted, sourceCollection, readFileContent, type);

		Assert.assertEquals(false, actual);

	}

	@Test
	public void createFlagNumberFormatExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String delimeted = "true";
		String sourceCollection = "Renewals_facets_GBD_Renewal";
		Row readFileContent = RowFactory.create("734M65193 Barbaric        Batterson                           PO Box 464                                                                        Monroe              IA 50170       5747733384           JASPER               F 72                                            PO Box 464                                                                        Monroe              IA 50170       INSUPWP0           200.5200           315.6700 IN Select Plan F 92 Std.1 Year Band 11/01 Att/Non Dis-MLSIF                                                                         22449GA00                  770470789E M 20171101 M N              1");
		String type = "facets_GBD";
		
		Map<String, String> mandatoryFields = new HashMap<String, String>();
		mandatoryFields.put("7", "State");
	
		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);

		when(fixedFileMetaDataPropertiesMock.getPropertyContext("State", type)).thenThrow(NumberFormatException.class);
		
		boolean actual = facets_GBD.createFlag(delimeted, sourceCollection, readFileContent, type);

		Assert.assertEquals(false, actual);
	}

	@Test
	public void createFlagExceptionExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String delimeted = "true";
		String sourceCollection = "Renewals_facets_GBD_Renewal";
		Row readFileContent = RowFactory.create("734M65193 Barbaric        Batterson                           PO Box 464                                                                        Monroe              IA 50170       5747733384           JASPER               F 72                                            PO Box 464                                                                        Monroe              IA 50170       INSUPWP0           200.5200           315.6700 IN Select Plan F 92 Std.1 Year Band 11/01 Att/Non Dis-MLSIF                                                                         22449GA00                  770470789E M 20171101 M N              1");
		String type = "facets_GBD";
		
		Map<String, String> mandatoryFields = new HashMap<String, String>();
		mandatoryFields.put("7", "State");
	
		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);

		when(fixedFileMetaDataPropertiesMock.getPropertyContext("State", type)).thenThrow(Exception.class);
		
		boolean actual = facets_GBD.createFlag(delimeted, sourceCollection, readFileContent, type);

		Assert.assertEquals(false, actual);

	}

	@Test
	public void appendRawNullPointerExceptionTest()
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, ParseException {

		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/GBD/RA_MEDICARE_ALL_IN_Annual_Triggers_November_20170915_1377records_update.txt";

		String guid = "130M55856770470789EMEDSUBSCR";
		boolean flag = false;
		Row readFileContent = RowFactory.create("130M55856 Joice           Johnston                            203 E Taylor St                                                                   Sims                IN 46986       7654532052           GRANT                F 60                                            203 E Taylor St                                                                   Sims                IN 46986       INSUPWP0          2000.8400          3069.8400 IN Plan A 92 Std.5 Year Band 11/01 Comm/Dis-MADIA                      House Account Invalid Broker                                 INIAAA344788    770470789E 770470789E M 20171101 M N              1");
		
		ProcessInput processInput = new ProcessInput();
		processInput.setType("facets_GBD");
		processInput.setSourceDB("bpconadsDB");
		processInput.setSourceCollection("Renewals_facets_GBD_Renewal");
		
		String type = "facets_GBD";
		//String sourceDB = processInput.getSourceDB();
		//String sourceCollection = processInput.getSourceCollection();

		ProcessFieldNames procFieldNames = new ProcessFieldNames();

		procFieldNames.setArrayFieldNames(
				"hcid,firstName,lastName,Address1,Address2,city,state,zipCode,phone,country,gender,age,email,mailing_Address1,mailing_Address2,mailing_city,mailing_state,mailing_zip,renewal_group,currentRate,newRate,planName,AgentName,AgentNumber,AgentTIN,AgencyTIN,BillingMode,Rate_RenewalDate,RecordType,HIPAA_Agreement,LastColInd");

		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);

		when(readMappingXmlMock.getAttributeValueOfField(type, "hcid", IConstants.DATATYPE)).thenThrow(NullPointerException.class);

		facets_GBD.appendRaw(processInput, sourcePath, guid, flag, readFileContent);

	}

	@Test
	public void appendRawArrayIndexOutOfBoundsExceptionTest()
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, ParseException {

		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/GBD/RA_MEDICARE_ALL_IN_Annual_Triggers_November_20170915_1377records_update.txt";

		String guid = "130M55856770470789EMEDSUBSCR";
		boolean flag = false;
		Row readFileContent = RowFactory.create("130M55856 Joice           Johnston                            203 E Taylor St                                                                   Sims                IN 46986       7654532052           GRANT                F 60                                            203 E Taylor St                                                                   Sims                IN 46986       INSUPWP0          2000.8400          3069.8400 IN Plan A 92 Std.5 Year Band 11/01 Comm/Dis-MADIA                      House Account Invalid Broker                                 INIAAA344788    770470789E 770470789E M 20171101 M N              1");
		
		ProcessInput processInput = new ProcessInput();
		processInput.setType("facets_GBD");
		processInput.setSourceDB("bpconadsDB");
		processInput.setSourceCollection("Renewals_facets_GBD_Renewal");
		
		String type = "facets_GBD";

		ProcessFieldNames procFieldNames = new ProcessFieldNames();

		procFieldNames.setArrayFieldNames(
				"hcid,firstName,lastName,Address1,Address2,city,state,zipCode,phone,country,gender,age,email,mailing_Address1,mailing_Address2,mailing_city,mailing_state,mailing_zip,renewal_group,currentRate,newRate,planName,AgentName,AgentNumber,AgentTIN,AgencyTIN,BillingMode,Rate_RenewalDate,RecordType,HIPAA_Agreement,LastColInd");

		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);

		when(readMappingXmlMock.getAttributeValueOfField(type, "hcid", IConstants.DATATYPE)).thenThrow(ArrayIndexOutOfBoundsException.class);

		facets_GBD.appendRaw(processInput, sourcePath, guid, flag, readFileContent);

	}

	@Test
	public void appendRawClassCastExceptionTest()
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, ParseException {

		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/GBD/RA_MEDICARE_ALL_IN_Annual_Triggers_November_20170915_1377records_update.txt";

		String guid = "130M55856770470789EMEDSUBSCR";
		boolean flag = false;
		Row readFileContent = RowFactory.create("130M55856 Joice           Johnston                            203 E Taylor St                                                                   Sims                IN 46986       7654532052           GRANT                F 60                                            203 E Taylor St                                                                   Sims                IN 46986       INSUPWP0          2000.8400          3069.8400 IN Plan A 92 Std.5 Year Band 11/01 Comm/Dis-MADIA                      House Account Invalid Broker                                 INIAAA344788    770470789E 770470789E M 20171101 M N              1");
		
		ProcessInput processInput = new ProcessInput();
		processInput.setType("facets_GBD");
		processInput.setSourceDB("bpconadsDB");
		processInput.setSourceCollection("Renewals_facets_GBD_Renewal");
		
		String type = "facets_GBD";

		ProcessFieldNames procFieldNames = new ProcessFieldNames();

		procFieldNames.setArrayFieldNames(
				"hcid,firstName,lastName,Address1,Address2,city,state,zipCode,phone,country,gender,age,email,mailing_Address1,mailing_Address2,mailing_city,mailing_state,mailing_zip,renewal_group,currentRate,newRate,planName,AgentName,AgentNumber,AgentTIN,AgencyTIN,BillingMode,Rate_RenewalDate,RecordType,HIPAA_Agreement,LastColInd");

		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);

		when(readMappingXmlMock.getAttributeValueOfField(type, "hcid", IConstants.DATATYPE)).thenThrow(ClassCastException.class);

		facets_GBD.appendRaw(processInput, sourcePath, guid, flag, readFileContent);

	}

	@Test
	public void appendRawNumberFormatExceptionTest()
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, ParseException {

		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/GBD/RA_MEDICARE_ALL_IN_Annual_Triggers_November_20170915_1377records_update.txt";

		String guid = "130M55856770470789EMEDSUBSCR";
		boolean flag = false;
		Row readFileContent = RowFactory.create("130M55856 Joice           Johnston                            203 E Taylor St                                                                   Sims                IN 46986       7654532052           GRANT                F 60                                            203 E Taylor St                                                                   Sims                IN 46986       INSUPWP0          2000.8400          3069.8400 IN Plan A 92 Std.5 Year Band 11/01 Comm/Dis-MADIA                      House Account Invalid Broker                                 INIAAA344788    770470789E 770470789E M 20171101 M N              1");
		
		ProcessInput processInput = new ProcessInput();
		processInput.setType("facets_GBD");
		processInput.setSourceDB("bpconadsDB");
		processInput.setSourceCollection("Renewals_facets_GBD_Renewal");
		
		String type = "facets_GBD";

		ProcessFieldNames procFieldNames = new ProcessFieldNames();

		procFieldNames.setArrayFieldNames(
				"hcid,firstName,lastName,Address1,Address2,city,state,zipCode,phone,country,gender,age,email,mailing_Address1,mailing_Address2,mailing_city,mailing_state,mailing_zip,renewal_group,currentRate,newRate,planName,AgentName,AgentNumber,AgentTIN,AgencyTIN,BillingMode,Rate_RenewalDate,RecordType,HIPAA_Agreement,LastColInd");

		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);

		when(readMappingXmlMock.getAttributeValueOfField(type, "hcid", IConstants.DATATYPE)).thenThrow(NumberFormatException.class);

		facets_GBD.appendRaw(processInput, sourcePath, guid, flag, readFileContent);

	}

	@Test
	public void appendRawExceptionExceptionTest()
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, ParseException {

		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/GBD/RA_MEDICARE_ALL_IN_Annual_Triggers_November_20170915_1377records_update.txt";

		String guid = "130M55856770470789EMEDSUBSCR";
		boolean flag = false;
		Row readFileContent = RowFactory.create("130M55856 Joice           Johnston                            203 E Taylor St                                                                   Sims                IN 46986       7654532052           GRANT                F 60                                            203 E Taylor St                                                                   Sims                IN 46986       INSUPWP0          2000.8400          3069.8400 IN Plan A 92 Std.5 Year Band 11/01 Comm/Dis-MADIA                      House Account Invalid Broker                                 INIAAA344788    770470789E 770470789E M 20171101 M N              1");
		
		ProcessInput processInput = new ProcessInput();
		processInput.setType("facets_GBD");
		processInput.setSourceDB("bpconadsDB");
		processInput.setSourceCollection("Renewals_facets_GBD_Renewal");
		
		String type = "facets_GBD";

		ProcessFieldNames procFieldNames = new ProcessFieldNames();

		procFieldNames.setArrayFieldNames(
				"hcid,firstName,lastName,Address1,Address2,city,state,zipCode,phone,country,gender,age,email,mailing_Address1,mailing_Address2,mailing_city,mailing_state,mailing_zip,renewal_group,currentRate,newRate,planName,AgentName,AgentNumber,AgentTIN,AgencyTIN,BillingMode,Rate_RenewalDate,RecordType,HIPAA_Agreement,LastColInd");

		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);

		when(readMappingXmlMock.getAttributeValueOfField(type, "hcid", IConstants.DATATYPE)).thenThrow(Exception.class);

		facets_GBD.appendRaw(processInput, sourcePath, guid, flag, readFileContent);

	}

	@Test
	public void appendRawTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException, ParseException {

		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/GBD/RA_MEDICARE_ALL_IN_Annual_Triggers_November_20170915_1377records_update.txt";

		String guid = "130M55856770470789EMEDSUBSCR";
		boolean flag = false;
		Row readFileContent = RowFactory.create("130M55856 Joice           Johnston                            203 E Taylor St                                                                   Sims                IN 46986       7654532052           GRANT                F 60                                            203 E Taylor St                                                                   Sims                IN 46986       INSUPWP0          2000.8400          3069.8400 IN Plan A 92 Std.5 Year Band 11/01 Comm/Dis-MADIA                      House Account Invalid Broker                                 INIAAA344788    770470789E 770470789E M 20171101 M N              1");
		
		ProcessInput processInput = new ProcessInput();
		processInput.setType("facets_GBD");
		processInput.setSourceDB("bpconadsDB");
		processInput.setSourceCollection("Renewals_facets_GBD_Renewal");
		
		String type = "facets_GBD";

		ProcessFieldNames procFieldNames = new ProcessFieldNames();

		procFieldNames.setArrayFieldNames(
				"hcid,firstName,lastName,Address1,Address2,city,state,zipCode,phone,country,gender,age,email,mailing_Address1,mailing_Address2,mailing_city,mailing_state,mailing_zip,renewal_group,currentRate,newRate,planName,AgentName,AgentNumber,AgentTIN,AgencyTIN,BillingMode,Rate_RenewalDate,RecordType,HIPAA_Agreement,LastColInd");

		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);
		
		String dataType = "String";
		String dataTypeDate = "Date MM/DD/YYYY";
		String dataTypedouble ="Double";
		String indexarray[] = {"1,11","27","63","104","145","165","168","180","201","222","224","229","270","311","352","372","375","387","396","415","434","505","566","582","593","604","606","615","617","619"};
		String fieldNames[] = {"hcid","firstName","lastName","Address1","Address2","city","state","zipCode","phone","country","gender","age","email","mailing_Address1","mailing_Address2","mailing_city","mailing_state","mailing_zip","renewal_group","currentRate","newRate","planName","AgentName","AgentNumber","AgentTIN","AgencyTIN","BillingMode","Rate_RenewalDate","RecordType","HIPAA_Agreement","LastColInd"};
		
		for (int i = 0; i < indexarray.length; i++) {
			
			doReturn(indexarray[i]).when(readMappingXmlMock).getIndex(type, fieldNames[i]);

			if (fieldNames[i].equalsIgnoreCase("Rate_RenewalDate")) {
				doReturn(dataTypeDate).when(readMappingXmlMock).getAttributeValueOfField(type, fieldNames[i],IConstants.DATATYPE);
			}else if(fieldNames[i].equalsIgnoreCase("currentRate") || fieldNames[i].equalsIgnoreCase("newRate"))
			{
				doReturn(dataTypedouble).when(readMappingXmlMock).getAttributeValueOfField(type, fieldNames[i],IConstants.DATATYPE);
			} 
			else {
				doReturn(dataType).when(readMappingXmlMock).getAttributeValueOfField(type, fieldNames[i],IConstants.DATATYPE);
			}

		}

		PowerMockito.doAnswer(new Answer<Void>() {
			@Override
			public Void answer(InvocationOnMock invocation) throws ParseException {
				Document doc = (Document) invocation.getArguments()[3];

				String datatype = (String) invocation.getArguments()[4];
				String fieldName = (String) invocation.getArguments()[1];
				String value = (String) invocation.getArguments()[2];

				if (datatype.equalsIgnoreCase("Date MM/DD/YYYY")) {
					DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
					formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
					Date date = formatter.parse(value);
					doc.append(fieldName, date);
				} else if (datatype.equalsIgnoreCase("Double")) {

					if (value.equals(null) || value.trim().equals("") || value.equalsIgnoreCase("null")
							|| value.trim().isEmpty()) {
						doc.append(fieldName, null);
					} else {

						value = value.replaceAll(IConstants.COMMA, "").replaceAll("\\$", "");

						if (value.indexOf('-') == value.length() - 1)
							value = '-' + value.substring(0, value.length() - 1);
						doc.append(fieldName, Double.parseDouble(value));
					}
				} else {
					doc.append((String) invocation.getArguments()[1], value);
				}
				return null;
			}
		}).when(Utility.class);

		utilityMock.applyZone(any(String.class), any(String.class), any(String.class), any(Document.class),	any(String.class), any(Row.class), any(String.class));

		facets_GBD.appendRaw(processInput, sourcePath, guid, flag, readFileContent);

	}

	@Test(expected = NullPointerException.class)
	public void facets_GBD_Renewals_IngestTDMProcessTest() throws Exception {

		BSONObject bsonObjectMock = bsonRawObject;

		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);

		String appendCollection = "renewals,contacts,agents";

		ProcessFieldNames Renewals_FACETS_GBDRenewals_tdm_Client = new ProcessFieldNames();
		Renewals_FACETS_GBDRenewals_tdm_Client.setArrayFieldNames(
				"GUID,ID,firstName,lastName,addressLine1,addressLine2,cityName.stateCode,postalCode,phoneNumber,county,facets_groupID,renewalDate");

		doReturn(Renewals_FACETS_GBDRenewals_tdm_Client).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.GBD_FACETS.concat("Renewals_tdm_Client").toString());

		ProcessFieldNames Renewals_FACETS_GBDRenewals_tdm_Renewal = new ProcessFieldNames();
		Renewals_FACETS_GBDRenewals_tdm_Renewal.setArrayFieldNames(
				"GUID,ID,facets_groupID,currentMonthlyPremium,monthlyPremium,currentContractPlanName,renewalContactPlanName,renewalDate,type");

		doReturn(Renewals_FACETS_GBDRenewals_tdm_Renewal).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.GBD_FACETS.concat("Renewals_tdm_Renewal").toString());

		ProcessFieldNames FACETS_ANTHEMBenefits = new ProcessFieldNames();
		FACETS_ANTHEMBenefits.setArrayFieldNames(
				"effectiveDate,renewalDate,ratingTier,productType,enrollmentType,currentContractPlanCode,currentContractPlanName,currentMonthlyPremium,currentTotalPremium,currentSubsidy,currentPremiumwithoutSubsidy,currentMemberSalary,currentMemberVolume,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee,renewalMonthlyPremium,renewalTotalPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanCode,renewalContractPlanName,renewalACAInsuranceFee,renewalACAReInsuranceFee,renewalACAExchangeFee,estimatedRenewalPremium,memberLDClassID,parentTIN,payeeTIN,writingTIN,deductible,saleChannelId,currentRatingMethod,renewalRatingMethod,bundling,medLock,rateGuaranteeEndDate,targetRateGuaranteeMonths,enforceProdId1RateGuaranteeMonths,isPNCCurrProduct1,isPNCTarProduct1,rateAdjustFactor");

		doReturn(FACETS_ANTHEMBenefits).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.FACETS_ANTHEM_REN_DET);

		String FeildTokens[] = { "GUID", "ID", "type", "relationship" };

		String bsonfeildName[] = { "GUID", "SubId", "Type", "relationship" };

		for (int i = 0; i < FeildTokens.length; i++) {
			doReturn(bsonfeildName[i]).when(readMappingXmlMock).getAttributeValueOfField(
					IConstants.GBD_FACETS.concat("Renewals_tdm_Client"), FeildTokens[i], IConstants.VALUE);
		}

		
		FACETS_ANTHEMBenefits.setArrayFieldNames(
				"effectiveDate,renewalDate,ratingTier,productType,enrollmentType,currentContractPlanCode,currentContractPlanName,currentMonthlyPremium,currentTotalPremium,currentSubsidy,currentPremiumwithoutSubsidy,currentMemberSalary,currentMemberVolume,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee,renewalMonthlyPremium,renewalTotalPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanCode,renewalContractPlanName,renewalACAInsuranceFee,renewalACAReInsuranceFee,renewalACAExchangeFee,estimatedRenewalPremium,memberLDClassID,parentTIN,payeeTIN,writingTIN,deductible,saleChannelId,currentRatingMethod,renewalRatingMethod,bundling,medLock,rateGuaranteeEndDate,targetRateGuaranteeMonths,enforceProdId1RateGuaranteeMonths,isPNCCurrProduct1,isPNCTarProduct1,rateAdjustFactor");

		doReturn(FACETS_ANTHEMBenefits).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM_REN_DET);

		
		String anthemBenefitFeildName[] = {"effectiveDate","renewalDate","ratingTier","productType","enrollmentType","currentContractPlanCode","currentContractPlanName","currentMonthlyPremium","currentTotalPremium","currentSubsidy","currentPremiumwithoutSubsidy","currentMemberSalary","currentMemberVolume","currentACAInsuranceFee","currentACAReInsuranceFee","currentACAExchangeFee","renewalMonthlyPremium","renewalTotalPremium","renewalSubsidy","renewalPremiumwithoutSubsidy","renewalContractCode","renewalContractPlanCode","renewalContractPlanName","renewalACAInsuranceFee","renewalACAReInsuranceFee","renewalACAExchangeFee","estimatedRenewalPremium","memberLDClassID","parentTIN","payeeTIN","writingTIN","deductible","saleChannelId","currentRatingMethod","renewalRatingMethod","bundling","medLock","rateGuaranteeEndDate","targetRateGuaranteeMonths","enforceProdId1RateGuaranteeMonths","isPNCCurrProduct1","isPNCTarProduct1","rateAdjustFactor"};
		String anthembsonfeildName[] = {"PlanEffDate","AnnivMnth","RatingLevel","ProductType","EnrollmentType","ProductString","PlanName" ,"CurrRate" ,"CurrRate" ,"CurrentSubsidy","CurrentPremiumwithoutSubsidy","CurrentMemberSalary","CurrentMemberVolume","CurrentACAInsuranceFee","CurrentACAReInsuranceFee","CurrentACAExchangeFee","NewRate","NewRate","RenewalSubsidy","RenewalPremiumwithoutSubsidy","ProductString","ProductString","PlanName","RenewalACAInsuranceFee","RenewalACAReInsuranceFee","RenewalACAExchangeFee","EstimatedRenewalPremium ","MemberLDClassID","ParentTIN ","PayeeTIN","WritingTIN","Deductible","SaleChannelId","CurrentRatingMethod","RenewalRatingMethod","Bundling","MedLock","RateGuaranteeEndDate ","TargetRateGuaranteeMonths","EnforceProdId1RateGuaranteeMonths","isPNCCurrProduct1","isPNCTarProduct1","RateAdjustFactor"};
		
		for (int i = 0; i < FeildTokens.length; i++) {
			doReturn(bsonfeildName[i]).when(readMappingXmlMock).getAttributeValueOfField(
					IConstants.FACETS_ANTHEM_REN_DET.concat("_modified"), anthemBenefitFeildName[i], IConstants.VALUE);
		}
		
		
		ProcessFieldNames ISG_RENEWALSrenewalProductsModified = new ProcessFieldNames();

		ISG_RENEWALSrenewalProductsModified.setArrayFieldNames(
				"productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");

		doReturn(ISG_RENEWALSrenewalProductsModified).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
		
		
		ProcessFieldNames FACETS_ANTHEMrenewals = new ProcessFieldNames();
		ProcessFieldNames FACETS_ANTHEMcontacts = new ProcessFieldNames();
		ProcessFieldNames FACETS_ANTHEMagents = new ProcessFieldNames();
		
		
		FACETS_ANTHEMrenewals.setArrayFieldNames("productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");
		FACETS_ANTHEMcontacts.setArrayFieldNames("addressType,addressLine1,addressLine2,addressLine3,countryCode,cityName,countyCode,countyName,stateCode,stateName,postalCode,phoneTypeCode,phoneAreaCode,phoneNumber,emailAddress");
		FACETS_ANTHEMagents.setArrayFieldNames("agentID,taxIDType,product,agentReference,name,AOREffectiveDate,AOREndDate");

		
		doReturn(FACETS_ANTHEMrenewals).when(fileNamesPropertiesMock).getPropertyContext(IConstants.GBD_FACETS.concat("renewals"));
		
		doReturn(FACETS_ANTHEMcontacts).when(fileNamesPropertiesMock).getPropertyContext(IConstants.GBD_FACETS.concat("contacts"));
		
		doReturn(FACETS_ANTHEMagents).when(fileNamesPropertiesMock).getPropertyContext(IConstants.GBD_FACETS.concat("agents"));
		

		utilityMock.applyZone(any(String.class), any(String.class), any(String.class), any(Document.class),
				any(String.class), any(Row.class), any(String.class));
		
		doReturn(true).when(changeDataCaptureMock).implementCdc(any(String.class), any(String.class), any(Document.class), any(List.class), any(List.class), any(String.class));
			
		facets_GBD.ingestTDMProcess("RDM", "Renewals_facets_GBD_Renewal", bsonFilterMock, "TDM", "Renewals_tdm_Renewal",
				appendCollection);

	}
	
	@Test 
	public void facets_GBD_Client_IngestTDMProcessTest() throws Exception {

		BSONObject bsonObjectMock = bsonRawObject;

		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);

		String appendCollection = "renewals,contacts,agents";

		ProcessFieldNames Renewals_FACETS_GBDRenewals_tdm_Client = new ProcessFieldNames();
		Renewals_FACETS_GBDRenewals_tdm_Client.setArrayFieldNames(
				"GUID,ID,firstName,lastName,addressLine1,addressLine2,cityName.stateCode,postalCode,phoneNumber,county,facets_groupID,renewalDate");

		doReturn(Renewals_FACETS_GBDRenewals_tdm_Client).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.GBD_FACETS.concat("Renewals_tdm_Client").toString());

		ProcessFieldNames Renewals_FACETS_GBDRenewals_tdm_Renewal = new ProcessFieldNames();
		Renewals_FACETS_GBDRenewals_tdm_Renewal.setArrayFieldNames(
				"GUID,ID,facets_groupID,currentMonthlyPremium,monthlyPremium,currentContractPlanName,renewalContactPlanName,renewalDate,type");

		doReturn(Renewals_FACETS_GBDRenewals_tdm_Renewal).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.GBD_FACETS.concat("Renewals_tdm_Renewal").toString());

		ProcessFieldNames FACETS_ANTHEMBenefits = new ProcessFieldNames();
		FACETS_ANTHEMBenefits.setArrayFieldNames(
				"effectiveDate,renewalDate,ratingTier,productType,enrollmentType,currentContractPlanCode,currentContractPlanName,currentMonthlyPremium,currentTotalPremium,currentSubsidy,currentPremiumwithoutSubsidy,currentMemberSalary,currentMemberVolume,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee,renewalMonthlyPremium,renewalTotalPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanCode,renewalContractPlanName,renewalACAInsuranceFee,renewalACAReInsuranceFee,renewalACAExchangeFee,estimatedRenewalPremium,memberLDClassID,parentTIN,payeeTIN,writingTIN,deductible,saleChannelId,currentRatingMethod,renewalRatingMethod,bundling,medLock,rateGuaranteeEndDate,targetRateGuaranteeMonths,enforceProdId1RateGuaranteeMonths,isPNCCurrProduct1,isPNCTarProduct1,rateAdjustFactor");

		doReturn(FACETS_ANTHEMBenefits).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.FACETS_ANTHEM_REN_DET);

		String FeildTokens[] = { "GUID", "ID", "type", "relationship" };

		String bsonfeildName[] = { "GUID", "SubId", "Type", "relationship" };

		for (int i = 0; i < FeildTokens.length; i++) {
			doReturn(bsonfeildName[i]).when(readMappingXmlMock).getAttributeValueOfField(
					IConstants.GBD_FACETS.concat("Renewals_tdm_Client"), FeildTokens[i], IConstants.VALUE);
		}

		
		FACETS_ANTHEMBenefits.setArrayFieldNames(
				"effectiveDate,renewalDate,ratingTier,productType,enrollmentType,currentContractPlanCode,currentContractPlanName,currentMonthlyPremium,currentTotalPremium,currentSubsidy,currentPremiumwithoutSubsidy,currentMemberSalary,currentMemberVolume,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee,renewalMonthlyPremium,renewalTotalPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanCode,renewalContractPlanName,renewalACAInsuranceFee,renewalACAReInsuranceFee,renewalACAExchangeFee,estimatedRenewalPremium,memberLDClassID,parentTIN,payeeTIN,writingTIN,deductible,saleChannelId,currentRatingMethod,renewalRatingMethod,bundling,medLock,rateGuaranteeEndDate,targetRateGuaranteeMonths,enforceProdId1RateGuaranteeMonths,isPNCCurrProduct1,isPNCTarProduct1,rateAdjustFactor");

		doReturn(FACETS_ANTHEMBenefits).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM_REN_DET);

		
		String anthemBenefitFeildName[] = {"effectiveDate","renewalDate","ratingTier","productType","enrollmentType","currentContractPlanCode","currentContractPlanName","currentMonthlyPremium","currentTotalPremium","currentSubsidy","currentPremiumwithoutSubsidy","currentMemberSalary","currentMemberVolume","currentACAInsuranceFee","currentACAReInsuranceFee","currentACAExchangeFee","renewalMonthlyPremium","renewalTotalPremium","renewalSubsidy","renewalPremiumwithoutSubsidy","renewalContractCode","renewalContractPlanCode","renewalContractPlanName","renewalACAInsuranceFee","renewalACAReInsuranceFee","renewalACAExchangeFee","estimatedRenewalPremium","memberLDClassID","parentTIN","payeeTIN","writingTIN","deductible","saleChannelId","currentRatingMethod","renewalRatingMethod","bundling","medLock","rateGuaranteeEndDate","targetRateGuaranteeMonths","enforceProdId1RateGuaranteeMonths","isPNCCurrProduct1","isPNCTarProduct1","rateAdjustFactor"};
		String anthembsonfeildName[] = {"PlanEffDate","AnnivMnth","RatingLevel","ProductType","EnrollmentType","ProductString","PlanName" ,"CurrRate" ,"CurrRate" ,"CurrentSubsidy","CurrentPremiumwithoutSubsidy","CurrentMemberSalary","CurrentMemberVolume","CurrentACAInsuranceFee","CurrentACAReInsuranceFee","CurrentACAExchangeFee","NewRate","NewRate","RenewalSubsidy","RenewalPremiumwithoutSubsidy","ProductString","ProductString","PlanName","RenewalACAInsuranceFee","RenewalACAReInsuranceFee","RenewalACAExchangeFee","EstimatedRenewalPremium ","MemberLDClassID","ParentTIN ","PayeeTIN","WritingTIN","Deductible","SaleChannelId","CurrentRatingMethod","RenewalRatingMethod","Bundling","MedLock","RateGuaranteeEndDate ","TargetRateGuaranteeMonths","EnforceProdId1RateGuaranteeMonths","isPNCCurrProduct1","isPNCTarProduct1","RateAdjustFactor"};
		
		for (int i = 0; i < FeildTokens.length; i++) {
			doReturn(bsonfeildName[i]).when(readMappingXmlMock).getAttributeValueOfField(
					IConstants.FACETS_ANTHEM_REN_DET.concat("_modified"), anthemBenefitFeildName[i], IConstants.VALUE);
		}
		
		
		ProcessFieldNames ISG_RENEWALSrenewalProductsModified = new ProcessFieldNames();

		ISG_RENEWALSrenewalProductsModified.setArrayFieldNames(
				"productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");

		doReturn(ISG_RENEWALSrenewalProductsModified).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
		
		
		ProcessFieldNames FACETS_ANTHEMrenewals = new ProcessFieldNames();
		ProcessFieldNames FACETS_ANTHEMcontacts = new ProcessFieldNames();
		ProcessFieldNames FACETS_ANTHEMagents = new ProcessFieldNames();
		
		
		FACETS_ANTHEMrenewals.setArrayFieldNames("productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");
		FACETS_ANTHEMcontacts.setArrayFieldNames("addressType,addressLine1,addressLine2,addressLine3,countryCode,cityName,countyCode,countyName,stateCode,stateName,postalCode,phoneTypeCode,phoneAreaCode,phoneNumber,emailAddress");
		FACETS_ANTHEMagents.setArrayFieldNames("agentID,taxIDType,product,agentReference,name,AOREffectiveDate,AOREndDate");

		
		doReturn(FACETS_ANTHEMrenewals).when(fileNamesPropertiesMock).getPropertyContext(IConstants.GBD_FACETS.concat("renewals"));
		
		doReturn(FACETS_ANTHEMcontacts).when(fileNamesPropertiesMock).getPropertyContext(IConstants.GBD_FACETS.concat("contacts"));
		
		doReturn(FACETS_ANTHEMagents).when(fileNamesPropertiesMock).getPropertyContext(IConstants.GBD_FACETS.concat("agents"));
		

		utilityMock.applyZone(any(String.class), any(String.class), any(String.class), any(Document.class),
				any(String.class), any(Row.class), any(String.class));
		
		doReturn(true).when(changeDataCaptureMock).implementCdc(any(String.class), any(String.class), any(Document.class), any(List.class), any(List.class), any(String.class));
	
		facets_GBD.ingestTDMProcess("RDM", "Renewals_facets_GBD_Renewal", bsonFilterMock, "TDM", "Renewals_tdm_Client",
				appendCollection);

	}
	


	@Test
	public void facetsgetRenewalProductsTest() throws Exception {

		String sourceCollection = "Renewals_facets_GBD_Renewal";
		Document outerDoc = conDocument;
		List<Document> renewalProducts = new ArrayList<>();

		ProcessFieldNames ISG_RENEWALSrenewalProductsModified = new ProcessFieldNames();

		ISG_RENEWALSrenewalProductsModified.setArrayFieldNames(
				"productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");

		doReturn(ISG_RENEWALSrenewalProductsModified).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));

		Document doc = new Document();

		renewalProducts.add(doc);

		/*
		 * This method is not used anywhere in the Project just for code
		 * coverage added this test method
		 */
		facets_GBD.getRenewalProducts(sourceCollection, outerDoc);

	}

	@Test
	public void facetsgetGrpRenewalProductsTest() throws Exception {

		String sourceCollection = "Renewals_facets_GBD_Renewal";

		Document outerDoc = benefitDocument;

		Document summaryDoc = conDocument;

		ProcessFieldNames ISG_RENEWALSrenewalProductsModified = new ProcessFieldNames();

		ISG_RENEWALSrenewalProductsModified.setArrayFieldNames(
				"productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");

		doReturn(ISG_RENEWALSrenewalProductsModified).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));

		facets_GBD.getGrpRenewalProducts(sourceCollection, outerDoc, summaryDoc);

	}


	@Test
	public void facetsIngestUDMProcessExceptionTest() {

		BSONObject bsonObjectMock = bsonTDMObject;

		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		
		facets_GBD.ingestUDMProcess("TDM", "Renewals_tdm_Client", bsonFilterMock, "ADS","Renewals_udm_Client", "None");
	}
	
	@Test
	public void facetsIngestUDMProcessTest() {

		BSONObject bsonObjectMock = bsonTDMObject;

		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		
		facets_GBD.ingestUDMProcess("TDM", "Renewals_tdm_Client", bsonFilterMock, "ADS","Renewals_udm_Client", "None");
		
	}

	@Test
	public void facetsIngestSDSProcessTest() {

		String sourceCollection = "Renewals_facets_GBD_Renewal";

		Document outerDoc = benefitDocument;

		Document summaryDoc = conDocument;

		String targetCollection = "Renewals_Summary";

		String targetDetailCollection = "Renewal_Details";

		String sourceDbTDM = "TDM";

		ProcessFieldNames groupSummaryModified = new ProcessFieldNames();

		groupSummaryModified.setArrayFieldNames(
				"ID,renewalDate,alternateID,groupID,type,groupStatus,sourceID,effectiveDate,groupName,SIC,size,association,agents,contacts");

		String sourceDb = "UDM";

		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonTDMObject);

		facets_GBD.ingestSDSProcess(sourceDb, sourceCollection, bsonFilterMock, groupSummaryModified, "SDS",
				targetCollection, targetDetailCollection, sourceDbTDM);

	}

	@Test
	public void facetsIngestSDSProcessTest2() {

		String sourceCollection = "Renewals_facets_GBD_Renewal";

		String sourceDb = "UDM";

		facets_GBD.ingestSDSProcess(sourceDb, sourceCollection);
	}
	
	
	@Test
	public void facetsIngestSDSProcessTest3() {
		
		 String[] sourceColl ={"Renewals_udm_Client","Renewals_udm_Renewal"};
		 
		 String sourceDb = "UDM";

	     Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonTDMObject);
		
		String targetDb = "SDS";
		
		String sourceCollection = "Renewals_facets_GBD_Renewal";

		String targetCollection = "Renewals_Summary";

		String targetDetailCollection = "Renewal_Details";

		facets_GBD.ingestSDSProcess( sourceDb,  sourceColl,  bsonFilterMock, targetDb,  targetCollection,  sourceDb);
		
	}
	
	
	
	/*@Test
	public void addGrpDeltaTestTwo() {
	
		double currentMonthlyPremium = 1000.21;
		double monthlyPremium = 2500.28;
		
		Document benefitDocument = new Document();
		benefitDocument.append("ID","008M64601");
		benefitDocument.append("lastName","Brown");
		benefitDocument.append("dateofBirth","6/1/1980");
		benefitDocument.append("currentMonthlyPremium",currentMonthlyPremium);
		benefitDocument.append("monthlyPremium",monthlyPremium);
		
		facets_GBD.addGrpDelta(benefitDocument);
	}*/
	
	/*@Test(expected=AssertionError.class)
	public void addGrpDeltaTestException() {
	
		Document benefitDocument = new Document();
		benefitDocument.append("ID","008M64601");
		benefitDocument.append("lastName","Brown");
		benefitDocument.append("dateofBirth","6/1/1980");
		benefitDocument.append("currentMonthlyPremium","0.0");
		benefitDocument.append("monthlyPremium","0.0");
		
		Exception e = new Exception();
		
		facets_GBD.addGrpDelta(benefitDocument);
		
		Assert.assertEquals(null, e);
		
	}*/
	

	/*@Test
	public void facetsIngestRDMprocessTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, ParseException
	{
		
		//RDD<String> objRDD = null;
		//ClassTag<String> classTag= null;
		
		//JavaRDD<String> javaRDD = new JavaRDD<String>(objRDD, classTag);
		
		
		//"130M55856 Joice           Johnston                            203 E Taylor St                                                                   Sims                IN 46986       7654532052           GRANT                F 60                                            203 E Taylor St                                                                   Sims                IN 46986       INSUPWP0          2000.8400          3069.8400 IN Plan A 92 Std.5 Year Band 11/01 Comm/Dis-MADIA                      House Account Invalid Broker                                 INIAAA344788    770470789E 770470789E M 20171101 M N              1";
		
		
		List<String> facetsList = new ArrayList<>();
		facetsList.add("130M55856 Joice           Johnston                            203 E Taylor St                                                                   Sims                IN 46986       7654532052           GRANT                F 60                                            203 E Taylor St                                                                   Sims                IN 46986       INSUPWP0          2000.8400          3069.8400 IN Plan A 92 Std.5 Year Band 11/01 Comm/Dis-MADIA                      House Account Invalid Broker                                 INIAAA344788    770470789E 770470789E M 20171101 M N              1");
		facetsList.add("734M65193 Barbaric        Batterson                           PO Box 464                                                                        Monroe              IA 50170       5747733384           JASPER               F 72                                            PO Box 464                                                                        Monroe              IA 50170       INSUPWP0           200.5200           315.6700 IN Select Plan F 92 Std.1 Year Band 11/01 Att/Non Dis-MLSIF                                                                         22449GA00                  770470789E M 20171101 M N              1");

		ProcessInput processInput = new ProcessInput();
		processInput.setSourceDB("RAW");
		processInput.setSourceCollection("Renewals_facets_GBD_Renewal");
		processInput.setDelimeted("true");
		processInput.setDelimeter("\\,");
		processInput.setType("facets_GBD");
		processInput.setFileType("facets_GBD");
		processInput.setFailedCollection("Renewals_facets_GBD_DQ_Reject");
		
		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/GBD/RA_MEDICARE_ALL_IN_Annual_Triggers_November_20170915_1377records_update.txt";
		String guidvalue = "hcid,AgentTIN";
		String strType = "com.anthem.marketplace.dataconsolidation.filesutils.facets_GBD" ;
	
		SparkConf conf = new SparkConf().setAppName("Spark Count").setMaster("local").set("user.name", "test");
		JavaSparkContext sparkContext = new JavaSparkContext(conf);
	
		doReturn(javaPairRddMock).when(javaSparkContextMock).textFile(sourcePath, 12);
		doReturn(sparkContext.parallelize(facetsList)).when(javaPairRddMock).map((any(org.apache.spark.api.java.function.Function.class)));
		
		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);
		doReturn(true).when(mongoConnectorMock).insertData(Matchers.anyListOf(Document.class), any(String.class), any(String.class), any(String.class));
		
		//Create Guid :
		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("1");
		processFixedFileMetaData.setend("9");
		processFixedFileMetaData.setType(null);
		
		ProcessFixedFileMetaData processFixedFileMetaData2 = new ProcessFixedFileMetaData();
		processFixedFileMetaData2.setstart("582");
		processFixedFileMetaData2.setend("591");
		processFixedFileMetaData2.setType(null);
		
		List<ProcessFixedFileMetaData> guidPosition = new ArrayList<>();
		guidPosition.add(processFixedFileMetaData);
		guidPosition.add(processFixedFileMetaData2);
		
		String type = "facets_GBD";

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("hcid", type);
		doReturn(processFixedFileMetaData2).when(fixedFileMetaDataPropertiesMock).getPropertyContext("AgentTIN", type);
		
		//createFlag:
		String delimeted = "true";
		String sourceCollection = "Renewals_facets_GBD_Renewal";
		Row readFileContent = RowFactory.create("734M65193 Barbaric        Batterson                           PO Box 464                                                                        Monroe              IA 50170       5747733384           JASPER               F 72                                            PO Box 464                                                                        Monroe              IA 50170       INSUPWP0           200.5200           315.6700 IN Select Plan F 92 Std.1 Year Band 11/01 Att/Non Dis-MLSIF                                                                         22449GA00                  770470789E M 20171101 M N              1");
		
		ProcessFixedFileMetaData processFixedFileMetaData3 = new ProcessFixedFileMetaData();
		processFixedFileMetaData3.setstart("165");
		processFixedFileMetaData3.setend("166");
		processFixedFileMetaData3.setType(null);
		
		Map<String, String> mandatoryFields = new HashMap<String, String>();
		mandatoryFields.put("7", "state");
	
		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);
		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("state", type);
		
		//append Raw :

		String guid = "130M55856770470789EMEDSUBSCR";
		boolean flag = false;
		

		ProcessFieldNames procFieldNames = new ProcessFieldNames();

		procFieldNames.setArrayFieldNames(
				"hcid,firstName,lastName,Address1,Address2,city,state,zipCode,phone,country,gender,age,email,mailing_Address1,mailing_Address2,mailing_city,mailing_state,mailing_zip,renewal_group,currentRate,newRate,planName,AgentName,AgentNumber,AgentTIN,AgencyTIN,BillingMode,Rate_RenewalDate,RecordType,HIPAA_Agreement,LastColInd");

		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);
		
		String dataType = "String";
		String dataTypeDate = "Date MM/DD/YYYY";
		String dataTypedouble ="Double";
		String indexarray[] = {"1","11","27","63","104","145","165","168","180","201","222","224","229","270","311","352","372","375","387","396","415","434","505","566","582","593","604","606","615","617","619"};
		String fieldNames[] = {"hcid","firstName","lastName","Address1","Address2","city","state","zipCode","phone","country","gender","age","email","mailing_Address1","mailing_Address2","mailing_city","mailing_state","mailing_zip","renewal_group","currentRate","newRate","planName","AgentName","AgentNumber","AgentTIN","AgencyTIN","BillingMode","Rate_RenewalDate","RecordType","HIPAA_Agreement","LastColInd"};
		
		for (int i = 0; i < indexarray.length; i++) {
			
			doReturn(indexarray[i]).when(readMappingXmlMock).getIndex(type, fieldNames[i]);

			if (fieldNames[i].equalsIgnoreCase("Rate_RenewalDate")) {
				doReturn(dataTypeDate).when(readMappingXmlMock).getAttributeValueOfField(type, fieldNames[i],IConstants.DATATYPE);
			}else if(fieldNames[i].equalsIgnoreCase("currentRate") || fieldNames[i].equalsIgnoreCase("newRate"))
			{
				doReturn(dataTypedouble).when(readMappingXmlMock).getAttributeValueOfField(type, fieldNames[i],IConstants.DATATYPE);
			} 
			else {
				doReturn(dataType).when(readMappingXmlMock).getAttributeValueOfField(type, fieldNames[i],IConstants.DATATYPE);
			}

		}

		PowerMockito.doAnswer(new Answer<Void>() {
			@Override
			public Void answer(InvocationOnMock invocation) throws ParseException {
				Document doc = (Document) invocation.getArguments()[3];

				String datatype = (String) invocation.getArguments()[4];
				String fieldName = (String) invocation.getArguments()[1];
				String value = (String) invocation.getArguments()[2];

				if (datatype.equalsIgnoreCase("Date MM/DD/YYYY")) {
					DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
					formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
					Date date = formatter.parse(value);
					doc.append(fieldName, date);
				} else if (datatype.equalsIgnoreCase("Double")) {

					if (value.equals(null) || value.trim().equals("") || value.equalsIgnoreCase("null")
							|| value.trim().isEmpty()) {
						doc.append(fieldName, null);
					} else {

						value = value.replaceAll(IConstants.COMMA, "").replaceAll("\\$", "");

						if (value.indexOf('-') == value.length() - 1)
							value = '-' + value.substring(0, value.length() - 1);
						doc.append(fieldName, Double.parseDouble(value));
					}
				} else {
					doc.append((String) invocation.getArguments()[1], value);
				}
				return null;
			}
		}).when(Utility.class);

		utilityMock.applyZone(any(String.class), any(String.class), any(String.class), any(Document.class),	any(String.class), any(Row.class), any(String.class));

		doReturn(true).when(changeDataCaptureMock).implementCdc(any(String.class), any(String.class), any(Document.class), any(List.class), any(List.class), any(String.class));
		
		facets_GBD.ingestRDMprocess(processInput,sourcePath,guidvalue,strType);
		
	}*/
	
	


}



