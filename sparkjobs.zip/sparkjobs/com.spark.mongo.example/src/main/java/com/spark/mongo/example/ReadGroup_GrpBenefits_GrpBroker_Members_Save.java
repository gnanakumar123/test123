package com.spark.mongo.example;

import static org.apache.spark.sql.functions.collect_list;

import java.util.ArrayList;
import java.util.List;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.mongodb.spark.MongoSpark;

public final class ReadGroup_GrpBenefits_GrpBroker_Members_Save {

	public static void main(final String[] args) throws InterruptedException {

		// Create a single Spark Session with reference to Mongo Db -
		// Database.Collection
		SparkSession spark = SparkSession.builder().master("local").appName("MongoSparkConnectorIntro")
				.config("spark.mongodb.input.uri", "mongodb://127.0.0.1/test.test")
				.config("spark.mongodb.output.uri", "mongodb://127.0.0.1/test.test").getOrCreate();

		// Create a Java Spark Context from a Spark Session
		JavaSparkContext jsc = new JavaSparkContext(spark.sparkContext());

		// Define a schema for a file
		StructType groupSchema = DataTypes.createStructType(
				new StructField[] { DataTypes.createStructField("seqNumber", DataTypes.StringType, true),
						DataTypes.createStructField("groupId", DataTypes.StringType, true),
						DataTypes.createStructField("firstName", DataTypes.StringType, true),
						DataTypes.createStructField("lastName", DataTypes.StringType, true),
						DataTypes.createStructField("premium", DataTypes.DoubleType, true),
						DataTypes.createStructField("renewalDate", DataTypes.DateType, true),
						DataTypes.createStructField("source", DataTypes.StringType, true)

				});

		StructType groupBrokerSchema = DataTypes.createStructType(
				new StructField[] { DataTypes.createStructField("seqNumber", DataTypes.StringType, true),
						DataTypes.createStructField("groupId", DataTypes.StringType, true),
						DataTypes.createStructField("writingAgentTin", DataTypes.StringType, true),
						DataTypes.createStructField("writingAgentName", DataTypes.StringType, true),
						DataTypes.createStructField("paidAgentTin", DataTypes.StringType, true),
						DataTypes.createStructField("paidAgentName", DataTypes.StringType, true),
						DataTypes.createStructField("GeneralAgentTin", DataTypes.StringType, true),
						DataTypes.createStructField("GeneralAgentName", DataTypes.StringType, true)

				});

		StructType groupBenefitSchema = DataTypes.createStructType(
				new StructField[] { DataTypes.createStructField("groupId", DataTypes.StringType, true),
						DataTypes.createStructField("productId", DataTypes.StringType, true),
						DataTypes.createStructField("productType", DataTypes.StringType, true),
						DataTypes.createStructField("productName", DataTypes.StringType, true),
						DataTypes.createStructField("benefitCoverage", DataTypes.DoubleType, true) });

		StructType memberInfoSchema = DataTypes.createStructType(
				new StructField[] { DataTypes.createStructField("groupId", DataTypes.StringType, true),
						DataTypes.createStructField("memberId", DataTypes.StringType, true),
						DataTypes.createStructField("subscriberFlag", DataTypes.StringType, true),
						DataTypes.createStructField("memberName", DataTypes.StringType, true),
						DataTypes.createStructField("addressLine1", DataTypes.StringType, true),
						DataTypes.createStructField("addressLine2", DataTypes.StringType, true),
						DataTypes.createStructField("city", DataTypes.StringType, true),
						DataTypes.createStructField("state", DataTypes.StringType, true),
						DataTypes.createStructField("zipcode", DataTypes.StringType, true)

				});

		Dataset<Row> groupDf = spark.read().format("csv") //
				.schema(groupSchema).option("header", "true") //
				.option("multiline", true) //
				.option("sep", ";") //
				.option("quote", "^") //
				.option("dateFormat", "M/d/y") //
				.option("inferSchema", false) //
				.load("src/main/resources/group.txt");

		// Create a dataframe from a text file using Spark Session
		// Map the fields in the file against the above custom Schema ( data
		// types for each field )
		Dataset<Row> groupBrokerDf = spark.read().format("csv") //
				.schema(groupBrokerSchema).option("header", "true") //
				.option("multiline", true) //
				.option("sep", ";") //
				.option("quote", "^") //
				.option("dateFormat", "M/d/y") //
				.option("inferSchema", false) //
				.load("src/main/resources/group_broker.txt");

		Dataset<Row> groupBenefitDf = spark.read().format("csv") //
				.schema(groupBenefitSchema).option("header", "true") //
				.option("multiline", true) //
				.option("sep", ";") //
				.option("quote", "^") //
				.option("dateFormat", "M/d/y") //
				.option("inferSchema", false) //
				.load("src/main/resources/group_benefit.txt");

		Dataset<Row> memberInfoDf = spark.read().format("csv") //
				.schema(memberInfoSchema).option("header", "true") //
				.option("multiline", true) //
				.option("sep", ";") //
				.option("quote", "^") //
				.option("dateFormat", "M/d/y") //
				.option("inferSchema", false) //
				.load("src/main/resources/memberinfo.txt");

		System.out.println("Printing incremental file content:");

		groupDf = groupDf.drop("seqNumber");
		groupBrokerDf = groupBrokerDf.drop("seqNumber");

		// Join Group and Group Benefits
		Dataset<Row> groupAndBenefitJoinedDf = groupDf
				.join(groupBenefitDf, groupDf.col("groupId").equalTo(groupBenefitDf.col("groupId")))
				.drop(groupBenefitDf.col("groupId")).select("groupId", "firstName", "lastName", "premium",
						"renewalDate", "source", "productId", "productType", "productName", "benefitCoverage");
		// groupAndBenefitJoinedDf.show(false);

		ArrayList<String> listString = new ArrayList<String>();
		listString.add("productId");
		listString.add("productType");
		listString.add("productName");
		listString.add("benefitCoverage");

		// Merge multiple columns in a Row as a single array of elements
		// ie.A,B,C,D ==> [ A,B,C,D]
		// E,F,G,H ==> [ E,F,G,H]
		// ie.  "groupId", "firstName", "lastName", "premium","renewalDate", "source",
		// ["productId", "productType", "productName", "benefitCoverage"]
		Dataset<Row> groupAndBenefitTempDf = mergeMultipleColumnsInRowAsArray(groupAndBenefitJoinedDf, listString);
		groupAndBenefitTempDf.show(false);

		// Aggregate array in each row of particular column into array of arrays
		// ie.[ [ A,B,C,D],[ E,F,G,H] ]
		Dataset<Row> aggDf = groupAndBenefitTempDf.groupBy("groupId")
				.agg(collect_list(groupAndBenefitTempDf.col("benefits")));
		aggDf.show(false);

		
		// Join Group id from above Aggregated Df with broker and get broker info
		Dataset<Row> groupAndBrokerJoinedDf = aggDf
				.join(groupBrokerDf, aggDf.col("groupId").equalTo(groupBrokerDf.col("groupId")))
				.drop(groupBrokerDf.col("groupId")).withColumnRenamed("collect_list(benefits)", "benefits");
		groupAndBrokerJoinedDf.show(false);

		// Join Group id from Group Df with MemberDf and get member info
		Dataset<Row> groupAndMemberJoinedDf = groupDf
				.join(memberInfoDf, groupDf.col("groupId").equalTo(memberInfoDf.col("groupId")))
				.drop(memberInfoDf.col("groupId")).drop(groupDf.col("firstName")).drop(groupDf.col("lastName"))
				.drop(groupDf.col("premium")).drop(groupDf.col("renewalDate"));

		MongoSpark.write(groupAndBrokerJoinedDf).option("collection", "renewalsummary").mode("append").save();
		MongoSpark.write(groupAndMemberJoinedDf).option("collection", "renewaldetails").mode("append").save();

		jsc.close();

	}

	public static Dataset<Row> mergeMultipleColumnsInRowAsArray(Dataset<Row> ds, List<String> columns) {
		return ds.withColumn("benefits", functions.array(columns.stream().map(functions::col).toArray(Column[]::new)));
	}

}
