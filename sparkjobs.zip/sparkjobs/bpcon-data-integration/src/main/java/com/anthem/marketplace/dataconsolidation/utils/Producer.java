package com.anthem.marketplace.dataconsolidation.utils;

import java.io.Serializable;

public class Producer implements Serializable {
	
	private static final long serialVersionUID = 1L;
	String agentTaxId;
	String starBrokerTin;
	String encryptedTaxId;
	String firstName;
	String middleName;
	String lastName;
	String agencyName;
	String agentId;
	String legacyAgentCode;
	String wgsAgentCode;
	
	public String getWgsAgentCode() {
		return wgsAgentCode;
	}
	public void setWgsAgentCode(String wgsAgentCode) {
		this.wgsAgentCode = wgsAgentCode;
	}
	public String getAgentTaxId() {
		return agentTaxId;
	}
	public void setAgentTaxId(String agentTaxId) {
		this.agentTaxId = agentTaxId;
	}
	public String getStarBrokerTin() {
		return starBrokerTin;
	}
	public void setStarBrokerTin(String startBrokerTin) {
		this.starBrokerTin = startBrokerTin;
	}
	public String getEncryptedTaxId() {
		return encryptedTaxId;
	}
	public void setEncryptedTaxId(String encryptedTaxId) {
		this.encryptedTaxId = encryptedTaxId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAgencyName() {
		return agencyName;
	}
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getLegacyAgentCode() {
		return legacyAgentCode;
	}
	public void setLegacyAgentCode(String legacyAgentCode) {
		this.legacyAgentCode = legacyAgentCode;
	}		
}
