package com.jobreadyprogrammer.spark;

public class Application {

	public static void main(String[] args) {
		
		System.out.println("*********************First output **********************");

		InferCSVSchema parser = new InferCSVSchema();
		parser.printSchema();
		
		System.out.println("*********************Second output **********************");

		DefineCSVSchema parser2 = new DefineCSVSchema();
		parser2.printDefinedSchema();
		
		System.out.println("*********************Third output **********************");

		JSONLinesParser parser3 = new JSONLinesParser();
		parser3.parseJsonLines();

	}

}
