package com.anthem.marketplace.dataconsolidation.utils;

public class ProcessFixedFileMetaData {
	
	private String fieldName;
	private String type;
	private String start;
	private String end;
	
	public ProcessFixedFileMetaData(){ 
		super();
	}
	
	public ProcessFixedFileMetaData(String fieldName,String type){
		this.fieldName = fieldName;
		this.type = type;
	}
		
	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getStart() {
		return start;
	}

	public void setstart(String start) {
		this.start = start;
	}

	public String getEnd() {
		return end;
	}

	public void setend(String end) {
		this.end = end;
	}

	@Override
	public String toString() {
		return "{type=" + this.type + ", start=" + this.start + ",end=" + this.end + "}";
		
	}
}