package com.anthem.marketplace.dataconsolidation.utils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * This class reads fieldNames from properties file and returns them.  
 */
public class FieldNamesProperties {
	
	static final  Logger logger = LoggerFactory.getLogger(FieldNamesProperties.class);
	private static FieldNamesProperties instance;
	private static HashMap<String,String> hashMapproperty;
	private FieldNamesProperties() throws IOException, NoSuchMethodException, ClassNotFoundException,
			InvocationTargetException, IllegalAccessException {
		hashMapproperty = readProp("fieldNames.properties");
	}

	public ProcessFieldNames getPropertyContext(String type) throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		ProcessFieldNames process = new ProcessFieldNames();
		process.setArrayFieldNames(hashMapproperty.get(type + IConstants.ARRAYFIELDNAMES));
		return process;
	}

	public static synchronized FieldNamesProperties getInstance() {
		if (instance == null) {
			try {
				instance = new FieldNamesProperties();

			} catch (Exception e) {
				logger.error("Error{}", e);
			}
		}
		return instance;
	}

	private HashMap<String, String> readProp(String configpath) throws IOException, NoSuchMethodException,
			ClassNotFoundException, InvocationTargetException, IllegalAccessException {
		Properties prop = new Properties();
		prop.load(FieldNamesProperties.class.getResourceAsStream("/" + configpath));
		Enumeration<?> propertyNames = prop.propertyNames();
		HashMap<String,String> propertyHashMap=new HashMap<>();
		while (propertyNames.hasMoreElements()) {
			String key = (String) propertyNames.nextElement();
				String Value = prop.getProperty(key);
				propertyHashMap.put(key, Value);
				
				}
		return propertyHashMap;
		}
}
