package com.anthem.marketplace.DataConsolidation.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

import com.anthem.marketplace.dataconsolidation.model.VARenewal;
import com.anthem.marketplace.dataconsolidation.utils.CustomRDDConverter;

import scala.Tuple2;

@RunWith(PowerMockRunner.class)
public class CustomRDDConverterTest {
	
	CustomRDDConverter customRDDConverter;

	@Test
	public void createVARenewalsTest() throws Exception {
		String xmlContent = CHIPSConstants.xmlString();
		Tuple2<String, String> fileContent = new Tuple2<>("1",xmlContent);
		customRDDConverter = new CustomRDDConverter();
		List<VARenewal> vaRenewalsList = customRDDConverter.call(fileContent);		
	}
}
