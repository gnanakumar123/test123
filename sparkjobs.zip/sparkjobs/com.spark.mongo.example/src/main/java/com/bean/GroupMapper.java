package com.bean;

import java.text.SimpleDateFormat;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Row;
import org.bson.Document;

public class GroupMapper implements MapFunction<Row, Group> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2L;

	@Override
	public Group call(Row value) throws Exception {

		Group document = new Group();

		document.setGroupId(value.getAs("groupId"));
		document.setFirstName(value.getAs("firstName"));
		document.setLastName(value.getAs("lastName"));
		document.setPremium(value.getAs("premium"));
		document.setRenewalDate(value.getAs("renewalDate"));

		return document;

	}

}
