/**
 * 
 */
package com.anthem.marketplace.DataConsolidation.test;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.lang.reflect.InvocationTargetException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.bson.BSONObject;
import org.bson.Document;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.filesutils.FACETS;
import com.anthem.marketplace.dataconsolidation.filesutils.UtilityInterface;
import com.anthem.marketplace.dataconsolidation.job.processor.IngestRDM;
import com.anthem.marketplace.dataconsolidation.utils.ChangeDataCapture;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.FixedFileMetaDataProperties;
import com.anthem.marketplace.dataconsolidation.utils.GetSysProperties;
import com.anthem.marketplace.dataconsolidation.utils.GuidProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.InputConnectors;
import com.anthem.marketplace.dataconsolidation.utils.InputProperties;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ProcessGuid;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXml;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SystemProperties;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.util.JSON;

import scala.Tuple2;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "org.apache.hadoop.*", "javax.*", "com.sun.org.apache.*", "org.apache.log4j.*", "org.w3c.dom.*",
		"org.apache.xerces.*" })
@PrepareForTest({ FACETS.class, ReadMappingXmlSingleton.class, MongoConnector.class, FieldNamesProperties.class,
		FixedFileMetaDataProperties.class, ReadMappingXml.class, Utility.class, UtilityInterface.class,
		SparkContextSingleton.class })

public class FACETSTest {

	@Mock
	ReadMappingXmlSingleton readMappingXmlSingletonMock;

	@Mock
	ReadMappingXml readMappingXmlMock;

	@Mock
	FieldNamesProperties fileNamesPropertiesMock;

	@Mock
	MongoConnector mongoConnectorMock;

	@Mock
	FixedFileMetaDataProperties fixedFileMetaDataPropertiesMock;

	@Mock
	GuidProperties guidPropertiesMock;

	@Mock
	GetSysProperties getSysPropertiesMock;

	@Mock
	InputConnectors inputConnectorsMock;

	@Mock
	InputProperties inputPropertiesMock;

	@Mock
	ProcessInput processInput;

	@Mock
	ProcessGuid processGuid;

	@Mock
	IngestRDM irdObj;

	@Mock
	UtilityInterface utilityInterface;

	@Mock
	SystemProperties systemProperties;

	@Mock
	BSONObject bsonObjectMock;

	@Mock
	Utility utilityMock;
	
	@Mock
	SparkContextSingleton sparkContextSingletonMock;
	
	@Mock
	JavaSparkContext javaSparkContextMock;
	
	@Mock
	JavaPairRDD javaPairRddMock;
	
	@Mock
	ChangeDataCapture changeDataCaptureMock;

	FACETS facets = (FACETS) Utility.createObject("com.anthem.marketplace.dataconsolidation.filesutils.FACETS");

	String sourceCollection = "FACETS(O65)";

	String delimeted = " ";

	static final Logger logger = LoggerFactory.getLogger(IngestRDM.class);

	String jsonRaw = "{\r\n" + "    \"_id\" : ObjectId(\"5bd988629ec0071b146696c6\"),\r\n"
			+ "    \"GUID\" : \"000M55781000M557816/1/2018MINDSUBSCR\",\r\n" + "    \"SubId\" : \"000M55781\",\r\n"
			+ "    \"SubFirstName\" : \"Chris\",\r\n" + "    \"SubLastName\" : \"Dimitroff\",\r\n"
			+ "    \"Addr1\" : \"451 American Way North\",\r\n" + "    \"Addr2\" : \"Apt 2H\",\r\n"
			+ "    \"City\" : \"Carmel\",\r\n" + "    \"State\" : \"IN\",\r\n" + "    \"Zip\" : \"46032\",\r\n"
			+ "    \"SubPhone\" : \"317-748-1153\",\r\n" + "    \"SubDOB\" : \"1/27/1979\",\r\n"
			+ "    \"DepName1\" : \"\",\r\n" + "    \"DepName2\" : \"\",\r\n" + "    \"DepName3\" : \"\",\r\n"
			+ "    \"DepName4\" : \"\",\r\n" + "    \"CurrRate\" : 407.73,\r\n" + "    \"NewRate\" : 480.49,\r\n"
			+ "    \"Difference%\" : \"17.85%\",\r\n" + "    \"RatingLevel\" : 0.573,\r\n"
			+ "    \"PlanName\" : \"SmartSense 30%\",\r\n" + "    \"Deductible\" : \"1000\",\r\n"
			+ "    \"AgentName\" : \"EXACT INSURANCE INSURANCE GROUP INC\",\r\n"
			+ "    \"AgentNumber\" : \"INI719812\",\r\n"
			+ "    \"PlanEffDate\" : ISODate(\"2018-06-01T04:00:00.000Z\"),\r\n"
			+ "    \"AnnivMnth\" : ISODate(\"2018-06-01T04:00:00.000Z\"),\r\n" + "    \"ProductType\" : \"M\",\r\n"
			+ "    \"ProductString\" : \"INE000701000V200\",\r\n"
			+ "    \"start-date\" : \"2018-10-31 16:18:02.258\",\r\n"
			+ "    \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n"
			+ "    \"source-path\" : \"D:/372712/Employer Broker/FeedFile/apps/Renewals/FACETS/AnthemU65/ANTHEM_IN_031218_SU65_060118_F1 - Copy.csv\",\r\n"
			+ "    \"source\" : \"FACETS(U65)\",\r\n" + "    \"Version\" : \"V1\",\r\n"
			+ "    \"status\" : \"un-processed\",\r\n" + "    \"Data_Quality_Check\" : \"passed\"\r\n" + "}";

	Document convertDocument = (Document) Document.parse(jsonRaw);

	BSONObject bsonRawObject = (BSONObject) JSON.parse(convertDocument.toJson());
	
	
	String jsonRawO65 = "{\r\n" + 
			"    \"_id\" : ObjectId(\"59e76f66ad48cae513edfac5\"),\r\n" + 
			"    \"GUID\" : \"400M55817400M5581708/01/2016MMEDSUBSCR\",\r\n" + 
			"    \"SubId\" : \"400M55817\",\r\n" + 
			"    \"SubFirstName\" : \"Frank\",\r\n" + 
			"    \"SubLastName\" : \"Farrell\",\r\n" + 
			"    \"Addr1\" : \"568 E 900 N\",\r\n" + 
			"    \"Addr2\" : \"\",\r\n" + 
			"    \"City\" : \"Westville\",\r\n" + 
			"    \"State\" : \"IN\",\r\n" + 
			"    \"Zip\" : \"46391\",\r\n" + 
			"    \"SubPhone\" : \"\",\r\n" + 
			"    \"SubDOB\" : \"\",\r\n" + 
			"    \"CurrRate\" : 1691.74,\r\n" + 
			"    \"NewRate\" : 1696.82,\r\n" + 
			"    \"RatingLevel\" : 1.745,\r\n" + 
			"    \"PlanName\" : \"Med Supp Trad F\",\r\n" + 
			"    \"Deductible\" : \"N/A\",\r\n" + 
			"    \"AgentName\" : \"MARK W FREEMAN\",\r\n" + 
			"    \"AgentNumber\" : \"INI704347\",\r\n" + 
			"    \"PlanEffDate\" : ISODate(\"2016-08-01T04:00:00.000Z\"),\r\n" + 
			"    \"AnnivMnth\" : ISODate(\"2016-08-01T04:00:00.000Z\"),\r\n" + 
			"    \"ProductType\" : \"M\",\r\n" + 
			"    \"start-date\" : \"2018-07-19 10:04:50.796\",\r\n" + 
			"    \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n" + 
			"    \"source-path\" : \"hdfs://mom9n90291.wellpoint.com:8020/apps/Renewals/FACETS/AnthemO65/ANTHEM_IN_060716_SO65_080119_F1.csv\",\r\n" + 
			"    \"source\" : \"FACETS(O65)\",\r\n" + 
			"    \"Version\" : \"V1\",\r\n" + 
			"    \"status\" : \"processed\",\r\n" + 
			"    \"Data_Quality_Check\" : \"passed\"\r\n" + 
			"}";

	Document convertDocumentO65 = (Document) Document.parse(jsonRawO65);

	BSONObject bsonRawObjectO65 = (BSONObject) JSON.parse(convertDocumentO65.toJson());

	
	
	String jsonTDMRenewal = "{\r\n" + "	    \"_id\" : ObjectId(\"5be949549ec00730101306df\"),\r\n"
			+ "	    \"GUID\" : \"000M55781000M557816/1/2019MINDSUBSCR\",\r\n" + "	    \"ID\" : \"000M55781\",\r\n"
			+ "	    \"renewalDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	    \"effectiveDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	    \"currentContractCode\" : \"INE000701000V200\",\r\n"
			+ "	    \"renewalContractCode\" : \"INE000701000V200\",\r\n" + "	    \"Delta\" : \"17.85%\",\r\n"
			+ "	    \"type\" : \"IND\",\r\n" + "	    \"relationship\" : \"SUBSCR\",\r\n"
			+ "	    \"renewalDependentsCovered\" : \"No\",\r\n" + "	    \"Benefits\" : [ \r\n" + "	        {\r\n"
			+ "	            \"effectiveDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	            \"renewalDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	            \"ratingTier\" : 0.573,\r\n" + "	            \"productType\" : \"M\",\r\n"
			+ "	            \"currentContractPlanCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"currentContractPlanName\" : \"SmartSense 30%\",\r\n"
			+ "	            \"currentMonthlyPremium\" : 500.73,\r\n"
			+ "	            \"currentTotalPremium\" : 500.73,\r\n"
			+ "	            \"renewalMonthlyPremium\" : 680.49,\r\n"
			+ "	            \"renewalTotalPremium\" : 680.49,\r\n"
			+ "	            \"renewalContractCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"renewalContractPlanCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"renewalContractPlanName\" : \"SmartSense 30%\",\r\n"
			+ "	            \"deductible\" : \"1000\",\r\n" + "	            \"renewalProducts\" : [ \r\n"
			+ "	                {\r\n" + "	                    \"productType\" : \"M\",\r\n"
			+ "	                    \"renewalContractCode\" : \"INE000701000V200\",\r\n"
			+ "	                    \"renewalContractPlanName\" : \"SmartSense 30%\"\r\n" + "	                }\r\n"
			+ "	            ]\r\n" + "	        }\r\n" + "	    ],\r\n" + "	    \"currentMonthlyPremium\" : 500.73,\r\n"
			+ "	    \"monthlyPremium\" : 680.49,\r\n" + "	    \"start-date\" : \"2018-11-12 15:05:16.397\",\r\n"
			+ "	    \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n"
			+ "	    \"source-path\" : \"D:/372712/Employer Broker/FeedFile/apps/Renewals/FACETS/AnthemU65/ANTHEM_IN_031218_SU65_060118_F1_update.csv\",\r\n"
			+ "	    \"source\" : \"FACETS(U65)\",\r\n" + "	    \"Version\" : \"V1\",\r\n"
			+ "	    \"status\" : \"un-processed\",\r\n" + "	    \"Data_Quality_Check\" : \"passed\"\r\n" + "	}\r\n"
			+ "";

	Document conDocument = (Document) Document.parse(jsonTDMRenewal);

	BSONObject bsonTDMObject = (BSONObject) JSON.parse(conDocument.toJson());

	String jsonTDMBenefit = "{\r\n" + "	    \"_id\" : ObjectId(\"5be949549ec00730101306df\"),\r\n"
			+ "	    \"Benefits\" : [ \r\n" + "	        {\r\n"
			+ "	            \"effectiveDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	            \"renewalDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	            \"ratingTier\" : 0.573,\r\n" + "	            \"productType\" : \"M\",\r\n"
			+ "	            \"currentContractPlanCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"currentContractPlanName\" : \"SmartSense 30%\",\r\n"
			+ "	            \"currentMonthlyPremium\" : 500.73,\r\n"
			+ "	            \"currentTotalPremium\" : 500.73,\r\n"
			+ "	            \"renewalMonthlyPremium\" : 680.49,\r\n"
			+ "	            \"renewalTotalPremium\" : 680.49,\r\n"
			+ "	            \"renewalContractCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"renewalContractPlanCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"renewalContractPlanName\" : \"SmartSense 30%\",\r\n"
			+ "	            \"deductible\" : \"1000\",\r\n" + "	            \"renewalProducts\" : [ \r\n"
			+ "	                {\r\n" + "	                    \"productType\" : \"M\",\r\n"
			+ "	                    \"renewalContractCode\" : \"INE000701000V200\",\r\n"
			+ "	                    \"renewalContractPlanName\" : \"SmartSense 30%\"\r\n" + "	                }\r\n"
			+ "	            ]\r\n" + "	        }\r\n" + "	    ],\r\n" + "	    \"currentMonthlyPremium\" : 500.73,\r\n"
			+ "	    \"monthlyPremium\" : 680.49,\r\n" + "	    \"start-date\" : \"2018-11-12 15:05:16.397\",\r\n"
			+ "	    \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n"
			+ "	    \"source-path\" : \"D:/372712/Employer Broker/FeedFile/apps/Renewals/FACETS/AnthemU65/ANTHEM_IN_031218_SU65_060118_F1_update.csv\",\r\n"
			+ "	    \"source\" : \"FACETS(U65)\",\r\n" + "	    \"Version\" : \"V1\",\r\n"
			+ "	    \"status\" : \"processed\",\r\n" + "	    \"Data_Quality_Check\" : \"passed\"\r\n" + "	}\r\n"
			+ "";

	Document benefitDocument = (Document) Document.parse(jsonTDMBenefit);

	BSONObject bsonTDMBenefitObject = (BSONObject) JSON.parse(benefitDocument.toJson());

	@Before
	public void setup() {

		/* ReadMappingXml Mock Singleton */

		PowerMockito.mockStatic(ReadMappingXmlSingleton.class);

		readMappingXmlSingletonMock = PowerMockito.mock(ReadMappingXmlSingleton.class);
		PowerMockito.when(ReadMappingXmlSingleton.getInstance()).thenReturn(readMappingXmlSingletonMock);

		readMappingXmlMock = PowerMockito.mock(ReadMappingXml.class);
		doReturn(readMappingXmlMock).when(readMappingXmlSingletonMock).getRead();

		/* SparkContextSingleton Mock Singleton */
		PowerMockito.mockStatic(SparkContextSingleton.class);

		sparkContextSingletonMock = PowerMockito.mock(SparkContextSingleton.class);
		PowerMockito.when(SparkContextSingleton.getInstance()).thenReturn(sparkContextSingletonMock);

		javaSparkContextMock = PowerMockito.mock(JavaSparkContext.class);
		doReturn(javaSparkContextMock).when(sparkContextSingletonMock).getSparkContext();

		/* MongoConnector Mock */
		PowerMockito.mockStatic(MongoConnector.class);
		mongoConnectorMock = PowerMockito.mock(MongoConnector.class);

		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);

		/* FieldNamesProperties Mock */
		PowerMockito.mockStatic(FieldNamesProperties.class);
		fileNamesPropertiesMock = PowerMockito.mock(FieldNamesProperties.class);

		PowerMockito.when(FieldNamesProperties.getInstance()).thenReturn(fileNamesPropertiesMock);

		/* FixedFileMetaDataProperties Mock */
		PowerMockito.mockStatic(FixedFileMetaDataProperties.class);
		fixedFileMetaDataPropertiesMock = PowerMockito.mock(FixedFileMetaDataProperties.class);
		PowerMockito.when(FixedFileMetaDataProperties.getInstance()).thenReturn(fixedFileMetaDataPropertiesMock);

		/* GuidProperties Mock */
		// PowerMockito.mockStatic(GuidProperties.class);
		guidPropertiesMock = PowerMockito.mock(GuidProperties.class);

		// PowerMockito.when(GuidProperties.getInstance()).thenReturn(guidPropertiesMock);

		/* GuidProperties Mock */
		// PowerMockito.mockStatic(GetSysProperties.class);
		getSysPropertiesMock = PowerMockito.mock(GetSysProperties.class);

		// PowerMockito.when(GetSysProperties.getInstance()).thenReturn(getSysPropertiesMock);

		/* InputConnectors Mock */
		// PowerMockito.mockStatic(InputConnectors.class);
		inputConnectorsMock = PowerMockito.mock(InputConnectors.class);

		// PowerMockito.when(InputConnectors.getInstance()).thenReturn(inputConnectorsMock);

		/* InputProperties Mock */
		// PowerMockito.mockStatic(InputProperties.class);
		inputPropertiesMock = PowerMockito.mock(InputProperties.class);

		// PowerMockito.when(InputProperties.getInstance()).thenReturn(inputPropertiesMock);

		/* Utility Mock */

		PowerMockito.mockStatic(Utility.class);
		utilityMock = PowerMockito.mock(Utility.class);
		
		
		sparkContextSingletonMock = PowerMockito.mock(SparkContextSingleton.class);
		PowerMockito.mockStatic(SparkContextSingleton.class);
		PowerMockito.when(SparkContextSingleton.getInstance()).thenReturn(sparkContextSingletonMock);
		javaSparkContextMock = PowerMockito.mock(JavaSparkContext.class);
		doReturn(javaSparkContextMock).when(sparkContextSingletonMock).getSparkContext();

	}

	@Test
	public void createGuidFacetsO65Test() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_facets_Renewal";
		String delimeted = "true";
		Row readFileContent = RowFactory.create("449M54947", "", "Robin", "Didonna", "4522 Sheraton Dr", "", "Parma",
				"OH", "44134", "", "M", "", "60918", "$218.19 ", "$225.08 ", "3.16%", "0", "0", "1", "1.745",
				"Med Select F", "N/A", "", "", "", " ", " ", " ", " ", "", "INI719812", "", "", " ", " ", " ", "M",
				"7/1/2016", "M", "OH", "N", "", "1");
		String guidvalue = "SubId,SubId,AnnivMnth,ProductType";
		String type = "facets_renewal_Anthem_O65";

		doReturn("0").when(readMappingXmlMock).getIndex(type, "SubId");
		doReturn("0").when(readMappingXmlMock).getIndex(type, "SubId");
		doReturn("37").when(readMappingXmlMock).getIndex(type, "AnnivMnth");
		doReturn("38").when(readMappingXmlMock).getIndex(type, "ProductType");

		String actual = facets.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);

		Assert.assertEquals("449M54947449M549477/1/2016MMEDSUBSCR", actual);
	}

	@Test
	public void createGuidFacetsU65Test() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_facets_Renewal";
		String delimeted = "true";
		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");
		String guidvalue = "SubId,SubId,AnnivMnth,ProductType";
		String type = "facets_renewal_Anthem_U65";

		doReturn("0").when(readMappingXmlMock).getIndex(type, "SubId");
		doReturn("0").when(readMappingXmlMock).getIndex(type, "SubId");
		doReturn("55").when(readMappingXmlMock).getIndex(type, "AnnivMnth");
		doReturn("56").when(readMappingXmlMock).getIndex(type, "ProductType");

		String actual = facets.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);

		Assert.assertEquals("000M55781000M557816/1/2019MINDSUBSCR", actual);
	}

	@SuppressWarnings("unchecked")
	@Test // (expected=NullPointerException.class)
	public void createGuidNullPointerExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_facets_Renewal";
		String delimeted = "true";
		Row readFileContent = RowFactory.create(
				"449M54947,,Robin,Didonna,4522 Sheraton Dr,,Parma,OH,44134,,M,,60918,$218.19 ,$225.08 ,3.16%,0,0,1,1.745,Med Select F,N/A,,,, , , , ,,INI719812,,, , , ,M,7/1/2016,M,OH,N,,1");
		String guidvalue = "SubId,SubId,AnnivMnth,ProductType";
		String type = "facets_renewal_Anthem_U65";

		String item = "SubId";

		when(readMappingXmlMock.getIndex(type, item)).thenThrow(NullPointerException.class);

		facets.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}

	@SuppressWarnings("unchecked")
	@Test // (expected=ArrayIndexOutOfBoundsException.class)
	public void createGuidArrayIndexOutOfBoundsExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_facets_Renewal";
		String delimeted = "true";
		Row readFileContent = RowFactory.create(
				"449M54947,,Robin,Didonna,4522 Sheraton Dr,,Parma,OH,44134,,M,,60918,$218.19 ,$225.08 ,3.16%,0,0,1,1.745,Med Select F,N/A,,,, , , , ,,INI719812,,, , , ,M,7/1/2016,M,OH,N,,1");
		String guidvalue = "SubId,SubId,AnnivMnth,ProductType";
		String type = "facets_renewal_Anthem_U65";

		String item = "SubId";

		when(readMappingXmlMock.getIndex(type, item)).thenThrow(ArrayIndexOutOfBoundsException.class);

		facets.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}

	@SuppressWarnings("unchecked")
	@Test // (expected=ClassCastException.class)
	public void createGuidClassCastExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_facets_Renewal";
		String delimeted = "true";
		Row readFileContent = RowFactory.create(
				"449M54947,,Robin,Didonna,4522 Sheraton Dr,,Parma,OH,44134,,M,,60918,$218.19 ,$225.08 ,3.16%,0,0,1,1.745,Med Select F,N/A,,,, , , , ,,INI719812,,, , , ,M,7/1/2016,M,OH,N,,1");
		String guidvalue = "SubId,SubId,AnnivMnth,ProductType";
		String type = "facets_renewal_Anthem_U65";
		String index = "0";

		String item = "SubId";

		when(readMappingXmlMock.getIndex(type, item)).thenThrow(ClassCastException.class);

		facets.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}

	@SuppressWarnings("unchecked")
	@Test // (expected=NumberFormatException.class)
	public void createGuidNumberFormatExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_facets_Renewal";
		String delimeted = "true";
		Row readFileContent = RowFactory.create(
				"449M54947,,Robin,Didonna,4522 Sheraton Dr,,Parma,OH,44134,,M,,60918,$218.19 ,$225.08 ,3.16%,0,0,1,1.745,Med Select F,N/A,,,, , , , ,,INI719812,,, , , ,M,7/1/2016,M,OH,N,,1");
		String guidvalue = "SubId,SubId,AnnivMnth,ProductType";
		String type = "facets_renewal_Anthem_U65";
		String index = "0";

		String item = "SubId";

		when(readMappingXmlMock.getIndex(type, item)).thenThrow(NumberFormatException.class);

		facets.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}

	@SuppressWarnings("unchecked")
	@Test // (expected=Exception.class)
	public void createGuidExceptionTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_facets_Renewal";
		String delimeted = "true";
		Row readFileContent = RowFactory.create(
				"449M54947,,Robin,Didonna,4522 Sheraton Dr,,Parma,OH,44134,,M,,60918,$218.19 ,$225.08 ,3.16%,0,0,1,1.745,Med Select F,N/A,,,, , , , ,,INI719812,,, , , ,M,7/1/2016,M,OH,N,,1");
		String guidvalue = "SubId,SubId,AnnivMnth,ProductType";
		String type = "facets_renewal_Anthem_U65";
		String index = "0";

		String item = "SubId";

		when(readMappingXmlMock.getIndex(type, item)).thenThrow(Exception.class);

		facets.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}

	@Test
	public void createFlagTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String delimeted = "true";
		String sourceCollection = "Renewals_facets_Renewal";

		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");

		String type = "facets_renewal_Anthem_U65";
		// boolean flag = false;

		Map<String, String> mandatoryFields = new HashMap<String, String>();

		mandatoryFields.put("49", "AgentNumber");
		mandatoryFields.put("7", "State");
		// mandatoryFields.put("0","State");

		// String item = "49";

		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);

		boolean actual = facets.createFlag(delimeted, sourceCollection, readFileContent, type);

		Assert.assertEquals(false, actual);

	}

	@Test
	public void createFlagExceptionTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String delimeted = "true";
		String sourceCollection = "Renewals_facets_Renewal";

		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");

		String type = "facets_renewal_Anthem_U65";
		// boolean flag = false;

		Map<String, String> mandatoryFields = new HashMap<String, String>();

		mandatoryFields.put("10", "");

		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);

		boolean actual = facets.createFlag(delimeted, sourceCollection, readFileContent, type);

		Assert.assertEquals(false, actual);

	}

	@Test
	public void createFlagcreateErrorCodeDescriptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String delimeted = "true";
		String sourceCollection = "Renewals_facets_Renewal";

		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");

		String type = "facets_renewal_Anthem_U65";
		// boolean flag = false;

		Map<String, String> mandatoryFields = new HashMap<String, String>();

		mandatoryFields.put("43", "AgentNumber");

		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);

		boolean actual = facets.createFlag(delimeted, sourceCollection, readFileContent, type);

		Assert.assertEquals(true, actual);

	}

	@Test
	public void createFlagNullPointerExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String delimeted = "true";
		String sourceCollection = "Renewals_facets_Renewal";

		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");

		String type = "facets_renewal_Anthem_U65";

		Map<String, String> mandatoryFields = new HashMap<String, String>();

		mandatoryFields.put("10", "");

		when(readMappingXmlMock.getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE))
				.thenThrow(NullPointerException.class);

		facets.createFlag(delimeted, sourceCollection, readFileContent, type);

	}

	@Test
	public void createFlagArrayIndexOutOfBoundsExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String delimeted = "true";
		String sourceCollection = "Renewals_facets_Renewal";

		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");

		String type = "facets_renewal_Anthem_U65";

		Map<String, String> mandatoryFields = new HashMap<String, String>();

		mandatoryFields.put("10", "");

		when(readMappingXmlMock.getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE))
				.thenThrow(ArrayIndexOutOfBoundsException.class);

		facets.createFlag(delimeted, sourceCollection, readFileContent, type);

	}

	@Test
	public void createFlagClassCastExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String delimeted = "true";
		String sourceCollection = "Renewals_facets_Renewal";

		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");

		String type = "facets_renewal_Anthem_U65";

		Map<String, String> mandatoryFields = new HashMap<String, String>();

		mandatoryFields.put("10", "");

		when(readMappingXmlMock.getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE))
				.thenThrow(ClassCastException.class);

		facets.createFlag(delimeted, sourceCollection, readFileContent, type);

	}

	@Test
	public void createFlagNumberFormatExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String delimeted = "true";
		String sourceCollection = "Renewals_facets_Renewal";

		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");

		String type = "facets_renewal_Anthem_U65";

		Map<String, String> mandatoryFields = new HashMap<String, String>();

		mandatoryFields.put("10", "");

		when(readMappingXmlMock.getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE))
				.thenThrow(NumberFormatException.class);

		facets.createFlag(delimeted, sourceCollection, readFileContent, type);

	}

	@Test
	public void createFlagExceptionExceptionTest() throws ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String delimeted = "true";
		String sourceCollection = "Renewals_facets_Renewal";

		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");

		String type = "facets_renewal_Anthem_U65";

		Map<String, String> mandatoryFields = new HashMap<String, String>();

		mandatoryFields.put("10", "");

		when(readMappingXmlMock.getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE)).thenThrow(Exception.class);

		facets.createFlag(delimeted, sourceCollection, readFileContent, type);

	}

	@Test
	public void appendRawNullPointerExceptionTest()
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, ParseException {

		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/FACETS/AnthemU65/ANTHEM_IN_031218_SU65_060118_F1_update.csv";

		String guid = "000M55781000M557816/1/2019MINDSUBSCR";
		boolean flag = false;
		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");
		String sourceDB = "bpconadsDB";
		String sourceCollection = "Renewals_facets_Renewal";
		boolean checkFlag = false;
		String dataType = "String";
		String dataTypeDate = "Date MM/DD/YYYY";
		String field = "sampleField";
		String fieldNames[] = { "SubId", "SubFirstName", "SubLastName" };
		String indexarray[] = { "0", "2", "3" };
		String type = "facets_renewal_Anthem_U65";

		Document doc = new Document();

		ProcessInput processInput = new ProcessInput();
		processInput.setType(type);
		processInput.setSourceDB(sourceDB);
		processInput.setSourceCollection(sourceCollection);

		ProcessFieldNames procFieldNames = new ProcessFieldNames();

		procFieldNames.setArrayFieldNames(
				"SubId,SubFirstName,SubLastName,Addr1,Addr2,City,State,Zip,SubPhone,SubDOB,DepName1,DepName2,DepName3,DepName4,CurrRate,NewRate,Difference%,RatingLevel,PlanName,Deductible,AgentName,AgentNumber,PlanEffDate,AnnivMnth,ProductType,ProductString,null");

		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);

		when(readMappingXmlMock.getAttributeValueOfField(type, "SubId", IConstants.DATATYPE))
				.thenThrow(NullPointerException.class);

		facets.appendRaw(processInput, sourcePath, guid, flag, readFileContent);

	}

	@Test
	public void appendRawArrayIndexOutOfBoundsExceptionTest()
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, ParseException {

		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/FACETS/AnthemU65/ANTHEM_IN_031218_SU65_060118_F1_update.csv";

		String guid = "000M55781000M557816/1/2019MINDSUBSCR";
		boolean flag = false;
		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");
		String sourceDB = "bpconadsDB";
		String sourceCollection = "Renewals_facets_Renewal";
		boolean checkFlag = false;
		String dataType = "String";
		String dataTypeDate = "Date MM/DD/YYYY";
		String field = "sampleField";
		String fieldNames[] = { "SubId", "SubFirstName", "SubLastName" };
		String indexarray[] = { "0", "2", "3" };
		String type = "facets_renewal_Anthem_U65";

		Document doc = new Document();

		ProcessInput processInput = new ProcessInput();
		processInput.setType(type);
		processInput.setSourceDB(sourceDB);
		processInput.setSourceCollection(sourceCollection);

		ProcessFieldNames procFieldNames = new ProcessFieldNames();

		procFieldNames.setArrayFieldNames(
				"SubId,SubFirstName,SubLastName,Addr1,Addr2,City,State,Zip,SubPhone,SubDOB,DepName1,DepName2,DepName3,DepName4,CurrRate,NewRate,Difference%,RatingLevel,PlanName,Deductible,AgentName,AgentNumber,PlanEffDate,AnnivMnth,ProductType,ProductString,null");

		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);

		when(readMappingXmlMock.getAttributeValueOfField(type, "SubId", IConstants.DATATYPE))
				.thenThrow(ArrayIndexOutOfBoundsException.class);

		facets.appendRaw(processInput, sourcePath, guid, flag, readFileContent);

	}

	@Test
	public void appendRawClassCastExceptionTest()
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, ParseException {

		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/FACETS/AnthemU65/ANTHEM_IN_031218_SU65_060118_F1_update.csv";

		String guid = "000M55781000M557816/1/2019MINDSUBSCR";
		boolean flag = false;
		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");
		String sourceDB = "bpconadsDB";
		String sourceCollection = "Renewals_facets_Renewal";
		boolean checkFlag = false;
		String dataType = "String";
		String dataTypeDate = "Date MM/DD/YYYY";
		String field = "sampleField";
		String fieldNames[] = { "SubId", "SubFirstName", "SubLastName" };
		String indexarray[] = { "0", "2", "3" };
		String type = "facets_renewal_Anthem_U65";

		Document doc = new Document();

		ProcessInput processInput = new ProcessInput();
		processInput.setType(type);
		processInput.setSourceDB(sourceDB);
		processInput.setSourceCollection(sourceCollection);

		ProcessFieldNames procFieldNames = new ProcessFieldNames();

		procFieldNames.setArrayFieldNames(
				"SubId,SubFirstName,SubLastName,Addr1,Addr2,City,State,Zip,SubPhone,SubDOB,DepName1,DepName2,DepName3,DepName4,CurrRate,NewRate,Difference%,RatingLevel,PlanName,Deductible,AgentName,AgentNumber,PlanEffDate,AnnivMnth,ProductType,ProductString,null");

		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);

		when(readMappingXmlMock.getAttributeValueOfField(type, "SubId", IConstants.DATATYPE))
				.thenThrow(ClassCastException.class);

		facets.appendRaw(processInput, sourcePath, guid, flag, readFileContent);

	}

	@Test
	public void appendRawNumberFormatExceptionTest()
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, ParseException {

		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/FACETS/AnthemU65/ANTHEM_IN_031218_SU65_060118_F1_update.csv";

		String guid = "000M55781000M557816/1/2019MINDSUBSCR";
		boolean flag = false;
		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");
		String sourceDB = "bpconadsDB";
		String sourceCollection = "Renewals_facets_Renewal";
		boolean checkFlag = false;
		String dataType = "String";
		String dataTypeDate = "Date MM/DD/YYYY";
		String field = "sampleField";
		String fieldNames[] = { "SubId", "SubFirstName", "SubLastName" };
		String indexarray[] = { "0", "2", "3" };
		String type = "facets_renewal_Anthem_U65";

		Document doc = new Document();

		ProcessInput processInput = new ProcessInput();
		processInput.setType(type);
		processInput.setSourceDB(sourceDB);
		processInput.setSourceCollection(sourceCollection);

		ProcessFieldNames procFieldNames = new ProcessFieldNames();

		procFieldNames.setArrayFieldNames(
				"SubId,SubFirstName,SubLastName,Addr1,Addr2,City,State,Zip,SubPhone,SubDOB,DepName1,DepName2,DepName3,DepName4,CurrRate,NewRate,Difference%,RatingLevel,PlanName,Deductible,AgentName,AgentNumber,PlanEffDate,AnnivMnth,ProductType,ProductString,null");

		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);

		when(readMappingXmlMock.getAttributeValueOfField(type, "SubId", IConstants.DATATYPE))
				.thenThrow(NumberFormatException.class);

		facets.appendRaw(processInput, sourcePath, guid, flag, readFileContent);

	}

	@Test
	public void appendRawExceptionExceptionTest()
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, ParseException {

		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/FACETS/AnthemU65/ANTHEM_IN_031218_SU65_060118_F1_update.csv";

		String guid = "000M55781000M557816/1/2019MINDSUBSCR";
		boolean flag = false;
		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");
		String sourceDB = "bpconadsDB";
		String sourceCollection = "Renewals_facets_Renewal";
		boolean checkFlag = false;
		String dataType = "String";
		String dataTypeDate = "Date MM/DD/YYYY";
		String field = "sampleField";
		String fieldNames[] = { "SubId", "SubFirstName", "SubLastName" };
		String indexarray[] = { "0", "2", "3" };
		String type = "facets_renewal_Anthem_U65";

		Document doc = new Document();

		ProcessInput processInput = new ProcessInput();
		processInput.setType(type);
		processInput.setSourceDB(sourceDB);
		processInput.setSourceCollection(sourceCollection);

		ProcessFieldNames procFieldNames = new ProcessFieldNames();

		procFieldNames.setArrayFieldNames(
				"SubId,SubFirstName,SubLastName,Addr1,Addr2,City,State,Zip,SubPhone,SubDOB,DepName1,DepName2,DepName3,DepName4,CurrRate,NewRate,Difference%,RatingLevel,PlanName,Deductible,AgentName,AgentNumber,PlanEffDate,AnnivMnth,ProductType,ProductString,null");

		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);

		when(readMappingXmlMock.getAttributeValueOfField(type, "SubId", IConstants.DATATYPE))
				.thenThrow(Exception.class);

		facets.appendRaw(processInput, sourcePath, guid, flag, readFileContent);

	}

	@Test
	public void appendRawTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException, ParseException {

		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/FACETS/AnthemU65/ANTHEM_IN_031218_SU65_060118_F1_update.csv";
		String sourcePath2 = "D:/372712/Employer Broker/FeedFile/apps/Renewals/FACETS/AnthemO65/ANTHEM_IN_031218_SU65_060118_F1_update.csv";

		String guid = "000M55781000M557816/1/2019MINDSUBSCR";
		boolean flag = false;
		Row readFileContent = RowFactory.create("000M55781", "620141151", "Christan", "Dimitroff",
				"451 American Way North", "Apt 2H", "Carmel", "IN", "46032", "317-748-1153", "M", "1/27/1979", " ", " ",
				" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", "195416", "$500.73 ", "$680.49 ",
				"17.85%", "0.573", "1", "0.573", "1", "SmartSense 30%", "1000", "2", " ", " ", "", "", "", " ", " ",
				" ", " ", "EXACT INSURANCE INSURANCE GROUP INC", "INI719812", "5915 N COLLEGE AVE STE 212", "",
				"INDIANAPOLIS", "IN", "46220", "6/1/2019", "M", "IN", "N", " ", "", "", "G", "", "", "INE000701000V200",
				"Hamilton", "1");
		String sourceDB = "bpconadsDB";
		String sourceCollection = "Renewals_facets_Renewal";
		boolean checkFlag = false;
		String dataType = "String";
		String dataTypeDate = "Date MM/DD/YYYY";
		String fieldNames[] = { "SubId", "SubFirstName", "SubLastName" };
		String indexarray[] = { "0", "2", "3" };
		String type = "facets_renewal_Anthem_U65";

		Document doc = new Document();

		ProcessInput processInput = new ProcessInput();
		processInput.setType(type);
		processInput.setSourceDB(sourceDB);
		processInput.setSourceCollection(sourceCollection);

		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames.setArrayFieldNames(
				"SubId,SubFirstName,SubLastName,Addr1,Addr2,City,State,Zip,SubPhone,SubDOB,DepName1,DepName2,DepName3,DepName4,CurrRate,NewRate,Difference%,RatingLevel,PlanName,Deductible,AgentName,AgentNumber,PlanEffDate,AnnivMnth,ProductType,ProductString,null");

		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);

		for (int i = 0; i < indexarray.length; i++) {
			doReturn(indexarray[i]).when(readMappingXmlMock).getIndex(type, fieldNames[i]);

			if (fieldNames[i].equalsIgnoreCase("AnnivMnth")) {
				doReturn(dataTypeDate).when(readMappingXmlMock).getAttributeValueOfField(type, fieldNames[i],
						IConstants.DATATYPE);
			} else {
				doReturn(dataType).when(readMappingXmlMock).getAttributeValueOfField(type, fieldNames[i],
						IConstants.DATATYPE);
			}

		}

		PowerMockito.doAnswer(new Answer<Void>() {
			@Override
			public Void answer(InvocationOnMock invocation) throws ParseException {
				Document doc = (Document) invocation.getArguments()[3];

				String datatype = (String) invocation.getArguments()[4];
				String fieldName = (String) invocation.getArguments()[1];
				String value = (String) invocation.getArguments()[2];

				if (datatype.equalsIgnoreCase("Date MM/DD/YYYY")) {
					DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
					formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
					Date date = formatter.parse(value);
					doc.append(fieldName, date);
				} else if (datatype.equalsIgnoreCase("Double")) {

					if (value.equals(null) || value.trim().equals("") || value.equalsIgnoreCase("null")
							|| value.trim().isEmpty()) {
						doc.append(fieldName, null);
					} else {

						value = value.replaceAll(IConstants.COMMA, "").replaceAll("\\$", "");

						if (value.indexOf('-') == value.length() - 1)
							value = '-' + value.substring(0, value.length() - 1);
						doc.append(fieldName, Double.parseDouble(value));
					}
				} else {
					doc.append((String) invocation.getArguments()[1], value);
				}
				return null;
			}
		}).when(Utility.class);

		utilityMock.applyZone(any(String.class), any(String.class), any(String.class), any(Document.class),
				any(String.class), any(Row.class), any(String.class));

		Document actualDoc = facets.appendRaw(processInput, sourcePath, guid, flag, readFileContent);

		Document actualDoc2 = facets.appendRaw(processInput, sourcePath2, guid, flag, readFileContent);

		Assert.assertEquals(actualDoc.get("SubId"), "000M55781");

		Assert.assertEquals(actualDoc2.get("SubId"), "000M55781");

	}
	
	@SuppressWarnings("unchecked")
	@Test(expected = NullPointerException .class)
	public void facetsIngestTDMProcessExceptionTest() throws Exception {

		BSONObject bsonObjectMock = bsonRawObject;

		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);

		String appendCollection = "renewals,contacts,agents";

		ProcessFieldNames Renewals_tdm_ClientFieldNames = new ProcessFieldNames();
		Renewals_tdm_ClientFieldNames.setArrayFieldNames(
				"GUID,ID,type,relationship,subID,name,groupNumber,alternateID,billingEntity,associationName,associationCode,SIC,contactName,effectiveDate,renewalDate,association,paperBilling,accountManagerID,salesRepID,underwriterID,exchangeIndicator,size,source,businessCode,employeeCount,marketSegment,relationship,enrollmentType,firstName,middleName,lastName,dateofBirth,age,gender,tobaccoUsage,tobaccoWellness,otherWellness,medicareEligible,consumerChoice,calCobraStateContInd,cobraIndicator,status,MBUType");

		when(fileNamesPropertiesMock.getPropertyContext(IConstants.FACETS_ANTHEM.concat("Renewals_tdm_Client").toString())).thenThrow(NullPointerException .class);
		
		facets.ingestTDMProcess("RDM", "Renewals_facets_Renewal", bsonFilterMock, "TDM", "Renewals_tdm_Client",appendCollection);
		
	}
	

	@Test
	public void facetsIngestTDMClientProcessTestU65() throws Exception {

		BSONObject bsonObjectMock = bsonRawObject;

		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);

		String appendCollection = "renewals,contacts,agents";

		ProcessFieldNames Renewals_tdm_ClientFieldNames = new ProcessFieldNames();
		Renewals_tdm_ClientFieldNames.setArrayFieldNames(
				"GUID,ID,type,relationship,subID,name,groupNumber,alternateID,billingEntity,associationName,associationCode,SIC,contactName,effectiveDate,renewalDate,association,paperBilling,accountManagerID,salesRepID,underwriterID,exchangeIndicator,size,source,businessCode,employeeCount,marketSegment,relationship,enrollmentType,firstName,middleName,lastName,dateofBirth,age,gender,tobaccoUsage,tobaccoWellness,otherWellness,medicareEligible,consumerChoice,calCobraStateContInd,cobraIndicator,status,MBUType");

		doReturn(Renewals_tdm_ClientFieldNames).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.FACETS_ANTHEM.concat("Renewals_tdm_Client").toString());

		ProcessFieldNames Renewals_tdm_RenewalFieldNames = new ProcessFieldNames();
		Renewals_tdm_RenewalFieldNames.setArrayFieldNames(
				"GUID,ID,type,relationship,clientReference,renewalMonth,renewalPeriod,renewalDate,estimatedLetterMailDate,currentMonthlyPremium,currentTotalPremium,currentPremiumwithoutSubsidy,currentPremiumwithSubsidy,currentRatingArea,currentSubsidy,renewalMonthlyPremium,renewalTotalPremium,renewalPremium,renewalPremiumwithoutSubsidy,renewalPremiumwithSubsidy,renewalRatingArea,renewalSubsidy,effectiveDate,renewalOptions,underwritingLevel,parentTIN,payeeTIN,writingTIN,exchangeIndicator,language,letterCode,letterCodeFlag,dentalEligibleEmployees,visGuaranteeMonths,denGuaranteeMonths,denPriorCoverage,saveAndGenerateFlag,renewalPacketToken,medicalFactorFlag,lifeFlag,enableGviFlag,MBUType,groupChangeInd,memberChangeInd,dentalSubscriberCnt,visionSubscriberCnt,targetDntlElgibleLivesCnt,targetVisElgibleLivesCnt,currDntlElgibleLivesCnt,currVisElgibleLivesCnt,dentalPriorCoverage,currentContractCode,renewalContractCode,currentDependentsCovered,renewalDependentsCovered,Delta");

		doReturn(Renewals_tdm_RenewalFieldNames).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.FACETS_ANTHEM.concat("Renewals_tdm_Renewal").toString());

		ProcessFieldNames FACETS_ANTHEMBenefits = new ProcessFieldNames();
		FACETS_ANTHEMBenefits.setArrayFieldNames(
				"effectiveDate,renewalDate,ratingTier,productType,enrollmentType,currentContractPlanCode,currentContractPlanName,currentMonthlyPremium,currentTotalPremium,currentSubsidy,currentPremiumwithoutSubsidy,currentMemberSalary,currentMemberVolume,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee,renewalMonthlyPremium,renewalTotalPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanCode,renewalContractPlanName,renewalACAInsuranceFee,renewalACAReInsuranceFee,renewalACAExchangeFee,estimatedRenewalPremium,memberLDClassID,parentTIN,payeeTIN,writingTIN,deductible,saleChannelId,currentRatingMethod,renewalRatingMethod,bundling,medLock,rateGuaranteeEndDate,targetRateGuaranteeMonths,enforceProdId1RateGuaranteeMonths,isPNCCurrProduct1,isPNCTarProduct1,rateAdjustFactor");

		doReturn(FACETS_ANTHEMBenefits).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.FACETS_ANTHEM_REN_DET);

		String FeildTokens[] = { "GUID", "ID", "type", "relationship" };

		String bsonfeildName[] = { "GUID", "SubId", "Type", "relationship" };

		for (int i = 0; i < FeildTokens.length; i++) {
			doReturn(bsonfeildName[i]).when(readMappingXmlMock).getAttributeValueOfField(
					IConstants.FACETS_ANTHEM.concat("Renewals_tdm_Client"), FeildTokens[i], IConstants.VALUE);
		}

		
		FACETS_ANTHEMBenefits.setArrayFieldNames(
				"effectiveDate,renewalDate,ratingTier,productType,enrollmentType,currentContractPlanCode,currentContractPlanName,currentMonthlyPremium,currentTotalPremium,currentSubsidy,currentPremiumwithoutSubsidy,currentMemberSalary,currentMemberVolume,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee,renewalMonthlyPremium,renewalTotalPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanCode,renewalContractPlanName,renewalACAInsuranceFee,renewalACAReInsuranceFee,renewalACAExchangeFee,estimatedRenewalPremium,memberLDClassID,parentTIN,payeeTIN,writingTIN,deductible,saleChannelId,currentRatingMethod,renewalRatingMethod,bundling,medLock,rateGuaranteeEndDate,targetRateGuaranteeMonths,enforceProdId1RateGuaranteeMonths,isPNCCurrProduct1,isPNCTarProduct1,rateAdjustFactor");

		doReturn(FACETS_ANTHEMBenefits).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM_REN_DET);

		
		String anthemBenefitFeildName[] = {"effectiveDate","renewalDate","ratingTier","productType","enrollmentType","currentContractPlanCode","currentContractPlanName","currentMonthlyPremium","currentTotalPremium","currentSubsidy","currentPremiumwithoutSubsidy","currentMemberSalary","currentMemberVolume","currentACAInsuranceFee","currentACAReInsuranceFee","currentACAExchangeFee","renewalMonthlyPremium","renewalTotalPremium","renewalSubsidy","renewalPremiumwithoutSubsidy","renewalContractCode","renewalContractPlanCode","renewalContractPlanName","renewalACAInsuranceFee","renewalACAReInsuranceFee","renewalACAExchangeFee","estimatedRenewalPremium","memberLDClassID","parentTIN","payeeTIN","writingTIN","deductible","saleChannelId","currentRatingMethod","renewalRatingMethod","bundling","medLock","rateGuaranteeEndDate","targetRateGuaranteeMonths","enforceProdId1RateGuaranteeMonths","isPNCCurrProduct1","isPNCTarProduct1","rateAdjustFactor"};
		String anthembsonfeildName[] = {"PlanEffDate","AnnivMnth","RatingLevel","ProductType","EnrollmentType","ProductString","PlanName" ,"CurrRate" ,"CurrRate" ,"CurrentSubsidy","CurrentPremiumwithoutSubsidy","CurrentMemberSalary","CurrentMemberVolume","CurrentACAInsuranceFee","CurrentACAReInsuranceFee","CurrentACAExchangeFee","NewRate","NewRate","RenewalSubsidy","RenewalPremiumwithoutSubsidy","ProductString","ProductString","PlanName","RenewalACAInsuranceFee","RenewalACAReInsuranceFee","RenewalACAExchangeFee","EstimatedRenewalPremium ","MemberLDClassID","ParentTIN ","PayeeTIN","WritingTIN","Deductible","SaleChannelId","CurrentRatingMethod","RenewalRatingMethod","Bundling","MedLock","RateGuaranteeEndDate ","TargetRateGuaranteeMonths","EnforceProdId1RateGuaranteeMonths","isPNCCurrProduct1","isPNCTarProduct1","RateAdjustFactor"};
		
		for (int i = 0; i < FeildTokens.length; i++) {
			doReturn(bsonfeildName[i]).when(readMappingXmlMock).getAttributeValueOfField(
					IConstants.FACETS_ANTHEM_REN_DET.concat("_modified"), anthemBenefitFeildName[i], IConstants.VALUE);
		}
		
		
		ProcessFieldNames ISG_RENEWALSrenewalProductsModified = new ProcessFieldNames();

		ISG_RENEWALSrenewalProductsModified.setArrayFieldNames(
				"productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");

		doReturn(ISG_RENEWALSrenewalProductsModified).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
		
		
		ProcessFieldNames FACETS_ANTHEMrenewals = new ProcessFieldNames();
		ProcessFieldNames FACETS_ANTHEMcontacts = new ProcessFieldNames();
		ProcessFieldNames FACETS_ANTHEMagents = new ProcessFieldNames();
		
		
		FACETS_ANTHEMrenewals.setArrayFieldNames("renewalPeriod,renewalReference");
		FACETS_ANTHEMcontacts.setArrayFieldNames("addressType,addressLine1,addressLine2,addressLine3,countryCode,cityName,countyCode,countyName,stateCode,stateName,postalCode,phoneTypeCode,phoneAreaCode,phoneNumber,emailAddress");
		FACETS_ANTHEMagents.setArrayFieldNames("agentID,taxIDType,product,agentReference,name,AOREffectiveDate,AOREndDate");

		
		doReturn(FACETS_ANTHEMrenewals).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM.concat("renewals"));
		
		doReturn(FACETS_ANTHEMcontacts).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM.concat("contacts"));
		
		doReturn(FACETS_ANTHEMagents).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM.concat("agents"));
		

		utilityMock.applyZone(any(String.class), any(String.class), any(String.class), any(Document.class),
				any(String.class), any(Row.class), any(String.class));
		
		doReturn(true).when(changeDataCaptureMock).implementCdc(any(String.class), any(String.class), any(Document.class), any(List.class), any(List.class), any(String.class));
			
		facets.ingestTDMProcess("RDM", "Renewals_facets_Renewal", bsonFilterMock, "TDM", "Renewals_tdm_Client",
				appendCollection);
		

	}
	
	
	@Test
	public void facetsIngestTDM_Renewals_TestU65() throws Exception {

		BSONObject bsonObjectMock = bsonRawObject;

		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);

		String appendCollection = "renewals,contacts,agents";

		ProcessFieldNames Renewals_tdm_ClientFieldNames = new ProcessFieldNames();
		Renewals_tdm_ClientFieldNames.setArrayFieldNames(
				"GUID,ID,type,relationship,subID,name,groupNumber,alternateID,billingEntity,associationName,associationCode,SIC,contactName,effectiveDate,renewalDate,association,paperBilling,accountManagerID,salesRepID,underwriterID,exchangeIndicator,size,source,businessCode,employeeCount,marketSegment,relationship,enrollmentType,firstName,middleName,lastName,dateofBirth,age,gender,tobaccoUsage,tobaccoWellness,otherWellness,medicareEligible,consumerChoice,calCobraStateContInd,cobraIndicator,status,MBUType");

		doReturn(Renewals_tdm_ClientFieldNames).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.FACETS_ANTHEM.concat("Renewals_tdm_Client").toString());

		ProcessFieldNames Renewals_tdm_RenewalFieldNames = new ProcessFieldNames();
		Renewals_tdm_RenewalFieldNames.setArrayFieldNames(
				"GUID,ID,type,relationship,clientReference,renewalMonth,renewalPeriod,renewalDate,estimatedLetterMailDate,currentMonthlyPremium,currentTotalPremium,currentPremiumwithoutSubsidy,currentPremiumwithSubsidy,currentRatingArea,currentSubsidy,renewalMonthlyPremium,renewalTotalPremium,renewalPremium,renewalPremiumwithoutSubsidy,renewalPremiumwithSubsidy,renewalRatingArea,renewalSubsidy,effectiveDate,renewalOptions,underwritingLevel,parentTIN,payeeTIN,writingTIN,exchangeIndicator,language,letterCode,letterCodeFlag,dentalEligibleEmployees,visGuaranteeMonths,denGuaranteeMonths,denPriorCoverage,saveAndGenerateFlag,renewalPacketToken,medicalFactorFlag,lifeFlag,enableGviFlag,MBUType,groupChangeInd,memberChangeInd,dentalSubscriberCnt,visionSubscriberCnt,targetDntlElgibleLivesCnt,targetVisElgibleLivesCnt,currDntlElgibleLivesCnt,currVisElgibleLivesCnt,dentalPriorCoverage,currentContractCode,renewalContractCode,currentDependentsCovered,renewalDependentsCovered,Delta");

		doReturn(Renewals_tdm_RenewalFieldNames).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.FACETS_ANTHEM.concat("Renewals_tdm_Renewal").toString());

		ProcessFieldNames FACETS_ANTHEMBenefits = new ProcessFieldNames();
		

		String FeildTokens[] = { "GUID", "ID", "type", "relationship" };

		String bsonfeildName[] = { "GUID", "SubId", "Type", "relationship" };

		for (int i = 0; i < FeildTokens.length; i++) {
			doReturn(bsonfeildName[i]).when(readMappingXmlMock).getAttributeValueOfField(
					IConstants.FACETS_ANTHEM.concat("Renewals_tdm_Renewal"), FeildTokens[i], IConstants.VALUE);
		}

		FACETS_ANTHEMBenefits.setArrayFieldNames(
				"effectiveDate,renewalDate,ratingTier,productType,enrollmentType,currentContractPlanCode,currentContractPlanName,currentMonthlyPremium,currentTotalPremium,currentSubsidy,currentPremiumwithoutSubsidy,currentMemberSalary,currentMemberVolume,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee,renewalMonthlyPremium,renewalTotalPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanCode,renewalContractPlanName,renewalACAInsuranceFee,renewalACAReInsuranceFee,renewalACAExchangeFee,estimatedRenewalPremium,memberLDClassID,parentTIN,payeeTIN,writingTIN,deductible,saleChannelId,currentRatingMethod,renewalRatingMethod,bundling,medLock,rateGuaranteeEndDate,targetRateGuaranteeMonths,enforceProdId1RateGuaranteeMonths,isPNCCurrProduct1,isPNCTarProduct1,rateAdjustFactor");

		doReturn(FACETS_ANTHEMBenefits).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM_REN_DET);

		
		String anthemBenefitFeildName[] = {"effectiveDate","renewalDate","ratingTier","productType","enrollmentType","currentContractPlanCode","currentContractPlanName","currentMonthlyPremium","currentTotalPremium","currentSubsidy","currentPremiumwithoutSubsidy","currentMemberSalary","currentMemberVolume","currentACAInsuranceFee","currentACAReInsuranceFee","currentACAExchangeFee","renewalMonthlyPremium","renewalTotalPremium","renewalSubsidy","renewalPremiumwithoutSubsidy","renewalContractCode","renewalContractPlanCode","renewalContractPlanName","renewalACAInsuranceFee","renewalACAReInsuranceFee","renewalACAExchangeFee","estimatedRenewalPremium","memberLDClassID","parentTIN","payeeTIN","writingTIN","deductible","saleChannelId","currentRatingMethod","renewalRatingMethod","bundling","medLock","rateGuaranteeEndDate","targetRateGuaranteeMonths","enforceProdId1RateGuaranteeMonths","isPNCCurrProduct1","isPNCTarProduct1","rateAdjustFactor"};
		String anthembsonfeildName[] = {"PlanEffDate","AnnivMnth","RatingLevel","ProductType","EnrollmentType","ProductString","PlanName" ,"CurrRate" ,"CurrRate" ,"CurrentSubsidy","CurrentPremiumwithoutSubsidy","CurrentMemberSalary","CurrentMemberVolume","CurrentACAInsuranceFee","CurrentACAReInsuranceFee","CurrentACAExchangeFee","NewRate","NewRate","RenewalSubsidy","RenewalPremiumwithoutSubsidy","ProductString","ProductString","PlanName","RenewalACAInsuranceFee","RenewalACAReInsuranceFee","RenewalACAExchangeFee","EstimatedRenewalPremium ","MemberLDClassID","ParentTIN ","PayeeTIN","WritingTIN","Deductible","SaleChannelId","CurrentRatingMethod","RenewalRatingMethod","Bundling","MedLock","RateGuaranteeEndDate ","TargetRateGuaranteeMonths","EnforceProdId1RateGuaranteeMonths","isPNCCurrProduct1","isPNCTarProduct1","RateAdjustFactor"};
		
		for (int i = 0; i < FeildTokens.length; i++) {
			doReturn(bsonfeildName[i]).when(readMappingXmlMock).getAttributeValueOfField(
					IConstants.FACETS_ANTHEM_REN_DET.concat("_modified"), anthemBenefitFeildName[i], IConstants.VALUE);
		}
		
		
		ProcessFieldNames ISG_RENEWALSrenewalProductsModified = new ProcessFieldNames();

		ISG_RENEWALSrenewalProductsModified.setArrayFieldNames(
				"productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");

		doReturn(ISG_RENEWALSrenewalProductsModified).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
		
		
		ProcessFieldNames FACETS_ANTHEMrenewals = new ProcessFieldNames();
		ProcessFieldNames FACETS_ANTHEMcontacts = new ProcessFieldNames();
		ProcessFieldNames FACETS_ANTHEMagents = new ProcessFieldNames();
		
		
		FACETS_ANTHEMrenewals.setArrayFieldNames("renewalPeriod,renewalReference");
		FACETS_ANTHEMcontacts.setArrayFieldNames("addressType,addressLine1,addressLine2,addressLine3,countryCode,cityName,countyCode,countyName,stateCode,stateName,postalCode,phoneTypeCode,phoneAreaCode,phoneNumber,emailAddress");
		FACETS_ANTHEMagents.setArrayFieldNames("agentID,taxIDType,product,agentReference,name,AOREffectiveDate,AOREndDate");

		
		doReturn(FACETS_ANTHEMrenewals).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM.concat("renewals"));
		
		doReturn(FACETS_ANTHEMcontacts).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM.concat("contacts"));
		
		doReturn(FACETS_ANTHEMagents).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM.concat("agents"));
		

		utilityMock.applyZone(any(String.class), any(String.class), any(String.class), any(Document.class),
				any(String.class), any(Row.class), any(String.class));
		
		doReturn(true).when(changeDataCaptureMock).implementCdc(any(String.class), any(String.class), any(Document.class), any(List.class), any(List.class), any(String.class));
			
		
		facets.ingestTDMProcess("RDM", "Renewals_facets_Renewal", bsonFilterMock, "TDM", "Renewals_tdm_Renewal",appendCollection);
		

	}
	
	@Test
	public void facetsIngestTDMClientProcessTestO65() throws Exception {

		BSONObject bsonObjectMock = bsonRawObjectO65;

		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);

		String appendCollection = "renewals,contacts,agents";

		ProcessFieldNames Renewals_tdm_ClientFieldNames = new ProcessFieldNames();
		Renewals_tdm_ClientFieldNames.setArrayFieldNames(
				"GUID,ID,type,relationship,subID,name,groupNumber,alternateID,billingEntity,associationName,associationCode,SIC,contactName,effectiveDate,renewalDate,association,paperBilling,accountManagerID,salesRepID,underwriterID,exchangeIndicator,size,source,businessCode,employeeCount,marketSegment,relationship,enrollmentType,firstName,middleName,lastName,dateofBirth,age,gender,tobaccoUsage,tobaccoWellness,otherWellness,medicareEligible,consumerChoice,calCobraStateContInd,cobraIndicator,status,MBUType");

		doReturn(Renewals_tdm_ClientFieldNames).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.FACETS_ANTHEM.concat("Renewals_tdm_Client").toString());

		ProcessFieldNames Renewals_tdm_RenewalFieldNames = new ProcessFieldNames();
		Renewals_tdm_RenewalFieldNames.setArrayFieldNames(
				"GUID,ID,type,relationship,clientReference,renewalMonth,renewalPeriod,renewalDate,estimatedLetterMailDate,currentMonthlyPremium,currentTotalPremium,currentPremiumwithoutSubsidy,currentPremiumwithSubsidy,currentRatingArea,currentSubsidy,renewalMonthlyPremium,renewalTotalPremium,renewalPremium,renewalPremiumwithoutSubsidy,renewalPremiumwithSubsidy,renewalRatingArea,renewalSubsidy,effectiveDate,renewalOptions,underwritingLevel,parentTIN,payeeTIN,writingTIN,exchangeIndicator,language,letterCode,letterCodeFlag,dentalEligibleEmployees,visGuaranteeMonths,denGuaranteeMonths,denPriorCoverage,saveAndGenerateFlag,renewalPacketToken,medicalFactorFlag,lifeFlag,enableGviFlag,MBUType,groupChangeInd,memberChangeInd,dentalSubscriberCnt,visionSubscriberCnt,targetDntlElgibleLivesCnt,targetVisElgibleLivesCnt,currDntlElgibleLivesCnt,currVisElgibleLivesCnt,dentalPriorCoverage,currentContractCode,renewalContractCode,currentDependentsCovered,renewalDependentsCovered,Delta");

		doReturn(Renewals_tdm_RenewalFieldNames).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.FACETS_ANTHEM.concat("Renewals_tdm_Renewal").toString());

		ProcessFieldNames FACETS_ANTHEMBenefits = new ProcessFieldNames();
		FACETS_ANTHEMBenefits.setArrayFieldNames(
				"effectiveDate,renewalDate,ratingTier,productType,enrollmentType,currentContractPlanCode,currentContractPlanName,currentMonthlyPremium,currentTotalPremium,currentSubsidy,currentPremiumwithoutSubsidy,currentMemberSalary,currentMemberVolume,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee,renewalMonthlyPremium,renewalTotalPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanCode,renewalContractPlanName,renewalACAInsuranceFee,renewalACAReInsuranceFee,renewalACAExchangeFee,estimatedRenewalPremium,memberLDClassID,parentTIN,payeeTIN,writingTIN,deductible,saleChannelId,currentRatingMethod,renewalRatingMethod,bundling,medLock,rateGuaranteeEndDate,targetRateGuaranteeMonths,enforceProdId1RateGuaranteeMonths,isPNCCurrProduct1,isPNCTarProduct1,rateAdjustFactor");

		doReturn(FACETS_ANTHEMBenefits).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.FACETS_ANTHEM_REN_DET);

		String FeildTokens[] = { "GUID", "ID", "type", "relationship" };

		String bsonfeildName[] = { "GUID", "SubId", "Type", "relationship" };

		for (int i = 0; i < FeildTokens.length; i++) {
			doReturn(bsonfeildName[i]).when(readMappingXmlMock).getAttributeValueOfField(
					IConstants.FACETS_ANTHEM.concat("Renewals_tdm_Client"), FeildTokens[i], IConstants.VALUE);
		}

		
		FACETS_ANTHEMBenefits.setArrayFieldNames(
				"effectiveDate,renewalDate,ratingTier,productType,enrollmentType,currentContractPlanCode,currentContractPlanName,currentMonthlyPremium,currentTotalPremium,currentSubsidy,currentPremiumwithoutSubsidy,currentMemberSalary,currentMemberVolume,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee,renewalMonthlyPremium,renewalTotalPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanCode,renewalContractPlanName,renewalACAInsuranceFee,renewalACAReInsuranceFee,renewalACAExchangeFee,estimatedRenewalPremium,memberLDClassID,parentTIN,payeeTIN,writingTIN,deductible,saleChannelId,currentRatingMethod,renewalRatingMethod,bundling,medLock,rateGuaranteeEndDate,targetRateGuaranteeMonths,enforceProdId1RateGuaranteeMonths,isPNCCurrProduct1,isPNCTarProduct1,rateAdjustFactor");

		doReturn(FACETS_ANTHEMBenefits).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM_REN_DET);

		
		String anthemBenefitFeildName[] = {"effectiveDate","renewalDate","ratingTier","productType","enrollmentType","currentContractPlanCode","currentContractPlanName","currentMonthlyPremium","currentTotalPremium","currentSubsidy","currentPremiumwithoutSubsidy","currentMemberSalary","currentMemberVolume","currentACAInsuranceFee","currentACAReInsuranceFee","currentACAExchangeFee","renewalMonthlyPremium","renewalTotalPremium","renewalSubsidy","renewalPremiumwithoutSubsidy","renewalContractCode","renewalContractPlanCode","renewalContractPlanName","renewalACAInsuranceFee","renewalACAReInsuranceFee","renewalACAExchangeFee","estimatedRenewalPremium","memberLDClassID","parentTIN","payeeTIN","writingTIN","deductible","saleChannelId","currentRatingMethod","renewalRatingMethod","bundling","medLock","rateGuaranteeEndDate","targetRateGuaranteeMonths","enforceProdId1RateGuaranteeMonths","isPNCCurrProduct1","isPNCTarProduct1","rateAdjustFactor"};
		String anthembsonfeildName[] = {"PlanEffDate","AnnivMnth","RatingLevel","ProductType","EnrollmentType","ProductString","PlanName" ,"CurrRate" ,"CurrRate" ,"CurrentSubsidy","CurrentPremiumwithoutSubsidy","CurrentMemberSalary","CurrentMemberVolume","CurrentACAInsuranceFee","CurrentACAReInsuranceFee","CurrentACAExchangeFee","NewRate","NewRate","RenewalSubsidy","RenewalPremiumwithoutSubsidy","ProductString","ProductString","PlanName","RenewalACAInsuranceFee","RenewalACAReInsuranceFee","RenewalACAExchangeFee","EstimatedRenewalPremium ","MemberLDClassID","ParentTIN ","PayeeTIN","WritingTIN","Deductible","SaleChannelId","CurrentRatingMethod","RenewalRatingMethod","Bundling","MedLock","RateGuaranteeEndDate ","TargetRateGuaranteeMonths","EnforceProdId1RateGuaranteeMonths","isPNCCurrProduct1","isPNCTarProduct1","RateAdjustFactor"};
		
		for (int i = 0; i < FeildTokens.length; i++) {
			doReturn(bsonfeildName[i]).when(readMappingXmlMock).getAttributeValueOfField(
					IConstants.FACETS_ANTHEM_REN_DET.concat("_modified"), anthemBenefitFeildName[i], IConstants.VALUE);
		}
		
		
		ProcessFieldNames ISG_RENEWALSrenewalProductsModified = new ProcessFieldNames();

		ISG_RENEWALSrenewalProductsModified.setArrayFieldNames(
				"productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");

		doReturn(ISG_RENEWALSrenewalProductsModified).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
		
		
		ProcessFieldNames FACETS_ANTHEMrenewals = new ProcessFieldNames();
		ProcessFieldNames FACETS_ANTHEMcontacts = new ProcessFieldNames();
		ProcessFieldNames FACETS_ANTHEMagents = new ProcessFieldNames();
		
		
		FACETS_ANTHEMrenewals.setArrayFieldNames("renewalPeriod,renewalReference");
		FACETS_ANTHEMcontacts.setArrayFieldNames("addressType,addressLine1,addressLine2,addressLine3,countryCode,cityName,countyCode,countyName,stateCode,stateName,postalCode,phoneTypeCode,phoneAreaCode,phoneNumber,emailAddress");
		FACETS_ANTHEMagents.setArrayFieldNames("agentID,taxIDType,product,agentReference,name,AOREffectiveDate,AOREndDate");

		
		doReturn(FACETS_ANTHEMrenewals).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM.concat("renewals"));
		
		doReturn(FACETS_ANTHEMcontacts).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM.concat("contacts"));
		
		doReturn(FACETS_ANTHEMagents).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM.concat("agents"));
		

		utilityMock.applyZone(any(String.class), any(String.class), any(String.class), any(Document.class),
				any(String.class), any(Row.class), any(String.class));
		
		doReturn(true).when(changeDataCaptureMock).implementCdc(any(String.class), any(String.class), any(Document.class), any(List.class), any(List.class), any(String.class));
			
		facets.ingestTDMProcess("RDM", "Renewals_facets_Renewal", bsonFilterMock, "TDM", "Renewals_tdm_Client",
				appendCollection);
		

	}
	
	
	@Test
	public void facetsIngestTDM_Renewals_TestO65() throws Exception {

		BSONObject bsonObjectMock = bsonRawObjectO65;

		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);

		String appendCollection = "renewals,contacts,agents";

		ProcessFieldNames Renewals_tdm_ClientFieldNames = new ProcessFieldNames();
		Renewals_tdm_ClientFieldNames.setArrayFieldNames(
				"GUID,ID,type,relationship,subID,name,groupNumber,alternateID,billingEntity,associationName,associationCode,SIC,contactName,effectiveDate,renewalDate,association,paperBilling,accountManagerID,salesRepID,underwriterID,exchangeIndicator,size,source,businessCode,employeeCount,marketSegment,relationship,enrollmentType,firstName,middleName,lastName,dateofBirth,age,gender,tobaccoUsage,tobaccoWellness,otherWellness,medicareEligible,consumerChoice,calCobraStateContInd,cobraIndicator,status,MBUType");

		doReturn(Renewals_tdm_ClientFieldNames).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.FACETS_ANTHEM.concat("Renewals_tdm_Client").toString());

		ProcessFieldNames Renewals_tdm_RenewalFieldNames = new ProcessFieldNames();
		Renewals_tdm_RenewalFieldNames.setArrayFieldNames(
				"GUID,ID,type,relationship,clientReference,renewalMonth,renewalPeriod,renewalDate,estimatedLetterMailDate,currentMonthlyPremium,currentTotalPremium,currentPremiumwithoutSubsidy,currentPremiumwithSubsidy,currentRatingArea,currentSubsidy,renewalMonthlyPremium,renewalTotalPremium,renewalPremium,renewalPremiumwithoutSubsidy,renewalPremiumwithSubsidy,renewalRatingArea,renewalSubsidy,effectiveDate,renewalOptions,underwritingLevel,parentTIN,payeeTIN,writingTIN,exchangeIndicator,language,letterCode,letterCodeFlag,dentalEligibleEmployees,visGuaranteeMonths,denGuaranteeMonths,denPriorCoverage,saveAndGenerateFlag,renewalPacketToken,medicalFactorFlag,lifeFlag,enableGviFlag,MBUType,groupChangeInd,memberChangeInd,dentalSubscriberCnt,visionSubscriberCnt,targetDntlElgibleLivesCnt,targetVisElgibleLivesCnt,currDntlElgibleLivesCnt,currVisElgibleLivesCnt,dentalPriorCoverage,currentContractCode,renewalContractCode,currentDependentsCovered,renewalDependentsCovered,Delta");

		doReturn(Renewals_tdm_RenewalFieldNames).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.FACETS_ANTHEM.concat("Renewals_tdm_Renewal").toString());

		ProcessFieldNames FACETS_ANTHEMBenefits = new ProcessFieldNames();
		

		String FeildTokens[] = { "GUID", "ID", "type", "relationship" };

		String bsonfeildName[] = { "GUID", "SubId", "Type", "relationship" };

		for (int i = 0; i < FeildTokens.length; i++) {
			doReturn(bsonfeildName[i]).when(readMappingXmlMock).getAttributeValueOfField(
					IConstants.FACETS_ANTHEM.concat("Renewals_tdm_Renewal"), FeildTokens[i], IConstants.VALUE);
		}

		FACETS_ANTHEMBenefits.setArrayFieldNames(
				"effectiveDate,renewalDate,ratingTier,productType,enrollmentType,currentContractPlanCode,currentContractPlanName,currentMonthlyPremium,currentTotalPremium,currentSubsidy,currentPremiumwithoutSubsidy,currentMemberSalary,currentMemberVolume,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee,renewalMonthlyPremium,renewalTotalPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanCode,renewalContractPlanName,renewalACAInsuranceFee,renewalACAReInsuranceFee,renewalACAExchangeFee,estimatedRenewalPremium,memberLDClassID,parentTIN,payeeTIN,writingTIN,deductible,saleChannelId,currentRatingMethod,renewalRatingMethod,bundling,medLock,rateGuaranteeEndDate,targetRateGuaranteeMonths,enforceProdId1RateGuaranteeMonths,isPNCCurrProduct1,isPNCTarProduct1,rateAdjustFactor");

		doReturn(FACETS_ANTHEMBenefits).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM_REN_DET);

		
		String anthemBenefitFeildName[] = {"effectiveDate","renewalDate","ratingTier","productType","enrollmentType","currentContractPlanCode","currentContractPlanName","currentMonthlyPremium","currentTotalPremium","currentSubsidy","currentPremiumwithoutSubsidy","currentMemberSalary","currentMemberVolume","currentACAInsuranceFee","currentACAReInsuranceFee","currentACAExchangeFee","renewalMonthlyPremium","renewalTotalPremium","renewalSubsidy","renewalPremiumwithoutSubsidy","renewalContractCode","renewalContractPlanCode","renewalContractPlanName","renewalACAInsuranceFee","renewalACAReInsuranceFee","renewalACAExchangeFee","estimatedRenewalPremium","memberLDClassID","parentTIN","payeeTIN","writingTIN","deductible","saleChannelId","currentRatingMethod","renewalRatingMethod","bundling","medLock","rateGuaranteeEndDate","targetRateGuaranteeMonths","enforceProdId1RateGuaranteeMonths","isPNCCurrProduct1","isPNCTarProduct1","rateAdjustFactor"};
		String anthembsonfeildName[] = {"PlanEffDate","AnnivMnth","RatingLevel","ProductType","EnrollmentType","ProductString","PlanName" ,"CurrRate" ,"CurrRate" ,"CurrentSubsidy","CurrentPremiumwithoutSubsidy","CurrentMemberSalary","CurrentMemberVolume","CurrentACAInsuranceFee","CurrentACAReInsuranceFee","CurrentACAExchangeFee","NewRate","NewRate","RenewalSubsidy","RenewalPremiumwithoutSubsidy","ProductString","ProductString","PlanName","RenewalACAInsuranceFee","RenewalACAReInsuranceFee","RenewalACAExchangeFee","EstimatedRenewalPremium ","MemberLDClassID","ParentTIN ","PayeeTIN","WritingTIN","Deductible","SaleChannelId","CurrentRatingMethod","RenewalRatingMethod","Bundling","MedLock","RateGuaranteeEndDate ","TargetRateGuaranteeMonths","EnforceProdId1RateGuaranteeMonths","isPNCCurrProduct1","isPNCTarProduct1","RateAdjustFactor"};
		
		for (int i = 0; i < FeildTokens.length; i++) {
			doReturn(bsonfeildName[i]).when(readMappingXmlMock).getAttributeValueOfField(
					IConstants.FACETS_ANTHEM_REN_DET.concat("_modified"), anthemBenefitFeildName[i], IConstants.VALUE);
		}
		
		
		ProcessFieldNames ISG_RENEWALSrenewalProductsModified = new ProcessFieldNames();

		ISG_RENEWALSrenewalProductsModified.setArrayFieldNames(
				"productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");

		doReturn(ISG_RENEWALSrenewalProductsModified).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));
		
		
		ProcessFieldNames FACETS_ANTHEMrenewals = new ProcessFieldNames();
		ProcessFieldNames FACETS_ANTHEMcontacts = new ProcessFieldNames();
		ProcessFieldNames FACETS_ANTHEMagents = new ProcessFieldNames();
		
		
		FACETS_ANTHEMrenewals.setArrayFieldNames("renewalPeriod,renewalReference");
		FACETS_ANTHEMcontacts.setArrayFieldNames("addressType,addressLine1,addressLine2,addressLine3,countryCode,cityName,countyCode,countyName,stateCode,stateName,postalCode,phoneTypeCode,phoneAreaCode,phoneNumber,emailAddress");
		FACETS_ANTHEMagents.setArrayFieldNames("agentID,taxIDType,product,agentReference,name,AOREffectiveDate,AOREndDate");

		
		doReturn(FACETS_ANTHEMrenewals).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM.concat("renewals"));
		
		doReturn(FACETS_ANTHEMcontacts).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM.concat("contacts"));
		
		doReturn(FACETS_ANTHEMagents).when(fileNamesPropertiesMock).getPropertyContext(IConstants.FACETS_ANTHEM.concat("agents"));
		

		utilityMock.applyZone(any(String.class), any(String.class), any(String.class), any(Document.class),
				any(String.class), any(Row.class), any(String.class));
		
		doReturn(true).when(changeDataCaptureMock).implementCdc(any(String.class), any(String.class), any(Document.class), any(List.class), any(List.class), any(String.class));
			
		
		facets.ingestTDMProcess("RDM", "Renewals_facets_Renewal", bsonFilterMock, "TDM", "Renewals_tdm_Renewal",appendCollection);
		

	}

	@Test
	public void facetsgetRenewalProductsTest() throws Exception {

		String sourceCollection = "Renewals_facets_Renewal";
		Document outerDoc = conDocument;
		List<Document> renewalProducts = new ArrayList<>();

		ProcessFieldNames ISG_RENEWALSrenewalProductsModified = new ProcessFieldNames();

		ISG_RENEWALSrenewalProductsModified.setArrayFieldNames(
				"productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");

		doReturn(ISG_RENEWALSrenewalProductsModified).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));

		Document doc = new Document();

		renewalProducts.add(doc);

		/*
		 * This method is not used anywhere in the Project just for code
		 * coverage added this test method
		 */
		facets.getRenewalProducts(sourceCollection, outerDoc);

	}
	
	
	@Test
	public void facetsgetRenewalProductsExceptionTest() throws Exception {

		String sourceCollection = "Renewals_facets_Renewal";
		Document outerDoc = conDocument;
		List<Document> renewalProducts = new ArrayList<>();

		ProcessFieldNames ISG_RENEWALSrenewalProductsModified = new ProcessFieldNames();

		ISG_RENEWALSrenewalProductsModified.setArrayFieldNames(
				"productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");

		when(fileNamesPropertiesMock.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED))).thenThrow(Exception.class);

		Document doc = new Document();

		renewalProducts.add(doc);

		/*
		 * This method is not used anywhere in the Project just for code
		 * coverage added this test method
		 */
		facets.getRenewalProducts(sourceCollection, outerDoc);

	}

	@Test
	public void facetsgetGrpRenewalProductsTest() throws Exception {

		String sourceCollection = "Renewals_facets_Renewal";

		Document outerDoc = benefitDocument;

		Document summaryDoc = conDocument;

		ProcessFieldNames ISG_RENEWALSrenewalProductsModified = new ProcessFieldNames();

		ISG_RENEWALSrenewalProductsModified.setArrayFieldNames(
				"productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");

		doReturn(ISG_RENEWALSrenewalProductsModified).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));

		facets.getGrpRenewalProducts(sourceCollection, outerDoc, summaryDoc);

	}
	
	@Test
	public void facetsgetGrpRenewalProductsExceptionTest() throws Exception {

		String sourceCollection = "Renewals_facets_Renewal";

		Document outerDoc = benefitDocument;

		Document summaryDoc = conDocument;

		ProcessFieldNames ISG_RENEWALSrenewalProductsModified = new ProcessFieldNames();

		ISG_RENEWALSrenewalProductsModified.setArrayFieldNames(
				"productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");
		
		when(fileNamesPropertiesMock.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED))).thenThrow(Exception.class);

		facets.getGrpRenewalProducts(sourceCollection, outerDoc, summaryDoc);

	}

	@Test
	public void facetsgetGrpRenewalProductsU65Test() throws Exception {

		String sourceCollection = "Renewals_facets_Renewal";
		Document outerDoc = benefitDocument;
		Document summaryDoc = conDocument;

		ProcessFieldNames ISG_RENEWALSrenewalProductsModified = new ProcessFieldNames();

		ISG_RENEWALSrenewalProductsModified.setArrayFieldNames(
				"productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");

		doReturn(ISG_RENEWALSrenewalProductsModified).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));

		facets.getGrpRenewalProductsU65(sourceCollection, outerDoc, summaryDoc);
		
	}

	@Test
	public void facetsIngestUDMProcessExceptionTest() {

		BSONObject bsonObjectMock = bsonTDMObject;

		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		
		facets.ingestUDMProcess("TDM", "Renewals_tdm_Client", bsonFilterMock, "ADS","Renewals_udm_Client", "None");
	}
	
	@Test
	public void facetsIngestUDMProcessTest() {

		BSONObject bsonObjectMock = bsonTDMObject;

		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		
		facets.ingestUDMProcess("TDM", "Renewals_tdm_Client", bsonFilterMock, "ADS","Renewals_udm_Client", "None");
		
	}

	@Test
	public void facetsIngestSDSProcessTest() {

		String sourceCollection = "Renewals_facets_Renewal";

		Document outerDoc = benefitDocument;

		Document summaryDoc = conDocument;

		String targetCollection = "Renewals_Summary";

		String targetDetailCollection = "Renewal_Details";

		String sourceDbTDM = "TDM";

		ProcessFieldNames groupSummaryModified = new ProcessFieldNames();

		groupSummaryModified.setArrayFieldNames(
				"ID,renewalDate,alternateID,groupID,type,groupStatus,sourceID,effectiveDate,groupName,SIC,size,association,agents,contacts");

		String sourceDb = "UDM";

		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonTDMObject);

		facets.ingestSDSProcess(sourceDb, sourceCollection, bsonFilterMock, groupSummaryModified, "SDS",
				targetCollection, targetDetailCollection, sourceDbTDM);

	}

	@Test
	public void facetsIngestSDSProcessTest2() {

		String sourceCollection = "Renewals_facets_Renewal";

		String sourceDb = "UDM";

		facets.ingestSDSProcess(sourceDb, sourceCollection);
	}
	
	
	@Test
	public void facetsIngestSDSProcessTest3() {
		
		 String[] sourceColl ={"Renewals_udm_Client","Renewals_udm_Renewal"};
		 
		 String sourceDb = "UDM";

	     Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonTDMObject);
		
		String targetDb = "SDS";
		
		String sourceCollection = "Renewals_facets_Renewal";

		String targetCollection = "Renewals_Summary";

		String targetDetailCollection = "Renewal_Details";

		facets.ingestSDSProcess( sourceDb,  sourceColl,  bsonFilterMock, targetDb,  targetCollection,  sourceDb);
		
	}
	
	
	@Test
	public void addGrpDeltaTest() {
		
		double currentMonthlyPremium = 1000.21;
		double monthlyPremium = 2500.28;
		double delta = 13.84;
	
		Document benefitDocument = new Document();
		benefitDocument.append("ID","008M64601");
		benefitDocument.append("renewalDate","Sat Jun 01 09:30:00 IST 2019");
		benefitDocument.append("type","IND");
		benefitDocument.append("effectiveDate","Sat Jun 01 09:30:00 IST 2019");
		benefitDocument.append("firstName","Transalyviya");
		benefitDocument.append("lastName","Brown");
		benefitDocument.append("dateofBirth","6/1/1980");
		benefitDocument.append("currentMonthlyPremium",currentMonthlyPremium);
		benefitDocument.append("monthlyPremium",monthlyPremium);
		benefitDocument.append("Delta",delta);
		
		facets.addGrpDelta(benefitDocument);
	}
	
	@Test
	public void addGrpDeltaTestTwo() {
	
		double currentMonthlyPremium = 1000.21;
		double monthlyPremium = 2500.28;
		
		Document benefitDocument = new Document();
		benefitDocument.append("ID","008M64601");
		benefitDocument.append("lastName","Brown");
		benefitDocument.append("dateofBirth","6/1/1980");
		benefitDocument.append("currentMonthlyPremium",currentMonthlyPremium);
		benefitDocument.append("monthlyPremium",monthlyPremium);
		
		facets.addGrpDelta(benefitDocument);
	}
	
	@Test(expected=AssertionError.class)
	public void addGrpDeltaTestException() {
	
		Document benefitDocument = new Document();
		benefitDocument.append("ID","008M64601");
		benefitDocument.append("lastName","Brown");
		benefitDocument.append("dateofBirth","6/1/1980");
		benefitDocument.append("currentMonthlyPremium","0.0");
		benefitDocument.append("monthlyPremium","0.0");
		
		Exception e = new Exception();
		
		facets.addGrpDelta(benefitDocument);
		
		Assert.assertEquals(null, e);
		
	}
	

	@Test
	public void facetsIngestRDMprocessTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, ParseException
	{
		List<String> facetsList = new ArrayList<>();
		facetsList.add("Sub ID,Meme Ck,Sub First Name,Sub Last Name,Addr 1,Addr 2,City,State,Zip,Sub Phone,Sub Gender,Sub DOB,Renewal Group ID,Curr Rate,New Rate,Difference %,New Risk Factor - Elec,New Risk Factor - Papr,Old Risk Factor - Elec,Old Risk Factor - Papr,Plan Name,Deductible,GA Name,GA Addr 1,GA Addr 2,GA City,GA State,GA Zip,GA TIN,Agent Name,Agent Number,Agent Addr 1,Agent Addr 2,Agent City,Agent State,Agent Zip,Sub Bill Mode,Rate Renewal Date,Record Type,Stat Structure State,Hipaa Agreement,Agent Rel Term Date,Last Column Indicator");
		facetsList.add("449M54947,,Robin,Didonna,4522 Sheraton Dr,,Parma,OH,44134,,M,,60918,$218.19 ,$225.08 ,3.16%,0,0,1,1.745,Med Select F,N/A,,,, , , , ,,INI719812,,, , , ,M,7/1/2016,M,OH,N,,1");
		
		ProcessInput processInput = new ProcessInput();
		processInput.setSourceDB("RAW");
		processInput.setSourceCollection("Renewals_facets_Renewal");
		processInput.setDelimeted("true");
		processInput.setDelimeter("\\,");
		processInput.setType("facets_renewal_Anthem_O65");
		processInput.setFileType("FACETS");
		processInput.setFailedCollection("Renewals_facets_DQ_Reject");
		
		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/FACETS/AnthemU65/ANTHEM_IN_031218_SU65_060118_F1_update.csv";
		String guidvalue = "SubId,SubId,AnnivMnth,ProductType"; 
		String strType = "com.anthem.marketplace.dataconsolidation.filesutils.FACETS" ;
	
		SparkConf conf = new SparkConf().setAppName("Spark Count").setMaster("local").set("user.name", "test");
		JavaSparkContext sparkContext = new JavaSparkContext(conf);
	
		doReturn(javaPairRddMock).when(javaSparkContextMock).wholeTextFiles(any(String.class));
		doReturn(sparkContext.parallelize(facetsList)).when(javaPairRddMock).flatMap((any(org.apache.spark.api.java.function.FlatMapFunction.class)));
		
		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);
		doReturn(true).when(mongoConnectorMock).insertData(Matchers.anyListOf(Document.class), any(String.class), any(String.class), any(String.class));
			
		//GUID
		
		String type = "facets_renewal_Anthem_O65";

		doReturn("0").when(readMappingXmlMock).getIndex(type, "SubId");
		doReturn("0").when(readMappingXmlMock).getIndex(type, "SubId");
		doReturn("37").when(readMappingXmlMock).getIndex(type, "AnnivMnth");
		doReturn("38").when(readMappingXmlMock).getIndex(type, "ProductType");
		
	
		//Create flag :
		Map<String, String> mandatoryFields = new HashMap<String, String>();

		mandatoryFields.put("49", "AgentNumber");
		mandatoryFields.put("7", "State");
		// mandatoryFields.put("0","State");

		// String item = "49";

		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(type, IConstants.REQUIRED_ATTRIBUTE);
		
		
		//append raw :

		String dataType = "String";
		String dataTypeDate = "Date MM/DD/YYYY";
		String fieldNames[] = { "SubId", "SubFirstName", "SubLastName" };
		String indexarray[] = { "0", "2", "3" };

		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames.setArrayFieldNames(
				"SubId,SubFirstName,SubLastName,Addr1,Addr2,City,State,Zip,SubPhone,SubDOB,DepName1,DepName2,DepName3,DepName4,CurrRate,NewRate,Difference%,RatingLevel,PlanName,Deductible,AgentName,AgentNumber,PlanEffDate,AnnivMnth,ProductType,ProductString,null");

		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);

		for (int i = 0; i < indexarray.length; i++) {
			doReturn(indexarray[i]).when(readMappingXmlMock).getIndex(type, fieldNames[i]);

			if (fieldNames[i].equalsIgnoreCase("AnnivMnth")) {
				doReturn(dataTypeDate).when(readMappingXmlMock).getAttributeValueOfField(type, fieldNames[i],
						IConstants.DATATYPE);
			} else {
				doReturn(dataType).when(readMappingXmlMock).getAttributeValueOfField(type, fieldNames[i],
						IConstants.DATATYPE);
			}

		}

		PowerMockito.doAnswer(new Answer<Void>() {
			@Override
			public Void answer(InvocationOnMock invocation) throws ParseException {
				Document doc = (Document) invocation.getArguments()[3];

				String datatype = (String) invocation.getArguments()[4];
				String fieldName = (String) invocation.getArguments()[1];
				String value = (String) invocation.getArguments()[2];

				if (datatype.equalsIgnoreCase("Date MM/DD/YYYY")) {
					DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
					formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
					Date date = formatter.parse(value);
					doc.append(fieldName, date);
				} else if (datatype.equalsIgnoreCase("Double")) {

					if (value.equals(null) || value.trim().equals("") || value.equalsIgnoreCase("null")
							|| value.trim().isEmpty()) {
						doc.append(fieldName, null);
					} else {

						value = value.replaceAll(IConstants.COMMA, "").replaceAll("\\$", "");

						if (value.indexOf('-') == value.length() - 1)
							value = '-' + value.substring(0, value.length() - 1);
						doc.append(fieldName, Double.parseDouble(value));
					}
				} else {
					doc.append((String) invocation.getArguments()[1], value);
				}
				return null;
			}
		}).when(Utility.class);
		
		

		utilityMock.applyZone(any(String.class), any(String.class), any(String.class), any(Document.class),
				any(String.class), any(Row.class), any(String.class));
		
		doReturn(true).when(changeDataCaptureMock).implementCdc(any(String.class), any(String.class), any(Document.class), any(List.class), any(List.class), any(String.class));
		
		facets.ingestRDMprocess(processInput,sourcePath,guidvalue,strType);
		
		
	
		
	}
	
	


}



