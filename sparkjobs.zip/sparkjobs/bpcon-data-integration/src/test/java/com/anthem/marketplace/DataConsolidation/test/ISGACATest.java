package com.anthem.marketplace.DataConsolidation.test;


import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.bson.BSONObject;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.filesutils.ISG_ACA;
import com.anthem.marketplace.dataconsolidation.filesutils.UtilityInterface;
import com.anthem.marketplace.dataconsolidation.job.processor.IngestRDM;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.FixedFileMetaDataProperties;
import com.anthem.marketplace.dataconsolidation.utils.GetSysProperties;
import com.anthem.marketplace.dataconsolidation.utils.GuidProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.InputConnectors;
import com.anthem.marketplace.dataconsolidation.utils.InputProperties;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFixedFileMetaData;
import com.anthem.marketplace.dataconsolidation.utils.ProcessGuid;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXml;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SystemProperties;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.mongodb.util.JSON;

import scala.Tuple2;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "org.apache.hadoop.*", "javax.*", "com.sun.org.apache.*", "org.apache.log4j.*", "org.w3c.dom.*",
		"org.apache.xerces.*" })
@PrepareForTest({ ISG_ACA.class, ReadMappingXmlSingleton.class, MongoConnector.class, FieldNamesProperties.class,
		FixedFileMetaDataProperties.class, ReadMappingXml.class, Utility.class, UtilityInterface.class,
		SparkContextSingleton.class })

public class ISGACATest {

	@Mock
	ReadMappingXmlSingleton readMappingXmlSingletonMock;

	@Mock
	ReadMappingXml readMappingXmlMock;

	@Mock
	SparkContextSingleton sparkContextSingletonMock;

	@Mock
	JavaSparkContext javaSparkContextMock;

	@Mock
	FieldNamesProperties fileNamesPropertiesMock;

	@Mock
	MongoConnector mongoConnectorMock;

	@Mock
	FixedFileMetaDataProperties fixedFileMetaDataPropertiesMock;

	// @Mock
	GuidProperties guidPropertiesMock;

	@Mock
	GetSysProperties getSysPropertiesMock;

	@Mock
	InputConnectors inputConnectorsMock;

	@Mock
	InputProperties inputPropertiesMock;

	@Mock
	ProcessInput processInput;

	@Mock
	ProcessGuid processGuid;

	@Mock
	IngestRDM irdObj;

	@Mock
	UtilityInterface utilityInterface;

	@Mock
	SystemProperties systemProperties;

	@Mock
	BSONObject bsonObjectMock;

	@Mock
	Utility utility;

	ISG_ACA isgaca = (ISG_ACA) Utility
			.createObject("com.anthem.marketplace.dataconsolidation.filesutils.ISG_ACA");

	String sourceCollection = "ISG(ACA)";

	String delimeted = " ";

	static final Logger logger = LoggerFactory.getLogger(IngestRDM.class);

	@Before
	public void setup() {

		/* ReadMappingXml Mock Singleton */

		PowerMockito.mockStatic(ReadMappingXmlSingleton.class);

		readMappingXmlSingletonMock = PowerMockito.mock(ReadMappingXmlSingleton.class);
		PowerMockito.when(ReadMappingXmlSingleton.getInstance()).thenReturn(readMappingXmlSingletonMock);

		readMappingXmlMock = PowerMockito.mock(ReadMappingXml.class);
		doReturn(readMappingXmlMock).when(readMappingXmlSingletonMock).getRead();

		/* SparkContextSingleton Mock Singleton */
		PowerMockito.mockStatic(SparkContextSingleton.class);

		sparkContextSingletonMock = PowerMockito.mock(SparkContextSingleton.class);
		PowerMockito.when(SparkContextSingleton.getInstance()).thenReturn(sparkContextSingletonMock);

		javaSparkContextMock = PowerMockito.mock(JavaSparkContext.class);
		doReturn(javaSparkContextMock).when(sparkContextSingletonMock).getSparkContext();

		/* MongoConnector Mock */
		PowerMockito.mockStatic(MongoConnector.class);
		mongoConnectorMock = PowerMockito.mock(MongoConnector.class);

		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);

		/* FieldNamesProperties Mock */
		PowerMockito.mockStatic(FieldNamesProperties.class);
		fileNamesPropertiesMock = PowerMockito.mock(FieldNamesProperties.class);

		PowerMockito.when(FieldNamesProperties.getInstance()).thenReturn(fileNamesPropertiesMock);

		/* FixedFileMetaDataProperties Mock */
		PowerMockito.mockStatic(FixedFileMetaDataProperties.class);
		fixedFileMetaDataPropertiesMock = PowerMockito.mock(FixedFileMetaDataProperties.class);
		PowerMockito.when(FixedFileMetaDataProperties.getInstance()).thenReturn(fixedFileMetaDataPropertiesMock);

		/* GuidProperties Mock */
		// PowerMockito.mockStatic(GuidProperties.class);
		guidPropertiesMock = PowerMockito.mock(GuidProperties.class);

		// PowerMockito.when(GuidProperties.getInstance()).thenReturn(guidPropertiesMock);

		/* GuidProperties Mock */
		// PowerMockito.mockStatic(GetSysProperties.class);
		getSysPropertiesMock = PowerMockito.mock(GetSysProperties.class);

		// PowerMockito.when(GetSysProperties.getInstance()).thenReturn(getSysPropertiesMock);

		/* InputConnectors Mock */
		// PowerMockito.mockStatic(InputConnectors.class);
		inputConnectorsMock = PowerMockito.mock(InputConnectors.class);

		// PowerMockito.when(InputConnectors.getInstance()).thenReturn(inputConnectorsMock);

		/* InputProperties Mock */
		// PowerMockito.mockStatic(InputProperties.class);
		inputPropertiesMock = PowerMockito.mock(InputProperties.class);

		// PowerMockito.when(InputProperties.getInstance()).thenReturn(inputPropertiesMock);

		/* Utility Mock */
		PowerMockito.mockStatic(Utility.class);

	}

	@Test
	public void createGuidSubscriberNullpointerTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_ISG_Renewal_ACA_sub";
		String delimeted = "false";
		Row readFileContent = RowFactory.create(
				"05112018                    FAITH                         P                             EEDECPASSTWO                            021T61236           KYBMGMPKLPLY                                                  BMGMPKLPLY                                                  BMGMPKLPLY                                                  ANTHEM SILVER PATHWAY X HMO 3500 S04                                                                                                                                                                                                                                                                                                                                                   1H88                          ANTHEM SILVER PATHWAY X HMO 3500 S04                                                                                                                                                                                                                                                                                                                                                   1H88                          PBACA          01012018                654.01    779.16    0.00      0.00      1030.49   0.00      0.00      DO NOT MAIL2                            DO NOT MAIL                                                                                                             BLAINE                        KY41124      DO NOT MAIL2                            DO NOT MAIL                                                                                                             BLAINE                        KY41124      ENG                          10012017                07                125.15    36239KY1140005                     ABC@XYZ.COM                                       1155.64                                                                         RN   NA   NA     HMO HMO N 0.00         0.00         0.00         0.00         ");
		String guidvalue = "HCID,HCID";
		String type = "isg_renewal_indsub";
		isgaca.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}
	
	@Test
	public void createGuidMemberNullpointerTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_ISG_Renewal_ACA_mem";
		String delimeted = "false";
		Row readFileContent = RowFactory.create(
				"021T61236           020      FAITH                         P                             EEDECPASSTWO                            0426198334 YNNU               ");
		String guidvalue = "HCID,HCID,MBR_CODE";
		String type = "isg_renewal_indmem";
		isgaca.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}
	
	@Test
	public void createGuidSubscriberArrayIndexOutOfBoundsExceptionTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_ISG_Renewal_ACA_sub";
		String delimeted = "false";
		Row readFileContent = RowFactory.create(
				"05112018                    FAITH                         P                             EEDECPASSTWO                            021T61236           KYBMGMPKLPLY                                                  BMGMPKLPLY                                                  BMGMPKLPLY                                                  ANTHEM SILVER PATHWAY X HMO 3500 S04                                                                                                                                                                                                                                                                                                                                                   1H88                          ANTHEM SILVER PATHWAY X HMO 3500 S04                                                                                                                                                                                                                                                                                                                                                   1H88                          PBACA          01012018                654.01    779.16    0.00      0.00      1030.49   0.00      0.00      DO NOT MAIL2                            DO NOT MAIL                                                                                                             BLAINE                        KY41124      DO NOT MAIL2                            DO NOT MAIL                                                                                                             BLAINE                        KY41124      ENG                          10012017                07                125.15    36239KY1140005                     ABC@XYZ.COM                                       1155.64                                                                         RN   NA   NA     HMO HMO N 0.00         0.00         0.00         0.00         ");
		String guidvalue = "HCID,HCID";
		String type = "isg_renewal_indsub";
		
		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("HCID", type);

		when(fixedFileMetaDataPropertiesMock.getPropertyContext("HCID", type)).thenThrow(new ArrayIndexOutOfBoundsException("Arry out of Bound Exception"));
		
		isgaca.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}
	
	@Test
	public void createGuidSubscriberNumberFormatExceptionTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_ISG_Renewal_ACA_sub";
		String delimeted = "false";
		Row readFileContent = RowFactory.create(
				"05112018                    FAITH                         P                             EEDECPASSTWO                            021T61236           KYBMGMPKLPLY                                                  BMGMPKLPLY                                                  BMGMPKLPLY                                                  ANTHEM SILVER PATHWAY X HMO 3500 S04                                                                                                                                                                                                                                                                                                                                                   1H88                          ANTHEM SILVER PATHWAY X HMO 3500 S04                                                                                                                                                                                                                                                                                                                                                   1H88                          PBACA          01012018                654.01    779.16    0.00      0.00      1030.49   0.00      0.00      DO NOT MAIL2                            DO NOT MAIL                                                                                                             BLAINE                        KY41124      DO NOT MAIL2                            DO NOT MAIL                                                                                                             BLAINE                        KY41124      ENG                          10012017                07                125.15    36239KY1140005                     ABC@XYZ.COM                                       1155.64                                                                         RN   NA   NA     HMO HMO N 0.00         0.00         0.00         0.00         ");
		String guidvalue = "HCID,HCID";
		String type = "isg_renewal_indsub";
		
		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("HCID", type);

		when(fixedFileMetaDataPropertiesMock.getPropertyContext("HCID", type)).thenThrow(new NumberFormatException ("NumberFormatException "));
		
		isgaca.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}
	
	@Test
	public void createGuidSubscriberExceptionTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_ISG_Renewal_ACA_sub";
		String delimeted = "false";
		Row readFileContent = RowFactory.create(
				"05112018                    FAITH                         P                             EEDECPASSTWO                            021T61236           KYBMGMPKLPLY                                                  BMGMPKLPLY                                                  BMGMPKLPLY                                                  ANTHEM SILVER PATHWAY X HMO 3500 S04                                                                                                                                                                                                                                                                                                                                                   1H88                          ANTHEM SILVER PATHWAY X HMO 3500 S04                                                                                                                                                                                                                                                                                                                                                   1H88                          PBACA          01012018                654.01    779.16    0.00      0.00      1030.49   0.00      0.00      DO NOT MAIL2                            DO NOT MAIL                                                                                                             BLAINE                        KY41124      DO NOT MAIL2                            DO NOT MAIL                                                                                                             BLAINE                        KY41124      ENG                          10012017                07                125.15    36239KY1140005                     ABC@XYZ.COM                                       1155.64                                                                         RN   NA   NA     HMO HMO N 0.00         0.00         0.00         0.00         ");
		String guidvalue = "HCID,HCID";
		String type = "isg_renewal_indsub";
		
		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("HCID", type);

		when(fixedFileMetaDataPropertiesMock.getPropertyContext("HCID", type)).thenThrow(new NullPointerException("Exception"));
		
		isgaca.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}
	
	@Test
	public void createGuidMemberClassCastExceptionTest() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_ISG_Renewal_ACA_mem";
		String delimeted = "false";
		Row readFileContent = RowFactory.create(
				"021T61236           020      FAITH                         P                             EEDECPASSTWO                            0426198334 YNNU               ");
		String guidvalue = "HCID,HCID,MBR_CODE";
		String type = "isg_renewal_indmem";
		
		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("HCID", type);

		when(fixedFileMetaDataPropertiesMock.getPropertyContext("HCID", type)).thenThrow(new ClassCastException("ClassCastException"));
		
		isgaca.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
		}
	
	
	
	
	@Test
	public void createGuidSubscriberTest2() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_ISG_Renewal_ACA_sub";
		String delimeted = "false";
		Row readFileContent = RowFactory.create(
				"05112018                    FAITH                         P                             EEDECPASSTWO                            021T61236           KYBMGMPKLPLY                                                  BMGMPKLPLY                                                  BMGMPKLPLY                                                  ANTHEM SILVER PATHWAY X HMO 3500 S04                                                                                                                                                                                                                                                                                                                                                   1H88                          ANTHEM SILVER PATHWAY X HMO 3500 S04                                                                                                                                                                                                                                                                                                                                                   1H88                          PBACA          01012018                654.01    779.16    0.00      0.00      1030.49   0.00      0.00      DO NOT MAIL2                            DO NOT MAIL                                                                                                             BLAINE                        KY41124      DO NOT MAIL2                            DO NOT MAIL                                                                                                             BLAINE                        KY41124      ENG                          10012017                07                125.15    36239KY1140005                     ABC@XYZ.COM                                       1155.64                                                                         RN   NA   NA     HMO HMO N 0.00         0.00         0.00         0.00         ");
		String guidvalue = "HCID,HCID";
		String type = "isg_renewal_indsub";

		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("129");
		processFixedFileMetaData.setend("148");

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("HCID", type);

		isgaca.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}
	
	@Test
	public void createGuidMemberTest2() throws ClassNotFoundException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		String sourceCollection = "Renewals_ISG_Renewal_ACA_mem";
		String delimeted = "false";
		Row readFileContent = RowFactory.create(
				"021T61236           020      FAITH                         P                             EEDECPASSTWO                            0426198334 YNNU               ");
		String guidvalue = "HCID,HCID,MBR_CODE";
		String type = "isg_renewal_indmem";

		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("129");
		processFixedFileMetaData.setend("148");
		ProcessFixedFileMetaData processFixedFileMetaData2 = new ProcessFixedFileMetaData();
		processFixedFileMetaData2.setstart("21");
		processFixedFileMetaData2.setend("29");

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("HCID", type);
		doReturn(processFixedFileMetaData2).when(fixedFileMetaDataPropertiesMock).getPropertyContext("MBR_CODE", type);

		isgaca.createGuid(sourceCollection, delimeted, readFileContent, guidvalue, type);
	}

	@Test
	public void createFlagTest() throws NullPointerException, ArrayIndexOutOfBoundsException, ClassCastException,
			NumberFormatException, Exception {

		String sourceCollection = "Renewals_ISG_Renewal_ACA_mem";
		String delimeted = "false";
		Row readFileContent = RowFactory.create(
				"021T61236           020      FAITH                         P                             EEDECPASSTWO                            0426198334 YNNU               ");

		String type = "isg_renewal_indmem";

		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("11");
		processFixedFileMetaData.setend("20");

		Map<String, String> mandatoryFields = new HashMap<String, String>();
		mandatoryFields.put("1", "GroupID1");

		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(any(String.class), any(String.class));

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("GroupID1", type);

		isgaca.createFlag(delimeted, sourceCollection, readFileContent, type);

	}
	
	@Test
	public void createFlagTest2() throws NullPointerException, ArrayIndexOutOfBoundsException, ClassCastException,
			NumberFormatException, Exception {

		String sourceCollection = "Renewals_ISG_Renewal_ACA_mem";
		String delimeted = "false";
		Row readFileContent = RowFactory.create(
				"021T61236           020      FAITH                         P                             EEDECPASSTWO                            0426198334 YNNU               ");

		String type = "isg_renewal_indmem";

		//metadata = FixedFileMetaDataProperties.getInstance().getPropertyContext(item, type);
		
		
		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("HCID", type);

		when(fixedFileMetaDataPropertiesMock.getPropertyContext("HCID", type)).thenThrow(new ClassCastException("ClassCastException"));

		
		
		/*ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("11");
		processFixedFileMetaData.setend("20");*/

		Map<String, String> mandatoryFields = new HashMap<String, String>();
		mandatoryFields.put("1", "GroupID1");

		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(any(String.class), any(String.class));

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext("GroupID1", type);

		isgaca.createFlag(delimeted, sourceCollection, readFileContent, type);

	}

	@Test
	public void appendRawTest() throws NullPointerException, ArrayIndexOutOfBoundsException, ClassCastException,
			NumberFormatException, Exception {

		String sourcePath = "D:/372712/Employer Broker/FeedFile/apps/Renewals/WSGRS/MemberBenInfo";
		Row readFileContent = RowFactory.create(
				"70ACES    360853                 0000027129AAR9V     MED                 09702855901         09702855901         EMP609.6000                                                      942.53C01                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             REXTR V 2.0     2018101518000039");

		String type = "isgaca_membeninfodet";

		ProcessInput processInput1 = new ProcessInput();
		processInput1.setType("isgaca_membeninfodet");
		processInput1.setSourceDB("RAW");
		processInput1.setSourceCollection("Renewals_ISG_ACABenefits");

		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames.setArrayFieldNames(
				"Record_type,Source_ID,GroupID1,GroupID2,Filler1,Prod_ID1,Prod_ID2,Prod_ID3,Prod_ID4,Subscriber_ID,Member_ID,Enrollment_Type,Current_Monthly_Prem,Member_LD_ClassID,Curr_Member_Salary,Curr_Member_Vol,Curr_ACA_Ins_Fee,Curr_ACA_ReIns_Fee,Curr_ACA_Exchng_Fee,Renewal_Monthly_Premium,Filler2,Audit_Trail_OperatorId,Audit_Trail_Prog_NM,Audit_Trail_Process_DT,Audit_Trail_Process_Time");
		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(type);

		String dataType = "String";
		String fieldNames = "Record_type";

		doReturn(dataType).when(readMappingXmlMock).getAttributeValueOfField(type, fieldNames, IConstants.DATATYPE);

		ProcessFixedFileMetaData processFixedFileMetaData = new ProcessFixedFileMetaData();
		processFixedFileMetaData.setstart("11");
		processFixedFileMetaData.setend("20");
		processFixedFileMetaData.setFieldName(fieldNames);

		doReturn(processFixedFileMetaData).when(fixedFileMetaDataPropertiesMock).getPropertyContext(fieldNames, type);

		isgaca.appendRaw(processInput1, sourcePath, "360853EMPSUBSCRALL", true, readFileContent);
	}

	@Test(expected = NullPointerException.class)
	public void selectFieldsTest() {

		String value = "false";

		// String fieldNames = "medBrokerWritingTin" ;

		String type = "isgaca_gpinfodet";
		String fieldNames = "addressLine3";

		BSONObject bsonObjectMock = rawBSONObject();
		Tuple2<Object, BSONObject> bsonFilter = new Tuple2<>("1", bsonObjectMock);

		String collName = "contacts";

		String sourcecollection = "Renewals_ISG_ACABenefits";

		doReturn(value).when(readMappingXmlMock).getAttributeValueOfField(type, fieldNames, IConstants.DATATYPE);

		isgaca.selectFields(fieldNames, bsonFilter, collName, sourcecollection);

	}

	@Test(expected = NullPointerException.class)
	public void selectMultiFieldsTest() {

		String value = "false";

		// String fieldNames = "medBrokerWritingTin" ;

		String type = "isgnonaca_gpinfodet";
		String fieldNames = "addressLine3";

		BSONObject bsonObjectMock = rawBSONObject();
		Tuple2<Object, BSONObject> bsonFilter = new Tuple2<>("1", bsonObjectMock);

		String collName = "contacts";

		String sourcecollection = "Renewals_ISG_ACABenefits";

		doReturn(value).when(readMappingXmlMock).getAttributeValueOfField(type, fieldNames, IConstants.DATATYPE);

		isgaca.getClass();

		isgaca.selectMultiFields(fieldNames, bsonFilter, collName, sourcecollection);

	}

	@Test(expected = NullPointerException.class)
	public void isgnonacaIngestTDMProcessTest() throws Exception {
		BSONObject bsonObjectMock = rawBSONObject();
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		ProcessFieldNames clientFieldNames = new ProcessFieldNames();
		clientFieldNames.setArrayFieldNames(
				"ID,type,relationship,renewalDate,effectiveDate,monthlyPremium,currentMonthlyPremium");
		doReturn(clientFieldNames).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.ISG_ACA.concat("Renewals_tdm_Renewal").toString());

		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames.setArrayFieldNames(
				"effectiveDate,renewalDate,currentMonthlyPremium,currentTotalPremium,currentContractPlanName,renewalMonthlyPremium,renewalTotalPremium,renewalContractPlanName");
		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(IConstants.RENEWAL_DETAILS);

		Document doc = isgaca.ingestTDMProcess("RDM", "Renewals_ISG_ACABenefits", bsonFilterMock, "TDM",
				"Renewals_tdm_Client", "None");
	}

	@Test
	public void getRenewalProductsTest() throws Exception {

		String sourceCollection = "Renewals_ISG_ACABenefits";
		Document outerDoc = conDocument;
		List<Document> renewalProducts = new ArrayList<>();
		
		ProcessFieldNames ISG_RENEWALSrenewalProductsModified = new ProcessFieldNames();

		ISG_RENEWALSrenewalProductsModified.setArrayFieldNames(
				"productType,renewalMonthlyPremium,renewalSubsidy,renewalPremiumwithoutSubsidy,renewalContractCode,renewalContractPlanName,currentACAInsuranceFee,currentACAReInsuranceFee,currentACAExchangeFee");

		doReturn(ISG_RENEWALSrenewalProductsModified).when(fileNamesPropertiesMock)
				.getPropertyContext(IConstants.ISG_REN.concat("renewalProducts").concat(IConstants.MODIFIED));

		Document doc = new Document();

		renewalProducts.add(doc);

		/*
		 * This method is not used anywhere in the Project just for code
		 * coverage added this test method
		 */
		isgaca.getRenewalProducts(sourceCollection, outerDoc);
		isgaca.getRenewalProducts(sourceCollection, outerDoc, rawBSONObject());

	}

	public static BSONObject rawBSONObject() {
		String clientrdm = "{  \r\n" + " \"_id\" : ObjectId(\"5b2a1a533b113945328f942e\"),\r\n"
				+ " \"GUID\" : \"152559CAB20180601SGGROUPALL\",\r\n" + " \"Record_type\" : \"40\",\r\n"
				+ " \"State_CD\" : \"CA\",\r\n" + " \"Business_CD\" : \"B\",\r\n" + " \"MBU_Type\" : \"G\",\r\n"
				+ " \"Source_ID\" : \"WGS\",\r\n" + " \"GroupID1\" : \"152559\",\r\n" + " \"GroupID2\" : \"\",\r\n"
				+ " \"Target_Bill_Entity\" : \"152559\",\r\n" + " \"Group_Name\" : \"HARBOR HEALTH CARE INC\",\r\n"
				+ " \"Group_Billing_Addr1\" : \"16917 CLARK AVE\",\r\n" + " \"Group_Billing_Addr2\" : \"\",\r\n"
				+ " \"Group_Billing_City\" : \"BELLFLOWER\",\r\n" + " \"Group_Billing_State\" : \"CA\",\r\n"
				+ " \"Group_Billing_Zip\" : \"907060000\",\r\n" + " \"Group_Service_Addr1\" : \"16917 CLARK AVE\",\r\n"
				+ " \"Group_Service_Addr2\" : \"\",\r\n" + " \"Group_Service_City\" : \"BELLFLOWER\",\r\n"
				+ " \"Group_Service_State\" : \"CA\",\r\n" + " \"Group_Service_Zip\" : \"907060000\",\r\n"
				+ " \"Group_Service_County_CD\" : \"037\",\r\n"
				+ " \"Group_Contact_Name\" : \"CHERYL LOFLIN WERTZ\",\r\n"
				+ " \"Group_Original_EffDT\" : ISODate(\"2005-06-01T04:00:00.000Z\"),\r\n"
				+ " \"Group_RenewalDT\" : ISODate(\"2018-06-01T04:00:00.000Z\"),\r\n" + " \"Group_Status\" : \"0\",\r\n"
				+ " \"SIC\" : \"8399\",\r\n" + " \"Filler1\" : \"\",\r\n" + " \"Filler2\" : \"\",\r\n"
				+ " \"Filler3\" : \"\",\r\n" + " \"Association_CD\" : \"\",\r\n" + " \"Association_Name\" : \"\",\r\n"
				+ " \"Paper_Billing\" : \"\",\r\n" + " \"Filler4\" : \"\",\r\n" + " \"Filler5\" : \"\",\r\n"
				+ " \"Account_Manager_ID\" : \"CA099\",\r\n" + " \"Sales_Rep_ID\" : \"GM005\",\r\n"
				+ " \"Underwriter_ID\" : \"999\",\r\n" + " \"OnExchangeInd\" : \"OF\",\r\n"
				+ " \"Group_SizeInd\" : \"1\",\r\n" + " \"Renewal_Format\" : \"acarenewal\",\r\n"
				+ " \"Group_Change_Ind\" : \"\",\r\n" + " \"Member_Change_Ind\" : \"\",\r\n"
				+ " \"Dental_Subscriber_Cnt\" : \"\",\r\n" + " \"Vision_Subscriber_Cnt\" : \"\",\r\n"
				+ " \"Target_Dental_EligibleLives_Count\" : \"\",\r\n"
				+ " \"Target_Vision_EligibleLives_Count\" : \"\",\r\n"
				+ " \"Current_Dental_EligibleLives_Count\" : \"\",\r\n"
				+ " \"Current_Vision_EligibleLives_Count\" : \"\",\r\n" + " \"Dental_Prior_Coverage\" : \"N\",\r\n"
				+ " \"Group_FDocID\" : \"3613435478\",\r\n" + " \"Broker_FDocID\" : \"3613435477\",\r\n"
				+ " \"Filler6\" : \"3613435478          3613435477\",\r\n"
				+ " \"Audit_Trail_Oper_Id\" : \"REXTR V\",\r\n" + " \"Audit_Trail_Pgm_Name\" : \"2.0\",\r\n"
				+ " \"Audit_Trail_Process_Date\" : ISODate(\"2018-03-15T04:00:00.000Z\"),\r\n"
				+ " \"Audit_Trail_Process_Time\" : \"12000003\",\r\n" + " \"type\" : \"SG\",\r\n"
				+ " \"relationship\" : \"GROUP\",\r\n" + " \"start-date\" : \"2018-06-20 09:11:03.527\",\r\n"
				+ " \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n"
				+ " \"source-path\" : \"hdfs://mom9n90291.wellpoint.com:8020/apps/Renewals/WSGRS/GroupInfo/WSGRS_Group_Info_PROD_20180315120003.txt\",\r\n"
				+ " \"source\" : \"WSGRS\",\r\n" + " \"Version\" : \"V1\",\r\n" + " \"status\" : \"processed\",\r\n"
				+ " \"Data_Quality_Check\" : \"passed\" \r\n    }";

		Document doc = (Document) Document.parse(clientrdm);
		BSONObject bsonObject = (BSONObject) JSON.parse(doc.toJson());
		return bsonObject;

	}
	
	String jsonTDMRenewal = "{\r\n" + "	    \"_id\" : ObjectId(\"5be949549ec00730101306df\"),\r\n"
			+ "	    \"GUID\" : \"000M55781000M557816/1/2019MINDSUBSCR\",\r\n" + "	    \"ID\" : \"000M55781\",\r\n"
			+ "	    \"renewalDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	    \"effectiveDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	    \"currentContractCode\" : \"INE000701000V200\",\r\n"
			+ "	    \"renewalContractCode\" : \"INE000701000V200\",\r\n" + "	    \"Delta\" : \"17.85%\",\r\n"
			+ "	    \"type\" : \"IND\",\r\n" + "	    \"relationship\" : \"SUBSCR\",\r\n"
			+ "	    \"renewalDependentsCovered\" : \"No\",\r\n" + "	    \"Benefits\" : [ \r\n" + "	        {\r\n"
			+ "	            \"effectiveDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	            \"renewalDate\" : ISODate(\"2019-06-01T04:00:00.000Z\"),\r\n"
			+ "	            \"ratingTier\" : 0.573,\r\n" + "	            \"productType\" : \"M\",\r\n"
			+ "	            \"currentContractPlanCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"currentContractPlanName\" : \"SmartSense 30%\",\r\n"
			+ "	            \"currentMonthlyPremium\" : 500.73,\r\n"
			+ "	            \"currentTotalPremium\" : 500.73,\r\n"
			+ "	            \"renewalMonthlyPremium\" : 680.49,\r\n"
			+ "	            \"renewalTotalPremium\" : 680.49,\r\n"
			+ "	            \"renewalContractCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"renewalContractPlanCode\" : \"INE000701000V200\",\r\n"
			+ "	            \"renewalContractPlanName\" : \"SmartSense 30%\",\r\n"
			+ "	            \"deductible\" : \"1000\",\r\n" + "	            \"renewalProducts\" : [ \r\n"
			+ "	                {\r\n" + "	                    \"productType\" : \"M\",\r\n"
			+ "	                    \"renewalContractCode\" : \"INE000701000V200\",\r\n"
			+ "	                    \"renewalContractPlanName\" : \"SmartSense 30%\"\r\n" + "	                }\r\n"
			+ "	            ]\r\n" + "	        }\r\n" + "	    ],\r\n" + "	    \"currentMonthlyPremium\" : 500.73,\r\n"
			+ "	    \"monthlyPremium\" : 680.49,\r\n" + "	    \"start-date\" : \"2018-11-12 15:05:16.397\",\r\n"
			+ "	    \"end-date\" : \"9999-12-31 00:00:00:000\",\r\n"
			+ "	    \"source-path\" : \"D:/372712/Employer Broker/FeedFile/apps/Renewals/GBD/RA_MEDICARE_ALL_IN_Annual_Triggers_November_20170915_1377.txt\",\r\n"
			+ "	    \"source\" : \"FACETS GBD\",\r\n" + "	    \"Version\" : \"V1\",\r\n"
			+ "	    \"status\" : \"processed\",\r\n" + "	    \"Data_Quality_Check\" : \"passed\"\r\n" + "	}\r\n"
			+ "";

	Document conDocument = (Document) Document.parse(jsonTDMRenewal);

}

