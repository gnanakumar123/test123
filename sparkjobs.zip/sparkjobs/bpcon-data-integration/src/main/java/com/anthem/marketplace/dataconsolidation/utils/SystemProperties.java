package com.anthem.marketplace.dataconsolidation.utils;

import java.util.*;

/**
 * A singleton class which is used to serve system properties. When an
 * application starts it needs to invoke intiializeProperties with the path to
 * the system properties file. After that occurs you can call getProperty to
 * obtain a setting in the system properties file.
 * 
 * This object works with an ini type file broken into sections. The file may
 * look something like this.
 * 
 * <pre>
* #comment
* myKey1=myValue1
* myKey2=myValue2
 * </pre>
 * 
 * invoking ... getProperty("myKey1") will return "myValue1".
 * getProperty("myKey2") will return "myValue2".
 * 
 */
public class SystemProperties {
	private static ResourceBundle resourceBundle = null;

	private SystemProperties() {
	}

	/**
	 * Returns the property with the specified key. pre: initializeProperties
	 * has been invoked.
	 */
	public static String getProperty(String key) {
		if (resourceBundle == null) {
			throw new RuntimeException("SystemPropertiesService has not been initialized");
		}
		return resourceBundle.getString(key);
	}

	/**
	 * Initializes this object with the specified path to the properties file.
	 * getProperty can not be invoked until this method is invoked.
	 */
	public static void initializeProperties(String propertiesFileName) throws RuntimeException

	{
			resourceBundle = ResourceBundle.getBundle(propertiesFileName);
	}
}
