package com.jobreadyprogrammer.spark;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.regression.LinearRegression;
import org.apache.spark.ml.regression.LinearRegressionModel;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class LinearMarketingVsSales {

	public static void main(String[] args) {

		Logger.getLogger("org").setLevel(Level.ERROR);
		Logger.getLogger("akka").setLevel(Level.ERROR);

		SparkSession spark = new SparkSession.Builder().appName("LinearRegressionExample").master("local")
				.getOrCreate();

		Dataset<Row> markVsSalesDf = spark.read().option("header", "true").option("inferSchema", "true").format("csv")
				.load("file:///D:/esi/spark/projects/sparkwithjava/project9/src/main/resources/marketing-vs-sales.csv");
		markVsSalesDf.show();

		// go through the lecture first and then start un-commenting the code
		// below

		Dataset<Row> mldf = markVsSalesDf.withColumnRenamed("sales", "label").select("label", "marketing_spend");

		mldf.show(false);

		String[] featureColumns = { "marketing_spend" };

		// Add all the Independent columns as FEATURES
		VectorAssembler assember = new VectorAssembler().setInputCols(featureColumns).setOutputCol("features");

		// Transform the existing DF to lable and features
		Dataset<Row> lblFeaturesDf = assember.transform(mldf).select("label", "features");
		lblFeaturesDf = lblFeaturesDf.na().drop();
		lblFeaturesDf.show(false);

		// next we need to create a linear regression model object to train the model object with test data
		LinearRegression lr = new LinearRegression();
		LinearRegressionModel learningModel = lr.fit(lblFeaturesDf);

		System.out.println("Predictions ******************* Check Prediction column");
		learningModel.summary().predictions().show();
		
		// Create new data for actual prediction
		Dataset<Row> predictDataDf = spark.read().option("header", "true").option("inferSchema", "true").format("csv").load(
				"file:///D:/esi/spark/projects/sparkwithjava/project9/src/main/resources/marketing-vs-sales-new-data.csv");

		String[] predictFeatureColumns = { "marketing_spend" };

		// Add all the Independent columns as FEATURES
		VectorAssembler predictVectorAssembler = new VectorAssembler().setInputCols(predictFeatureColumns).setOutputCol("features");

		Dataset<Row> lblFeaturesDfNew = predictVectorAssembler.transform(predictDataDf).select("label", "features");
		lblFeaturesDfNew = lblFeaturesDfNew.na().drop();
		lblFeaturesDfNew.show(false);

		System.out.println(
				" ***************************** Transforming new dataset ********** Predict values ***********");
		learningModel.transform(lblFeaturesDfNew).show();

		System.out.println(" ***************************** Evaluate new dataset ********** Predict values ***********");
		learningModel.evaluate(lblFeaturesDfNew).predictions().show();

		System.out.println("R Squared: " + learningModel.summary().r2());

	}
}
