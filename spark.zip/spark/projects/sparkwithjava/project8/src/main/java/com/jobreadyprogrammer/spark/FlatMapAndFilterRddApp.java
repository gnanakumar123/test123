package com.jobreadyprogrammer.spark;

public class FlatMapAndFilterRddApp {

}
