package com.anthem.marketplace.dataconsolidation.utils;

import java.io.StringReader;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.spark.api.java.function.FlatMapFunction;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

import scala.Tuple2;
/* CR-FACETS Renewals BPP-24173 : Added new file CustomCsvReader */
public class CustomCsvReader implements FlatMapFunction<Tuple2<String, String>, String> {

	@Override
	public Iterator<String> call(Tuple2<String, String> file) throws Exception {
		
		final CSVParser parser = new CSVParserBuilder()
				.withSeparator(',')
				.withIgnoreQuotations(false)
				.build();
		CSVReader csvReader= new CSVReaderBuilder(new StringReader(file._2)).withCSVParser(parser).build();
		
		List<String[]> fileContent = csvReader.readAll();
		
		Iterator<String> lines = fileContent.stream().map(f -> String.join("\",\"", f)).map(s->{return new StringBuffer().append("\"").append(s).append("\"").toString();}).collect(Collectors.toList()).iterator();
		
		return lines;
		
	}


	

}
