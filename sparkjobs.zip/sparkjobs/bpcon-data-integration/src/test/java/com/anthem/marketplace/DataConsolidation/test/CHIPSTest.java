package com.anthem.marketplace.DataConsolidation.test;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.bson.BSONObject;
import org.bson.Document;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.anthem.marketplace.dataconsolidation.filesutils.CHIPS;
import com.anthem.marketplace.dataconsolidation.model.VARenewal;
import com.anthem.marketplace.dataconsolidation.utils.ChangeDataCapture;
import com.anthem.marketplace.dataconsolidation.utils.ChipsUtils;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.MongoConnector;
import com.anthem.marketplace.dataconsolidation.utils.ProcessFieldNames;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXml;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;
import com.anthem.marketplace.dataconsolidation.utils.SparkContextSingleton;
import com.anthem.marketplace.dataconsolidation.utils.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.MongoCollection;
import com.mongodb.util.JSON;

//import akka.japi.Function;
//import akka.japi.function.Function2;
import scala.Tuple2;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"org.apache.hadoop.*","javax.*","com.sun.org.apache.*","org.apache.log4j.*","org.w3c.dom.*","org.apache.xerces.*"})
@PrepareForTest({CHIPS.class,ReadMappingXmlSingleton.class,MongoConnector.class,ChipsUtils.class,FieldNamesProperties.class,Utility.class,SparkContextSingleton.class})
public class CHIPSTest {

	@Mock
	MongoCollection mockCollection;


	MongoConnector mongoConnectorMock;


	ReadMappingXmlSingleton readMappingXmlSingletonMock;


	ReadMappingXml readMappingXmlMock;


	FieldNamesProperties fileNamesPropertiesMock;
	
	@Mock
	SparkContextSingleton sparkContextSingletonMock;
	
	@Mock
	JavaSparkContext javaSparkContextMock;
	
	@Mock
	JavaPairRDD javaPairRddMock;
	
	@Mock
	Utility utility;
	
	@Mock
	ChangeDataCapture changeDataCaptureMock;
	
	CHIPS chips= (CHIPS) Utility.createObject("com.anthem.marketplace.dataconsolidation.filesutils.CHIPS");
	
	String sourceCollection = "Renewals_CHIPS";
	
	String delimeted ="|";
	
	String type = "chips_renewal";
	

	ChipsUtils chipsUtilsMock;

	@Before
	public void setup() {
		readMappingXmlSingletonMock = PowerMockito.mock(ReadMappingXmlSingleton.class);
		PowerMockito.mockStatic(ReadMappingXmlSingleton.class);
		readMappingXmlMock = PowerMockito.mock(ReadMappingXml.class);
		mongoConnectorMock = PowerMockito.mock(MongoConnector.class);
		PowerMockito.mockStatic(MongoConnector.class);
		PowerMockito.when(ReadMappingXmlSingleton.getInstance()).thenReturn(readMappingXmlSingletonMock);
		doReturn(readMappingXmlMock).when(readMappingXmlSingletonMock).getRead();
		fileNamesPropertiesMock = PowerMockito.mock(FieldNamesProperties.class);
		PowerMockito.mockStatic(FieldNamesProperties.class);
		PowerMockito.when(FieldNamesProperties.getInstance()).thenReturn(fileNamesPropertiesMock);
		chipsUtilsMock = PowerMockito.mock(ChipsUtils.class);
		PowerMockito.mockStatic(ChipsUtils.class);
		PowerMockito.when(ChipsUtils.getInstance()).thenReturn(chipsUtilsMock);
		PowerMockito.mockStatic(Utility.class);
		sparkContextSingletonMock = PowerMockito.mock(SparkContextSingleton.class);
		PowerMockito.mockStatic(SparkContextSingleton.class);
		PowerMockito.when(SparkContextSingleton.getInstance()).thenReturn(sparkContextSingletonMock);
		javaSparkContextMock = PowerMockito.mock(JavaSparkContext.class);
		doReturn(javaSparkContextMock).when(sparkContextSingletonMock).getSparkContext();
	}
	
	private void getDataTypeMock(ProcessFieldNames processInput,String type, String datatype) {
		for(String fieldName : processInput.getArrayFieldNames().split(IConstants.SPLIT_COMMA)) {
			if(fieldName.equals("oldRate") ||  fieldName.equals("newRate") || fieldName.equals("deductible")) {
				doReturn("Double").when(readMappingXmlMock).getAttributeValueOfField(type,
						fieldName, datatype);
			}else if(fieldName.equals("effectiveDate") || fieldName.equals("dateOfBirth") || fieldName.equals("spouseDateOfBirth") || fieldName.equals("dependentDateOfBirth")){
				doReturn("Date YYYY-MM-DD").when(readMappingXmlMock).getAttributeValueOfField(type,
						fieldName, datatype);
			}else {
				doReturn("String").when(readMappingXmlMock).getAttributeValueOfField(type,
						fieldName, datatype);
			}

		}
	}
	
	@Test
	public void ingestUDMProcessTest() {
		BSONObject bsonObjectMock = CHIPSConstants.clientBSONObject();
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		Document doc = chips.ingestUDMProcess("TDM", "Renewals_tdm_Client", bsonFilterMock, "ADS", "Renewals_tdm_Client", "None");
	}
	
	
	@Test
	public void ingestTDMRenewalProcessTest() throws Exception {
		
		String appendCollection = "renewals,contacts,agents";
		
		ProcessFieldNames clientFieldNames = new ProcessFieldNames();
		clientFieldNames.setArrayFieldNames("ID,type,relationship,renewalDate,effectiveDate,monthlyPremium,currentMonthlyPremium");
		doReturn(clientFieldNames).when(fileNamesPropertiesMock).getPropertyContext(IConstants.CHIPS.concat("Renewals_tdm_Renewal").toString());
		
		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames.setArrayFieldNames("effectiveDate,renewalDate,currentMonthlyPremium,currentTotalPremium,currentContractPlanName,renewalMonthlyPremium,renewalTotalPremium,renewalContractPlanName");
		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext(IConstants.CHIPSBENEFITS);
		
		Row readFileContent = RowFactory.create(CHIPSConstants.createVARenewals());
		BSONObject bsonObjectMock = getVABsonObject(readFileContent);
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		
		doReturn(CHIPSConstants.tdmRenewalBenefitsList()).when(chipsUtilsMock).createRenewalBenefits(any(ProcessFieldNames.class), any(Tuple2.class), any(String.class), any(Document.class),any(String.class));
		PowerMockito.doAnswer(new Answer<Void>() {
	        @Override
	        public Void answer(InvocationOnMock invocation) throws ParseException {
	        	 Document doc = (Document) invocation.getArguments()[4];
	        	 	doc.append("ID", "236M64949");
		    		doc.append("renewalDate", new Timestamp(new java.util.Date().getTime()).toString());
		    		doc.append("effectiveDate", new Timestamp(new java.util.Date().getTime()).toString());
		    		doc.append("monthlyPremium", Double.parseDouble("942.0"));
		    		doc.append("currentMonthlyPremium", Double.parseDouble("863.0"));
				return null;
	        }
	    }).when(chipsUtilsMock).addToDocument(any(ProcessFieldNames.class), any(Tuple2.class), any(String.class), any(String.class), any(Document.class));
		
		Document tdmRenewalDoc = chips.ingestTDMProcess("RAW", sourceCollection, bsonFilterMock, "TDM", "Renewals_tdm_Renewal", appendCollection);
		Assert.assertEquals("236M64949", tdmRenewalDoc.get("ID"));
		verify(chipsUtilsMock, times(1)).createRenewalBenefits(any(ProcessFieldNames.class), any(Tuple2.class), any(String.class), any(Document.class),any(String.class));
	}
	
	@Test
	public void ingestTDMClientProcessTest() throws Exception {
		
		String appendCollection = "renewals,contacts,agents";
		ProcessFieldNames clientFieldNames = new ProcessFieldNames();
		clientFieldNames.setArrayFieldNames("ID,type,relationship,renewalDate,effectiveDate,firstName,middleName,lastName,dateofBirth");
		doReturn(clientFieldNames).when(fileNamesPropertiesMock).getPropertyContext(IConstants.CHIPS.concat("Renewals_tdm_Client").toString());
		
		ProcessFieldNames agentFieldNames = new ProcessFieldNames();
		agentFieldNames.setArrayFieldNames("taxIDType,product,name");
		doReturn(agentFieldNames).when(fileNamesPropertiesMock).getPropertyContext(IConstants.CHIPS.concat("agents").toString());


		ProcessFieldNames contactsFieldNames = new ProcessFieldNames();
		contactsFieldNames.setArrayFieldNames("addressType,addressLine1,addressLine2,addressLine3,cityName,stateCode,postalCode");
		doReturn(contactsFieldNames).when(fileNamesPropertiesMock).getPropertyContext(IConstants.CHIPS.concat("contacts").toString());

		ProcessFieldNames renewalsFieldNames = new ProcessFieldNames();
		renewalsFieldNames.setArrayFieldNames("renewalPeriod");
		doReturn(renewalsFieldNames).when(fileNamesPropertiesMock).getPropertyContext(IConstants.CHIPS.concat("renewals").toString());

		Row readFileContent = RowFactory.create(CHIPSConstants.createVARenewals());
		BSONObject bsonObjectMock = getVABsonObject(readFileContent);
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		
		Document doc = new Document();
		PowerMockito.doAnswer(new Answer<Void>() {
	        @Override
	        public Void answer(InvocationOnMock invocation) throws ParseException {
	        	 Document doc = (Document) invocation.getArguments()[4];
	        	 	doc.append("ID", "236M64949");
		    		doc.append("renewalDate", new Timestamp(new java.util.Date().getTime()).toString());
		    		doc.append("effectiveDate", new Timestamp(new java.util.Date().getTime()).toString());
		    		doc.append("firstName", "BRYAN A");
		    		doc.append("lastName", "RICE");
		    		doc.append("dateOfBirth", "ISODate(\"1964-09-10T04:00:00.000Z\")");
				return null;
	        }
	    }).when(chipsUtilsMock).addToDocument(any(ProcessFieldNames.class), any(Tuple2.class), any(String.class), any(String.class), any(Document.class));	

		PowerMockito.doAnswer(new Answer<Void>() {
	        @Override
	        public Void answer(InvocationOnMock invocation) throws ParseException {
	            Document doc = (Document) invocation.getArguments()[0];
	            doc.append(IConstants.SOURCE_PATH_FIELD, "/apps/Renewals/CHIPS");
	    		doc.append(IConstants.START_DATE_FIELD, new Timestamp(new java.util.Date().getTime()).toString());
	    		doc.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE);
	    		doc.append(IConstants.SOURCE_FIELD, type.toUpperCase());
	    		doc.append(IConstants.VERSION_FIELD, "V1");
	    		doc.append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED);
				doc.append(IConstants.DQC_FIELD, IConstants.PASSED);
	            return null;
	        }
	    }).when(Utility.class);
		utility.insertMetadata(any(Document.class), any(String.class), any(String.class), any(String.class), any(String.class), any(String.class), any(Boolean.class),any(Boolean.class),any(String.class));

		
		doReturn(CHIPSConstants.tdmAgentsListDoc()).when(chipsUtilsMock).createAgentsList(agentFieldNames, bsonFilterMock, "agents", "TDM");
		doReturn(CHIPSConstants.tdmContactsListDoc()).when(chipsUtilsMock).createContactDoc(contactsFieldNames, bsonFilterMock, "contacts");
		doReturn(CHIPSConstants.tdmRenewalsDoc()).when(chipsUtilsMock).createRenewalsDoc(renewalsFieldNames);
		doReturn(CHIPSConstants.tdmMemberListDoc()).when(chipsUtilsMock).createMemberDocList(bsonFilterMock);
		
		Document tdmClientDoc = chips.ingestTDMProcess("RAW", sourceCollection, bsonFilterMock, "TDM", "Renewals_tdm_Client", appendCollection);
		verify(chipsUtilsMock, times(1)).createAgentsList(agentFieldNames, bsonFilterMock, "agents", "TDM");
		verify(chipsUtilsMock, times(1)).createContactDoc(contactsFieldNames, bsonFilterMock, "contacts");
		verify(chipsUtilsMock, times(1)).createRenewalsDoc(renewalsFieldNames);
		verify(chipsUtilsMock, times(1)).createMemberDocList(bsonFilterMock);
	}
	
	@Test
	public void ingestSDSProcessTest() throws Exception {
		
		ProcessFieldNames memberSummary = new ProcessFieldNames();
		ProcessFieldNames memberDetail = new ProcessFieldNames();
		ProcessFieldNames memberSummaryBenefits = new ProcessFieldNames();
		
		BSONObject bsonObjectMock = CHIPSConstants.clientBSONObject();
		Tuple2<Object, BSONObject> bsonFilterMock = new Tuple2<>("1", bsonObjectMock);
		
		memberSummary.setArrayFieldNames("ID,renewalDate,enrollmentType,type,effectiveDate,firstName,lastName,dateofBirth,age,gender,agents,contacts");
		memberDetail.setArrayFieldNames("ID,type,relationship,renewalDate,firstName,lastName,dateofBirth,age,gender,tobaccoUsage,tobaccoWellness,contacts,agents");
		memberSummaryBenefits.setArrayFieldNames("productType,productSubType,renewalDate,currentContractPlanCode,renewalLetterCode,currentContractPlanName,enrollmentCode,renewalProducts,contractPlanCode,productType");
		doReturn(memberSummary).when(fileNamesPropertiesMock).getPropertyContext("memberSummary");
		doReturn(memberDetail).when(fileNamesPropertiesMock).getPropertyContext("memberDetail");
		doReturn(memberSummaryBenefits).when(fileNamesPropertiesMock).getPropertyContext("memberSummaryBenefits");
		
		doReturn(CHIPSConstants.sdsRenewalDetailDocument()).when(chipsUtilsMock).createDetailDocument(any(ProcessFieldNames.class), any(Tuple2.class), any(String.class), any(String[].class));
		
		doReturn(CHIPSConstants.sdsRenewalSummaryDocument()).when(chipsUtilsMock).createSummaryDocument(any(ProcessFieldNames.class), any(ProcessFieldNames.class), any(Tuple2.class), any(String.class), any(String[].class));
		
		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);
		PowerMockito.doNothing().when(mongoConnectorMock).removePreviousDocuments(any(String.class), any(String.class), any(String.class), any(String.class), any(Document.class));
		doReturn(true).when(mongoConnectorMock).updateStatus(any(String.class), any(String.class), any(Tuple2.class), any(String.class));
		doReturn(true).when(mongoConnectorMock).insertData(Matchers.anyListOf(Document.class), any(String.class), any(String.class), any(String.class));
		
		chips.ingestSDSProcess("TDM", "Renewals_tdm_Client,Renewals_tdm_Renewal".split(IConstants.SPLIT_COMMA), bsonFilterMock , "renewalsDb", "RenewalSummary", "RenewalDetails",new ProcessInput());
		verify(mongoConnectorMock, times(1)).updateStatus(any(String.class), any(String.class), any(Tuple2.class), any(String.class));
		verify(mongoConnectorMock, times(2)).insertData(Matchers.anyListOf(Document.class), any(String.class), any(String.class), any(String.class));
		verify(chipsUtilsMock, times(1)).createDetailDocument(any(ProcessFieldNames.class), any(Tuple2.class), any(String.class), any(String[].class));
		verify(chipsUtilsMock, times(1)).createSummaryDocument(any(ProcessFieldNames.class), any(ProcessFieldNames.class), any(Tuple2.class), any(String.class), any(String[].class));

	}
	
	@Test
	public void ingestRDMprocessTest() throws Exception {
		ProcessInput processInput = new ProcessInput();
		processInput.setSourceDB("RAW");
		processInput.setSourceCollection("Renewals_CHIPS");
		processInput.setDelimeted("false");
		processInput.setDelimeter("\\|");
		processInput.setType("chips_renewals");
		processInput.setFileType("CHIPS");
		processInput.setFailedCollection("Renewals_ISGREN_DQ_Reject");
		
		SparkConf conf = new SparkConf().setAppName("Spark Count").setMaster("local").set("user.name", "test");
		JavaSparkContext sparkContext = new JavaSparkContext(conf);
		
		VARenewal vaRenewal = CHIPSConstants.createVARenewals();
		List<VARenewal> vaRenewalList = new ArrayList<VARenewal>();
		vaRenewalList.add(vaRenewal);
		doReturn(javaPairRddMock).when(javaSparkContextMock).wholeTextFiles(any(String.class));
		doReturn(sparkContext.parallelize(Arrays.asList(vaRenewalList))).when(javaPairRddMock).map((any(org.apache.spark.api.java.function.Function.class)));
		PowerMockito.when(MongoConnector.getInstance()).thenReturn(mongoConnectorMock);
		doReturn(true).when(mongoConnectorMock).insertData(Matchers.anyListOf(Document.class), any(String.class), any(String.class), any(String.class));
		//Create Guid Test
		Row readFileContent = RowFactory.create(CHIPSConstants.createVARenewals());
		String guidvalue = "hcid,effectiveDate,dependentDateOfBirth";
		Document doc = getVADocument(readFileContent);
		doReturn(doc).when(chipsUtilsMock).getVADocument(any(Row.class));
		doReturn("236M64949").when(chipsUtilsMock).getValue(doc,"contract","hcid");
		doReturn("2018-07-31").when(chipsUtilsMock).getValue(doc,"contract","effectiveDate");
		doReturn("1998-09-30").when(chipsUtilsMock).getValue(doc,"contract","dependentDateOfBirth");
		
		//Create Flag Test
		Map<String,String> mandatoryFields = new HashMap<String,String>();
		mandatoryFields.put("1", "hcid");
		mandatoryFields.put("2", "dependentDateOfBirth");
		doReturn(mandatoryFields).when(readMappingXmlMock).getMandatoryFields(any(String.class), any(String.class));
		doReturn(doc).when(chipsUtilsMock).getVADocument(readFileContent);
		doReturn("236M64949").when(chipsUtilsMock).getValue(doc,"contract","hcid");
		doReturn("1998-09-30").when(chipsUtilsMock).getValue(doc,"dependentDetails","dependentDateOfBirth");
		
		
		//Append Raw Test
		ProcessInput processInput1 = new ProcessInput();
		processInput1.setType("chips_renewal");
		processInput1.setSourceDB("RAW");
		processInput1.setSourceCollection("Renewals_CHIPS");
		
		ProcessFieldNames procFieldNames = new ProcessFieldNames();
		procFieldNames.setArrayFieldNames("hcid,contractId,product,deductible,oldRate,newRate,effectiveDate,dateOfBirth,addressLine1,addressLine2,addressLine3,city,state,zip,phoneNumber,firstName,lastName,uwLevel,spouseFirstName,spouseLastName,spouseUwLevel,spouseDateOfBirth,dependentFirstName,dependentLastName,dependentUwLevel,dependentDateOfBirth,agentNumber,agencyNumber,agencyName,agencyAddressLine1,agencyAddressLine2,agencyCity,agencyState,agencyZip");
		doReturn(procFieldNames).when(fileNamesPropertiesMock).getPropertyContext("chips_renewal");
		
		doReturn(doc).when(chipsUtilsMock).getVADocument(readFileContent);
		
		String sourcePath = "C:/apps/Renewals/CHIPS/PHC.TST.BRXML.MPH7507.CATUP.D180810.XML";
		boolean flag = false;
		String guid = "236M649492018-07-31INDSUBSCR";
		getDataTypeMock(procFieldNames,"chips_renewal",IConstants.DATATYPE);
		PowerMockito.doAnswer(new Answer<Void>() {
	        @Override
	        public Void answer(InvocationOnMock invocation) throws ParseException {
	            Document doc = (Document) invocation.getArguments()[3];
	            DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
				Date date = formatter.parse((String) invocation.getArguments()[2]);
				doc.append((String) invocation.getArguments()[1], date);
	            return null;
	        }
	    }).when(Utility.class);
		
		utility.applyZone(any(String.class), any(String.class), any(String.class), any(Document.class), any(String.class) , any(Row.class), any(String.class));
		
		PowerMockito.doAnswer(new Answer<Void>() {
	        @Override
	        public Void answer(InvocationOnMock invocation) throws ParseException {
	            Document doc = (Document) invocation.getArguments()[0];
	            doc.append(IConstants.SOURCE_PATH_FIELD, sourcePath);
	    		doc.append(IConstants.START_DATE_FIELD, new Timestamp(new java.util.Date().getTime()).toString());
	    		doc.append(IConstants.END_DATE_FIELD, IConstants.MAX_DATE);
	    		doc.append(IConstants.SOURCE_FIELD, type.toUpperCase());
	    		doc.append(IConstants.VERSION_FIELD, "V1");
	    		doc.append(IConstants.STATUS_FIELD, IConstants.UNPROCESSED);
				doc.append(IConstants.DQC_FIELD, IConstants.PASSED);
	            return null;
	        }
	    }).when(Utility.class);
		utility.insertMetadata(any(Document.class), any(String.class), any(String.class), any(String.class), any(String.class), any(String.class), any(Boolean.class),any(Boolean.class),any(String.class));
		
		doReturn(true).when(changeDataCaptureMock).implementCdc(any(String.class), any(String.class), any(Document.class), any(List.class), any(List.class), any(String.class));
		
		chips.ingestRDMprocess(processInput1, "/apps/Renewals/CHIPS", guidvalue,"CHIPS");
	}
	

	private Document getVADocument(Row readFileContent) throws JsonProcessingException {
		// TODO Auto-generated method stub
		ObjectMapper mapper = new ObjectMapper();
		VARenewal vaRenewal = (VARenewal) readFileContent.get(0);
		mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));
		Document doc = Document.parse(mapper.writeValueAsString(vaRenewal));
		return doc;
	}
	
	private BSONObject getVABsonObject(Row readFileContent) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		VARenewal vaRenewal = (VARenewal) readFileContent.get(0);
		mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));
		String json = mapper.writeValueAsString(vaRenewal);
		BSONObject bsonObject = (BSONObject) JSON.parse(json);
		bsonObject.put("GUID", "236M649492018-07-31INDSUBSCR");
		bsonObject.put("source", "CHIPS");
		bsonObject.put("start-date", "2018-09-21 19:02:37.65");
		bsonObject.put("end-date", "9999-12-31 00:00:00:000");
		bsonObject.put("source-path", "D:/Renewals/feedfile/VA/PHC.TST.BRXML.MPH7507.CATUP.D180810.XML");	
		bsonObject.put("Version", "V1");
		bsonObject.put("status", "processed");
		bsonObject.put("Data_Quality_Check", "passed");
		return bsonObject;
	}
}
