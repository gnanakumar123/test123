package com.jobreadyprogrammer.spark;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class JSONLinesParser {

	public void parseJsonLines() {
		SparkSession spark = SparkSession.builder().appName("JSON Lines to Dataframe").master("local").getOrCreate();

		// Dataset<Row> df = spark.read().format("json")
		// .load("src/main/resources/simple.json");

		Dataset<Row> df2 = spark.read().format("json").option("multiline", true)
				// .load("/home/ubuntu/sparkwithjava/project2/src/main/resources/multiline.json");
				.load("src/main/resources/multiline.json");

		// show 5 records and all characters of each column
		df2.show(5, false);

		// show 7 records and show only 10 characters of each column
		df2.show(7, 10);
		df2.printSchema();
	}

}
