package com.map.examples;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.VoidFunction;

public class RDD_MapPartitionsWithFlatMapFunction implements Serializable {

	public static void main(String[] args) {

		SparkConf conf = new SparkConf().setAppName("MapPartitionsWithIndexEx").setMaster("local[3]");
		JavaSparkContext sc = new JavaSparkContext(conf);

		JavaRDD<String> rawInputRdd = sc
				.textFile("D:\\anthem\\sparkjobs\\com.spark.mongo.example\\src\\main\\resources\\group.txt");

		// MAP Partitions with FlatMapFunction - returns an ITERATOR of LIST
		JavaRDD<String[]> Mappartitionsresult = rawInputRdd
				.mapPartitions(new FlatMapFunction<Iterator<String>, String[]>() {
					@Override
					public Iterator<String[]> call(Iterator<String> stringiterator) throws Exception {
						List<String[]> resultArray = new ArrayList<>();
						
						System.out.println("mapPartitions - call() method is invoked");
						
						while (stringiterator.hasNext()) {
							String line = stringiterator.next();
							String[] Tmpresult = line.split(";");
							resultArray.add(Tmpresult);
						}
						return resultArray.iterator();
					}
				});

		System.out.println("Printing MAP Partitions with FlatMapFunction results");
		Mappartitionsresult.foreach(new VoidFunction<String[]>() {
			@Override
			public void call(String[] strings) throws Exception {
				System.out.println(Arrays.toString(strings));
			}
		});

		
	}

}
