package com.sparkTutorial.rdd.nasaApacheWebLogs;

import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import scala.Tuple2;

public class CartesianSolution {

    public static void main(String[] args) throws Exception {

    	Logger.getLogger("org").setLevel(Level.ERROR);
        SparkConf conf = new SparkConf().setAppName("cartesianSolution").setMaster("local[*]");

        JavaSparkContext sc = new JavaSparkContext(conf);

        JavaRDD<String> group1 = sc.parallelize(Arrays.asList("A", "B", "C"));
        JavaRDD<String> group2 = sc.parallelize(Arrays.asList("1", "4", "5"));

        JavaPairRDD<String, String> cartesianProduct = group1.cartesian(group2);

        List<Tuple2<String, String>> output = cartesianProduct.collect();
        for (Tuple2<String, String> tuple2 : output) {
			System.out.println(tuple2._1() + " " + tuple2._2());
		}
    }
}
