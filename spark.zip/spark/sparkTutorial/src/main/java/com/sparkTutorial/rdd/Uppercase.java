package com.sparkTutorial.rdd;


import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class Uppercase {

    public static void main(String[] args) throws Exception {
    	Logger.getLogger("org").setLevel(Level.ERROR);
        // Create a Java Spark Context.
        SparkConf conf = new SparkConf().setAppName("uppercase").setMaster("local[*]");

        JavaSparkContext sc = new JavaSparkContext(conf);

        JavaRDD<String> lines = sc.textFile("in/uppercase.text");
        
        // Transformation 1
        JavaRDD<String> lowerCaseLines = lines.map(line -> line.toUpperCase());

        // Action
        //lowerCaseLines.saveAsTextFile("out/uppercase.text");
        lowerCaseLines.collect().forEach(line -> System.out.println(line));
    }
}
