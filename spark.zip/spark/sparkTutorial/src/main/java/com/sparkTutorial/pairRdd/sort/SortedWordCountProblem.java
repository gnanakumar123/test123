package com.sparkTutorial.pairRdd.sort;

import java.util.Arrays;
import java.util.Map.Entry;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;

import scala.Tuple2;

public class SortedWordCountProblem {

    /* Create a Spark program to read the an article from in/word_count.text,
       output the number of occurrence of each word in descending order.

       Sample output:

       apple : 200
       shoes : 193
       bag : 176
       ...
     */
	
	public static void main(String[] args) {
		Logger.getLogger("org").setLevel(Level.ERROR);
		SparkConf conf = new SparkConf().setAppName("sortedWordCount").setMaster("local[3]");
		JavaSparkContext sc = new JavaSparkContext(conf);
		
		JavaRDD<String> lines = sc.textFile("in/word_count.text");
		JavaRDD<String> words = lines.flatMap(line -> Arrays.asList(line.split(" ")).iterator());
				
		JavaPairRDD<String, Integer> wordsCountMap = words.mapToPair((PairFunction<String, String, Integer>) word -> new Tuple2<>(word, 1));
		JavaPairRDD<String, Integer> wordsCount = wordsCountMap.reduceByKey((Function2<Integer, Integer, Integer>) (x, y) -> x + y);
		
		
		JavaPairRDD<Integer, String> countToWords = wordsCount.mapToPair(wordCount -> new Tuple2<>(wordCount._2(), wordCount._1()));
		JavaPairRDD<Integer, String> sortedCountToWords = countToWords.sortByKey(false);
		
		/*for (Entry<Integer, String> entry : sortedCountToWords.collectAsMap().entrySet()) {
			System.out.println(entry.getValue() + " : " + entry.getKey());
		}*/
		JavaPairRDD<String, Integer> wordsToWords = sortedCountToWords.mapToPair(wordCount -> new Tuple2<>(wordCount._2(), wordCount._1()));
		
		for (Tuple2<String, Integer> entry : wordsToWords.collect()) {
			System.out.println(entry._1() + " : " + entry._2());
		}
	}
}

