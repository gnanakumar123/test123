package com.anthem.marketplace.dataconsolidation.execution;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.xml.transform.Templates;

import org.quartz.DisallowConcurrentExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.marketplace.dataconsolidation.trigger.rdm.ScheduleJob;
import com.anthem.marketplace.dataconsolidation.utils.FieldNamesProperties;
import com.anthem.marketplace.dataconsolidation.utils.FixedFileMetaDataProperties;
import com.anthem.marketplace.dataconsolidation.utils.GetSysProperties;
import com.anthem.marketplace.dataconsolidation.utils.GuidProperties;
import com.anthem.marketplace.dataconsolidation.utils.IConstants;
import com.anthem.marketplace.dataconsolidation.utils.InputConnectors;
import com.anthem.marketplace.dataconsolidation.utils.InputProperties;
import com.anthem.marketplace.dataconsolidation.utils.InvokeType;
import com.anthem.marketplace.dataconsolidation.utils.LoadProducer;
import com.anthem.marketplace.dataconsolidation.utils.ProcessInput;
import com.anthem.marketplace.dataconsolidation.utils.ReadMappingXmlSingleton;

/*
 * This is the main method class which starts application by calling Trigger Object
 * @author : MongoDB Team
 * @version : 1.0
 * @Date : April 2016
 * It returns nothing.
 */
@DisallowConcurrentExecution
public class Start {
	static final Logger logger = LoggerFactory.getLogger(Start.class);
	public static HashMap<String, ProcessInput> inputProperties = new HashMap<>();
	public static Templates templates = null;

	private Start() {

	}

	public static void main(String[] args) {

		try {

			loadProperties();
			
			java.util.List<String> sources = new ArrayList<String>();
			sources = Arrays.asList(args);
			System.out.println("---sources---" + sources);

			java.util.List<String> type_prop = InvokeType.getInstance().getPropertyContext();
			System.out.println("---type_prop---" + type_prop);
			
			java.util.List<String> list = new ArrayList<String>();  
			
			if(sources.size() >= 0)
			{
				list = sources;
			}else 
			{
				list= type_prop;
			}
			
			ScheduleJob job = new ScheduleJob();
			for (String strType : list) {

				if (null != strType && !(strType.equalsIgnoreCase("lookup_prod_refresh"))) {
					/*
					 * To start the job for other sources
					 * [ISGACA,ISGNONACA,FACETS,FACETS GBD,WSGRS,SGRS]
					 */
					 job.execute(strType);
				} else if (null != strType && strType.equalsIgnoreCase("lookup_prod_refresh")) {
					/* BPP-31959: Start Automate Lookup_prod in TDM */
					/* To refresh the Lookup_prod collection in the TDM Layer */
					LoadProducer lp = new LoadProducer();
					ProcessInput processInput = Start.inputProperties.get(strType);
					String[] sourcePath = processInput.getArraySourcePath();
					String sourceCollection = processInput.getSourceCollection();
					String sourceDB = processInput.getSourceDB();
					lp.loadLookupProd(sourcePath[0], sourceCollection, sourceDB);
					/* BPP-31959: End Automate Lookup_prod in TDM */
				}

			}
			job = null;

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
	}

	private static void loadProperties() {
		try {
			inputProperties = InputProperties.getInstance().getPropertyContext();

		} catch (Exception e) {
			logger.error(IConstants.ERROR_PREPEND, e);
		}
		ReadMappingXmlSingleton.getInstance();
		FieldNamesProperties.getInstance();
		FixedFileMetaDataProperties.getInstance();
		GuidProperties.getInstance();
		GetSysProperties.getInstance();
		InputConnectors.getInstance();

	}
}
