package com.spark.mongo.example;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.mongodb.spark.MongoSpark;

public final class MongoSparkLoad_CompareWithExistingRecordsAndSave {

	public static void main(final String[] args) throws InterruptedException {

		// Create a single Spark Session with reference to Mongo Db -
		// Database.Collection
		SparkSession spark = SparkSession.builder().master("local").appName("MongoSparkConnectorIntro")
				.config("spark.mongodb.input.uri", "mongodb://127.0.0.1/test.test")
				.config("spark.mongodb.output.uri", "mongodb://127.0.0.1/test.test").getOrCreate();

		// Create a Java Spark Context from a Spark Session
		JavaSparkContext jsc = new JavaSparkContext(spark.sparkContext());

		// Define a schema for a file
		StructType schema = DataTypes.createStructType(
				new StructField[] { DataTypes.createStructField("seqNumber", DataTypes.StringType, true),
						DataTypes.createStructField("groupId", DataTypes.StringType, true),
						DataTypes.createStructField("firstName", DataTypes.StringType, true),
						DataTypes.createStructField("lastName", DataTypes.StringType, true),
						DataTypes.createStructField("premium", DataTypes.DoubleType, true),
						DataTypes.createStructField("renewalDate", DataTypes.DateType, true),
						DataTypes.createStructField("source", DataTypes.StringType, true)

				});

		// Create a dataframe from a text file using Spark Session
		// Map the fields in the file against the above custom Schema ( data
		// types for each field )
		Dataset<Row> inputfileDf = spark.read().format("csv") //
				.schema(schema).option("header", "true") //
				.option("multiline", true) //
				.option("sep", ";") //
				.option("quote", "^") //
				.option("dateFormat", "M/d/y") //
				.option("inferSchema", false) //
				.load("src/main/resources/group_incremental.txt");

		System.out.println("Printing incremental file content:");

		inputfileDf = inputfileDf.drop("seqNumber");
		// inputfileDf.show(false);

		System.out.println("Mongo Collections content:");

		// Load from MongoDB
		Dataset<Row> mongoDf = MongoSpark.load(jsc).toDF();
		mongoDf.printSchema();
		// mongoDf.show(false);

		System.out.println("Filtered by source system 'WSGRS' records in Mongo :");
		// Filter by specific source system
		Dataset<Row> filteredDf = mongoDf.filter("source = \"WSGRS\"");
		// filteredDf.show();

		// LEFT OUTER JOIN the input DF and Mongo DF with GROUPID column and
		// then SELECT _id from Mongo
		// for the matched records
		// Therefore, Non-Matched records will not have any "_id" values
		Dataset<Row> incrementalChangedRows = inputfileDf
				.join(filteredDf, inputfileDf.col("groupId").equalTo(mongoDf.col("groupId")), "left_outer")
				.select(filteredDf.col("_id"), inputfileDf.col("groupId"), inputfileDf.col("firstName"),
						inputfileDf.col("lastName"), inputfileDf.col("premium"), inputfileDf.col("renewalDate"),
						inputfileDf.col("source"));
		incrementalChangedRows.show(false);

		MongoSpark.write(incrementalChangedRows).option("collection", "test").mode("append").save();

		jsc.close();

	}

}
