package com.anthem.marketplace.dataconsolidation.utils;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.text.translate.CharSequenceTranslator;
import org.apache.commons.lang3.text.translate.LookupTranslator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class is responsible for cleaning the log data with Apache Commons lang
 */
public class LogCleaner {

	private static final Logger LOGGER = LoggerFactory.getLogger(LogCleaner.class);

	public static final CharSequenceTranslator ESCAPE_JAVA_SPL = new LookupTranslator(
			new String[][] { { "\b", "\\b" }, { "\n", "\\n" }, { "\t", "\\t" }, { "\f", "\\f" }, { "\r", "\\r" } });

	public static String cleanLog(String unCleanedLogText) {
		String encodedCleanedLogText = "";
		try {
			if (unCleanedLogText != null){
				String cleanedLogText = ESCAPE_JAVA_SPL.translate(unCleanedLogText);
				encodedCleanedLogText = StringEscapeUtils.escapeHtml4(cleanedLogText);
			}
		} catch (Exception ex) {
			LOGGER.error("Exception in cleanLog method !");
		}
		return encodedCleanedLogText;
	}	
}